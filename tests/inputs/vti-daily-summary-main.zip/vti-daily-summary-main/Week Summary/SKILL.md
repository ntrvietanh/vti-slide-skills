---
name: weekly-summary-monday-3am
description: Chạy mỗi Mon 03:00 GMT+7. Tổng hợp tuần trước (Mon-Sun) từ 8 nguồn (Daily Recap/Mail/Chat/Tracker/Memory/Calendar/Fireflies/Drive deep-read) thành .docx VTI-brand trên Drive `Weekly Summary/W{NN}-{YYYY}/` + Discord recap (webhook v2 riêng). Brief schema v2 = Summary + Operation + Customers + cross_week_diff. Deep research MANDATORY: 1 cluster planner OPUS + 5 deep sub-agent OPUS per dynamic cluster + Drive deep-read attachments + Calendar/Fireflies enrichment + cross-week context expansion.
---

# Weekly Summary — Cowork skill v3.1 (17/05/2026) — DEEP RESEARCH MANDATORY, OPUS EVERYWHERE

## Sourcing principles (Michael's chốt 17/05/2026)

1. **Recap-first**: Daily Recap (`week_context/daily_briefs.json`) là nguồn TRUNG TÂM. Sub-agent đọc recap đầu tiên, rồi từ recap mới expand sang mail thread / chat link / Drive URL / fireflies transcript liên quan. KHÔNG nhảy thẳng vào mail/chat.
2. **Cross-week expansion**: khi đầu việc trong tuần thiếu context (root email cũ, fireflies action_item từ meeting cũ, scope decided 2 tuần trước), agent PHẢI mở rộng search ra ngoài tuần. Window vẫn là tuần trước, chỉ data hỗ trợ là cross-week.
3. **Fireflies mandatory**: Calendar = lịch họp, Fireflies = nội dung họp. Pull 3 tuần (window + 2 tuần lookback) để cover follow-up.
4. **Opus everywhere**: orchestrator + cluster planner + 5 deep sub-agents → tất cả `model=opus`. Routing decision của planner ảnh hưởng kết quả cả pipeline; deep research cần reasoning sâu.
5. **No hardcode customer**: cluster planner đọc `_discovered_customers.json` (dynamic) + W-1 brief (carried RED). Mỗi tuần cluster có thể đổi theme — theo nội dung tuần, không theo template tuần trước.
6. **Agent write-back contract**: mỗi sub-agent PHẢI write JSON output file (path cố định trong `week_context/agent_outputs/`) qua bash heredoc + tự validate. Orchestrator chỉ đọc FILE, không tin return text. File thiếu/parse fail → re-dispatch agent đó.

Bạn là Weekly Summary Assistant cho Michael (`anh.nguyentruongviet@vti.com.vn`) tại VTI APAC.
Job chạy **03:00 GMT+7 mỗi thứ Hai**, tạo:
- 1 file `.docx` mới VTI-brand `Weekly Summary — DD-MM → DD-MM-YYYY.docx` trong Drive `Daily Meeting Prep / Weekly Summary / W{NN}-{YYYY} /`.
- 1 snapshot `Meeting_Memory_<ISO_WEEK>.md` trong `Weekly Summary / _snapshots /`.
- 1 snapshot `weekly_brief_v2_<ISO_WEEK>.json` trong `Weekly Summary / W{NN}-{YYYY} /`.
- 2-3 Discord posts BRIEF (header + RED items + optional cross-week) lên webhook riêng Weekly Summary.

## Format brief v2

**3 phần chính:**
1. **Summary** — KHÔNG giới hạn 5-8 bullet. Phải comprehensive — notes HẾT activities trong tuần, organized 6 categories:
   - `decisions_signoffs[]` — every concrete deliverable sent/approved
   - `meetings_touchpoints[]` — every meeting with attendees + outcome (theo ngày)
   - `new_opps_intros[]` — new introductions + new requirements surfaced
   - `issues_blockers_red[]` — RED items needing immediate attention (no emoji, use text)
   - `internal_operations[]` — EP/Bank/Hire/ISMS/etc status
   - `customers_activity_brief[]` — 1-line per customer (capture all 25-30 opps)
   Total ~50-80 bullets typical. Renderer auto-splits into H3 sub-sections.
2. **Operation** — đầu việc lớn nội bộ (Văn phòng / EP / Bank account / Hire / Legal / Internal policy / ISMS audits). Mỗi item: title + context + sub-tasks (Status / PIC / Việc sẽ làm / Deadline).
3. **Khách hàng** — mỗi opp: "Đã làm/trao đổi trong tuần", "Vấn đề hiện tại + giải pháp", sub-tasks.
4. **So với tuần trước** (cross_week_diff) — 4 bucket: updated / no_update / dropped (RED) / new.
5. Phụ lục ngắn: `deferred_or_noisy[]` + `stats_compact{}`.

**FORMAT RULES:**
- KHÔNG emoji/icon (doc + Discord).
- Priority `[RED]` / `[AMBER]` / `[GREEN]` text label.
- VTI brand docx (navy header + logo + bright blue accent + priority pills).

## Pipeline 12 bước v3 (deep-research mandatory)

### Bước 1 — Xác nhận môi trường

```bash
WORKDIR=$(find / -type d -name "Week Summary" 2>/dev/null | grep '/mnt/' | head -1)
[ -z "$WORKDIR" ] && { echo "FAIL: Week Summary not mounted"; exit 1; }
# Symlink Meeting Preparation nếu cần (cùng cấp)
if [ ! -d "/sessions/festive-quirky-lovelace/mnt/Meeting Preparation" ] && [ -d "/sessions/festive-quirky-lovelace/mnt/Projects/Meeting Preparation" ]; then
  ln -sfn "/sessions/festive-quirky-lovelace/mnt/Projects/Meeting Preparation" "/sessions/festive-quirky-lovelace/mnt/Meeting Preparation"
fi
# Deps + auth
pip install --user --break-system-packages -r "$WORKDIR/requirements.txt" 2>&1 | tail -3
cd "$WORKDIR" && python3 auth_setup.py --test 2>&1 | tail -3
```

### Bước 2 — Compute window

```bash
cd "$WORKDIR" && python3 week_prelude.py window
```

### Bước 3 — 4 deterministic crawlers

```bash
cd "$WORKDIR"
python3 week_prelude.py briefs   2>&1 | tail -10
python3 week_prelude.py tracker  2>&1 | tail -5
python3 week_prelude.py memory   2>&1 | tail -10
python3 week_prelude.py chat     2>&1 | tail -20    # SLOW: 3-5 phút
```

### Bước 4 — Gmail crawl (deep — FULL bodies)

Gmail search + pagination. Per thread top business → **gmail.get_thread(threadId=..., messageFormat=FULL_CONTENT)** để có full body (chứa Drive URLs, full quotes, attachments info). KHÔNG dùng MINIMAL.

Smart-filter skip auto/HR/system noise: `notification@vtiworkplace.com`, `no-reply@vti.com.vn`, `vms@vti.com.vn`, `marketing@vti.com.vn`, `vbs@vti.com.vn`, `announcement@vti.com.vn`, `vtitraining@vti.com.vn`, `teamzoom@e.zoom.us`, `no-reply@grab.com`, `no-reply@hack2skill`, `contact@napkin.ai`, `vinasa.org.vn`, `Sumsub`, `chat-noreply@google.com` digests, `swiftly.sg`.

Cap 100 threads top by recency × priority. Dump `week_context/mail_threads.json`. Schema include `full_body` field (str, ~5KB max) for top 25 threads.

### Bước 5 — Calendar + Fireflies enrichment (BẮT BUỘC — 2 nguồn meeting-truth)

**5a. Calendar (Google Calendar MCP)**

```bash
# Sử dụng mcp__google-calendar list_events qua Claude reasoning
# Query: startTime=<week_start_T00:00:00+07:00>, endTime=<week_end_plus_1_T00:00:00+07:00>, pageSize=100
```

Calendar bắt được **NEW intro meetings** mà mail/chat có thể bỏ sót (VD W19: Volkswagen Group-IT 5/5, AsiaPac Cora Cloud Migration 7/5). Dump `week_context/_calendar.json` (raw events) + extract attendees + descriptions để feed vào sub-agents.

**5b. Fireflies transcripts (MANDATORY — `mcp__fireflies__*`)**

Fireflies là **ground truth của meetings đã diễn ra** (Calendar chỉ có lịch, Fireflies có nội dung). Phải pull MEETING-LEVEL data cho TẤT CẢ transcript trong window + 14 ngày trước window (để các sub-agent có thể trace back follow-up từ meeting tuần trước, tuần trước nữa).

Pipeline:
1. `fireflies_get_transcripts` với date range = `[week_start - 14 days, week_end]` (tức là 3 tuần data, tuần đang recap + 2 tuần trước để cover follow-up context).
2. Per transcript trong WINDOW chính: `fireflies_get_transcript(transcript_id)` lấy summary + action_items + keywords + speakers. KHÔNG cần full transcript text (quá dài) — chỉ summary + action_items + 10-15 soundbites quan trọng.
3. Per transcript NGOÀI window (2 tuần trước): chỉ lấy metadata + summary headline + action_items — dùng cho cross-week reference.
4. Dump `week_context/_fireflies.json`:

```json
{
  "window": {"start": "...", "end": "...", "lookback_start": "..."},
  "in_window": [
    {
      "id": "...",
      "title": "...",
      "date": "YYYY-MM-DD",
      "organizer_email": "...",
      "participants": [{"name", "email"}],
      "duration_min": 45,
      "summary": "<2-3 paragraph summary>",
      "action_items": [{"assignee", "text", "due"}],
      "keywords": [...],
      "soundbites": [{"speaker", "time", "text"}],
      "drive_links_in_meeting": [...]   // any Drive URLs mentioned by speakers
    }
  ],
  "lookback_2w": [
    {"id", "title", "date", "summary_short", "action_items_open": [...]}
  ]
}
```

5. Fireflies action_items với `due` chưa đến window_end → **carry candidate** (sub-agents phải đối chiếu với weekly_activity của customer tương ứng để verify đã follow-up chưa).

Why mandatory: nhiều opportunity chỉ nói trên meeting, không xuất hiện trên mail/chat. Bỏ qua fireflies = mất context meeting → sub-agent sẽ kết luận sai trạng thái customer.

### Bước 6 — Compile chat_compact.json

```bash
python3 -c "
import json
d = json.load(open('$WORKDIR/week_context/chat_signals.json'))
out = {}
for k, v in d.get('by_space', {}).items():
    if int(v.get('msg_count', 0)) < 3: continue
    msgs = []
    for s in v.get('messages_sample', [])[:30]:
        if isinstance(s, dict):
            txt = (s.get('text') or s.get('message') or '').strip()
            if txt: msgs.append({'sender': s.get('sender', '?'), 'time': str(s.get('timestamp', ''))[:19], 'text': txt[:500]})
    out[v.get('space_name', k)] = {'msg_count': int(v['msg_count']), 'michael_msg_count': int(v.get('michael_msg_count', 0)), 'messages': msgs}
json.dump(out, open('$WORKDIR/week_context/chat_compact.json', 'w'), ensure_ascii=False, indent=1)
print(f'chat_compact.json: {len(out)} spaces')
"
```

### Bước 7 — Drive deep-read pass (MANDATORY — extract URLs từ mail/chat → fetch content)

```bash
cd "$WORKDIR"
# Scan mail+chat for Drive URLs (docs.google.com, drive.google.com)
python3 deep_read_drive.py extract-urls-from-context 2>&1 | tail -5
# Output: week_context/_drive_urls_from_context.json — list URLs per thread/space
```

Sau đó với mỗi URL/file_id quan trọng (filter by customer context): `python3 deep_read_drive.py read <file_id>` để fetch content (Gdoc/Docx/PDF/Xlsx/Slides → text). Lưu output vào `week_context/drive_content/<file_id>.txt` để sub-agents Read.

**Plus**: search Drive cho file liên quan customer trong window (NEW capability):
```bash
# Per major customer keyword
python3 deep_read_drive.py search "KGI" --after 2026-05-04 --before 2026-05-11
python3 deep_read_drive.py search "Ufinity" --after 2026-05-04 --before 2026-05-11
# ... etc cho từng customer
```

Save findings vào `week_context/drive_search_<customer>.json`. Sub-agents sẽ Read these để biết file W{NN} liên quan customer (BQ, proposals, briefs, recordings transcripts).

**Customer keyword cho Drive search KHÔNG hardcode** — lấy từ output Discovery (Bước 7.5) `known_active[].name` + `new_unknown[].name`.

### Bước 7.5 — Customer Discovery (MANDATORY — dynamic, NO hardcoded list)

```bash
cd "$WORKDIR" && python3 discover_customers.py 2>&1 | tail -10
```

`discover_customers.py` scan toàn bộ data đã crawl, extract distinct customer/topic mention được, cross-reference với `memory_baseline.md` (known clients) + W-1 brief snapshot (carried RED items). Output `week_context/_discovered_customers.json`:

```json
{
  "window": {...},
  "stats": {...},
  "known_active":   [{"name", "mention_count", "sources", "first_seen", "memory_match": true}, ...],
  "new_unknown":    [{"name", "mention_count", "sources", "first_seen"}, ...],
  "carried_red_from_prev_week": [{"name", "prev_priority", "prev_current_problem"}, ...],
  "dormant":        [{"name", "mentioned_this_week": false}, ...]
}
```

**Đây là nguồn duy nhất quyết định "customer của tuần này là ai".** Bước 8 sẽ KHÔNG hardcode list customer nữa — sẽ đọc file này.

### Bước 7.6 — Cluster Planner (MANDATORY — 1 sub-agent OPUS)

Dispatch 1 sub-agent `model=opus` (Michael yêu cầu mọi agent + orchestrator phải dùng opus best model; routing decision tuần này ảnh hưởng kết quả cả pipeline → KHÔNG được tiết kiệm bằng Sonnet) đọc:
- `week_context/_discovered_customers.json` (output Bước 7.5)
- `week_context/memory_baseline.md` (memory clients section)
- W-1 brief snapshot (carried context — load qua `compare_brief_v2.py` đã download sẵn)
- `week_context/_calendar_compact.json` (hot meeting để estimate workload)
- `week_context/_fireflies.json` (in_window.title + participants → cluster meeting density)
- `week_context/daily_briefs.json` (recap để hiểu chủ đề chính tuần này — nguồn TRUNG TÂM)

**Prompt template:**

```
Bạn là Cluster Planner cho Weekly Summary tuần {{week_label}}.
Đọc _discovered_customers.json + memory_baseline.md.

NHIỆM VỤ: phân tất cả customer trong (known_active + new_unknown + carried_red_from_prev_week)
thành 5 cluster BALANCED workload (mỗi cluster ~5-7 customer hoặc theo logic theme tự nhiên),
plus 1 nhóm operation_items riêng cho đầu việc nội bộ.

Tiêu chí phân cluster (theo PRIORITY ORDER):
1. THEME tự nhiên — gom customer cùng PIC/PM/Sales/PartnerSource (vd Anthony intros, AsiaPac umbrella,
   Ufinity sub-projects) — ưu tiên trên balanced workload.
2. CARRIED RED — mọi customer trong carried_red_from_prev_week PHẢI được assign vào 1 agent dù
   tuần này im (để agent verify trạng thái thay đổi gì so với tuần trước).
3. NEW_UNKNOWN — assign vào agent có theme gần nhất, nếu không fit nhóm nào → assign vào agent
   "wildcard" (default = agent có ít customer nhất). KHÔNG bỏ qua khách mới.
4. DORMANT — KHÔNG assign. Chỉ liệt kê trong cluster_assignment.dormant_skipped[] để brief đề cập 1 dòng.

Output JSON vào `week_context/_cluster_assignment.json`:

{
  "week_label": "...",
  "clusters": [
    {
      "id": "agent_a",
      "theme": "<auto-named, vd 'Ufinity umbrella + KGI'>",
      "rationale": "<1-2 câu giải thích tại sao gom thế này>",
      "customers": [{"name", "source": "known|new|carried_red", "priority_hint": "RED|AMBER|GREEN|?"}],
      "estimated_workload": "small|medium|large"
    },
    {"id": "agent_b", ...},
    {"id": "agent_c", ...},
    {"id": "agent_d", ...},
    {"id": "agent_e", ...}
  ],
  "operation_items": ["EP", "OCBC bank", "CorpZap", ...],  // separate from customer clusters
  "dormant_skipped": [...],
  "unassigned": []   // PHẢI = []. Nếu có entry → planner sai, re-prompt.
}

Hard rules:
- Tổng customer trong 5 cluster = |known_active| + |new_unknown| + |carried_red| - overlap.
- KHÔNG được drop customer nào (trừ dormant).
- Mỗi cluster ≤ 8 customer (nếu hot tuần đó vượt 8 → split).
```

Save output `week_context/_cluster_assignment.json`. Verify `unassigned == []`. Nếu không, re-prompt planner với feedback.

### Bước 8 — Deep-research sub-agents (MANDATORY — 5 parallel opus, DYNAMIC cluster)

Dispatch 5 sub-agent `model=opus` parallel trong **1 message**. Cluster CỦA MỖI AGENT đọc từ `_cluster_assignment.json` (KHÔNG hardcode). Cluster theme + rationale có thể đổi tuần qua tuần.

Cluster A-D: each handles customer cluster. Cluster E: vẫn dispatch nhưng cluster definition giờ là output planner agent_e (thường là wildcard + smallest themed group). **operation_items** vẫn assign cho agent C (vì C luôn cần xử lý PSA + MC + operation overhead — đây là rule consistent).

**SOURCING ORDER (BẮT BUỘC trong sub-agent prompt — recap-first):**

Mỗi sub-agent PHẢI source theo thứ tự sau, KHÔNG được nhảy thẳng vào mail/chat:

1. **Daily Recap đầu tiên** (`week_context/daily_briefs.json`) — recap là nguồn TRUNG TÂM, chứa kết luận đã chốt + Drive URL đã ghi nhận + tên người + tên opp. Đọc 7 file recap trong tuần, grep theo cluster customer keyword. Đây là "table of contents" cho deep research.
2. **Từ recap → pull mail thread liên quan** (`mail_threads.json`) — recap thường nhắc subject email; lấy full body + attachments info. Nếu thread root nằm NGOÀI window (vd email gốc gửi tuần W17, follow-up tuần W19) → vẫn fetch `gmail.get_thread` để có đầy đủ context.
3. **Từ recap → pull chat space tương ứng** (`chat_compact.json` hoặc `chat_signals.json`) — recap thường nhắc người (Joseph, Lara, Danny); grep space theo participant. Nếu chat link tới Drive / Doc → mở Drive file (qua `drive_content/` đã fetched).
4. **Từ recap → pull Drive attachments + links** (`_drive_urls_from_context.json` + `drive_content/<file_id>.txt`) — mọi Drive URL recap đề cập PHẢI được đọc text. BQ, proposal, signed contract đều ở đây.
5. **Fireflies meeting truth** (`_fireflies.json` → `in_window[]` và `lookback_2w[]`) — match meeting title / participants với customer cluster. Action_items từ fireflies = source-of-truth cho "Việc sẽ làm". Soundbites cụ thể = quote-able trong weekly_activity.
6. **Calendar attendee enrichment** (`_calendar.json`) — fill in attendee list nếu fireflies chưa cover.
7. **Tracker + Memory** (`tracker_snapshot.json` + `memory_baseline.md`) — verify long-running commitments + persona.

**CROSS-WEEK CONTEXT EXPANSION (BẮT BUỘC — không bị bó cứng trong window):**

Khi sub-agent thấy 1 đầu việc của customer trong tuần này nhưng KHÔNG đủ context (vd: mail thread chỉ có 1 message reply, fireflies action_item nói "follow-up Joseph re: BQ revision" nhưng không biết BQ là gì), agent PHẢI mở rộng search:

- **Mail**: tự call `gmail.search_threads(query="<customer keyword> from:<sender> -in:draft")` không có date filter — pull root thread cũ (có thể vài tuần trước).
- **Fireflies**: `_fireflies.json.lookback_2w[]` đã có sẵn metadata 2 tuần trước; nếu vẫn không đủ → tự call `fireflies_search(query="<customer name>")` để mở rộng thêm.
- **Drive**: nếu file referenced trong tuần có version cũ trên Drive, `deep_read_drive.py search "<customer>"` không cần `--after` (sẽ trả về toàn bộ file liên quan customer trên Drive).
- **Memory baseline**: grep section cũ của customer để hiểu lịch sử trước window.

Mục tiêu: weekly_activity + current_problem phải "stand-alone" — đọc xong hiểu cả lịch sử đầu việc, không bắt user phải mở 5 tab khác. Nếu data này ở tuần khác → vẫn lấy, vẫn nhắc trong weekly_activity với cụm "(context từ W{N-1}/W{N-2})" để Michael biết.

KHÔNG dùng cross-week expansion để báo cáo nhầm tuần. Window vẫn là tuần trước; chỉ dùng cross-week data để LÀM SẠCH context cho hoạt động xảy ra TRONG window.

Output files (cố định, để Bước 9 merge ổn định):
- `agent_a.json` (was `kgi_ufinity.json` — đổi tên general)
- `agent_b.json`
- `agent_c_customers.json` + `operation.json`
- `agent_d.json`
- `agent_e.json` (vẫn có `anthony_network` + `deferred_or_noisy` keys)

**Each sub-agent prompt MUST include:**
- **Cluster definition** — đọc `week_context/_cluster_assignment.json` → tìm entry `clusters[].id == agent_<x>` → list `customers[]` chính là customer của agent. KHÔNG hardcode trong prompt — paste content vào.
- **Coverage commitment** — "MUST produce 1 entry per customer in cluster.customers[], kể cả customer in `source=carried_red` mà tuần này im (chỉ note 'no activity W{NN} — last RED problem was: ...')."
- **Sourcing order** — copy phần "SOURCING ORDER" trên vào prompt agent, KHÔNG bỏ qua thứ tự recap-first.
- **Cross-week expansion** — copy phần "CROSS-WEEK CONTEXT EXPANSION" vào prompt agent.
- Pointer to `daily_briefs.json` — **first stop**, đọc 7 recap rồi mới grep nguồn khác.
- Pointer to memory_baseline.md sections relevant (use grep cho từng tên trong cluster)
- Pointer to mail_threads.json (with full bodies) + permission to call `gmail.get_thread` / `gmail.search_threads` thêm cho thread cũ ngoài window.
- Pointer to chat_compact.json (or full chat_signals.json) — read all messages per relevant space
- Pointer to _calendar.json (filter events for cluster's customers)
- Pointer to `_fireflies.json` (in_window + lookback_2w) + permission to call `fireflies_search` / `fireflies_get_transcript` cho meeting cụ thể.
- Pointer to _drive_urls_from_context.json + drive_content/ (read fetched file contents) + permission to call `deep_read_drive.py read <id>` hoặc `search <kw>` thêm.
- Pointer to drive_search_<customer>.json (Drive-discovered files — chỉ những customer có file)
- Pointer to tracker_snapshot.json (filter carry by customer's keyword)
- **Write-back contract** — agent PHẢI write output JSON file (đường dẫn cố định bên dưới) qua bash heredoc + tự validate `python3 -c "import json; json.load(open(...))"`. Orchestrator chỉ đọc FILE, không phụ thuộc agent's return text. Nếu file thiếu / parse fail → orchestrator re-dispatch agent đó.
- Use model=opus (passed via Agent tool's `model: "opus"` parameter)

**SCHEMA RULES — MUST follow exactly (renderer crashes otherwise):**

Customer entries (customers/active_opps/asiapac/etc.):
```json
{
  "customer": "<full opp name>",       // KEY = "customer" (NOT "name")
  "priority": "RED|AMBER|GREEN",
  "weekly_activity": "<4-6 sentences>",
  "current_problem": "<3-5 sentences>",
  "tasks": [
    {                                   // tasks[] MUST be array of OBJECTS, never strings
      "title": "<short task name>",     // mandatory key
      "status": "in_progress|done|pending|blocked",
      "pic": "Full Name (Alias)",
      "next_action": "<what will be done next>",
      "deadline": "DD/MM/YYYY hoặc text",
      "priority": "RED|AMBER|GREEN"
    }
  ]
}
```

Operation items (operation.json):
```json
{
  "item": "<full operation title>",    // KEY = "item" (NOT "title")
  "priority": "RED|AMBER|GREEN",
  "context": "<background paragraph>",
  "tasks": [ { ...same dict shape as above... } ]
}
```

**HARD RULES — NEVER violate:**
- Tasks MUST be `[ {title, status, pic, next_action, deadline, priority}, ... ]` — NEVER plain strings. If you only have a short task line, wrap it: `{"title": "<the line>", "status":"pending", "pic":"", "next_action":"", "deadline":"", "priority":""}`.
- Customer object key MUST be `"customer"`. Operation object key MUST be `"item"`. Renderer reads exactly these.
- NO emoji in any string value (use text labels `RED`/`AMBER`/`GREEN`).

**Each agent expected to:**
- Read memory_baseline section deep
- Grep all data sources for customer keyword
- Build customer entries with rich `weekly_activity` (4-6 câu CỤ THỂ: tên người, ngày, topic, outcome) and `current_problem` (3-5 câu detail)
- Capture ALL relevant tracker actions per customer (don't drop any)
- Use full names (PIC = "Hung Nguyen Duc (David)" not "Hung")
- Specific deadlines (DD/MM/YYYY hoặc text "Tuần 18-22/05")
- Priority RED/AMBER/GREEN per task
- If Drive file fetched chứa relevant data (BQ values, signed contracts, scope changes) → reference in weekly_activity / current_problem

### Bước 9 — Merge sub-agent outputs + normalize + build summary_categorized

```bash
cd "$WORKDIR"
python3 << 'PYEOF_MERGE'
import json
from pathlib import Path
ctx = Path('week_context')
out = ctx / 'agent_outputs'

# Load all agent outputs (file names FIXED per Bước 8 — cluster content variable)
a = json.load(open(out / 'agent_a.json'))
b = json.load(open(out / 'agent_b.json'))
c_cust = json.load(open(out / 'agent_c_customers.json'))
d = json.load(open(out / 'agent_d.json'))
e = json.load(open(out / 'agent_e.json'))
op = json.load(open(out / 'operation.json'))

customers = []
for src in (a, b, c_cust, d):
    customers.extend(src if isinstance(src, list) else [])
e_list = e.get('anthony_network', e) if isinstance(e, dict) else e
customers.extend([x for x in e_list if isinstance(x, dict)])
deferred = e.get('deferred_or_noisy', []) if isinstance(e, dict) else []

# COVERAGE CHECK — verify mọi customer trong discovered file đều có entry
try:
    disc = json.load(open(ctx / '_discovered_customers.json'))
    expected = set()
    for k in ('known_active', 'new_unknown', 'carried_red_from_prev_week'):
        for c in disc.get(k, []):
            expected.add(_slug := c['name'].lower().strip())
    found = {(c.get('customer') or c.get('name') or '').lower().strip() for c in customers}
    missing = [n for n in expected if not any(n in f or f in n for f in found if len(f)>3)]
    if missing:
        print(f"WARNING: {len(missing)} customer in discovery missing from agent outputs: {missing[:10]}")
    else:
        print(f"Coverage OK: all {len(expected)} discovered customers covered")
except FileNotFoundError:
    print("WARNING: _discovered_customers.json not found — skip coverage check (run Bước 7.5 first)")

# --- NORMALIZE (defensive — sub-agents occasionally return tasks as strings) ---
def _norm_tasks(holder):
    for i, t in enumerate(holder.get('tasks', []) or []):
        if isinstance(t, str):
            holder['tasks'][i] = {'title': t, 'status': 'pending', 'pic': '',
                                  'next_action': '', 'deadline': '', 'priority': ''}
for c in customers: _norm_tasks(c)
for o in op: _norm_tasks(o)

# --- BUILD summary_categorized (6 sub-sections) ---
import json as _json
cal = _json.load(open(ctx / '_calendar_compact.json'))
day_map = {'2026-05-04':'Mon','2026-05-05':'Tue','2026-05-06':'Wed','2026-05-07':'Thu','2026-05-08':'Fri','2026-05-09':'Sat','2026-05-10':'Sun'}
skip_meeting_pat = ['BOM WEEKLY','Weekly Operation','BD Weekly','VTI Global] Weekly','DG Operation meeting','VAP] Weekly Meeting']

decisions, meetings, new_opps, red, ops_summary, cust_brief = [], [], [], [], [], []
for e in cal:
    title = (e.get('summary') or '')[:80]
    d = (e.get('start') or '')[:10]
    if not d or any(p in title for p in skip_meeting_pat): continue
    meetings.append(f"{day_map.get(d,d)} {d[-5:].replace('-','/')}: {title}")

for c in customers:
    name = c.get('customer','?'); prio = (c.get('priority') or '').upper()
    wa = (c.get('weekly_activity') or '')[:200]; cp = (c.get('current_problem') or '')[:200]
    cust_brief.append(f"{name} [{prio}]: {wa[:140]}")
    if prio == 'RED' or '[RED]' in (wa+cp).upper():
        red.append(f"{name}: {cp[:160] or wa[:160]}")
    if any(k in name for k in ['New','intro','Introduction','NEW']) or 'intro' in wa.lower()[:60]:
        new_opps.append(f"{name}: {wa[:140]}")
    if any(kw in (wa+cp).lower() for kw in ['sign-off','signed off','submitted','sent','delivered','approved','invoice','quote','quotation','proposal','closed','nda','contract']):
        decisions.append(f"{name}: {wa[:160]}")

for o in op:
    item = o.get('item','?'); prio = (o.get('priority') or '').upper()
    ctx_short = (o.get('context') or '')[:150]
    ops_summary.append(f"{item} [{prio}]: {ctx_short}")
    if prio == 'RED': red.append(f"OP {item}: {ctx_short}")

summary_categorized = {
    'decisions_signoffs': decisions[:30],
    'meetings_touchpoints': meetings[:30],
    'new_opps_intros': new_opps[:15],
    'issues_blockers_red': red[:25],
    'internal_operations': ops_summary[:15],
    'customers_activity_brief': cust_brief[:35],
}

# --- STATS (include BOTH key naming conventions for downstream compat) ---
chat = _json.load(open(ctx / 'chat_compact.json'))
mail = _json.load(open(ctx / 'mail_threads.json'))
tracker = _json.load(open(ctx / 'tracker_snapshot.json'))
tot_tasks = sum(len(c.get('tasks',[])) for c in customers) + sum(len(o.get('tasks',[])) for o in op)
red_n = len([c for c in customers if (c.get('priority') or '').upper()=='RED']) + len([o for o in op if (o.get('priority') or '').upper()=='RED'])
stats = {
    'mail_threads_analyzed': len(mail.get('threads',[])),
    'mail_threads_reviewed': len(mail.get('threads',[])),       # alias for Discord script
    'chat_spaces_active': len(chat),
    'chat_messages_total': sum(int(v.get('msg_count',0)) for v in chat.values()),
    'calendar_events_week': len(cal),
    'tracker_open_actions': tracker.get('stats',{}).get('all_open', 0) if isinstance(tracker,dict) else 0,
    'tracker_carry_open': tracker.get('stats',{}).get('all_open', 0) if isinstance(tracker,dict) else 0,  # alias
    'customers_total': len(customers),
    'operation_items': len(op),
    'tasks_total': tot_tasks,
    'red_items': red_n,
    'deferred_items': len(deferred),
}

window = _json.load(open(ctx / '_window.json'))
brief = {
    "meta": {
        "run_date": window["run_date"],
        "week_label": window["week_label"],
        "iso_week": window["iso_week"],
        "format": "v2-deep-research",
        "deep_research_agents": 5,
        "model": "opus"
    },
    # NOTE: renderer + Discord both read "summary_categorized" — don't use bare "summary"
    "summary_categorized": summary_categorized,
    "summary": summary_categorized,  # alias for any older consumers
    "operation": op,
    "customers": customers,
    "deferred_or_noisy": deferred,
    "stats_compact": stats,
}
json.dump(brief, open(ctx / 'weekly_brief_v2.json','w'), ensure_ascii=False, indent=1)
print(f"Brief: {len(customers)} customers, {len(op)} ops, {tot_tasks} tasks, {red_n} RED")
PYEOF_MERGE
```

**Critical**: Summary is now built CATEGORIZED (6 buckets) not as a flat 5-8 bullet list. Renderer expects `summary_categorized` dict, Discord script reads the same. If you skip this, doc will fall back to dict-key iteration and print `decisions_signoffs / meetings_touchpoints / ...` as raw labels.

### Bước 10 — Cross-week diff với W-1 snapshot

```bash
cd "$WORKDIR" && python3 compare_brief_v2.py 2>&1 | tail -5
```

Script tự download `weekly_brief_v2_<ISO_W-1>.json` từ Drive `Weekly Summary/W{prev}-{prev_YYYY}/`, fuzzy-match SequenceMatcher (threshold 0.65 task, 0.55 item/customer), emit `cross_week_diff` block 4 bucket.

### Bước 11 — Render VTI-brand docx v5 + upload (TỰ tạo W{NN}-{YYYY})

**Renderer v5 improvements (Michael feedback 17/05/2026):**
- Comprehensive summary với 6 H3 sub-sections (decisions/meetings/new_opps/blockers_red/ops/customers).
- Auto-split long `weekly_activity` + `current_problem` + `operation.context` thành multiple paragraphs at sentence boundaries (~220 chars target).
- Auto-detect numbered lists `(1)`, `(2)`, `(3)`... trong text → render thành bulleted list cho readability.
- Spacer paragraph giữa customer entries cho breathing room.
- **LOGO_PATH dynamic**: renderer auto-detects logo via `glob("/sessions/*/mnt/.claude/skills/vti-brief-doc/assets/logo-horizontal-white.png")` — session IDs change each run, so DO NOT hardcode.
- **Reads keys per SKILL schema**: `customer.customer` (not `name`), `operation.item` (not `title`), `summary_categorized` (not flat `summary`). Renderer has fallbacks for backward-compat, but Step 9 must emit new keys.

```bash
cd "$WORKDIR" && python3 render_weekly_docx_v5.py render-and-upload 2>&1 | tail -5
```

VTI brand: navy header (#051934) + logo embedded (`logo-horizontal-white.png` 3cm) + bright blue (#0468E6) accent rule + section labels uppercase blue + ▸ item titles navy + task cards bordered table với priority pill (RED #b02020 bg #fff0f0, AMBER #b05a00 bg #fff4e6, GREEN #1a7a4a bg #e6f4ed) + field-list (Status/PIC/Việc sẽ làm/Deadline).

### Bước 12 — Snapshot Memory + Brief + Discord recap

```bash
cd "$WORKDIR"
python3 snapshot_memory.py save 2>&1 | tail -3       # vào _snapshots/
python3 snapshot_brief_v2.py 2>&1 | tail -3          # vào W{NN}-{YYYY}/
python3 send_discord_weekly_v3_brief.py dry-run 2>&1 | tail -5     # verify char limits
python3 send_discord_weekly_v3_brief.py build-and-send 2>&1 | tail -40
```

Discord ~33 posts (1 header + 8 operation + 23 customers + 1 cross-week). Mỗi post < 1900 chars. Rate-limit 1.2s. Webhook hardcoded `send_discord_weekly_v3_brief.py:DEFAULT_WEBHOOK` (riêng Weekly Summary, KHÔNG dùng chung Meeting Prep).

### Bước 13 — Báo cáo console (≤250 từ)

Doc link · Brief snapshot id · Memory snapshot id · Discord N posts ok/fail · cross_week_diff counts · stats · elapsed.

## Quy ước chung

- **Email**: `anh.nguyentruongviet@vti.com.vn`
- **Timezone**: GMT+7 (Asia/Ho_Chi_Minh)
- **Window**: Mon 00:00 → Sun 23:59 của tuần TRƯỚC
- **Drive parent**: `Daily Meeting Prep / Weekly Summary /` (cached `_state.json: weekly_folder_id`)
- **Per-week subfolder**: `W{NN}-{YYYY}` (vd `W19-2026`)
- **Memory snapshots**: vẫn vào `Weekly Summary / _snapshots /`
- **Drive folder nguồn**: `Daily Meeting Prep /`, `Google Chat Crawl /`
- **OAuth scope**: full `https://www.googleapis.com/auth/drive` cho phép đọc shared-with-me files
- **Discord webhook**: RIÊNG Weekly Summary, hardcoded trong `send_discord_weekly_v3_brief.py`
- **Doc format**: `.docx` native (KHÔNG convert Google Doc)
- **Logo VTI**: `/sessions/.../mnt/.claude/skills/vti-brief-doc/assets/logo-horizontal-white.png`

## Anti-patterns v3 (FAIL hoặc undo deep research)

- ❌ Dùng `render_weekly_docx.py` / `render_weekly_docx_v3.py` cũ — phải dùng `render_weekly_docx_v5.py` (VTI brand).
- ❌ Dùng `send_discord_weekly.py` cũ — phải dùng `send_discord_weekly_v3_brief.py`.
- ❌ Build brief inline KHÔNG dispatch sub-agents — deep research là MANDATORY, không optional.
- ❌ Skip Calendar enrichment (Bước 5a) — sẽ miss NEW intro meetings.
- ❌ Skip Fireflies pull (Bước 5b) — sẽ miss ground-truth meeting content + action_items mà chỉ nói trên call, không xuất hiện trên mail/chat.
- ❌ Fireflies pull chỉ trong window (Mon-Sun) — phải pull thêm 2 tuần trước (lookback_2w) để sub-agent trace follow-up từ meeting cũ.
- ❌ Skip Drive deep-read pass (Bước 7) — sẽ miss attachments + Drive-shared docs trong chat/mail.
- ❌ Dùng `gmail.get_thread` với MINIMAL — phải FULL_CONTENT để có body + URLs.
- ❌ Build brief theo schema v1 (by_client, mail_intel.top_threads_detail, memory_diff, risk_register, ai_log, next_week_focus).
- ❌ Dùng emoji 🔴/🟡/🟢 trong doc/Discord — text label `[RED]`/`[AMBER]`/`[GREEN]` only.
- ❌ Upload doc vào root `Weekly Summary/` — phải vào `W{NN}-{YYYY}/`.
- ❌ Skip snapshot Memory / snapshot brief — tuần sau sẽ không có baseline.
- ❌ Sub-agents dùng model mặc định (Sonnet/Haiku) — PHẢI dùng `model="opus"` cho deep reasoning.
- ❌ Sub-agents bỏ qua memory_baseline.md — phải đọc per-account section deep.

- ❌ Summary chỉ 5-8 bullets — phải comprehensive 6-category format (~50-80 bullets) capturing ALL W19 activities.
- ❌ Discord spam customer details (33+ posts) — Discord chỉ BRIEF (2-3 posts: header + RED items). User đọc full doc.
- ❌ Renderer dùng v3/v4 cũ — phải `render_weekly_docx_v5.py` (split long paragraphs + bullet numbered lists).
- ❌ Discord dùng v2 (33 posts) — phải `send_discord_weekly_v3_brief.py` (2-3 brief posts).
- ❌ Sub-agents trả về `tasks: ["string1", "string2"]` — phải dict array `[{title,status,pic,next_action,deadline,priority}]`. Renderer crash `'str' object has no attribute 'get'`.
- ❌ Sub-agents output key `"name"` cho customer hoặc `"title"` cho operation — schema spec là `"customer"` và `"item"`. Sai key → header doc hiển thị `▸ ?`.
- ❌ Bước 9 emit brief với key `"summary"` (list rỗng hoặc flat bullets) — phải `"summary_categorized"` (dict 6 buckets). Sai key → doc render "1. decisions_signoffs / 2. meetings_touchpoints / ..." (raw label thay vì content).
- ❌ Hardcode `LOGO_PATH` với session ID cố định — sessions đổi mỗi run. Phải dùng `glob("/sessions/*/mnt/.claude/skills/vti-brief-doc/assets/...")`. (Renderer v5 đã fix sẵn.)
- ❌ **HARDCODE cluster customer trong Bước 8** — cluster phải dynamic, đọc từ `_cluster_assignment.json` (Bước 7.6). Hardcode sẽ miss khách mới + tốn token cho khách im lặng.
- ❌ Skip Bước 7.5 Discovery — sẽ không biết khách mới của tuần. Tuần sau sẽ chỉ thấy customer trong portfolio cũ.
- ❌ Skip Bước 7.6 Cluster Planner — main agent tự chia cluster sẽ bias theo cluster tuần trước. Planner agent OPUS làm decision dựa fact, không bias.
- ❌ Cluster planner dùng Sonnet/Haiku — Michael yêu cầu agent + orchestrator phải dùng opus best model. Planner cũng là agent → opus.
- ❌ Sub-agent recap fallback "không có recap → skip recap source" — recap LUÔN là first stop. Nếu recap empty cho 1 ngày, vẫn read các ngày khác trong daily_briefs.json + nói rõ trong weekly_activity "no recap doc for {date}".
- ❌ Sub-agent hardcode customer keyword trong prompt — agent đọc cluster định nghĩa từ `_cluster_assignment.json` rồi tự grep. Mọi keyword đều dynamic theo tuần.
- ❌ Sub-agent đóng khung context chỉ trong window — phải mở rộng cross-week (mail thread root cũ, fireflies lookback_2w, drive file cũ) khi data trong window không đủ.
- ❌ Orchestrator parse return text của sub-agent — agent PHẢI write file, orchestrator chỉ đọc file. Nếu file thiếu → re-dispatch.
- ❌ Cluster planner emit `unassigned != []` — fail loop: re-prompt planner. KHÔNG dispatch sub-agent với unassigned vì sẽ drop khách.
- ❌ Window crawl lấy nhầm tuần — verify `_window.json` `week_start` PHẢI là Monday tuần TRƯỚC (run Mon 18/05 → week_start 11/05; run lệch lịch như Sun thì vẫn ra tuần trước nữa, KHÔNG lấy tuần đang chạy). Logic `weekly_lib.compute_window` đã đúng — không sửa.

## Gotcha: bindfs cache cho file Python

Khi sửa file >20KB → dùng bash heredoc thay vì Write tool:
```bash
cat > deep_read_drive.py << 'PYEOF'
...
PYEOF
python3 -c "import ast; ast.parse(open('deep_read_drive.py').read()); print('OK')"
```

## Debug

- Brief sai → edit `weekly_brief_v2.json` rồi `python3 send_discord_weekly_v3_brief.py dry-run`.
- Render lỗi → check `outputs/weekly_doc_v5.docx` syntax với LibreOffice.
- Cross-week diff fail → check Drive `W{prev}-{prev_YYYY}/` permissions.
- Sub-agent fail → check `agent_outputs/*.json` syntax; có thể re-run cá nhân agent.
- Drive deep-read 404 → file đã xoá / không có quyền (OK, skip; ghi log).
- Discord timeout (33 posts ~45s) → run resumable: detect last sent label từ run.log, resume từ index +1.
- Daily Recap docs không tồn tại → daily recap system chưa bắt đầu tuần W{N} (vd W19 — confirmed empty trên Drive); pipeline vẫn tiếp tục với 7 nguồn còn lại nhưng ghi note "recap-first fallback: missing for W{NN}" để sub-agent biết tự lift fireflies/mail làm "table of contents" thay recap.
- Fireflies MCP không trả về transcript → check rate limit hoặc token. Fallback: pull metadata-only (title + date + participants) cho window + lookback, skip soundbites.

## Files trong `Week Summary/` (v3 pipeline — ACTIVE)

```
Week Summary/
├── SKILL.md                          # File này (v3)
├── SKILL.md.v1.bak / .v2.bak         # Backups
├── PLAN.md                           # Reference plan
├── requirements.txt                  # python-docx, google-auth, openpyxl, beautifulsoup4, +pypdf khuyến nghị
├── auth_setup.py                     # OAuth setup
├── weekly_lib.py                     # Shared helpers (Drive, OAuth, week window)
├── week_prelude.py                   # Crawler dispatcher
├── crawl_briefs.py                   # Daily briefs crawler
├── crawl_tracker.py                  # Action_Tracker.xlsx download + slice
├── crawl_memory.py                   # Meeting_Memory.md baseline + diff
├── crawl_chat.py                     # Google Chat aggregate (slow)
├── deep_read_drive.py                # NEW v3 ACTIVE — Drive URL extract + content fetch (Gdoc/Docx/PDF/Xlsx) + search
├── render_weekly_docx_v5.py          # ACTIVE — VTI brand docx + comprehensive summary + split long paragraphs + bullet numbered lists
├── render_weekly_docx_v4.py          # DEPRECATED (pre-formatting-improvements; kept for diff)
├── snapshot_memory.py                # Meeting_Memory_<ISO>.md → _snapshots/
├── snapshot_brief_v2.py              # weekly_brief_v2_<ISO>.json → W{NN}-{YYYY}/
├── compare_brief_v2.py               # cross-week diff với W-1 snapshot
├── send_discord_weekly_v3_brief.py         # ACTIVE — 33-post format → webhook riêng
├── render_weekly_docx_v3.py          # DEPRECATED pre-VTI-brand (kept for diff)
├── render_weekly_docx.py             # DEPRECATED v1 (icons, by_client)
├── send_discord_weekly.py            # DEPRECATED v1 (Meeting Prep webhook)
├── _state.json                       # Cache folder IDs + last run version
├── week_context/                     # Per-run dumps
│   ├── _window.json
│   ├── _calendar.json                # NEW v3 — Calendar events for window
│   ├── _fireflies.json               # NEW v3.1 — Fireflies transcripts (in_window + lookback_2w)
│   ├── _drive_urls_from_context.json # NEW v3 — URLs extracted from mail/chat
│   ├── drive_content/<file_id>.txt   # NEW v3 — fetched Drive file content
│   ├── drive_search_<customer>.json  # NEW v3 — Drive search results per customer
│   ├── mail_threads.json             # with full_body for top 25
│   ├── chat_signals.json             # full chat dump (large)
│   ├── chat_compact.json             # compact per-space msgs (for sub-agents)
│   ├── daily_briefs.json
│   ├── tracker_snapshot.json
│   ├── memory_baseline.md            # current Meeting_Memory.md
│   ├── memory_snapshot_prev.md       # W-1 memory snapshot
│   ├── memory_changes.md             # changelog filter
│   ├── memory_diff_input.json
│   ├── weekly_brief_v2.json          # ACTIVE brief
│   ├── weekly_brief_v2_prev.md       # cached W-1 download (debug)
│   └── agent_outputs/                # NEW v3 — sub-agent outputs
│       ├── kgi_ufinity.json
│       ├── asiapac.json
│       ├── mc_psa.json
│       ├── operation.json
│       ├── active_opps.json
│       └── anthony_network.json
└── outputs/
    ├── weekly_doc_v5.docx            # ACTIVE v4 VTI-brand render
    └── discord_posts_v2.json
```
