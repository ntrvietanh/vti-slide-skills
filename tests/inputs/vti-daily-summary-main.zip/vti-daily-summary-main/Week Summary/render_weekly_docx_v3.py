#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_weekly_docx_v3.py — Render weekly_brief_v2.json (clean format, no icons).

Sections:
  1. Cover (Week label + ISO)
  2. Summary (bullet)
  3. Operation (nested: item → context → tasks as field-list)
  4. Khách hàng (per opp: weekly_activity → current_problem → tasks)
  5. So với tuần trước (cross_week_diff) — RED if dropped/no-update items
  6. Phụ lục (deferred + stats)

Design rules:
  - NO emoji / icons. Plain text labels only.
  - Status badges: [RED], [AMBER], [GREEN] in brackets, optional bold red color for RED.
  - Tasks rendered as borderless 2-column field-list (label cell bold, value cell normal).
  - Hierarchy: H1 (section) > H2 (item/opp) > Task (bold) > Field-list.
"""

from __future__ import annotations
import json, sys
from pathlib import Path
from weekly_lib import (
    load_json, get_drive, load_credentials,
    load_state, save_state, log, ensure_folder,
    PROJECT_DIR, OUTPUTS_DIR, CONTEXT_DIR,
)


def week_folder_name(iso_week: str) -> str:
    """Convert ISO week '2026-W19' -> folder name 'W19-2026'."""
    if not iso_week:
        return "Wxx-yyyy"
    s = iso_week.strip()
    if "-W" in s:
        year, w = s.split("-W", 1)
        return f"W{w}-{year}"
    return s

BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2.json"
DOCX_PATH = OUTPUTS_DIR / "weekly_doc_v3.docx"
WINDOW_PATH = CONTEXT_DIR / "_window.json"


def docx_filename(win, version=1):
    ws = win["week_start"][8:10] + "-" + win["week_start"][5:7]
    we = win["week_end"][8:10] + "-" + win["week_end"][5:7] + "-" + win["week_end"][0:4]
    base = f"Weekly Summary — {ws} → {we}"
    if version > 1:
        return f"{base} (v{version}).docx"
    return f"{base}.docx"


def get_weekly_folder_id(drive):
    state = load_state()
    fid = state.get("weekly_folder_id")
    if not fid:
        log("ERROR: weekly_folder_id missing in _state.json")
        sys.exit(2)
    return fid


# --------------------------- style helpers ---------------------------------
NAVY = (0x05, 0x19, 0x34)
BLUE_2 = (0x1F, 0x3A, 0x68)
GRAY_3 = (0x55, 0x55, 0x55)
RED = (0xC0, 0x39, 0x2B)
AMBER = (0xB9, 0x77, 0x0B)
GREEN = (0x1E, 0x7E, 0x34)


def _set_doc_style(doc):
    from docx.shared import Pt
    from docx.oxml.ns import qn
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(11)
    # set asian font fallback
    rpr = style.element.get_or_add_rPr()
    rFonts = rpr.find(qn('w:rFonts'))
    if rFonts is None:
        from docx.oxml import OxmlElement
        rFonts = OxmlElement('w:rFonts')
        rpr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), 'Calibri')


def _h1(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(18)
    r.font.color.rgb = RGBColor(*NAVY)


def _h2(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(13)
    r.font.color.rgb = RGBColor(*BLUE_2)


def _h3(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(11)
    r.font.color.rgb = RGBColor(*GRAY_3)


def _para(doc, text, italic=False, bold=False, color=None, size=None):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text)
    r.italic = italic
    r.bold = bold
    if color:
        r.font.color.rgb = RGBColor(*color)
    if size:
        r.font.size = Pt(size)
    return p


def _bullet(doc, text):
    try:
        doc.add_paragraph(text, style="List Bullet")
    except KeyError:
        doc.add_paragraph("• " + text)


def _priority_color(p):
    p = (p or "").upper()
    return {"RED": RED, "AMBER": AMBER, "GREEN": GREEN}.get(p)


def _priority_label(p):
    p = (p or "").upper()
    if p in ("RED", "AMBER", "GREEN"):
        return f"[{p}]"
    return ""


def _remove_table_borders(table):
    """Make all borders invisible (cleaner look)."""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    tbl = table._tbl
    tblPr = tbl.tblPr
    tblBorders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        border = OxmlElement(f'w:{edge}')
        border.set(qn('w:val'), 'nil')
        tblBorders.append(border)
    tblPr.append(tblBorders)


def _task_block(doc, task):
    """Render one task: title line + indented field-list."""
    from docx.shared import Pt, RGBColor, Cm, Inches

    # Title line: bold title, optional [RED]/[AMBER]/[GREEN] prefix
    title = task.get("title", "Untitled task")
    pri = task.get("priority", "")
    pri_label = _priority_label(pri)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.left_indent = Cm(0.3)
    if pri_label:
        color = _priority_color(pri)
        rp = p.add_run(pri_label + " ")
        rp.bold = True
        if color:
            rp.font.color.rgb = RGBColor(*color)
    rt = p.add_run(title)
    rt.bold = True

    # Field-list as borderless table (2 cols)
    rows = []
    if task.get("status"):
        rows.append(("Status", task["status"]))
    if task.get("pic"):
        rows.append(("PIC", task["pic"]))
    if task.get("next_action"):
        rows.append(("Việc sẽ làm", task["next_action"]))
    if task.get("deadline"):
        rows.append(("Deadline", task["deadline"]))
    if not rows:
        return

    table = doc.add_table(rows=len(rows), cols=2)
    table.autofit = False
    _remove_table_borders(table)
    # Set column widths
    for row in table.rows:
        row.cells[0].width = Cm(3.4)
        row.cells[1].width = Cm(14.0)
    for (lbl, val), row in zip(rows, table.rows):
        c1 = row.cells[0]
        c2 = row.cells[1]
        p1 = c1.paragraphs[0]
        p1.paragraph_format.left_indent = Cm(0.8)
        p1.paragraph_format.space_after = Pt(0)
        r1 = p1.add_run(lbl)
        r1.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = RGBColor(*GRAY_3)
        p2 = c2.paragraphs[0]
        p2.paragraph_format.space_after = Pt(0)
        r2 = p2.add_run(val)
        r2.font.size = Pt(10)


def render_cover(doc, brief):
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    meta = brief.get("meta", {})

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("WEEKLY SUMMARY")
    r.bold = True
    r.font.size = Pt(26)
    r.font.color.rgb = RGBColor(*NAVY)

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run(meta.get("week_label", ""))
    r2.font.size = Pt(15)
    r2.italic = True

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r3 = p3.add_run(f"ISO {meta.get('iso_week','')} · Run {meta.get('run_date','')}")
    r3.font.size = Pt(10)
    doc.add_paragraph()


def render_summary(doc, brief):
    _h1(doc, "Summary")
    for item in brief.get("summary", []):
        _bullet(doc, item)
    doc.add_paragraph()


def render_operation(doc, brief):
    _h1(doc, "Operation (vận hành nội bộ)")
    items = brief.get("operation", [])
    if not items:
        _para(doc, "(không có item)", italic=True)
        return
    for it in items:
        _h2(doc, it.get("title", "?"))
        if it.get("context"):
            _para(doc, it["context"], italic=True)
        for t in it.get("tasks", []):
            _task_block(doc, t)


def render_customers(doc, brief):
    _h1(doc, "Khách hàng / Opportunity")
    items = brief.get("customers", [])
    if not items:
        _para(doc, "(không có opp)", italic=True)
        return
    for c in items:
        _h2(doc, c.get("name", "?"))
        if c.get("weekly_activity"):
            _h3(doc, "Đã làm / trao đổi trong tuần")
            _para(doc, c["weekly_activity"])
        if c.get("current_problem"):
            _h3(doc, "Vấn đề hiện tại / Giải pháp")
            _para(doc, c["current_problem"])
        tasks = c.get("tasks", [])
        if tasks:
            _h3(doc, "Tasks")
            for t in tasks:
                _task_block(doc, t)
        else:
            _para(doc, "(không có task tuần này)", italic=True)


def render_cross_week_diff(doc, brief):
    cwd = brief.get("cross_week_diff")
    if not cwd:
        return
    _h1(doc, "So với tuần trước (W-1 baseline)")
    if not cwd.get("baseline_available"):
        _para(doc, cwd.get("note", "(baseline tuần trước chưa có)"), italic=True)
        return

    sc = cwd.get("summary_counts", {})
    base_iso = cwd.get("baseline_iso_week", "?")
    curr_iso = cwd.get("current_iso_week", "?")
    _para(doc, f"Baseline: {base_iso} → Current: {curr_iso}", italic=True)
    _para(doc, (
        f"Operation — updated {sc.get('op_updated_tasks',0)} · no-update {sc.get('op_no_update_tasks',0)} · "
        f"dropped {sc.get('op_dropped_tasks',0)} · new {sc.get('op_new_tasks',0)} | "
        f"Customer — updated {sc.get('cust_updated_tasks',0)} · no-update {sc.get('cust_no_update_tasks',0)} · "
        f"dropped {sc.get('cust_dropped_tasks',0)} · new {sc.get('cust_new_tasks',0)}"
    ))

    # Operation diff section
    op_diff = cwd.get("operation_diff", [])
    if op_diff:
        _h2(doc, "Operation diff")
        for od in op_diff:
            _h3(doc, od.get("operation_title", "?"))
            if od.get("is_new_operation_item"):
                _para(doc, "(Mới — không có trong tuần trước)", italic=True, color=GREEN)
            elif od.get("is_entirely_dropped"):
                _para(doc, "(Toàn bộ item bị drop — tuần này không thấy update)",
                      italic=True, color=RED)
            _render_tasks_diff(doc, od.get("tasks_diff", {}))

    # Customer diff section
    c_diff = cwd.get("customers_diff", [])
    if c_diff:
        _h2(doc, "Customer diff")
        for cd in c_diff:
            _h3(doc, cd.get("customer_name", "?"))
            if cd.get("is_new_customer"):
                _para(doc, "(Mới — không có trong tuần trước)", italic=True, color=GREEN)
            elif cd.get("is_entirely_dropped"):
                _para(doc, "(Toàn bộ customer bị drop — tuần này không thấy update)",
                      italic=True, color=RED)
            _render_tasks_diff(doc, cd.get("tasks_diff", {}))


def _render_tasks_diff(doc, td):
    """Render the 4 buckets: updated / no_update / dropped / new."""
    from docx.shared import Pt, RGBColor, Cm
    buckets = [
        ("Updated (có thay đổi status/PIC/deadline)", td.get("updated", []), BLUE_2),
        ("Không update (giữ nguyên từ tuần trước)", td.get("no_update", []), GRAY_3),
        ("Tuần trước có — tuần này KHÔNG nhắc (cần verify)", td.get("dropped", []), RED),
        ("Mới phát sinh tuần này", td.get("new", []), GREEN),
    ]
    for label, items, color in buckets:
        if not items:
            continue
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.left_indent = Cm(0.3)
        r = p.add_run(f"{label}:")
        r.bold = True
        r.font.color.rgb = RGBColor(*color)
        r.font.size = Pt(10)
        for it in items:
            title = it.get("title", "?")
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.left_indent = Cm(1.0)
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(title)
            r.font.size = Pt(10)
            # Show delta lines if updated
            if "prev_status" in it and "curr_status" in it and label.startswith("Updated"):
                if it.get("prev_status") != it.get("curr_status"):
                    p2 = doc.add_paragraph()
                    p2.paragraph_format.left_indent = Cm(1.5)
                    p2.paragraph_format.space_after = Pt(0)
                    r2 = p2.add_run(f"Status: «{it.get('prev_status','-')}» → «{it.get('curr_status','-')}»")
                    r2.font.size = Pt(9)
                    r2.italic = True
                if it.get("prev_deadline") != it.get("curr_deadline"):
                    p2 = doc.add_paragraph()
                    p2.paragraph_format.left_indent = Cm(1.5)
                    p2.paragraph_format.space_after = Pt(0)
                    r2 = p2.add_run(f"Deadline: «{it.get('prev_deadline','-')}» → «{it.get('curr_deadline','-')}»")
                    r2.font.size = Pt(9)
                    r2.italic = True
            elif label.startswith("Tuần trước"):
                # show prev metadata for context
                meta = []
                if it.get("prev_status"): meta.append(f"prev status: {it['prev_status']}")
                if it.get("prev_pic"): meta.append(f"PIC: {it['prev_pic']}")
                if it.get("prev_deadline"): meta.append(f"deadline: {it['prev_deadline']}")
                if meta:
                    p2 = doc.add_paragraph()
                    p2.paragraph_format.left_indent = Cm(1.5)
                    p2.paragraph_format.space_after = Pt(0)
                    r2 = p2.add_run(" · ".join(meta))
                    r2.font.size = Pt(9)
                    r2.italic = True


def render_appendix(doc, brief):
    deferred = brief.get("deferred_or_noisy", [])
    stats = brief.get("stats_compact", {})
    if deferred:
        _h1(doc, "Phụ lục — Deferred / Noisy items")
        for d in deferred:
            _bullet(doc, d)
    if stats:
        _h3(doc, "Stats compact")
        for k, v in stats.items():
            _bullet(doc, f"{k}: {v}")


def render(brief_path: Path, out_path: Path):
    from docx import Document
    brief = load_json(brief_path)
    if not brief:
        log(f"ERROR: brief not found at {brief_path}")
        sys.exit(2)
    doc = Document()
    _set_doc_style(doc)
    render_cover(doc, brief)
    render_summary(doc, brief)
    render_operation(doc, brief)
    render_customers(doc, brief)
    render_cross_week_diff(doc, brief)
    render_appendix(doc, brief)
    doc.save(out_path)
    log(f"Rendered docx v3 -> {out_path} ({out_path.stat().st_size} bytes)")
    return out_path


def upload_docx(out_path: Path):
    from googleapiclient.http import MediaFileUpload
    creds = load_credentials()
    drive = get_drive(creds)
    parent_folder_id = get_weekly_folder_id(drive)
    win = load_json(WINDOW_PATH)
    # Ensure week-specific subfolder (e.g. W19-2026)
    wf_name = week_folder_name(win.get("iso_week", ""))
    folder_id = ensure_folder(drive, wf_name, parent_folder_id)
    log(f"Target folder: {wf_name} (id={folder_id})")
    state = load_state()
    last_run_window = state.get("last_run_window")
    version = 1
    if last_run_window == win["week_label"]:
        version = int(state.get("last_run_version", 1)) + 1
    name = docx_filename(win, version=version)
    media = MediaFileUpload(
        str(out_path),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        resumable=False,
    )
    body = {
        "name": name,
        "parents": [folder_id],
        "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }
    f = drive.files().create(body=body, media_body=media, fields="id,webViewLink").execute()
    log(f"Uploaded {name} -> id={f['id']}")
    state["last_run_window"] = win["week_label"]
    state["last_run_version"] = version
    state["last_docx_id"] = f["id"]
    state["last_docx_link"] = f.get("webViewLink")
    save_state(state)
    return {"file_id": f["id"], "name": name, "link": f.get("webViewLink")}


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "render-and-upload"
    if cmd == "render":
        render(BRIEF_PATH, DOCX_PATH)
    elif cmd == "upload":
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    elif cmd == "render-and-upload":
        render(BRIEF_PATH, DOCX_PATH)
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    else:
        print("Usage: render_weekly_docx_v3.py [render|upload|render-and-upload]", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
