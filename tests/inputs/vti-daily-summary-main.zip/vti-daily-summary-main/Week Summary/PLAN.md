# Weekly Summary — Kế hoạch triển khai v2 (đã chốt)

**Author:** Claude (16/05/2026, v2 sau khi Michael chốt 5 quyết định)
**Trigger:** Scheduled task `weekly-summary-monday-3am` — cron `0 3 * * 1` (GMT+7).
**Mục tiêu:** Mỗi sáng thứ Hai 03:00, tự động review toàn bộ hoạt động tuần trước (Mon→Sun), compile thành 1 file `.docx` nguyên bản trên Drive folder *Daily Meeting Prep / Weekly Summary* + đăng recap lên Discord (cùng webhook Meeting Prep).

## Chốt v2 (16/05/2026)

| # | Quyết định | Implication |
|---|---|---|
| 1 | Discord webhook chung Meeting Prep | Reuse `DISCORD_WEBHOOK` từ `meeting_lib.py`, KHÔNG hardcode khác |
| 2 | Folder đích `Daily Meeting Prep / Weekly Summary` (nested) | `ensure_folder(drive, "Weekly Summary", parent_id=DAILY_PREP_ID)` |
| 3 | `.docx` nguyên bản (giữ format khi download) | Dùng `python-docx` trực tiếp giống `render_docx.py` Meeting Prep, mime `application/vnd.openxmlformats-officedocument.wordprocessingml.document`, KHÔNG để Drive convert thành Google Doc |
| 4 | Chạy thử thủ công ngay tuần này (review Mon 11/05 → Sun 17/05) | Phase 6 sẽ chạy thử với window cố định trước, schedule task setup sau khi verify output |
| 5 | Memory diff = Cách B (snapshot diff sections) — càng chi tiết càng tốt | Cần thêm cơ chế snapshot mỗi tuần. Tuần đầu chưa có baseline → fallback Cách A (chỉ changelog) + ghi note |

## Implication chi tiết của Cách B (Memory snapshot diff)

**Cơ chế snapshot:**
- Sau khi render Doc Weekly xong (Bước 6), copy `Meeting_Memory.md` hiện tại vào `Daily Meeting Prep / Weekly Summary / _snapshots / Meeting_Memory_<ISO_WEEK>.md` (vd `Meeting_Memory_2026-W20.md`).
- Tuần sau khi diff: download snapshot W-1 từ folder `_snapshots/` + Memory hiện tại → diff section-by-section.

**Diff per section** (5 section đã định nghĩa: `clients`, `meeting_types`, `general`, `changelog`, `provenance`):
- **clients**: per client → list bullet (a) added, (b) modified (sub-bullet line cũ → line mới), (c) removed
- **meeting_types**: tương tự
- **general**: text-level diff, hiển thị paragraph thay đổi
- **changelog**: filter dòng có date trong window (vẫn cần — đây là "intent" của thay đổi do AI agent ghi)
- **provenance**: count agent invocations trong tuần

**Tuần đầu chạy (không có snapshot W-1):**
- Phát hiện: `_snapshots/Meeting_Memory_<W-1>.md` không tồn tại
- Fallback: chỉ làm Cách A (filter changelog theo date)
- Ghi note vào `gaps`: "Memory snapshot diff: tuần đầu, baseline chưa có → từ tuần sau sẽ diff đầy đủ"
- Vẫn lưu snapshot tuần này để tuần sau dùng

**Fallback nếu snapshot W-1 hỏng:**
- Skip diff phần đó, không crash. Ghi gaps + AI log.

---

## 1. Phân vai trò (kế thừa pattern Mail Summary v3 + Meeting Prep v8)

### Python deterministic (KHÔNG reasoning)
| Module | Mục đích |
|---|---|
| `weekly_lib.py` | Shared utils — re-export từ `meeting_lib`: `load_credentials`, `get_drive`, `ensure_folder`, `log`, `DISCORD_WEBHOOK`, `DISCORD_USER_AGENT`. Thêm helper compute ISO week window (Mon-Sun) + path constants riêng |
| `auth_setup.py` | Reuse token.json của Meeting Preparation (cùng scope). Copy `auth_setup.py` từ Meeting Prep, đổi WORKDIR check |
| `week_prelude.py` | Compute window → crawl 5 nguồn → dump file context |
| `render_weekly_docx.py` | Đọc `weekly_brief.json` → build `.docx` native bằng `python-docx` → upload Drive với mime docx (giữ nguyên format khi download). Pattern kế thừa từ `render_docx.py` Meeting Prep |
| `send_discord_weekly.py` | Đọc `weekly_brief.json` → build 3-5 post Discord (recap) → POST webhook chung Meeting Prep |
| `snapshot_memory.py` | Save snapshot `Meeting_Memory.md` → Drive `_snapshots/`. Load snapshot W-1 cho diff |
| `requirements.txt` | `google-auth`, `google-auth-oauthlib`, `google-api-python-client`, `openpyxl`, `python-docx` |

### Claude reasoning (làm trong skill prompt)
1. Đọc 5 file context dump bởi prelude
2. Compile `week_context/weekly_brief.json` (single source of truth)
3. Gọi 3 sub-agent (rollup, action-velocity, sanity-check) — tham khảo pattern Meeting Prep
4. Gọi 2 writer Python theo đúng thứ tự (Doc → Discord)
5. Báo cáo ngắn lên console

---

## 2. Pipeline 8 bước

### Bước 1 — Xác nhận môi trường
```bash
WORKDIR=$(find / -type d -name "Week Summary" 2>/dev/null | grep '/mnt/' | head -1)
cd "$WORKDIR" && python3 auth_setup.py --test 2>&1 | tail -3
```
Auth fail → STOP, ghi note "Re-run trên máy Michael".

### Bước 2 — Compute week window
```bash
python3 week_prelude.py window
```
Output `week_context/_window.json`:
```json
{
  "run_date": "2026-05-18",
  "run_dow": "Mon",
  "week_start": "2026-05-11",   // Monday
  "week_end": "2026-05-17",     // Sunday
  "week_label": "11/05 → 17/05/2026",
  "iso_week": "2026-W20"
}
```

### Bước 3 — Crawl 5 nguồn (deterministic + Claude MCP mix)

**3a. Mail (Gmail MCP — Claude gọi)**
- `gmail.search_threads(query="after:2026/05/11 before:2026/05/18 -in:draft -label:Claude/Skip")`
- Pagination tới 1000 thread
- Per-thread cần fetch: `gmail.get_thread` (chỉ thread có message trong window — diff vs Mail Summary state.json để KHÔNG re-fetch)
- Smart-filter giống Mail Summary: skip auto/HR/system
- Dump: `week_context/mail_threads.json` (list `{thread_id, subject, latest_sender, latest_at, summary, last_action_status}`)

**3b. Chat (Drive folder "Google Chat Crawl")**
- List 7 folder con `Google Chat Crawl/YYYY-MM-DD/` cho Mon→Sun
- Mỗi ngày có nhiều file `HH-MM.json` (hourly snapshot). Skip nếu trống.
- Ưu tiên đọc file `_summary.json` per-space (nếu Meeting Prep đã sinh). Fallback: gộp raw.
- Smart-filter F1-F5 giống Meeting Prep Bước 1.9 (chỉ giữ space active)
- Dump: `week_context/chat_signals.json`

**3c. Daily Meeting Prep (Drive folder "Daily Meeting Prep")**
- List 7 Docs tên `Daily Recap & Prep — DD/MM/YYYY` cho Mon→Sun
- Drive API `files.export(mimeType="text/html")` cho mỗi Doc
- Parse HTML, trích từng section: recap, prep, actions, gaps
- Skip ngày không có Doc (cuối tuần, lễ)
- Dump: `week_context/daily_briefs.json`

**3d. Action_Tracker.xlsx (Drive folder "Daily Meeting Prep")**
- Download `Action_Tracker.xlsx` (cùng folder gốc Daily Meeting Prep)
- Parse với openpyxl, slice theo `last_updated` trong window:
  - `opened_this_week`: rows với `date_opened` trong window
  - `closed_this_week`: rows với `status=Done` AND `last_updated` trong window
  - `still_open_with_overdue`: rows `status≠Done` AND `deadline < week_end`
  - `carry_to_next_week`: rows `status≠Done` AND `deadline > week_end`
- Dump: `week_context/tracker_snapshot.json`

**3e. Meeting_Memory.md (Drive folder "Daily Meeting Prep")**
```bash
cd "$WORKDIR" && python3 -c "
from meeting_lib import load_credentials, get_drive
# Download Meeting_Memory.md content
# Trích section changelog, filter dòng có date trong window
"
```
- Dump: `week_context/memory_changes.md` (chỉ phần changelog tuần này)

### Bước 4 — Claude reason → `weekly_brief.json`

Single source of truth. Schema bắt buộc:

```json
{
  "meta": {
    "run_date": "2026-05-18",
    "week_label": "11/05 → 17/05/2026",
    "iso_week": "2026-W20",
    "generated_at_local": "03:01",
    "version": 1,
    "counts": {
      "mail_threads_reviewed": 87,
      "chat_spaces_active": 12,
      "meetings_total": 14,
      "actions_opened": 23,
      "actions_closed": 18
    }
  },

  "executive_summary": [
    "Top 3-5 highlights tuần (1 câu mỗi cái, mạnh nhất lên đầu)"
  ],

  "by_client": [
    {
      "name": "KGI / Ufinity",
      "meetings_count": 3,
      "meetings_detail": [
        {
          "date": "2026-05-12",
          "title": "KGI Discovery — AI Adoption",
          "attendees_external": ["Joseph Tan (CTO)", "..."],
          "summary_bullets": ["3-5 bullet"],
          "decisions": ["chốt 1", "..."],
          "actions_from_this_meeting": [<action_row>],
          "risk_level": "amber"
        }
      ],
      "decisions_aggregate": ["chốt cấp client tuần này"],
      "actions_open": [<action_row>],
      "actions_closed": [<action_row>],
      "chat_signals": [
        {"type":"decision_pending","summary":"...","space":"KGI","date":"2026-05-15","raw_excerpt":"..."}
      ],
      "mail_threads_count": 8,
      "top_mail_threads": [
        {"subject":"...","from":"...","status":"awaiting Michael reply","priority":"red","summary":"1-2 câu","last_msg_at":"2026-05-15 14:30"}
      ],
      "sentiment_shift": {
        "this_week": "positive | neutral | negative | mixed",
        "vs_last_week": "improved | stable | declined",
        "evidence": ["1-2 câu lý do từ chat/mail"]
      },
      "next_step": "1 câu hướng tuần sau",
      "risk_level": "red | amber | green",
      "risk_reason": "1 dòng",
      "carry_open_actions_count": 4
    }
  ],

  "by_meeting_type": [
    {"type": "Internal Standup", "count": 4, "key_decisions": ["..."]},
    {"type": "Customer Discovery", "count": 3, "key_decisions": ["..."]},
    {"type": "Pitch / Demo", "count": 2, "key_decisions": ["..."]}
  ],

  "mail_intel": {
    "total_threads_in_window": 87,
    "filtered_after_smart_filter": 52,
    "top_threads_detail": [
      {
        "subject":"...","from":"...","client":"KGI",
        "status":"awaiting Michael reply",
        "priority":"red",
        "summary":"2-3 câu nội dung",
        "thread_msg_count":4,
        "last_msg_from":"customer",
        "last_msg_at":"2026-05-15 14:30",
        "waiting_days":3
      }
    ],
    "pending_replies_michael": [{"subject":"...","waiting_days":3,"client":"..."}],
    "pending_replies_external": [{"subject":"...","waiting_days":2,"who":"..."}],
    "new_external_contacts": [{"name":"...","company":"...","first_thread_subject":"..."}],
    "thread_volume_by_client": {"KGI":12,"AsiaPac":8,"Internal":31}
  },

  "chat_intel": {
    "spaces_active_count": 12,
    "messages_total_in_window": 432,
    "by_space_detail": [
      {
        "space_name":"KGI - VTI Working",
        "msg_count":47,
        "trending_topics":["AI adoption roadmap","data pipeline timeline"],
        "decisions_made":["..."],
        "questions_unanswered":["..."],
        "michael_msgs_count":12,
        "michael_pending_replies":[{"to":"...","topic":"...","raw":"..."}],
        "sentiment":"neutral",
        "urgency_flags":["..."]
      }
    ],
    "trending_topics_global": ["topic 1 (5 spaces)","topic 2 (3 spaces)"],
    "decisions_made_global": ["..."],
    "urgent_unaddressed": [{"space":"...","summary":"...","date":"..."}],
    "michael_persona_language_samples": ["3-5 câu Michael viết tuần qua, để Meeting Prep adapt persona"]
  },

  "action_tracker_delta": {
    "opened_this_week": 23,
    "closed_this_week": 18,
    "still_open": 41,
    "overdue_count": 5,
    "overdue_items": [<action_row top 5>],
    "closed_items_top": [<action_row top 5 mới đóng>],
    "carry_to_next_week": [<action_row top 10>]
  },

  "memory_diff": {
    "baseline_iso_week": "2026-W19",
    "baseline_available": true,
    "clients": [
      {
        "name": "KGI / Ufinity",
        "added": ["bullet mới"],
        "modified": [{"before": "...", "after": "..."}],
        "removed": []
      }
    ],
    "meeting_types": [
      {
        "type": "Customer Discovery",
        "added": ["dấu hiệu warning mới: ..."],
        "modified": [],
        "removed": []
      }
    ],
    "general_text_diff": "paragraph mức ngắn nếu có thay đổi",
    "changelog_this_week": [
      "2026-05-12: persona refresh KGI Joseph",
      "2026-05-14: Customer Discovery pattern thêm warning"
    ],
    "provenance_counts": {
      "persona-inference": 7,
      "action-qc": 5,
      "cross-carry": 5,
      "chat-extractor": 5,
      "sanity": 5
    }
  },

  "next_week_focus": [
    "5 priority items cho tuần tới — extracted từ action_open + chat_urgent + Michael cam kết"
  ],

  "risk_register": [
    {"item": "...", "severity": "red", "owner": "Michael", "deadline": "DD/MM"}
  ],

  "ai_log": [
    "client-rollup: 5 clients processed, 1 missing transcript",
    "action-velocity: opened 23 / closed 18 ratio 0.78 (healthy)",
    "sanity: 0 BLOCKER, 2 WARN (mail threads thiếu summary)"
  ]
}
```

**action_row** (kế thừa Meeting Prep):
```json
{"pic":"...","task":"...","output":"...","deadline":"DD/MM/YYYY","priority":"red|amber|green","from_meeting":"...","status":"Open|In progress|Done"}
```

### Bước 5 — Sub-agent reasoning (Task tool, parallel)

Pattern kế thừa Meeting Prep, đơn giản hơn:

| Agent | Input | Output |
|---|---|---|
| **A) client-rollup** (parallel per client) | mail_threads + daily_briefs + chat_signals filtered per client | `by_client[]` entries hoàn chỉnh — bao gồm `meetings_detail`, `top_mail_threads`, `chat_signals` raw |
| **B) action-velocity-check** | tracker_snapshot + daily_briefs.actions | `action_tracker_delta` + insights cho `executive_summary` |
| **C) sentiment-shift-analyzer** | chat_signals + mail (per client) tuần này + memory_diff baseline | `sentiment_shift` cho mỗi `by_client[]` entry |
| **D) memory-diff-extractor** | Meeting_Memory.md hiện tại + snapshot W-1 từ `_snapshots/` | `memory_diff` block hoàn chỉnh, fallback Cách A nếu thiếu baseline |
| **E) chat-week-extractor** | 7 ngày Chat Crawl (raw + summary) | `chat_intel` block — gộp signals → trending topics + Michael persona samples |
| **F) sanity-check-publish** | weekly_brief.json hoàn chỉnh | BLOCKER (exit 3) nếu schema sai / empty / contradiction / counts mismatch |

**Thứ tự chạy:**
1. Parallel: A (per major client, 5-8 agent đồng thời) + B + D + E
2. Sau khi A xong: chạy C parallel per client (sentiment cần baseline từ D)
3. Merge tất cả vào `weekly_brief.json`
4. Cuối cùng: F (sanity check)

### Bước 6 — Render docx + upload Doc + lưu Memory snapshot
```bash
cd "$WORKDIR"

# 6a) Render .docx native (python-docx, NOT HTML convert)
python3 render_weekly_docx.py render-and-upload 2>&1 | tail -5
DOC_LINK=$(python3 render_weekly_docx.py render-and-upload 2>/dev/null | tail -1 | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['link'])")

# 6b) Lưu snapshot Meeting_Memory.md cho tuần sau diff
python3 snapshot_memory.py save 2>&1 | tail -3
# → Copy Meeting_Memory.md hiện tại vào Drive: Daily Meeting Prep/Weekly Summary/_snapshots/Meeting_Memory_<ISO_WEEK>.md
```
- Doc name: `Weekly Summary — 11-05 → 17-05-2026.docx` (hoặc `(v2).docx` nếu re-run cùng tuần)
- Drive folder: `Daily Meeting Prep / Weekly Summary` (tạo nếu chưa có)
- Mime: `application/vnd.openxmlformats-officedocument.wordprocessingml.document` — KHÔNG để Drive convert
- Snapshot lưu trong: `Daily Meeting Prep / Weekly Summary / _snapshots / Meeting_Memory_<ISO_WEEK>.md`

### Bước 7 — Build + send Discord recap
```bash
cat > links.json <<EOF
{"doc_link": "$DOC_LINK"}
EOF
python3 send_discord_weekly.py build-and-send --links links.json 2>&1 | tail -5
```

Cấu trúc 3-5 post (≤2000 char/post):
- **Post 1 — Header + Exec summary** (5 highlights + link Doc)
- **Post 2 — By Client** (top 3-5 client + risk_level)
- **Post 3 — Action Tracker delta** (opened/closed/overdue counts + top 3 overdue)
- **Post 4 — Next week focus** (5 priorities)
- **Post 5 (optional) — Risk register** (chỉ post nếu có RED items)

### Bước 8 — Báo cáo console
≤250 từ:
- Doc tên + link
- Discord: N posts, ok/fail
- AI log 3 agent
- Elapsed seconds

---

## 3. Files cần tạo

```
Week Summary/
├── SKILL.md                       # Skill chính — paste vào scheduled task
├── PLAN.md                        # File này — review trước khi code
├── README.md                      # Setup + debug guide
├── requirements.txt
├── auth_setup.py                  # Reuse Meeting Prep
├── weekly_lib.py                  # Shared (import từ meeting_lib + override)
├── week_prelude.py                # Compute window + crawl 5 nguồn
├── render_weekly_doc.py           # Render Doc HTML + upload Drive
├── send_discord_weekly.py         # Build 3-5 post + POST webhook
├── credentials.json               # Copy từ Meeting Prep (KHÔNG commit)
├── token.json                     # Tạo bởi auth_setup.py (KHÔNG commit)
├── _state.json                    # Cache fileId Doc tuần cuối + window cuối đã chạy
├── week_context/
│   ├── _window.json               # Output Bước 2
│   ├── mail_threads.json          # Bước 3a
│   ├── chat_signals.json          # Bước 3b
│   ├── daily_briefs.json          # Bước 3c
│   ├── tracker_snapshot.json      # Bước 3d
│   ├── memory_changes.md          # Bước 3e
│   └── weekly_brief.json          # Claude output Bước 4
├── outputs/
│   ├── weekly_doc.html            # Render trung gian
│   └── discord_posts.json         # Build Discord trước khi POST
└── run.log
```

---

## 4. Scheduled task config

| Field | Value |
|---|---|
| Name | `weekly-summary-monday-3am` |
| Cron | `0 3 * * 1` |
| Timezone | `Asia/Ho_Chi_Minh` (GMT+7) |
| Prompt | Toàn bộ nội dung `SKILL.md` |
| Estimated duration | 8-15 phút (tuỳ N mail thread + N space chat) |

Edge case: Thứ Hai trùng nghỉ lễ → vẫn chạy bình thường, week trước Mon-Sun không phụ thuộc.

---

## 5. Quy ước chung (kế thừa unchanged)

- **Email**: `anh.nguyentruongviet@vti.com.vn`
- **Múi giờ**: GMT+7
- **Search window mail**: chính xác Mon 00:00 → Mon 00:00 (Gmail dùng UTC, cần ±1 ngày buffer rồi filter lại)
- **Internal-only meeting**: vẫn count, ghi rút gọn trong `by_client` group "Internal"
- **Drive folder mới**: `Weekly Summary` (root, tự tạo)
- **Discord webhook**: **chưa chốt** — xem câu hỏi follow-up (#1 dưới)

---

## 6. Risks & Gotchas

| Risk | Mitigation |
|---|---|
| OAuth scope chưa đủ Chat read | Reuse token Meeting Prep (đã có scope) — Bước A trong setup |
| Doc Daily thiếu 1-2 ngày (cuối tuần / lễ) | Graceful skip, ghi note vào `gaps` |
| Action_Tracker.xlsx bị Michael edit notes column | KHÔNG ghi đè — Weekly Summary chỉ READ tracker, không write |
| Chat folder per-day trống | Skip silently, log debug |
| bindfs truncation cho file Python lớn (>22KB) | Dùng `cat > file.py << 'PYEOF'` heredoc, test syntax `ast.parse` sau write |
| Re-run cùng tuần (Michael trigger thủ công) | Doc name suffix `(v2)`, bump `meta.version` |
| Mail thread quá nhiều (>200) trong tuần busy | Smart-filter trước khi đưa vào reasoning. Cap N=100 threads, ghi gaps "thread > 100, top 100 by recency" |
| Discord rate limit (POST quá nhanh) | `time.sleep(1.0)` giữa posts giống `send_discord.py` |

---

## 7. Anti-patterns (LÀM SẼ FAIL)

- Sửa output Python writer bằng tay sau khi render
- Inline urllib POST Discord trong skill — phải dùng `send_discord_weekly.py`
- Tự call Drive API bằng bash curl — dùng wrapper
- Skip BLOCKER assertion bằng `--force`
- Ghi đè `notes` column trong Action_Tracker.xlsx
- Chạy reasoning trên mail/chat KHÔNG smart-filter (sẽ ngợp + chậm)
- Tạo OAuth project mới — reuse `credentials.json` Meeting Prep

---

## 8. Setup ban đầu (1 lần — trên máy Michael)

```bash
# 1. Cài dependencies
cd "C:\Users\Administrator\Documents\Claude\Projects\Week Summary"
pip install --user -r requirements.txt

# 2. Copy credentials
copy "..\Meeting Preparation\credentials.json" .

# 3. OAuth flow (browser)
python auth_setup.py --auth-url
# Mở URL → sign-in → approve → copy redirect URL
python auth_setup.py --finish-auth "http://localhost?code=..."
python auth_setup.py --test
# Expect: ✅ Drive auth OK: anh.nguyentruongviet@vti.com.vn

# 4. Test 1 lần thủ công (window là tuần qua)
python week_prelude.py window
python week_prelude.py crawl-all  # hoặc step riêng từng nguồn
# Claude reasoning bằng tay → tạo weekly_brief.json mẫu
python render_weekly_doc.py render-and-upload
python send_discord_weekly.py dry-run  # check post trước khi POST thật

# 5. Tạo scheduled task trong Cowork
#    Paste SKILL.md vào prompt, cron "0 3 * * 1"
```

---

## 9. Effort estimate

| Phase | Time | Description |
|---|---|---|
| Phase 1 | 2-3h | `weekly_lib.py` + reuse `auth_setup.py` + scaffold prelude crawl 5 nguồn |
| Phase 2 | 1-2h | Test crawl với window tuần qua thật, dump 5 file context |
| Phase 3 | 2-3h | `render_weekly_doc.py` (kế thừa pattern `render_doc_html.py`) |
| Phase 4 | 1-2h | `send_discord_weekly.py` (kế thừa pattern `send_discord.py`) |
| Phase 5 | 1-2h | Viết `SKILL.md` chuẩn + tune sub-agent prompts |
| Phase 6 | 1h | E2E test → tạo scheduled task → wait Mon 3AM |
| Phase 7 | 1h | Polish sau lần chạy thật đầu tiên (chỉnh schema/format dựa feedback Michael) |

**Total: ~1.5 ngày dev + 1 tuần observe + tune.**

---

## 10. Câu hỏi cần Michael chốt trước khi code

1. **Discord webhook**: dùng chung webhook VTI Meeting Prep (đã hardcode trong `meeting_lib.py`) hay tạo channel riêng *VTI Weekly Summary*?
2. **Folder Drive đích**: tên `Weekly Summary` (root)? Hay `Daily Meeting Prep/Weekly Recap/`?
3. **Doc format**: Google Doc (Drive convert HTML) hay file `.docx` upload nguyên bản?
4. **Tuần đầu chạy thử**: bắt đầu Mon 25/05/2026 (review 18-24/05) hay chạy thử thủ công ngay tuần này để tune?
5. **Memory diff**: chỉ trích section `changelog` filter theo date, hay thêm phần `clients`/`meeting_types` thay đổi gì so với tuần trước?
