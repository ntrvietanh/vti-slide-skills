#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""crawl_memory.py — Download Meeting_Memory.md (current) + snapshot W-1 (nếu có).

Cách B (snapshot diff section-by-section):
1. Download Meeting_Memory.md hiện tại từ Daily Meeting Prep folder
   → save as week_context/memory_baseline.md
2. Tìm snapshot W-1 trong _snapshots/Meeting_Memory_<W-1>.md
   → save as week_context/memory_snapshot_prev.md (hoặc note nếu không có)
3. Filter changelog section: chỉ giữ dòng có date trong window
   → save as week_context/memory_changes.md

Sections của Memory.md (markers `<!-- BEGIN: X -->` / `<!-- END: X -->`):
  clients, pics, opps, meeting_types, general, changelog, provenance

Output:
- memory_baseline.md (full current Memory.md)
- memory_snapshot_prev.md (full W-1 snapshot, or note if missing)
- memory_changes.md (changelog filtered theo date trong window)
- memory_diff_input.json (parsed sections cho cả 2, để Claude reason diff)
"""

from __future__ import annotations

import re
import sys
from datetime import date
from pathlib import Path

from weekly_lib import (
    CONTEXT_DIR,
    MEMORY_BASELINE_PATH,
    MEMORY_CHANGES_PATH,
    MEMORY_FILE_NAME,
    MEMORY_SNAPSHOT_PREV_PATH,
    WINDOW_PATH,
    download_text,
    find_file,
    get_daily_prep_folder_id,
    get_drive,
    get_snapshots_folder_id,
    load_credentials,
    load_json,
    log,
    memory_snapshot_filename,
    save_json,
)


_SECTION_RE = re.compile(
    r"<!-- BEGIN: (?P<name>[a-zA-Z0-9_-]+) -->(?P<body>.*?)<!-- END: (?P=name) -->",
    re.DOTALL,
)

# Match dates in changelog: "YYYY-MM-DD" or "DD/MM/YYYY" anywhere in line
_DATE_ISO_RE = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
_DATE_DMY_RE = re.compile(r"\b(\d{2})/(\d{2})/(\d{4})\b")


def parse_sections(markdown: str) -> dict[str, str]:
    """Extract all sections marked `<!-- BEGIN: X -->...<!-- END: X -->` thành dict."""
    out = {}
    for m in _SECTION_RE.finditer(markdown):
        out[m.group("name")] = m.group("body").strip()
    return out


def filter_changelog_by_window(changelog: str, week_start: date, week_end: date) -> str:
    """Trả về dòng changelog có date trong [week_start, week_end]."""
    out_lines = []
    for line in changelog.splitlines():
        line_dates = []
        for m in _DATE_ISO_RE.finditer(line):
            try:
                line_dates.append(date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
            except ValueError:
                pass
        for m in _DATE_DMY_RE.finditer(line):
            try:
                line_dates.append(date(int(m.group(3)), int(m.group(2)), int(m.group(1))))
            except ValueError:
                pass
        if any(week_start <= d <= week_end for d in line_dates):
            out_lines.append(line)
    return "\n".join(out_lines)


def crawl():
    win = load_json(WINDOW_PATH)
    if not win:
        log("ERROR: window not computed yet. Run `python weekly_lib.py window` first.")
        sys.exit(2)

    week_start = date.fromisoformat(win["week_start"])
    week_end = date.fromisoformat(win["week_end"])

    creds = load_credentials()
    drive = get_drive(creds)

    # 1) Download CURRENT Meeting_Memory.md từ Daily Meeting Prep folder
    parent_id = get_daily_prep_folder_id(drive)
    mem_id = find_file(drive, MEMORY_FILE_NAME, parent_id)
    if not mem_id:
        log(f"WARN: {MEMORY_FILE_NAME} not found in Daily Meeting Prep folder")
        save_json(CONTEXT_DIR / "memory_diff_input.json", {
            "window": win, "memory_found": False,
            "error": f"{MEMORY_FILE_NAME} not in Drive folder",
        })
        return

    log(f"Downloading current {MEMORY_FILE_NAME} (id={mem_id})...")
    current_md = download_text(drive, mem_id) or ""
    MEMORY_BASELINE_PATH.write_text(current_md, encoding="utf-8")
    log(f"  Current Memory → {MEMORY_BASELINE_PATH} ({len(current_md)} chars)")

    # 2) Tìm snapshot W-1 trong _snapshots/
    snap_folder = get_snapshots_folder_id(drive)
    snap_filename = memory_snapshot_filename(win["iso_week_prev"])
    snap_id = find_file(drive, snap_filename, snap_folder)
    prev_md = None
    if snap_id:
        log(f"Found snapshot W-1 ({snap_filename}, id={snap_id})...")
        prev_md = download_text(drive, snap_id) or ""
        MEMORY_SNAPSHOT_PREV_PATH.write_text(prev_md, encoding="utf-8")
        log(f"  Snapshot W-1 → {MEMORY_SNAPSHOT_PREV_PATH} ({len(prev_md)} chars)")
    else:
        note = (
            f"# No baseline snapshot for ISO week {win['iso_week_prev']}\n\n"
            f"Tuần đầu chạy hoặc snapshot không có. Cách B fallback Cách A "
            f"(chỉ trích changelog filter theo date).\n"
            f"Snapshot tuần này sẽ được lưu sau khi render Doc xong, "
            f"để tuần sau diff được đầy đủ.\n"
        )
        MEMORY_SNAPSHOT_PREV_PATH.write_text(note, encoding="utf-8")
        log(f"  No W-1 snapshot — fallback Cách A (note → {MEMORY_SNAPSHOT_PREV_PATH})")

    # 3) Parse sections cho cả current + prev
    current_sections = parse_sections(current_md)
    prev_sections = parse_sections(prev_md) if prev_md else {}

    # 4) Filter changelog tuần này
    changelog = current_sections.get("changelog", "")
    filtered = filter_changelog_by_window(changelog, week_start, week_end)
    if not filtered:
        filtered = "(Không có dòng changelog nào có date trong window)"
    MEMORY_CHANGES_PATH.write_text(
        f"# Changelog filtered for {win['week_label']} (ISO {win['iso_week']})\n\n{filtered}\n",
        encoding="utf-8",
    )
    log(f"  Changelog filtered → {MEMORY_CHANGES_PATH} ({len(filtered.splitlines())} lines)")

    # 5) Dump sections JSON cho Claude reason diff
    diff_input = {
        "window": win,
        "memory_found": True,
        "memory_file_id": mem_id,
        "snapshot_prev_found": snap_id is not None,
        "snapshot_prev_file_id": snap_id,
        "current_sections": current_sections,
        "prev_sections": prev_sections,
        "changelog_filtered_lines": filtered.splitlines(),
        "section_sizes_current": {k: len(v) for k, v in current_sections.items()},
        "section_sizes_prev": {k: len(v) for k, v in prev_sections.items()},
    }
    save_json(CONTEXT_DIR / "memory_diff_input.json", diff_input)
    log(f"  Diff input → {CONTEXT_DIR / 'memory_diff_input.json'}")
    log(f"  Sections current: {list(current_sections.keys())}")
    log(f"  Sections prev: {list(prev_sections.keys()) if prev_sections else '(none — first run)'}")


if __name__ == "__main__":
    crawl()
