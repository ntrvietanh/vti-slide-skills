#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""auth_setup.py — One-time OAuth flow cho Week Summary.

Pattern y hệt Meeting Preparation. Vì SCOPES được import từ meeting_lib (qua
weekly_lib), token sinh ra ở đây tương thích 100% với cả 2 project.

Default behavior: prefer SHARED token với Meeting Prep (KHÔNG cần re-auth nếu
Michael đã setup Meeting Prep). Chỉ chạy --auth-url khi muốn local-only token.

Usage:
  python auth_setup.py --test
      → Test load credentials + list user info. Default check.

  python auth_setup.py --auth-url
      → Sinh URL OAuth (chỉ chạy khi muốn token LOCAL của Week Summary,
        không share với Meeting Prep).

  python auth_setup.py --finish-auth "<full redirect URL>"
      → Hoàn tất OAuth flow, ghi token.json vào folder Week Summary.
"""

from __future__ import annotations

import os

# Phải set BEFORE importing google_auth_oauthlib
os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")
os.environ.setdefault("OAUTHLIB_INSECURE_TRANSPORT", "1")

import sys
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from weekly_lib import (
    CREDENTIALS_FILE,
    PROJECT_DIR,
    SCOPES,
    TOKEN_FILE,
    log,
    load_credentials,
    get_drive,
)

OOB_REDIRECT_URI = "http://localhost"
PKCE_VERIFIER_FILE = PROJECT_DIR / ".pkce_verifier"
LOCAL_TOKEN_FILE = PROJECT_DIR / "token.json"  # luôn ghi LOCAL khi --finish-auth


def _build_flow():
    from google_auth_oauthlib.flow import Flow

    if not CREDENTIALS_FILE.exists():
        raise FileNotFoundError(
            f"Missing {CREDENTIALS_FILE}.\n"
            f"Copy credentials.json từ ../Meeting Preparation/ sang đây nếu muốn local-only.\n"
            f"Hoặc đảm bảo Meeting Prep folder có credentials.json."
        )
    return Flow.from_client_secrets_file(
        str(CREDENTIALS_FILE), scopes=SCOPES, redirect_uri=OOB_REDIRECT_URI
    )


def cmd_auth_url() -> int:
    flow = _build_flow()
    auth_url, _ = flow.authorization_url(
        access_type="offline", include_granted_scopes="true", prompt="consent"
    )
    verifier = getattr(flow, "code_verifier", None)
    if verifier:
        PKCE_VERIFIER_FILE.write_text(verifier, encoding="utf-8")
    print("\n" + "=" * 72)
    print("OPEN IN BROWSER (sign in with anh.nguyentruongviet@vti.com.vn):")
    print(auth_url)
    print("=" * 72)
    print(
        "\nAfter approving, browser redirects to http://localhost?code=...\n"
        "Copy FULL URL from address bar, then run:\n"
        '  python auth_setup.py --finish-auth "<full URL>"\n'
    )
    return 0


def cmd_finish_auth(redirect_url: str) -> int:
    parsed = urlparse(redirect_url)
    code = parse_qs(parsed.query).get("code", [None])[0]
    if not code:
        print("ERROR: No ?code= in URL.", file=sys.stderr)
        return 2
    flow = _build_flow()
    if PKCE_VERIFIER_FILE.exists():
        flow.code_verifier = PKCE_VERIFIER_FILE.read_text(encoding="utf-8").strip()
    flow.fetch_token(code=code)
    LOCAL_TOKEN_FILE.write_text(flow.credentials.to_json(), encoding="utf-8")
    log(f"Token saved → {LOCAL_TOKEN_FILE} (LOCAL Week Summary)")
    print(f"\n[OK] token.json created with scopes:\n  " + "\n  ".join(SCOPES))
    return 0


def cmd_test() -> int:
    """Quick smoke test: load creds → list user info."""
    print(f"Using TOKEN_FILE: {TOKEN_FILE}")
    print(f"Using CREDENTIALS_FILE: {CREDENTIALS_FILE}")
    creds = load_credentials()
    drive = get_drive(creds)
    about = drive.about().get(fields="user(emailAddress,displayName)").execute()
    print(f"\n[OK] Drive auth OK: {about['user']['emailAddress']} ({about['user']['displayName']})")
    return 0


def main() -> int:
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__, file=sys.stderr)
        return 2
    cmd = args[0]
    if cmd == "--auth-url":
        return cmd_auth_url()
    if cmd == "--finish-auth":
        if len(args) < 2:
            print("ERROR: --finish-auth requires the redirect URL", file=sys.stderr)
            return 2
        return cmd_finish_auth(args[1])
    if cmd == "--test":
        return cmd_test()
    print(f"Unknown command: {cmd}", file=sys.stderr)
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
