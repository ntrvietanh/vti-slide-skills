#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""snapshot_brief_v2.py — Upload weekly_brief_v2.json hiện tại lên Drive snapshots/.

Format file: weekly_brief_v2_<ISO_WEEK>.json (mỗi tuần 1 file).
Idempotent: re-run cùng tuần sẽ update file cũ.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
from weekly_lib import (
    load_json, get_drive, load_credentials,
    get_snapshots_folder_id, find_file, upload_text, log,
    ensure_folder, load_state,
    CONTEXT_DIR,
)


def week_folder_name(iso_week: str) -> str:
    if not iso_week: return "Wxx-yyyy"
    s = iso_week.strip()
    if "-W" in s:
        year, w = s.split("-W", 1)
        return f"W{w}-{year}"
    return s


def get_weekly_folder_id(drive):
    state = load_state()
    fid = state.get("weekly_folder_id")
    return fid

BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2.json"
WINDOW_PATH = CONTEXT_DIR / "_window.json"


def snapshot_filename(iso_week: str) -> str:
    return f"weekly_brief_v2_{iso_week}.json"


def main():
    brief = load_json(BRIEF_PATH)
    if not brief:
        log(f"ERROR: brief not found at {BRIEF_PATH}")
        sys.exit(2)
    window = load_json(WINDOW_PATH)
    iso = window.get("iso_week", "")
    if not iso:
        log("ERROR: iso_week missing in _window.json")
        sys.exit(2)

    creds = load_credentials()
    drive = get_drive(creds)
    # Place snapshot inside week subfolder under Weekly Summary parent
    weekly_parent = get_weekly_folder_id(drive)
    wf_name = week_folder_name(iso)
    folder_id = ensure_folder(drive, wf_name, weekly_parent)
    log(f"Snapshot target folder: {wf_name} (id={folder_id})")
    fname = snapshot_filename(iso)
    content = json.dumps(brief, ensure_ascii=False, indent=2)
    fid = find_file(drive, fname, folder_id)
    new_id = upload_text(drive, folder_id, fname, content,
                          mimetype="application/json",
                          existing_id=fid)
    log(f"Snapshot uploaded: {fname} (id={new_id})")
    print(new_id)


if __name__ == "__main__":
    main()
