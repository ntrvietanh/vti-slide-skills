"""
discover_customers.py — Bước 7.5

Scan toàn bộ data đã crawl của tuần để extract distinct customer/topic mention,
cross-reference với memory_baseline (known clients) + W-1 brief snapshot (carried
RED items), produce `week_context/_discovered_customers.json` cho cluster planner
(Bước 7.6) sử dụng.

Output schema:
{
  "window": {...},
  "known_active":   [{name, mention_count, sources[], memory_section_hits}],
  "new_unknown":    [{name, first_seen_date, sources[], intro_via}],
  "dormant":        [{name, last_seen_in_memory, mentioned_this_week: false}],
  "carried_red_from_prev_week": [{name, prev_priority, prev_current_problem}],
  "stats": {...}
}

Run: python3 discover_customers.py
"""
from __future__ import annotations

import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).parent
CTX = ROOT / "week_context"

# Pattern detect customer name từ subject/space/event title
# - mail subject: [Customer & VTI] ..., [VTI APAC & Customer] ..., Customer Subject ...
# - chat space: Space_[VAP & D9] Customer - Project_XXXXX, Space_Customer_XXXXX
# - calendar event: [Customer & VTI] Intro Meeting, Customer x VTI Sync, ...
BRACKET_PAT = re.compile(r"\[([^\]]+)\]")
KNOWN_PREFIX_TOKENS = {
    "vap", "vti", "vti.apac", "vap & d1", "vap & d3", "vap & d8", "vap & d9",
    "vap & ta", "vap & ga & it & isms", "vap & legal", "vap & hr & isms",
    "vap & vsl", "vapxdg", "gits & vap", "vap d3", "vap & re", "vap & vsl",
    "vap d2", "vap d3", "vap d1", "vap d8", "vap d9", "vap d5",
    "tentative", "online", "update", "updated invitation", "invitation",
    "rsvp", "remind internal", "vap d3 - 2nd remind internal",
    "vap d3 - remind internal", "vti building", "vti.bom", "vti.delivery",
    "vti.vap", "vap & d9 - operation - management", "vap corporation",
    "vap - sales support", "vap & gam & af", "vap - dg - presales & operation",
    "vap - d1 - presales & operation", "vti global", "vti bd",
}
EMAIL_DOMAIN_SKIP = {
    "vti.com.vn", "gmail.com", "google.com", "googlegroups.com",
    "teams.mail.microsoft", "accounts.google.com", "samsungknox.com",
    "mail.postman.gov.sg", "drive-shares-dm-noreply.google.com",
}


def _slug(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9 ]+", " ", s).strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s


def _is_useful_token(tok: str) -> bool:
    tok_l = tok.lower().strip()
    if not tok_l or len(tok_l) < 3:
        return False
    if tok_l in KNOWN_PREFIX_TOKENS:
        return False
    if tok_l.startswith(("vap", "vti")):
        return False
    return True


def extract_from_subject(subject: str) -> list[str]:
    """Pull customer name candidates from email subject.

    Examples:
      "[Recruit Express & VTI APAC] Service Agreement ..."  → "Recruit Express"
      "[SLW Technology & VTI] CVs for Magento Developers"   → "SLW Technology"
      "VTI - Confirmation on Facial Recognition Storage"    → "Facial Recognition Storage"
      "RE: Great Meeting You at GITEX Asia from Dialogg AI" → "Dialogg AI"
    """
    if not subject:
        return []
    out = []
    # 1. Bracket pattern: [X & VTI] or [VTI & X]
    for m in BRACKET_PAT.findall(subject):
        # split on '&' or '+' or 'x'
        parts = re.split(r"\s*[&+]\s*|\s+x\s+", m)
        for p in parts:
            p = p.strip()
            if _is_useful_token(p):
                out.append(p)
    # 2. "VTI – X" or "VTI - X" pattern → take X
    m = re.search(r"VTI\s*[–\-]\s*(.+?)(?:\s*[\|\(\[]|\s*$)", subject)
    if m:
        cand = m.group(1).strip()
        if _is_useful_token(cand) and len(cand) < 60:
            out.append(cand)
    # 3. "from X" — last-resort
    m = re.search(r"from\s+(\w[\w\s\.]{2,40})$", subject)
    if m:
        cand = m.group(1).strip()
        if _is_useful_token(cand) and "team" not in cand.lower():
            out.append(cand)
    return out


def extract_from_chat_space(space_name: str) -> list[str]:
    """Pull customer from space name.

    Examples:
      "Space_[VAP & D9] AsiaPac - C99 - System Enhancement (Phase 1)_AAQAI3AJn9U"
       → "AsiaPac"  (+ optionally "C99")
      "Space_[VAP D3] Wiki Labs - AIOps_AAQAnzGKPuY" → "Wiki Labs"
      "Space_AsiaPac-SPPL - VTI Project Teams_AAAATbep7gY" → "AsiaPac SPPL"
    """
    if not space_name:
        return []
    # Drop "Space_" prefix and "_AAAA..." suffix
    s = re.sub(r"^Space_", "", space_name)
    s = re.sub(r"_[A-Za-z0-9_\-]{8,}$", "", s)
    out = []
    # Bracket prefix [VAP & D9] → ignore content
    if s.startswith("["):
        m = re.match(r"\[([^\]]+)\]\s*(.+)", s)
        if m:
            s = m.group(2).strip()
    # Now s = "AsiaPac - C99 - System Enhancement" or "Wiki Labs - AIOps" or ...
    # Take first segment before " - " as customer; second if shorter
    parts = [p.strip() for p in s.split(" - ")]
    if parts:
        cand = parts[0]
        if _is_useful_token(cand):
            out.append(cand)
        # Add 2nd segment if it looks like a project tag (short)
        if len(parts) > 1:
            sub = parts[1]
            if _is_useful_token(sub) and len(sub) < 30:
                out.append(f"{parts[0]} {sub}")
    return out


def extract_from_calendar(title: str) -> list[str]:
    """Pull customer from calendar event title."""
    return extract_from_subject(title)  # same heuristic works


def load_window() -> dict:
    return json.loads((CTX / "_window.json").read_text())


def load_mail_index() -> list[dict]:
    p = CTX / "mail_threads_index.json"
    if not p.exists():
        return []
    d = json.loads(p.read_text())
    return d.get("threads", [])


def load_chat_compact() -> dict:
    p = CTX / "chat_compact.json"
    if not p.exists():
        return {}
    return json.loads(p.read_text())


def load_calendar() -> list[dict]:
    p = CTX / "_calendar_compact.json"
    if not p.exists():
        return []
    return json.loads(p.read_text())


def load_memory_clients() -> set[str]:
    """Parse memory_baseline.md to extract known client names.

    Looks for section under '## clients' or similar, extracts H3/H4 names."""
    p = CTX / "memory_baseline.md"
    if not p.exists():
        return set()
    text = p.read_text(encoding="utf-8", errors="ignore")
    names = set()
    # Look for client section
    in_clients = False
    for line in text.splitlines():
        if line.startswith("## "):
            in_clients = "client" in line.lower() or "opps" in line.lower()
            continue
        if not in_clients:
            continue
        m = re.match(r"^#{3,4}\s+(.+?)(?:\s*\(|\s*$)", line)
        if m:
            cand = m.group(1).strip()
            if cand and len(cand) < 80:
                names.add(_slug(cand))
    # Also scan whole doc for capitalized customer-looking tokens (broad)
    for line in text.splitlines():
        for m in re.finditer(r"\b([A-Z][A-Za-z0-9]+(?:\s+[A-Z][A-Za-z0-9]+)*)\b", line):
            tok = m.group(1)
            if 3 < len(tok) < 40 and tok.lower() not in {"michael", "kevin", "anthony", "vti", "the", "and"}:
                names.add(_slug(tok))
    return names


def load_prev_brief() -> dict | None:
    """Try to load W-1 snapshot brief if downloaded by compare_brief_v2."""
    p = CTX / "weekly_brief_v2_prev.md"  # compare_brief_v2 saves as .md (raw)
    if not p.exists():
        # try JSON
        for cand in CTX.glob("weekly_brief_v2_*W*.json"):
            try:
                return json.loads(cand.read_text())
            except Exception:
                pass
        return None
    try:
        # the .md is actually JSON dumped to .md per compare_brief_v2
        return json.loads(p.read_text())
    except Exception:
        return None


def main():
    window = load_window()
    mail = load_mail_index()
    chat = load_chat_compact()
    cal = load_calendar()
    memory_known = load_memory_clients()
    prev_brief = load_prev_brief()

    mentions: dict[str, dict] = defaultdict(lambda: {
        "name": "",
        "slug": "",
        "mention_count": 0,
        "sources": [],
        "first_seen": None,
        "intro_via": None,
    })

    def _add(name: str, source: str, date: str = ""):
        slug = _slug(name)
        if not slug or len(slug) < 3:
            return
        rec = mentions[slug]
        if not rec["name"]:
            rec["name"] = name.strip()
            rec["slug"] = slug
        rec["mention_count"] += 1
        rec["sources"].append(source)
        if date and (rec["first_seen"] is None or date < rec["first_seen"]):
            rec["first_seen"] = date

    # Scan mail
    for t in mail:
        sub = t.get("subject", "")
        first_date = (t.get("first_date") or "")[:10]
        # Heuristic: extract from subject
        for name in extract_from_subject(sub):
            _add(name, f"mail:{sub[:50]}", first_date)
        # From sender domain (e.g., danny.thian@wikilabs.asia → "Wiki Labs"-like)
        sender = (t.get("sender") or "").lower()
        if "@" in sender:
            dom = sender.split("@", 1)[1]
            if dom not in EMAIL_DOMAIN_SKIP and not dom.endswith(".vti.com.vn"):
                # Use domain second-level token as proxy
                tok = dom.split(".")[0].capitalize()
                if _is_useful_token(tok):
                    _add(tok, f"mail-domain:{dom}", first_date)

    # Scan chat
    for space_name in chat:
        for name in extract_from_chat_space(space_name):
            _add(name, f"chat:{space_name[:40]}", window["week_start"])

    # Scan calendar
    for e in cal:
        title = e.get("summary", "")
        date = (e.get("start") or "")[:10]
        for name in extract_from_calendar(title):
            _add(name, f"cal:{title[:50]}", date)
        # Also pull external attendee domain
        for a in e.get("attendees", []):
            em = (a.get("email") or "").lower()
            if "@" in em:
                dom = em.split("@", 1)[1]
                if dom not in EMAIL_DOMAIN_SKIP and not dom.endswith(".vti.com.vn"):
                    tok = dom.split(".")[0].capitalize()
                    if _is_useful_token(tok):
                        _add(tok, f"cal-attendee:{dom}", date)

    # Cross-reference with memory
    known_active = []
    new_unknown = []
    for slug, rec in mentions.items():
        if rec["mention_count"] < 1:
            continue
        # Match if slug appears as substring in any memory known name
        is_known = any(slug in m or m in slug for m in memory_known if len(m) > 4)
        entry = {
            "name": rec["name"],
            "mention_count": rec["mention_count"],
            "sources": list(dict.fromkeys(rec["sources"]))[:8],  # dedupe, cap 8
            "first_seen": rec["first_seen"] or window["week_start"],
        }
        if is_known:
            entry["memory_match"] = True
            known_active.append(entry)
        else:
            new_unknown.append(entry)

    # Sort by mention_count desc
    known_active.sort(key=lambda x: -x["mention_count"])
    new_unknown.sort(key=lambda x: -x["mention_count"])

    # Carried RED from prev week
    carried_red = []
    if prev_brief and isinstance(prev_brief, dict):
        for c in prev_brief.get("customers", []):
            if (c.get("priority") or "").upper() == "RED":
                carried_red.append({
                    "name": c.get("customer", c.get("name", "?")),
                    "prev_priority": c.get("priority"),
                    "prev_current_problem": (c.get("current_problem") or "")[:240],
                })

    # Dormant — in memory but no mention this week
    mentioned_slugs = {r["slug"] for r in mentions.values() if r["mention_count"] > 0}
    dormant = []
    for m_slug in sorted(memory_known):
        if len(m_slug) < 5:
            continue
        if not any(m_slug in s or s in m_slug for s in mentioned_slugs if len(s) > 4):
            dormant.append({"name": m_slug, "mentioned_this_week": False})
    dormant = dormant[:30]  # cap

    out = {
        "window": window,
        "stats": {
            "mail_threads_scanned": len(mail),
            "chat_spaces_scanned": len(chat),
            "cal_events_scanned": len(cal),
            "memory_known_clients_count": len(memory_known),
            "discovered_known_active": len(known_active),
            "discovered_new_unknown": len(new_unknown),
            "carried_red_from_prev_week": len(carried_red),
            "dormant_in_memory": len(dormant),
        },
        "known_active": known_active,
        "new_unknown": new_unknown,
        "carried_red_from_prev_week": carried_red,
        "dormant": dormant,
    }

    out_path = CTX / "_discovered_customers.json"
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=1))
    print(f"Discovery → {out_path}")
    print(f"  known_active:               {len(known_active)}")
    print(f"  new_unknown:                {len(new_unknown)}")
    print(f"  carried_red_from_prev_week: {len(carried_red)}")
    print(f"  dormant_in_memory:          {len(dormant)}")
    if new_unknown:
        print("  TOP 5 new_unknown:")
        for n in new_unknown[:5]:
            print(f"    - {n['name']} (mentions={n['mention_count']}, sources={n['sources'][:2]})")
    if carried_red:
        print(f"  Carried RED to monitor: {[c['name'][:40] for c in carried_red[:5]]}")


if __name__ == "__main__":
    main()
