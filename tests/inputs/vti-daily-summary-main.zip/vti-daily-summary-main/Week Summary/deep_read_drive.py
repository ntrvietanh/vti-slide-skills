#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""deep_read_drive.py — Drive deep-read helpers cho Weekly Summary sub-agents.

Use cases:
  1. Extract Drive URLs from mail/chat text (docs.google.com/document, drive.google.com/file, etc.)
  2. Fetch + parse content of Drive files (Gdoc/Docx/PDF/Xlsx/Slides) → text
  3. Search Drive by keyword + date range for customer/opp related files
  4. Search Drive for files SHARED to Michael by external partners

CLI:
  python3 deep_read_drive.py extract-urls <text_file>            # extract Drive URLs from a text file
  python3 deep_read_drive.py extract-urls-from-context           # scan week_context/mail+chat for URLs
  python3 deep_read_drive.py read <file_id_or_url>               # fetch + extract text from a file
  python3 deep_read_drive.py search "<keyword>" [--after 2026-05-04] [--before 2026-05-11]

Library use (import in sub-agent or pipeline):
  from deep_read_drive import (extract_drive_urls, fetch_drive_text,
                                search_drive_by_keyword, search_drive_for_customer)
"""

from __future__ import annotations
import json, re, sys
from pathlib import Path
from typing import Optional
from weekly_lib import (
    load_json, get_drive, load_credentials, log,
    CONTEXT_DIR,
)

# Drive URL patterns
URL_PATTERNS = [
    r"https?://docs\.google\.com/document/d/([a-zA-Z0-9_-]{20,})",
    r"https?://docs\.google\.com/spreadsheets/d/([a-zA-Z0-9_-]{20,})",
    r"https?://docs\.google\.com/presentation/d/([a-zA-Z0-9_-]{20,})",
    r"https?://drive\.google\.com/file/d/([a-zA-Z0-9_-]{20,})",
    r"https?://drive\.google\.com/u/\d+/file/d/([a-zA-Z0-9_-]{20,})",
    r"https?://drive\.google\.com/open\?id=([a-zA-Z0-9_-]{20,})",
    r"https?://drive\.google\.com/drive/folders/([a-zA-Z0-9_-]{20,})",
    r"https?://drive\.google\.com/drive/u/\d+/folders/([a-zA-Z0-9_-]{20,})",
]
URL_RE = re.compile("|".join(URL_PATTERNS), re.IGNORECASE)


def extract_drive_urls(text: str) -> list[dict]:
    """Find all Drive URLs in text. Returns list of {url, file_id, kind}."""
    if not text:
        return []
    out = []
    seen = set()
    for m in URL_RE.finditer(text):
        url = m.group(0)
        # File ID is whichever capture group matched
        file_id = next((g for g in m.groups() if g), None)
        if not file_id or file_id in seen:
            continue
        seen.add(file_id)
        if "/document/" in url: kind = "gdoc"
        elif "/spreadsheets/" in url: kind = "gsheet"
        elif "/presentation/" in url: kind = "gslides"
        elif "/folders/" in url: kind = "folder"
        elif "/file/" in url or "open?id=" in url: kind = "file"
        else: kind = "unknown"
        out.append({"url": url.split("?")[0].split("#")[0], "file_id": file_id, "kind": kind})
    return out


def extract_url_from_anything(s):
    """Accept either a URL or a bare file_id; return (file_id, kind)."""
    if not s: return None, None
    s = s.strip()
    urls = extract_drive_urls(s)
    if urls:
        return urls[0]["file_id"], urls[0]["kind"]
    # Bare ID?
    if re.fullmatch(r"[a-zA-Z0-9_-]{20,}", s):
        return s, "unknown"
    return None, None


# ---------------------------------------------------------------------------
# Fetch & parse file content
# ---------------------------------------------------------------------------
def _drive_get_meta(drive, file_id: str) -> Optional[dict]:
    try:
        return drive.files().get(fileId=file_id, fields="id,name,mimeType,size,modifiedTime,owners,parents").execute()
    except Exception as e:
        log(f"  ! file meta {file_id}: {e}")
        return None


def fetch_drive_text(drive, file_id: str, max_chars: int = 20000) -> dict:
    """Download a Drive file and extract text. Returns {file_id, name, mime, text, truncated, error}."""
    meta = _drive_get_meta(drive, file_id)
    if not meta:
        return {"file_id": file_id, "error": "meta_fetch_failed"}
    mime = meta.get("mimeType", "")
    name = meta.get("name", "?")
    out = {"file_id": file_id, "name": name, "mime": mime,
           "modifiedTime": meta.get("modifiedTime", ""),
           "size": int(meta.get("size", 0) or 0), "text": "", "truncated": False, "error": None}
    try:
        if mime == "application/vnd.google-apps.document":
            raw = drive.files().export(fileId=file_id, mimeType="text/plain").execute()
            text = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else raw
        elif mime == "application/vnd.google-apps.spreadsheet":
            raw = drive.files().export(fileId=file_id, mimeType="text/csv").execute()
            text = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else raw
        elif mime == "application/vnd.google-apps.presentation":
            raw = drive.files().export(fileId=file_id, mimeType="text/plain").execute()
            text = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else raw
        elif mime == "application/pdf":
            raw = drive.files().get_media(fileId=file_id).execute()
            text = _extract_pdf_text(raw)
        elif mime in ("application/vnd.openxmlformats-officedocument.wordprocessingml.document",):
            raw = drive.files().get_media(fileId=file_id).execute()
            text = _extract_docx_text(raw)
        elif mime in ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",):
            raw = drive.files().get_media(fileId=file_id).execute()
            text = _extract_xlsx_text(raw)
        elif mime.startswith("text/"):
            raw = drive.files().get_media(fileId=file_id).execute()
            text = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else raw
        elif mime == "application/vnd.google-apps.folder":
            out["text"] = f"(folder — list contents via search_drive_by_keyword instead)"
            return out
        elif mime.startswith("image/") or mime.startswith("video/") or mime.startswith("audio/"):
            out["text"] = f"({mime} — binary, not text-extractable)"
            return out
        else:
            raw = drive.files().get_media(fileId=file_id).execute()
            try:
                text = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else str(raw)
            except Exception:
                text = f"(mime {mime} — extraction not supported)"
        if len(text) > max_chars:
            out["text"] = text[:max_chars] + "\n\n…[TRUNCATED]…"
            out["truncated"] = True
        else:
            out["text"] = text
    except Exception as e:
        out["error"] = str(e)[:200]
    return out


def _extract_docx_text(raw_bytes: bytes) -> str:
    from io import BytesIO
    from docx import Document
    doc = Document(BytesIO(raw_bytes))
    lines = []
    for p in doc.paragraphs:
        if p.text.strip(): lines.append(p.text)
    for t in doc.tables:
        for row in t.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells: lines.append(" | ".join(cells))
    return "\n".join(lines)


def _extract_xlsx_text(raw_bytes: bytes) -> str:
    from io import BytesIO
    from openpyxl import load_workbook
    wb = load_workbook(BytesIO(raw_bytes), data_only=True, read_only=True)
    lines = []
    for sheet in wb.worksheets:
        lines.append(f"\n## Sheet: {sheet.title}")
        count = 0
        for row in sheet.iter_rows(values_only=True):
            row_cells = [str(c) if c is not None else "" for c in row]
            if any(c.strip() for c in row_cells):
                lines.append(" | ".join(row_cells))
                count += 1
                if count >= 200:
                    lines.append("(…truncated at 200 rows)")
                    break
    return "\n".join(lines)


def _extract_pdf_text(raw_bytes: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            return "(PDF text extraction needs pypdf or PyPDF2 installed)"
    from io import BytesIO
    reader = PdfReader(BytesIO(raw_bytes))
    lines = []
    for page in reader.pages[:50]:  # cap 50 pages
        try:
            t = page.extract_text() or ""
            if t.strip(): lines.append(t)
        except Exception:
            pass
    return "\n\n--- page break ---\n\n".join(lines)


# ---------------------------------------------------------------------------
# Search Drive
# ---------------------------------------------------------------------------
def search_drive_by_keyword(drive, keyword: str, after: str = None, before: str = None,
                              page_size: int = 25) -> list[dict]:
    """Search Drive by keyword in filename OR fullText. Returns list of file metadata."""
    qparts = [f"(name contains '{keyword}' or fullText contains '{keyword}')",
              "trashed = false"]
    if after: qparts.append(f"modifiedTime > '{after}T00:00:00Z'")
    if before: qparts.append(f"modifiedTime < '{before}T23:59:59Z'")
    q = " and ".join(qparts)
    try:
        resp = drive.files().list(
            q=q, fields="files(id,name,mimeType,modifiedTime,owners(emailAddress,displayName),size,webViewLink)",
            pageSize=page_size, orderBy="modifiedTime desc"
        ).execute()
        return resp.get("files", [])
    except Exception as e:
        log(f"  search_drive_by_keyword({keyword}): {e}")
        return []


def search_drive_for_customer(drive, customer_keywords: list[str],
                                after: str, before: str, page_size: int = 15) -> dict:
    """Run a search per customer keyword, dedupe by file_id, return {file_id: meta} dict."""
    seen = {}
    for kw in customer_keywords:
        files = search_drive_by_keyword(drive, kw, after=after, before=before, page_size=page_size)
        for f in files:
            seen[f["id"]] = f
    return seen


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _cmd_extract_urls_from_context():
    """Scan week_context/mail_threads.json + chat_compact.json for Drive URLs."""
    out = {"mail_threads": [], "chat_spaces": []}
    mail = load_json(CONTEXT_DIR / "mail_threads.json")
    if mail:
        for t in mail.get("threads", []):
            blob = json.dumps(t, ensure_ascii=False)
            urls = extract_drive_urls(blob)
            if urls:
                out["mail_threads"].append({"thread_id": t.get("thread_id"), "subject": t.get("subject", "")[:80], "urls": urls})
    chat = load_json(CONTEXT_DIR / "chat_compact.json")
    if chat:
        for space_name, sp in chat.items():
            urls = []
            for m in sp.get("messages", []):
                urls.extend(extract_drive_urls(m.get("text", "")))
            # dedupe
            seen, dedupe = set(), []
            for u in urls:
                if u["file_id"] not in seen:
                    seen.add(u["file_id"])
                    dedupe.append(u)
            if dedupe:
                out["chat_spaces"].append({"space_name": space_name, "urls": dedupe})
    print(json.dumps(out, ensure_ascii=False, indent=2))
    # Also save
    out_path = CONTEXT_DIR / "_drive_urls_from_context.json"
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2))
    log(f"Wrote {out_path}")
    log(f"  Mail threads with Drive URLs: {len(out['mail_threads'])}")
    log(f"  Chat spaces with Drive URLs: {len(out['chat_spaces'])}")


def _cmd_read(arg: str):
    """Fetch and print text of a Drive file."""
    file_id, kind = extract_url_from_anything(arg)
    if not file_id:
        print(f"ERROR: can't parse {arg} as Drive URL or file ID", file=sys.stderr)
        sys.exit(2)
    creds = load_credentials()
    drive = get_drive(creds)
    result = fetch_drive_text(drive, file_id)
    print(json.dumps({k: v for k, v in result.items() if k != "text"}, indent=2))
    print("\n--- TEXT ---\n")
    print(result.get("text", "")[:5000])


def _cmd_search(args):
    """Search Drive by keyword (with optional --after / --before)."""
    after = before = None
    kw = []
    i = 0
    while i < len(args):
        if args[i] == "--after" and i+1 < len(args):
            after = args[i+1]; i += 2
        elif args[i] == "--before" and i+1 < len(args):
            before = args[i+1]; i += 2
        else:
            kw.append(args[i]); i += 1
    if not kw:
        print("Usage: search <keyword> [--after YYYY-MM-DD] [--before YYYY-MM-DD]", file=sys.stderr)
        sys.exit(2)
    creds = load_credentials()
    drive = get_drive(creds)
    files = search_drive_by_keyword(drive, " ".join(kw), after=after, before=before)
    print(json.dumps(files, indent=2, ensure_ascii=False))


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__); sys.exit(0)
    cmd = args[0]
    if cmd == "extract-urls" and len(args) > 1:
        text = Path(args[1]).read_text(encoding="utf-8", errors="replace")
        print(json.dumps(extract_drive_urls(text), indent=2))
    elif cmd == "extract-urls-from-context":
        _cmd_extract_urls_from_context()
    elif cmd == "read":
        _cmd_read(args[1])
    elif cmd == "search":
        _cmd_search(args[1:])
    else:
        print(__doc__); sys.exit(2)


if __name__ == "__main__":
    main()
