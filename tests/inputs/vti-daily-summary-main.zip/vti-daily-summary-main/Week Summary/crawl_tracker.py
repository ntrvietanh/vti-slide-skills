#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""crawl_tracker.py — Download Action_Tracker.xlsx và slice theo window."""
from __future__ import annotations
import io, sys
from datetime import date, datetime
from weekly_lib import (
    TRACKER_FILE_NAME, TRACKER_SNAPSHOT_PATH, WINDOW_PATH,
    find_file, get_daily_prep_folder_id, get_drive,
    load_credentials, load_json, log, save_json,
)


def _parse_date(s):
    if not s: return None
    if isinstance(s, date) and not isinstance(s, datetime): return s
    if isinstance(s, datetime): return s.date()
    s = str(s).strip()
    if not s: return None
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%Y-%m-%d %H:%M:%S"):
        try: return datetime.strptime(s, fmt).date()
        except ValueError: continue
    return None


def _norm_header(c):
    s = (str(c).strip().lower() if c else "")
    # "Notes (your space)" -> "notes"; "Output / Deliverable" -> "output"
    s = s.replace("(your space)", "").replace("/", " ")
    parts = [p for p in s.split() if p]
    joined = "_".join(parts)
    # canonicalize
    canon_map = {
        "output_deliverable": "output",
        "date_opened": "date_opened",
        "last_updated": "last_updated",
        "source_meeting": "source_meeting",
    }
    return canon_map.get(joined, joined)


def _row_to_dict(row, headers):
    return {h: (row[i] if i < len(row) else None) for i, h in enumerate(headers)}


def _normalize_row(d):
    out = {}
    for k, v in d.items():
        if v is None: out[k] = None
        elif isinstance(v, (datetime, date)): out[k] = v.isoformat()
        else: out[k] = str(v).strip() if isinstance(v, str) else v
    return out


def crawl():
    win = load_json(WINDOW_PATH)
    if not win:
        log("ERROR: window not computed")
        sys.exit(2)
    week_start = date.fromisoformat(win["week_start"])
    week_end = date.fromisoformat(win["week_end"])
    creds = load_credentials()
    drive = get_drive(creds)
    parent_id = get_daily_prep_folder_id(drive)
    file_id = find_file(drive, TRACKER_FILE_NAME, parent_id)
    if not file_id:
        log(f"WARN: {TRACKER_FILE_NAME} not in Daily Meeting Prep folder")
        save_json(TRACKER_SNAPSHOT_PATH, {"window": win, "tracker_found": False})
        return

    log(f"Downloading {TRACKER_FILE_NAME} (id={file_id})...")
    from openpyxl import load_workbook
    from googleapiclient.http import MediaIoBaseDownload
    req = drive.files().get_media(fileId=file_id)
    buf = io.BytesIO()
    dl = MediaIoBaseDownload(buf, req)
    done = False
    while not done:
        _, done = dl.next_chunk()
    buf.seek(0)
    wb = load_workbook(buf, data_only=True)
    ws = wb["All"] if "All" in wb.sheetnames else wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        log("WARN: All sheet empty")
        save_json(TRACKER_SNAPSHOT_PATH, {"window": win, "tracker_found": True, "all_rows": []})
        return

    # Detect header row in first 3 rows
    headers = None
    data_start = 0
    for i, r in enumerate(rows[:3]):
        normed = [_norm_header(c) for c in r]
        if r and "id" in normed:
            headers = normed
            data_start = i + 1
            break
    if not headers:
        log("ERROR: cannot detect header row")
        sys.exit(3)
    log(f"Normalized headers: {headers}")

    all_rows = []
    for r in rows[data_start:]:
        if not any(r): continue
        all_rows.append(_normalize_row(_row_to_dict(r, headers)))
    log(f"Parsed {len(all_rows)} action rows")

    opened, closed, cancelled = [], [], []
    overdue, carry, no_dl = [], [], []
    for r in all_rows:
        st = (r.get("status") or "").strip()
        d_open = _parse_date(r.get("date_opened"))
        d_upd = _parse_date(r.get("last_updated"))
        d_dl = _parse_date(r.get("deadline"))
        if d_open and week_start <= d_open <= week_end:
            opened.append(r)
        if st == "Done" and d_upd and week_start <= d_upd <= week_end:
            closed.append(r)
        if st == "Cancelled" and d_upd and week_start <= d_upd <= week_end:
            cancelled.append(r)
        if st not in ("Done", "Cancelled"):
            if d_dl is None: no_dl.append(r)
            elif d_dl < week_end: overdue.append(r)
            elif d_dl > week_end: carry.append(r)

    out = {
        "window": win, "tracker_found": True, "tracker_file_id": file_id,
        "headers": headers,
        "stats": {
            "total_rows": len(all_rows),
            "opened_this_week": len(opened),
            "closed_this_week": len(closed),
            "cancelled_this_week": len(cancelled),
            "still_open_overdue": len(overdue),
            "carry_to_next_week": len(carry),
            "still_open_no_deadline": len(no_dl),
            "all_open": len(overdue) + len(carry) + len(no_dl),
        },
        "opened_this_week": opened,
        "closed_this_week": closed,
        "cancelled_this_week": cancelled,
        "still_open_overdue": overdue,
        "carry_to_next_week": carry,
        "still_open_no_deadline": no_dl,
    }
    save_json(TRACKER_SNAPSHOT_PATH, out)
    log(f"Tracker snapshot -> {TRACKER_SNAPSHOT_PATH}")
    log(f"  Stats: {out['stats']}")


if __name__ == "__main__":
    crawl()
