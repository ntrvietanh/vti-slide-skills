{
  "meta": {
    "run_date": "2026-05-17",
    "week_label": "04/05 → 10/05/2026",
    "iso_week": "2026-W19",
    "format": "v2-deep-research",
    "deep_research_agents": 5,
    "model": "opus"
  },
  "summary": {
    "decisions_signoffs": [
      "KGI Trading (via Ufinity): Week 04-10/05/2026 was the kickoff week of the KGI Trading Platform proposal cycle. Tue 05/05 Mark Choon (Ufinity Account Director) emailed Tyson Nguyen confirm",
      "CA Web (Corporate Actions Web — Ufinity sub-project, KGI parallel): Week 04-10/05/2026 saw CA Web BQ kickoff in parallel with KGI Trading. Tue 05/05 Mark Choon's NDA-pending email included CA Web as the second budgetary scope (t",
      "Ufinity ODC (Java + .NET Full-stack Offshore Devs): Week 04-10/05/2026 ran two parallel ODC threads. (1) Java ODC billing: Thu 07/05 Charlotte (Quyen Nguyen Thi Do) sent Daniel Goh (Ufinity) the Minutes of Accept",
      "Facial Recognition Storage (Ufinity ODC8 audit dependency): Week 04-10/05/2026 saw a high-tempo audit-evidence cycle driven by Chen Yijin Anthony (Ufinity BDG) for the GovTech ODC renewal qualification. Fri 08/05 16:22 A",
      "AsiaPac IPOS Grow: W19 (04/05-10/05/2026) — Thứ Hai 04/05/2026 03:48 UTC, Kevin Nguyen (Sales Manager APAC, VTI) gửi mail '[Re: IPOS Grow]' tới Robert Wong (Director Sales, AsiaPa",
      "AsiaPac MOD Smart Cookhouse: W19 (04/05-10/05/2026) dự án đang ở giai đoạn close-out. Thứ Năm 08/05/2026 Dat Phan (DS, VTI) gửi mail 'UAT Milestone Sign-off - AsiaPac - MOD Smart Cookhouse ",
      "AsiaPac Cora Cloud & App Migration: W19 (04/05-10/05/2026) là tuần cao điểm escalation. Thứ Hai 04/05/2026 11:43 UTC Tyson Nguyen reply mail 'Re: AsiaPac | VTI - Cora Cloud & App Migration - Docum",
      "Mitsubishi Corporation (MC HCMC + MC SG): Tuan W19 (04/05/2026 -> 10/05/2026): (1) MC HCMC IT body-shop 6-month trial - Saoko Miyamoto (Mitsubishi Corp Tokyo HR) thread 'Following up about IT personnel'",
      "PSA Marine PSAM - DevSecOps Milestone 6 (End-of-Warranty): Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[PSAM & VTI] DevSecOps Project - Payment Review for Milestone 6 - End of Warranty' - Charlotte (Quyen Nguyen Thi Do",
      "Wiki Labs (NxGen AIOps / Lucid Impact): Tuần W19 (04-10/05/2026) là tuần kick-off tender response cho NxGen HDB AI: (1) Wed 06/05/2026 Tyson Nguyen chair online 'AI Ops Opportunity Discussion' với Wik",
      "UPP — Salesforce/NPSP/Drupal RA: Tuần W19 (04-10/05/2026) là tuần cao điểm UPP với 3 meetings liên tiếp: (1) Mon 05/05/2026 14:00 ICT '[UPP & VTI] Customer Sync-up on Salesforce, NPSP, and Drup",
      "Terrabit Networks Introduction: 1st intro meeting held Mon 11/05/2026 (carried into next week's window per baseline). Anthony Tee intro to Simon (MD) + Dominic. In meeting NDA two-way agreed. ",
      "Concentrix (Bich Ngoc Thach Mia + Tuong Vy): Khanh Tran Duy sent VTI corporate deck + resource summary to Bich Ngoc Thach (Mia, Vietnam Lead Consultant Innovation & Transformation) + chi Vy on Tue 05/05/20",
      "Technovation (SW Tang, Penang): Anthony Tee sent intro email 'Technovation/VTI Meet' Wed 06/05/2026 11:47 ICT to SW Tang (swtang@technovation.com.my) CC Michael Nguyen + Kevin Nguyen + Tung Ng",
      "Digital Concierge Solutions for RWS Hospitality (NEW - Anthony's network play): Kevin Nguyen sent Wed 06/05/2026 21:00 UTC email '[Anthony & VTI] VTI Track Records on Digital Concierge Solutions for Hospitality' to Anthony Tee - bundled 7 h",
      "HopeRun Software Singapore - NDA (Tyson - Boon Siang Sim): NO activity in week 04-10/05/2026. Thread history: NDA negotiation started Nov 2025 (Tung Nguyen Ba ↔ boonsiang@hoperun.com.sg), put on hold Dec 2025 due to Hop"
    ],
    "meetings_touchpoints": [
      "Mon 4/5: [VTI BD] Weekly Meeting",
      "Mon 4/5: [VAP] Hoàn ứng Malay 07-10/04/2026",
      "Mon 4/5: [VAP&Legal] EP Concern Resolve",
      "Tue 5/5: BCDR for ODC room",
      "Tue 5/5: [TF & VTI] Sync-up on Salesforce, NPSP, and Drupal Resources Augmentation Reques",
      "Tue 5/5: [UPP & VTI] Customer Sync-up on Salesforce, NPSP, and Drupal Resources Augmentat",
      "Tue 5/5: [Volkswagen Group-IT & VTI] Introduction Meeting ",
      "Wed 6/5: [UPP & VTI] Discuss quote for Salesforce and NPSP Resources Augmentation Request",
      "Wed 6/5: [Online] AI Ops Opportunity Discussion",
      "Thu 7/5: UF x VTI: KGI requirements sharing for budgetary quote",
      "Thu 7/5: [UPP & VTI] 2nd Customer Sync-up on Salesforce, NPSP, and Drupal Resources Augme",
      "Thu 7/5: PSAM WMS-X Internal Sync-up pre-submission",
      "Thu 7/5: AsiaPac | VTI - Cora Cloud & App Migration - Documentation - Meeting",
      "Thu 7/5: VAP UF Syncup",
      "Fri 8/5: Mr. Anthony & VTI - Weekly Sync-up ",
      "Fri 8/5: [SWAT Mobility & VTI] Sync-up on the customizations for enterprise clients",
      "Fri 8/5: Re-hearsal trước interview MC HCMC ",
      "Fri 8/5: Rehearsal IT MC HCMC",
      "Fri 8/5: VAP D3 - Remind internal - Collect Detailed AI Ops use cases & demo"
    ],
    "new_opps_intros": [
      "GovTech intro (via Ufinity ODC8 facility visit): Week 04-10/05/2026 introduced a NEW GovTech touchpoint via Ufinity's ODC governance. Mon 11/05 (just at W19 close) Anthony Chen Yijin (Ufini",
      "AsiaPac IPOS II New Workbench: W19 (04/05-10/05/2026) là điểm nóng escalation. Thứ Hai 05/05/2026 09:17 UTC, Michael Nguyen reply mail của Linh Tran Quang (PM D1, gửi 29/0",
      "Avows — New Development Opportunity: Tuần W19 (04-10/05/2026): Không có mail thread Avows / Francis Lim (francis.l@avowstech.com) trong mail_threads.json, không có chat space Av",
      "Volkswagen Group-IT (NEW intro NOT via Anthony - via Kevin Nguyen + Dung Nguyen Thi forward): Intro meeting held Tue 05/05/2026 10:30 CEST / 15:30 ICT ([Volkswagen Group-IT & VTI] Introduction Meeting, organizer kevin.nguyen, MS Teams",
      "Terrabit Networks Introduction: 1st intro meeting held Mon 11/05/2026 (carried into next week's window per baseline). Anthony Tee intro to Simon (MD) + Dominic. In meeting ",
      "Technovation (SW Tang, Penang): Anthony Tee sent intro email 'Technovation/VTI Meet' Wed 06/05/2026 11:47 ICT to SW Tang (swtang@technovation.com.my) CC Michael Nguyen + Ke",
      "Digital Concierge Solutions for RWS Hospitality (NEW - Anthony's network play): Kevin Nguyen sent Wed 06/05/2026 21:00 UTC email '[Anthony & VTI] VTI Track Records on Digital Concierge Solutions for Hospitality' to Antho"
    ],
    "issues_blockers_red": [
      "KGI Trading (via Ufinity): VTI does not have an internal financial-domain SME for KGI Trading (admitted by Long Vu Thanh: 'call thì call được, nhưng k chắc nghe có hiểu nổi khách k') and ",
      "CA Web (Corporate Actions Web — Ufinity sub-project, KGI parallel): D9 resource bottleneck: Tuan Viet pulled into H2biz/Hang Moon firefight leaving Tuan Mai Van light on senior partner, Thang Nguyen Van 1 picking up estimate fra",
      "Facial Recognition Storage (Ufinity ODC8 audit dependency): Facial recognition system (FaceXpress vendor app) does not expose a storage-limit setting page from the standard user/admin UI — Tyson initially answered 'no se",
      "AsiaPac IPOS II New Workbench: RED. (1) Dự án underestimate ~50 MMs (33% over scope 150 MM) — Michael đã chốt 13/05/2026 start inform khách CR6. Risk: AsiaPac (Do Manh Cuong, Alvin See) pushb",
      "AsiaPac C99 Sembcorp Phase 1: RED. (1) Khách (Ling) không thấy button Convert to LI — root cause unclear: VTI đã update source nhưng AsiaPac side (Elvis, Anurag) chưa deploy code; Anurag đan",
      "AsiaPac Cora Cloud & App Migration: RED. (1) Khách AsiaPac (Do Manh Cuong, Anthony Tor) escalate liên tục 3 email trong 8 ngày (30/04, 05/05, 08/05/2026) đòi outstanding documents + handover — con",
      "Mitsubishi Corporation (MC HCMC + MC SG): RED - Khach MC HCMC da doi quyet dinh candidate Toan ~2 tuan; Khanh chua gui email accept 6-month trial cho Tam-san + Dung-san; Charlotte chua draft trial contr",
      "Wiki Labs (NxGen AIOps / Lucid Impact): RED — đây là PRIMARY ACTIVE OPP / ESCALATION. (1) Tender deadline 21/05/2026 cực gấp; proposal v1 + budget phải gửi Ian Choy 21/05/2026. (2) Demo materials (Dyn",
      "Volkswagen Group-IT (NEW intro NOT via Anthony - via Kevin Nguyen + Dung Nguyen Thi forward): Customer declined this round - VTI lacks European enterprise track-record proof points. No active follow-up scheduled. Door left open for future. Risk: this dec",
      "OP EP Agreement (Recruit Express) - Service Agreement for Michael EP Application: Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[Recruit Express & VTI APAC] Service Agreement for EP Application Services' - Karin Chan (Recruit Express",
      "OP OCBC / Bank account VTI APAC PTE. LTD. - Bank statement cho Global PSA first electronic payment: Evangeline Tan (EVANGELI@globalpsa.com) gui yeu cau bank statement header VTI APAC PTE. LTD. lan dau ngay 06/04/2026. Den 06/05/2026 Evangeline gui re",
      "OP ISMS Audits - ODC Audit April 2026 (Ufinity/Anthony Chen): Thread 'ODC Audit - Apr 2026' - Chen Yijin Anthony (Ufinity) request bien ban audit thang 4/2026 ngay 01/05/2026: Biometric System Access Report + Log"
    ],
    "internal_operations": [
      "EP Agreement (Recruit Express) - Service Agreement for Michael EP Application [RED]: Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[Recruit Express & VTI APAC] Service Agreement for EP Application Services' - Karin Chan (Recruit Express",
      "OCBC / Bank account VTI APAC PTE. LTD. - Bank statement cho Global PSA first electronic payment [RED]: Evangeline Tan (EVANGELI@globalpsa.com) gui yeu cau bank statement header VTI APAC PTE. LTD. lan dau ngay 06/04/2026. Den 06/05/2026 Evangeline gui re",
      "CorpZap registered address + Company Secretary (ACRA update VTI APAC PTE. LTD.) [AMBER]: Thread '[VTI APAC & CorpZap] Guidance Required for Registered Address and Company Profile Updates' - Charlotte lam viec voi Nuraini (CorpZap, CS provi",
      "SG hire wrap-up - Hoan ung Malaysia trip 07-10/04/2026 [AMBER]: Calendar event '[VAP] Hoan ung Malay 07-10/04/2026' Mon 04/05/2026 14:00 ICT - close out chuyen Malaysia trip thang 4/2026 cua VAP team (sourcing/recr",
      "vitX Platform Engineer (01 HC bodyshop) - partnership Mind Supernova [AMBER]: Tuan W19: Thread 'VTI - vitX Platform Engineer (01 Headcount) | Ho tro trien khai hop dong hop tac voi Mind Supernova' - Tyson Nguyen Ba de xuat bodys",
      "Sembcorp IT Infrastructure Assessment and Maintenance - Commercial position + headcount buyout [AMBER]: Chat space '[VAP] Sembcorp IT Infrastructure Assessment and Maintenance' (27 msgs trong tuan): Sembcorp phan hoi vu IT - nhu cau thue part-time trong ",
      "ISMS Audits - ODC Audit April 2026 (Ufinity/Anthony Chen) [RED]: Thread 'ODC Audit - Apr 2026' - Chen Yijin Anthony (Ufinity) request bien ban audit thang 4/2026 ngay 01/05/2026: Biometric System Access Report + Log",
      "BCDR for ODC room (GovTech renewal qualification) [AMBER]: Calendar 'Invitation: BCDR for ODC room' Tue 05/05/2026 10:00-11:00 ICT (Microsoft Teams) - organizer Chen Yijin Anthony (Ufinity), guests VTI ISMS, T",
      "Sembcorp AMS Outsourcing L1 & L1.5 Service RFP - tender evaluation pending [AMBER]: Thread 'Re: Invitation for AMS Outsourcing - L1 & L1.5 Service RFP' - VTI da submit GEP tender ngay 01/04/2026 (Price Sheet + Supplier Prequalificatio",
      "Internal ISMS approver authority debate (TRN vs DLs) + ISMS quiz improvement [AMBER]: Chat space 'TRN vs DLs' (156 msgs trong tuan) tranh luan policy ISMS: IT co nen giu quyen approver duy nhat cho viec cam thiet bi ngoai vao mang cty k",
      "Weekly wrap-up template - Anthony Tee Friday sync new rule [AMBER]: Anthony Tee (VTI APAC Senior Advisor) ban hanh NEW RULE tu Fri 15/05/2026: Michael gui weekly wrap-up TRUOC Anthony sync moi Fri morning. Template can"
    ],
    "customers_activity_brief": [
      "KGI Trading (via Ufinity) [RED]: Week 04-10/05/2026 was the kickoff week of the KGI Trading Platform proposal cycle. Tue 05/05 Mark Choon (Ufinity Account Director) emailed ",
      "CA Web (Corporate Actions Web — Ufinity sub-project, KGI parallel) [RED]: Week 04-10/05/2026 saw CA Web BQ kickoff in parallel with KGI Trading. Tue 05/05 Mark Choon's NDA-pending email included CA Web as the secon",
      "Ufinity ODC (Java + .NET Full-stack Offshore Devs) [AMBER]: Week 04-10/05/2026 ran two parallel ODC threads. (1) Java ODC billing: Thu 07/05 Charlotte (Quyen Nguyen Thi Do) sent Daniel Goh (Ufinity) t",
      "Facial Recognition Storage (Ufinity ODC8 audit dependency) [RED]: Week 04-10/05/2026 saw a high-tempo audit-evidence cycle driven by Chen Yijin Anthony (Ufinity BDG) for the GovTech ODC renewal qualificatio",
      "IHL bridge (Ufinity ODC <-> AsiaPac/IHL — context only this week) [GREEN]: Week 04-10/05/2026 had NO direct Ufinity-IHL bridging activity. The Ufinity ODC8 workstream is shared physical/governance scope (audit, faci",
      "GovTech intro (via Ufinity ODC8 facility visit) [AMBER]: Week 04-10/05/2026 introduced a NEW GovTech touchpoint via Ufinity's ODC governance. Mon 11/05 (just at W19 close) Anthony Chen Yijin (Ufini",
      "AsiaPac IPOS Grow [GREEN]: W19 (04/05-10/05/2026) — Thứ Hai 04/05/2026 03:48 UTC, Kevin Nguyen (Sales Manager APAC, VTI) gửi mail '[Re: IPOS Grow]' tới Robert Wong (Di",
      "AsiaPac IPOS II New Workbench [RED]: W19 (04/05-10/05/2026) là điểm nóng escalation. Thứ Hai 05/05/2026 09:17 UTC, Michael Nguyen reply mail của Linh Tran Quang (PM D1, gửi 29/0",
      "AsiaPac MOD Smart Cookhouse [AMBER]: W19 (04/05-10/05/2026) dự án đang ở giai đoạn close-out. Thứ Năm 08/05/2026 Dat Phan (DS, VTI) gửi mail 'UAT Milestone Sign-off - AsiaPac - ",
      "AsiaPac C99 Sembcorp Phase 1 [RED]: W19 (04/05-10/05/2026) chat space Space_[VAP & D9] AsiaPac - C99 Sembcorp - System Enhancement (Phase 1) (78 msgs total) cực kỳ active xoay ",
      "AsiaPac SPPL [AMBER]: W19 (04/05-10/05/2026) chat space Space_AsiaPac-SPPL - VTI Project Teams (API GW & Microservices) (75 msgs) cực kỳ active xoay quanh việc so",
      "AsiaPac IHL Portal [AMBER]: W19 (04/05-10/05/2026) KHÔNG có IHL Portal CR Part 1/Part 2/Odoo/Ariba activity nào — toàn bộ scope expansion (Kit Yi Chow 5 deliverables, J",
      "AsiaPac Cora Cloud & App Migration [RED]: W19 (04/05-10/05/2026) là tuần cao điểm escalation. Thứ Hai 04/05/2026 11:43 UTC Tyson Nguyen reply mail 'Re: AsiaPac | VTI - Cora Cloud & A",
      "Mitsubishi Corporation (MC HCMC + MC SG) [RED]: Tuan W19 (04/05/2026 -> 10/05/2026): (1) MC HCMC IT body-shop 6-month trial - Saoko Miyamoto (Mitsubishi Corp Tokyo HR) thread 'Following up",
      "VTI Da Nang Grand Opening Ceremony (22-23/05/2026) [AMBER]: Tuan W19 (04/05/2026 -> 10/05/2026): VTI Da Nang Grand Opening Ceremony 22-23/05/2026 - Kevin Nguyen dieu phoi email thread '[MC & VTI] Invi",
      "PSA Marine PSAM - DevSecOps Milestone 6 (End-of-Warranty) [GREEN]: Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[PSAM & VTI] DevSecOps Project - Payment Review for Milestone 6 - End of Warranty' - Charlotte ",
      "PSA PSAM Warehouse (Site Visit BQ Follow-Up R13.1/R13.2) [AMBER]: Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[Request for BQ] Follow-Up on PSAM Warehouse Site Visit' - sau site visit 28/04/2026, Allen L. ",
      "Wiki Labs (NxGen AIOps / Lucid Impact) [RED]: Tuần W19 (04-10/05/2026) là tuần kick-off tender response cho NxGen HDB AI: (1) Wed 06/05/2026 Tyson Nguyen chair online 'AI Ops Opportunity",
      "SLW Technology — Magento Developers [AMBER]: Tuần W19 (04-10/05/2026): SLW Technology là thầu chính (Singapore end-client công ty sản xuất quần áo) — cần 10 Magento 2 Developers, 3+ năm",
      "UPP — Salesforce/NPSP/Drupal RA [AMBER]: Tuần W19 (04-10/05/2026) là tuần cao điểm UPP với 3 meetings liên tiếp: (1) Mon 05/05/2026 14:00 ICT '[UPP & VTI] Customer Sync-up on Salesf",
      "SWAT Mobility — Customization [AMBER]: Tuần W19 (04-10/05/2026): Thu 08/05/2026 06:06 ICT Kevin Nguyen gửi 'Invitation: [SWAT Mobility & VTI] Sync-up on the customizations for ent",
      "Sembcorp IT Infrastructure (separate from C99) [AMBER]: Tuần W19 (04-10/05/2026): Chat space [VAP] Sembcorp IT Infrastructure Assessment and Maintenance (27 msgs trong tuần) phát hiện scope MỚI: S",
      "GITS — Offshore Magento Bodyshop [AMBER]: Tuần W19 (04-10/05/2026): GITS là recruiting vendor VTI chọn để source CV cho case SLW Technology (đính kèm — case CV Magento Developers 10 ",
      "ALPSoft — SG Cloud Engineer Recruitment [GREEN]: Tuần W19 (04-10/05/2026): Mail thread '[ALPSoft & VTI] Recruitment Service for On-site Cloud Engineer in Singapore' (8 msgs, last 04/05/2026",
      "Avows — New Development Opportunity [GREEN]: Tuần W19 (04-10/05/2026): Không có mail thread Avows / Francis Lim (francis.l@avowstech.com) trong mail_threads.json, không có chat space Av",
      "Anthony Tee - Weekly Sync-up + Expense Apr 2026 [GREEN]: Mr. Anthony & VTI Weekly Sync-up scheduled Fri 08/05/2026 09:00 SGT (Google Meet meet.google.com/gba-yjpt-hoe, organizer Kevin Nguyen, atten",
      "Volkswagen Group-IT (NEW intro NOT via Anthony - via Kevin Nguyen + Dung Nguyen Thi forward) [RED]: Intro meeting held Tue 05/05/2026 10:30 CEST / 15:30 ICT ([Volkswagen Group-IT & VTI] Introduction Meeting, organizer kevin.nguyen, MS Teams",
      "Terrabit Networks Introduction [AMBER]: 1st intro meeting held Mon 11/05/2026 (carried into next week's window per baseline). Anthony Tee intro to Simon (MD) + Dominic. In meeting ",
      "Dialogg AI (Thao Nguyen) [AMBER]: Re-engagement nudge email Fri 08/05/2026 02:00 UTC from thao.nguyen@dialogg.ai to Michael Nguyen + Kevin Nguyen: 'Em hy vọng là vẫn được hai",
      "Hellopine (Pongsak Kongrattana, Bangkok) [GREEN]: Yoshiyama Kotaro (VTI VVN Japan team) Bangkok site visit logistics finalized in week 04-10/05/2026 for Thu 14/05/2026 10:00 Hellopine office",
      "Concentrix (Bich Ngoc Thach Mia + Tuong Vy) [AMBER]: Khanh Tran Duy sent VTI corporate deck + resource summary to Bich Ngoc Thach (Mia, Vietnam Lead Consultant Innovation & Transformation) + ch",
      "Technovation (SW Tang, Penang) [AMBER]: Anthony Tee sent intro email 'Technovation/VTI Meet' Wed 06/05/2026 11:47 ICT to SW Tang (swtang@technovation.com.my) CC Michael Nguyen + Ke",
      "Tenant City / Flexi Group (Virtual Office Tour - Jason Ong, Santhosh MV) [GREEN]: Original thread Jan 2026 (08-13/01): Kevin Nguyen + jason@tenantcity.com.sg + santhosh.mv@theflexigroup.com - Commonground + The Hive office",
      "Digital Concierge Solutions for RWS Hospitality (NEW - Anthony's network play) [AMBER]: Kevin Nguyen sent Wed 06/05/2026 21:00 UTC email '[Anthony & VTI] VTI Track Records on Digital Concierge Solutions for Hospitality' to Antho",
      "HopeRun Software Singapore - NDA (Tyson - Boon Siang Sim) [GREEN]: NO activity in week 04-10/05/2026. Thread history: NDA negotiation started Nov 2025 (Tung Nguyen Ba ↔ boonsiang@hoperun.com.sg), put on hold"
    ]
  },
  "operation": [
    {
      "item": "EP Agreement (Recruit Express) - Service Agreement for Michael EP Application",
      "priority": "RED",
      "context": "Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[Recruit Express & VTI APAC] Service Agreement for EP Application Services' - Karin Chan (Recruit Express, EP Business Specialist) dang doi VTI gui version voi 2 outstanding clauses Legal da raise. Calendar invite '[VAP&Legal] EP Concern Resolve' Mon 04/05/2026 16:00 ICT; tiep theo Charlotte gui calendar '[VAP&RE] EP Agreement Discussion' Mon 11/05/2026 voi Kevin + Tri Truong Trong Ngoc - thao luan internal redline + clause 45-day termination notice. Day la Service Agreement EP Application Services + Appendix C fee structure; sau khi sign se start MCF candidate interviews 4-6 tuan cho Michael's EP. Tracker carry: Charlotte gui redline toi Karin (DL 13/05/2026 RED), Tri sign-off 45-day termination (DL 15/05/2026), Charlotte gui v3 + Docusign (DL 15/05/2026).",
      "tasks": [
        {
          "title": "Gui EP agreement redline toi Karin Chan voi deadline phan hoi 16/05/2026",
          "status": "Open - chua gui",
          "pic": "Charlotte (Quyen Nguyen Thi Do)",
          "next_action": "Hoan tat redline 2 outstanding clauses tu Legal, gui Karin Chan + set deadline ro 16/05/2026",
          "deadline": "13/05/2026",
          "priority": "RED"
        },
        {
          "title": "Final redline sign-off voi 45-day termination notice clause",
          "status": "Open - phu thuoc redline phia Charlotte",
          "pic": "Tri Truong Trong Ngoc (VTI Legal)",
          "next_action": "Review redline Charlotte, confirm clause 45-day termination, ky sign-off",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Gui EP final draft v3 toi Karin Chan + Docusign envelope",
          "status": "Pending - sau khi Tri sign-off",
          "pic": "Charlotte (Quyen Nguyen Thi Do)",
          "next_action": "Generate Docusign envelope, gui Karin Chan ky (Karin co pattern ky som 1 ngay truoc deadline)",
          "deadline": "15/05/2026 (target Karin sign 16/05/2026)",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "OCBC / Bank account VTI APAC PTE. LTD. - Bank statement cho Global PSA first electronic payment",
      "priority": "RED",
      "context": "Evangeline Tan (EVANGELI@globalpsa.com) gui yeu cau bank statement header VTI APAC PTE. LTD. lan dau ngay 06/04/2026. Den 06/05/2026 Evangeline gui reminder lan 2 (mail '[Request of bank details for VTI APAC PTE. LTD.]'). Day la dieu kien internal control de Global PSA xu ly first electronic payment cho VTI APAC PTE. LTD. (lien quan invoice 1017 DevSecOps EOW da submit Oracle 12/05/2026). Tinh den cuoi W19 (10/05/2026) Michael van chua reply - overdue ~10 ngay ke tu reminder, ~34 ngay ke tu request goc.",
      "tasks": [
        {
          "title": "Cung cap screenshot/copy bank statement header VTI APAC PTE. LTD. cho Evangeline Tan (Global PSA)",
          "status": "RED - Qua han (Evangeline da ping 2 lan chua co phan hoi cua Michael)",
          "pic": "Michael Nguyen + BDG team",
          "next_action": "Lien he ngan hang (OCBC/DBS/UOB tuy account thuc te) lay screenshot/PDF bank header (ten company VTI APAC PTE. LTD. + account no), reply Evangeline thread + CC bdg@vti.com.vn",
          "deadline": "ASAP - overdue 10+ ngay tinh tu reminder 06/05/2026",
          "priority": "RED"
        }
      ]
    },
    {
      "item": "CorpZap registered address + Company Secretary (ACRA update VTI APAC PTE. LTD.)",
      "priority": "AMBER",
      "context": "Thread '[VTI APAC & CorpZap] Guidance Required for Registered Address and Company Profile Updates' - Charlotte lam viec voi Nuraini (CorpZap, CS provider Singapore) cap nhat ACRA registered address + nominee director cho VTI APAC PTE. LTD. sau khi da update ACRA. CS team yeu cau Michael lam 2 loai Sumsub digital verification (Basic link nepHkw2xEgmEPoAh + Enhanced link ET9jCH7tuRpTEamt) - can screenshot done/completed gui CorpZap. Charlotte confirm collecting documents 06/05/2026.",
      "tasks": [
        {
          "title": "Thu thap + gui tai lieu CS theo yeu cau Nuraini (CorpZap)",
          "status": "Dang lam - Charlotte confirm collecting documents (06/05/2026)",
          "pic": "Charlotte (Quyen Nguyen Thi Do)",
          "next_action": "Hoan tat danh sach tai lieu CS yeu cau, gui Nuraini, confirm intend giu CorpZap CS role",
          "deadline": "Tuan W20 (11/05/2026 -> 15/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "Michael hoan tat Sumsub digital verification (Basic + Enhanced)",
          "status": "Open - chua lam",
          "pic": "Michael Nguyen",
          "next_action": "Mo 2 links Sumsub (Basic: nepHkw2xEgmEPoAh, Enhanced: ET9jCH7tuRpTEamt), hoan tat KYC, screenshot done gui Charlotte forward Nuraini",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "SG hire wrap-up - Hoan ung Malaysia trip 07-10/04/2026",
      "priority": "AMBER",
      "context": "Calendar event '[VAP] Hoan ung Malay 07-10/04/2026' Mon 04/05/2026 14:00 ICT - close out chuyen Malaysia trip thang 4/2026 cua VAP team (sourcing/recruiting context); reconcile chi phi vat, lodging, transport va submit hoan ung BDG. Lien quan rong hon: Anthony Tee (Senior Advisor) trong Fri Sync push Michael consolidate Singapore admin+sales hire budget - boi canh APAC pipeline scaling 'Kevin alone can't handle' voi multi SG accounts (KGI/Ufinity, NxGen, AsiaPac, MC SG, Sembcorp, RWS, OBS, Technovation, Terabit). Anthony can budget proposal de plan hiring SG local.",
      "tasks": [
        {
          "title": "Hoan tat hoan ung Malaysia trip 07-10/04/2026 (receipt + reconcile + submit BDG)",
          "status": "In progress - meeting 04/05/2026 14:00 ICT da set",
          "pic": "VAP team (Khanh Tran Duy + Charlotte) + BDG",
          "next_action": "Gom receipt cua tat ca participants, reconcile voi cash advance, submit form hoan ung qua bdg@vti.com.vn",
          "deadline": "Tuan W20 (15/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "Consolidate Singapore admin+sales hire budget 1 doc gui Anthony Tee",
          "status": "Chua bat dau",
          "pic": "Michael Nguyen",
          "next_action": "Tong hop HC count + cost (salary + CPF + overhead) admin + sales tu Charlotte (HR) + Kevin (sales side), goi 1 doc proposal gui Anthony review",
          "deadline": "22/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "vitX Platform Engineer (01 HC bodyshop) - partnership Mind Supernova",
      "priority": "AMBER",
      "context": "Tuan W19: Thread 'VTI - vitX Platform Engineer (01 Headcount) | Ho tro trien khai hop dong hop tac voi Mind Supernova' - Tyson Nguyen Ba de xuat bodyshop 1 HC cho khach vitX (GITS follow truoc do nhung dung do conflict khoi luong + chi phi); nego lai voi partner Mind Supernova lam vendor. Tyson tao chat space '[VAP TA] Mind Supernova - 1 headcount bodyshop' nho chi Hoai (VTI.TA) support. Chi Hien (VTI.D8) duyet chu truong hop tac Mind Supernova ngay 08/05/2026 (mail Hien chot OK chu truong, Tyson contact legal). Chi Hoai (TA) raise concern: chi Hoai chi negotiate rate + dua nguon vendor, khong review HD; ben HR (chi Lanh) se process thu tuc HD + NDA. Concern legal chua ro: form HD phai la bodyshop (by-name nhan su/skill, vendor coverage ro) chu khong phai HD phat trien phan mem.",
      "tasks": [
        {
          "title": "Xu ly concerns legal/HD voi Mind Supernova (vendor coverage, by-name form)",
          "status": "Dang cho - Tyson contact legal, comeback voi Hoai/Lanh",
          "pic": "Tyson Nguyen Ba",
          "next_action": "Confirm form HD phu hop (bodyshop vs phat trien phan mem), email cc chi Hoai + chi Lanh + Hien; xin template bodyshop co san cua legal VTI thay vi draft tu dau",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Gui CV + details candidate Mind Supernova cho chi Hoai danh gia",
          "status": "Open - chi Hoai yeu cau",
          "pic": "Tyson Nguyen Ba",
          "next_action": "Gui CV + ket qua danh gia (neu co) cho chi Hoai + Hien review truoc khi chot voi Mind Supernova",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "Sembcorp IT Infrastructure Assessment and Maintenance - Commercial position + headcount buyout",
      "priority": "AMBER",
      "context": "Chat space '[VAP] Sembcorp IT Infrastructure Assessment and Maintenance' (27 msgs trong tuan): Sembcorp phan hoi vu IT - nhu cau thue part-time trong 6 thang dau, sau do xem xet chuyen sang full-time tuy hieu qua; resource level junior -> middle, co y dinh 'mua dut headcount' nen can bao gia. Anh Thanh Nguyen Minh (VTI.IT) confirm nguoi noi bo VTI serve duoc case nay. VAP raise can clarify commercial: x2.5 gia part-time cho headcount buyout (refer Google Sheet pricing template). VTI dong y nguyen tac SembCorp co quyen mua dut nhan su sau 1 nam lam viec - voi dieu kien nguyen vong nhan vien va clarification quy trinh quan ly + chat luong dich vu. Song song: chat 'Sembcorp Incident One Alert_Group Leader' (3 msgs) - khach pending go-live, khong co updates/responses; Kevin nhan/goi ban Jon 2 lan khong duoc; anh Tai email push tiep.",
      "tasks": [
        {
          "title": "Confirm Sembcorp commercial - keep gia hop dong nguyen + propose headcount buyout x2.5 part-time rate",
          "status": "In discussion - chua chot",
          "pic": "Cuong Nguyen Duc 2 (VTI.VAP) + Kevin Nguyen",
          "next_action": "Internal alignment commercial position; Cuong soan email khach voi 2 phan: (a) clarify quy trinh quan ly trong service period, (b) headcount buyout terms sau 1 nam + nguyen vong NV - send Sembcorp",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Sembcorp Incident One Alert (go-live pending) - push khach response",
          "status": "Stuck - khach khong response Kevin sau 2 lan goi",
          "pic": "Tai Do Anh (VTI.DG) + Kevin Nguyen",
          "next_action": "Tai email push tiep + Kevin try trao doi voi Jon (Sembcorp); escalate qua Le Thi Thu Huyen neu khong response them 1 tuan",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "ISMS Audits - ODC Audit April 2026 (Ufinity/Anthony Chen)",
      "priority": "RED",
      "context": "Thread 'ODC Audit - Apr 2026' - Chen Yijin Anthony (Ufinity) request bien ban audit thang 4/2026 ngay 01/05/2026: Biometric System Access Report + Log + Visitor Log Book. Charlotte gui report sai (March 2026) ngay 04/05/2026 -> Anthony bounce back -> Charlotte gui lai version dung April 2026 ngay 05/05/2026 18:44. Audit findings nghiem trong tu Anthony (mail 13/05/2026 00:53): (1) Cleaning lady vao ODC room 16:14 ngay 21/04/2026 nhung khong ghi gio chinh xac trong visitor log -> remind toan bo visitors ghi gio HH:MM tren biometric scanner. (2) Security guard vao ODC room 27/04/2026 de cua mo + chup anh + lat dac do tren ban Tung -> Charlotte phai check intent security guard + review CCTV 27/04/2026. Anthony da request CCTV recordings cho 10 timeslots khac nhau (camera trong + ngoai ODC room).",
      "tasks": [
        {
          "title": "Tra loi audit findings Anthony Chen (cleaning lady + security guard incident 27/04/2026)",
          "status": "Open - Anthony gui findings 13/05/2026",
          "pic": "Charlotte (Quyen Nguyen Thi Do) + Tyson Nguyen Ba",
          "next_action": "Investigate security guard intent (interview, lay loi giai thich), share CCTV evidence cho Anthony, ban hanh remind toan ODC team ghi gio HH:MM tren scanner; reply Anthony thread CC BDG + Daniel Goh",
          "deadline": "Tuan W20 (15/05/2026)",
          "priority": "RED"
        },
        {
          "title": "Cung cap CCTV recordings 10 timeslots Anthony request (camera trong + ngoai ODC room thang 4/2026)",
          "status": "In progress - Tyson da gui CCTV control screenshots 08/05/2026 cho thread 'New Requirements for ODC'",
          "pic": "Tyson Nguyen Ba + VTI IT (Thanh Nguyen Minh)",
          "next_action": "Extract 10 CCTV timeslot recordings (vd: 01/04 11:38-11:46, 03/04 13:12-13:18, 21/04 16:00-16:16, 27/04 08:24-08:26, 28/04 14:24-14:26 ...), gui Anthony qua secure channel",
          "deadline": "15/05/2026",
          "priority": "RED"
        }
      ]
    },
    {
      "item": "BCDR for ODC room (GovTech renewal qualification)",
      "priority": "AMBER",
      "context": "Calendar 'Invitation: BCDR for ODC room' Tue 05/05/2026 10:00-11:00 ICT (Microsoft Teams) - organizer Chen Yijin Anthony (Ufinity), guests VTI ISMS, Thanh Nguyen Minh, Ngoc Tran Dang, Hung Tran Van 2, Daniel Goh, Kevin Nguyen, Michael Nguyen. Agenda: (1) BCP document Ufinity drafted - process khi VTI building khong accessible (fire/flood): recovery cho ODC room, ODC staff laptop, time unlock physical lock, IT enable wifi during flood. (2) Qualification renewal: screenshots CCTV config 12 months storage, door access control 12 months, ISMS test result 2026, secure wipe practice, Tung's laptop khong co admin rights. (3) AOB ODC Staff Movement Tracker. Mail 11/05/2026 Anthony confirm finalised BCDR Plan se submit GovTech cho renewal qualification ODC room; RTO timings da agreed offline; Tung's laptop access rights da review OK. Anthony bao tiep theo se co online call GovTech request VTI facility tour + infrastructure review.",
      "tasks": [
        {
          "title": "Standby cho GovTech online call facility tour + infrastructure review ODC room",
          "status": "Pending - doi Ufinity forward meeting invite tu GovTech",
          "pic": "Tyson Nguyen Ba + Thanh Nguyen Minh (VTI.IT) + Hung Tran Van 2 (VTI.ISMS)",
          "next_action": "Khi nhan duoc invite tu Anthony Chen -> setup facility walkthrough deck (ODC room layout + biometric + CCTV + BCP recovery flow), assign owner per topic",
          "deadline": "TBD - sau khi GovTech share invite",
          "priority": "AMBER"
        },
        {
          "title": "Hoan thien ODC Staff Movement Tracker sheet (AOB BCDR meeting)",
          "status": "In progress - raised 05/05/2026 BCDR meeting",
          "pic": "Hung Tran Van 2 (VTI.ISMS) + Thanh Nguyen Minh (VTI.IT)",
          "next_action": "Standardize template tracker movement ODC staff (in/out time, purpose, approver), share cho ODC team + Ufinity",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "Sembcorp AMS Outsourcing L1 & L1.5 Service RFP - tender evaluation pending",
      "priority": "AMBER",
      "context": "Thread 'Re: Invitation for AMS Outsourcing - L1 & L1.5 Service RFP' - VTI da submit GEP tender ngay 01/04/2026 (Price Sheet + Supplier Prequalification Form). Tuan W19 (05/05/2026 01:14): Anri Kobayashi (Sembcorp) reply Kevin: hy vong nhan duoc all evaluations vao cuoi thang 5/2026; Yvonne Cheong duoc tag de follow up technical evaluators submit scores. Lien quan VTI side: Kevin Nguyen + Linh Tran Quang (VTI.DG) + Hung Nguyen Duc (VTI.DG) + Khanh Tran Duy (VTI.VAP) + BDG.",
      "tasks": [
        {
          "title": "Follow Sembcorp AMS RFP evaluation result (target end of May 2026)",
          "status": "Waiting - Anri target evaluations cuoi thang 5/2026",
          "pic": "Kevin Nguyen",
          "next_action": "Sau 14 ngay khong reply (target 19/05/2026) -> light ping Anri + Yvonne Cheong; chuan bi clarification responses neu Sembcorp request",
          "deadline": "31/05/2026 (target eval close)",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "Internal ISMS approver authority debate (TRN vs DLs) + ISMS quiz improvement",
      "priority": "AMBER",
      "context": "Chat space 'TRN vs DLs' (156 msgs trong tuan) tranh luan policy ISMS: IT co nen giu quyen approver duy nhat cho viec cam thiet bi ngoai vao mang cty khong. Quan diem raise: 'khong co qui dinh nao yeu cau IT la nguoi thuc thi'; 'can ca 3 ong approve' (IT + ISMS + DL/quan ly); 'chi DL + ISMS ok co the dan den chet mang cty'. De xuat tach 2 luong: (1) NV mang thiet bi -> IT kiem tra (C/control), (2) IT kiem tra co van de -> IT control + can nhac cap phep (A/approve) trong luong rieng. Song song: tranh luan bo de thi ISMS quiz co cau hoi/dap an lung cung (vd cau Google Drive 'Anyone with the link') - Lead ISMS (Hung Tran Van 2) approve dap an cuoi, sua cai tien lan sau.",
      "tasks": [
        {
          "title": "Resolve ISMS approver authority policy - chot model approve thiet bi ngoai (tach C vs A)",
          "status": "Dang tranh luan - chua ket",
          "pic": "Hung Tran Van 2 (VTI.ISMS) + Thanh Nguyen Minh (VTI.IT) + BOM",
          "next_action": "Setup hop ngan giua 2 phong ISMS + IT chot policy: tach C (control) va A (approve) thanh 2 luong, ban hanh procedure update, share toan cty",
          "deadline": "Tuan W20-W21 (22/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "Cai tien bo de thi ISMS quiz - fix cau hoi/dap an lung cung",
          "status": "Dang gom feedback",
          "pic": "Hung Tran Van 2 (VTI.ISMS Lead) + PDT",
          "next_action": "Approve Failed -> Pass cho cac case cai tien; sua lai wording dap an (vd cau Google Drive option 2/3); ban hanh quiz v2 lan thi sau",
          "deadline": "Truoc ky thi ISMS tiep theo",
          "priority": "AMBER"
        }
      ]
    },
    {
      "item": "Weekly wrap-up template - Anthony Tee Friday sync new rule",
      "priority": "AMBER",
      "context": "Anthony Tee (VTI APAC Senior Advisor) ban hanh NEW RULE tu Fri 15/05/2026: Michael gui weekly wrap-up TRUOC Anthony sync moi Fri morning. Template can chuan hoa de Anthony nhin nhanh status APAC truoc cuoc. Boi canh APAC pipeline scaling - Anthony can visibility ngang doc cac account SG + VN.",
      "tasks": [
        {
          "title": "Build weekly wrap-up template chuan (Summary + Operation + Customer per-account)",
          "status": "Chua bat dau",
          "pic": "Michael Nguyen",
          "next_action": "Draft template: (1) Summary 3-5 dong, (2) Operation items (item + priority + context + tasks), (3) Customer per-account (weekly_activity + current_problem + tasks); gui Anthony review truoc khi ban hanh tu Fri 22/05/2026",
          "deadline": "22/05/2026 (apply tu Fri sync ke tiep)",
          "priority": "AMBER"
        }
      ]
    }
  ],
  "customers": [
    {
      "customer": "KGI Trading (via Ufinity)",
      "priority": "RED",
      "weekly_activity": "Week 04-10/05/2026 was the kickoff week of the KGI Trading Platform proposal cycle. Tue 05/05 Mark Choon (Ufinity Account Director) emailed Tyson Nguyen confirming NDA was pending signature and requested arrangement to discuss 2 KGI budgetary-quote scopes (KGI Client Portal Web+Mobile+Admin CRM + Corporate Actions Web). Wed 06/05 Mark sent full requirement note: KGI Client Portal tech stack .NET MVC (web) + .NET MAUI (mobile), Phase 0 demo trading on web by June 2026 and Phase 1 full features incl mobile and backend CRM by Sept 2026; CA Web also .NET MVC. Thu 07/05 09:00-10:00 the UF x VTI: KGI requirements sharing for budgetary quote meeting was held on Teams (organizer Tung Nguyen Ba aka Tyson, attendees Hung Nguyen Duc (David), Kevin Nguyen, Linh Tran Quang, Cuong Nguyen Duc 2, Anh Nguyen Truong Viet, Hieu Nguyen Trung 4) with Mark Choon's side showing figma mockups. Same day 16:50 a 15-min VAP UF Syncup happened with Daniel Goh + Tyson + Kevin + Anh to align cadence. Tyson created internal Space [VAP & D1] Ufinity - KGI Trading Platform, distributed requirement + timeline + expectation + BQ reference template, tagged Hieu Nguyen Trung 4, Hung Nguyen Duc (David), Son Nguyen Van, Long Vu Thanh and proposed 10:00 VNT Thu 14/05 joint customer syncup; Son and Long agreed to pre-call internal sync Tue 12/05 or Wed-morning 13/05.",
      "current_problem": "VTI does not have an internal financial-domain SME for KGI Trading (admitted by Long Vu Thanh: 'call thì call được, nhưng k chắc nghe có hiểu nổi khách k') and NinjaTrader SDK chart-embed feasibility is unproven, so estimate carries large risk and must rely on range estimate + assumption list. Mark Choon's same-day scope-expansion pattern (KGI Client Portal + CA Web disclosed at NDA-signing stage) means proposal v1 has gap-list exposure. The customer-prefers-delivery-direct-presentation expectation puts pressure on Hung Nguyen Duc (David) + Son Nguyen Van + Long Vu Thanh as customer-facing presenters despite English barrier. Solution path locked W19 -> W20: 13/05 internal BQ 1st draft -> 14/05 UF x VTI joint customer call -> same-day post-mortem -> revise -> 20/05 v3 submit. Phase 0 end-June demo commitment is the binding external deadline.",
      "tasks": [
        {
          "title": "NinjaTrader SDK chart embed feasibility deep-dive (SDK/API + mobile/web + cash flow deposit/withdraw)",
          "status": "in_progress",
          "pic": "Long Vu Thanh",
          "next_action": "Output feasibility + risk note, feed into FP v2; deep-dive 12-13/05",
          "deadline": "13/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Finalize FP v2 KGI Trading with chart embed Phase 1.5 split",
          "status": "pending",
          "pic": "Son Nguyen Van",
          "next_action": "Wait for Long's SDK output, then close FP v2 evening 13/05",
          "deadline": "13/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Coordinate cash-flow + trading-data architecture + review estimate + guide FP team",
          "status": "pending",
          "pic": "Hung Nguyen Duc (David)",
          "next_action": "Architecture sign-off + estimate review before 14/05 customer call",
          "deadline": "14/05/2026",
          "priority": "RED"
        },
        {
          "title": "Prepare chart drawing integration doc NinjaTrader + approval with Long",
          "status": "pending",
          "pic": "Hieu Nguyen Trung 4",
          "next_action": "Finalize integration doc, joint approval with Long",
          "deadline": "14/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Prep RSA alternative quote for KGI Trading (separate from fixed-price)",
          "status": "pending",
          "pic": "Tyson Nguyen (Tung Nguyen Ba)",
          "next_action": "Build 1-pager RSA quote with PM headcount assumptions",
          "deadline": "14/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Joint UF x VTI customer call KGI Trading Platform (proposal v1 presentation)",
          "status": "pending",
          "pic": "Tyson Nguyen (Tung Nguyen Ba) + Hung Nguyen Duc (David) + Son Nguyen Van + Long Vu Thanh + Hieu Nguyen Trung 4",
          "next_action": "Run call 10:00 Thu 14/05 VNT, capture customer feedback for post-mortem 21:00",
          "deadline": "14/05/2026",
          "priority": "RED"
        },
        {
          "title": "Consolidate KGI Trading proposal v3 + cost docs upload Drive",
          "status": "pending",
          "pic": "Tyson Nguyen + Team",
          "next_action": "Compile v3 after Thu post-mortem, upload Drive",
          "deadline": "20/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "CA Web (Corporate Actions Web — Ufinity sub-project, KGI parallel)",
      "priority": "RED",
      "weekly_activity": "Week 04-10/05/2026 saw CA Web BQ kickoff in parallel with KGI Trading. Tue 05/05 Mark Choon's NDA-pending email included CA Web as the second budgetary scope (tech stack .NET MVC, team size + timeframe required). Tyson Nguyen routed CA Web BQ work to D9 via Space [VAP & D9] Ufinity - CA Web - Offshore Full-stack Developers (.NET). Tuan Mai Van and Thang Nguyen Van 1 were assigned to build proposal estimate; Hung Nguyen Duc (David) joined to set framework. Internal call set 13:15 (early afternoon) on Fri 08/05 to align estimate — Tuan reported 'không có ai đây' due to Tuan Viet pulled away by H2biz / Hang Moon emergency. Mockup acknowledged as small ('k nhiều màn hình lắm') but new info captured from customer call previous day. Target: 1st draft BQ + estimate ready Tue 13/05 for proposal submission to Mark Choon. Tyson requested recording of prior customer call distributed to Thang and self, plus BQ template. End-of-week (12/05 — just outside W19) Tyson sent BQ_Ufinity - Corporate Actions Web Application (CAWeb) - VTI's solution & cost estimation - v2 - 12-05-2026.xlsx to Mark, validating the W19 pipeline.",
      "current_problem": "D9 resource bottleneck: Tuan Viet pulled into H2biz/Hang Moon firefight leaving Tuan Mai Van light on senior partner, Thang Nguyen Van 1 picking up estimate framing. CA Web has no financial-domain SME inside VTI (same risk class as KGI Trading) so estimate must use range + assumption list. Justin (Ufinity) has not yet returned Q&A pack — Tyson needs to set hard deadline. Mockup looks small but requirement gaps remain after Wed customer call. Path forward: Tue 12/05 09:00 internal review with finalized range + assumption list; UF x VTI CAWeb session #1 10:00 Tue + #2 16:00 Tue (with Alex Chow NEW Ufinity Commercial Director); gap-list compiled by Kevin Nguyen post-call within 24h SLA.",
      "tasks": [
        {
          "title": "Finalize CA Web range estimate + assumption list before 09:00 Tue 12/05",
          "status": "in_progress",
          "pic": "Tuan Mai Van + Thang Nguyen Van 1",
          "next_action": "Hand-off to internal review 09:00 Tue 12/05, then ready for UF call 10:00",
          "deadline": "12/05/2026",
          "priority": "RED"
        },
        {
          "title": "Set deadline for Justin (Ufinity) to send Q&A pack CA Web",
          "status": "pending",
          "pic": "Tyson Nguyen (Tung Nguyen Ba)",
          "next_action": "Email Justin with deadline 14/05",
          "deadline": "13/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Compile 10-item gap list CA Web post 16:00 Tue call, send Mark Choon",
          "status": "pending",
          "pic": "Kevin Nguyen",
          "next_action": "Email Mark within 24h SLA after Tue 12/05 16:00 session",
          "deadline": "13/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Profile Alex Chow (Ufinity Commercial Director) — role + decision authority",
          "status": "pending",
          "pic": "Tyson Nguyen (Tung Nguyen Ba)",
          "next_action": "Add persona note to Memory after Tue 12/05 16:00 first appearance",
          "deadline": "13/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "Ufinity ODC (Java + .NET Full-stack Offshore Devs)",
      "priority": "AMBER",
      "weekly_activity": "Week 04-10/05/2026 ran two parallel ODC threads. (1) Java ODC billing: Thu 07/05 Charlotte (Quyen Nguyen Thi Do) sent Daniel Goh (Ufinity) the Minutes of Acceptance MSA-VTI-22001 SOW 4 Backend Software Engineer April 2026 + invoice for Apr 01-30, 2026; Daniel approved 08/05 01:15 UTC ('Please proceed'); Charlotte returned signed invoice 08/05 09:15 UTC awaiting payment update. In Space [VAP & D9] Ufinity - ODC Java Dev, Tung Ngo Quang (VTI.D9) handed over April timesheet via Google Sheet 1pX-iEuCze1rQbrh-igS0ruw8jS2W3Ekn on deadline. (2) .NET Full-stack RSA: long-running thread [Ufinity & VTI] Quotation for Resources Augmentation of Offshore Full-stack Developers — Mon 04/05 Tyson asked Charlotte to chase VTI legal NDA review; Tue 05/05 Mark Choon checked NDA status (he wants to start KGI BQ discussions); Tue 05/05 Charlotte confirmed NDA reviewed no comments awaiting Ufinity signature; Wed 06/05 Mark requested VTI sign first; same day Charlotte sent VTI-signed PDF; Mon 12/05 (just outside W19) Mark returned fully signed copy — closing the RSA NDA loop after 10+ weeks. Cc thread includes Royston HO, Tyson, Michael Nguyen (VTI.APAC), Kevin, BDG, Alex Chow, Daniel Goh, Tan Yen Hock.",
      "current_problem": "NDA for .NET RSA dragged from late Feb 2026 to first week of May — Mark Choon's signature was the final gate and only closed 12/05. The 10-week NDA cycle compressed the subsequent BQ window: Mark immediately pivoted to KGI Trading + CA Web budgetary quotes once NDA cleared, creating same-week pile-up (KGI requirements 07/05 + CAWeb internal 08/05 + KGI internal 12/05 + CAWeb double-session 12/05). Java ODC billing cycle is healthy — Charlotte + Daniel Goh have stable monthly cadence; Tung Ngo Quang's timesheet handoff was on-time. No blocker on Java ODC, but RSA .NET execution depends on KGI Trading proposal landing well so resource demand materializes.",
      "tasks": [
        {
          "title": "Track Ufinity Java ODC April invoice payment",
          "status": "in_progress",
          "pic": "Charlotte (Quyen Nguyen Thi Do)",
          "next_action": "Await Daniel Goh's payment update; chase if not received by mid-May",
          "deadline": "20/05/2026",
          "priority": "GREEN"
        },
        {
          "title": "Close fully-signed NDA RSA .NET Full-stack and start resource staging",
          "status": "done",
          "pic": "Tyson Nguyen + Mark Choon",
          "next_action": "NDA fully signed 12/05; downstream RSA quote prep moves to Tyson under KGI Trading task list",
          "deadline": "12/05/2026",
          "priority": "GREEN"
        },
        {
          "title": "Submit April timesheet Java ODC",
          "status": "done",
          "pic": "Tung Ngo Quang (VTI.D9)",
          "next_action": "Done — Google Sheet sent on deadline",
          "deadline": "Early W19",
          "priority": "GREEN"
        },
        {
          "title": "RSA .NET Full-stack quote preparation (post-NDA)",
          "status": "pending",
          "pic": "Tyson Nguyen (Tung Nguyen Ba)",
          "next_action": "Quote prep follows KGI Trading proposal v3 — see KGI tasks",
          "deadline": "20/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "Facial Recognition Storage (Ufinity ODC8 audit dependency)",
      "priority": "RED",
      "weekly_activity": "Week 04-10/05/2026 saw a high-tempo audit-evidence cycle driven by Chen Yijin Anthony (Ufinity BDG) for the GovTech ODC renewal qualification. Fri 08/05 16:22 Anthony asked Tyson Nguyen 2 questions: (1) confirm 3-year storage limit applies to both access log + facial image, (2) provide full screenshot of facial recognition settings page proving no configurable storage limit. Fri 08/05 16:59 Tyson stated facial recognition limit is 3 years; 17:35 Tyson confirmed Q1 and answered Q2 with 'there is no setting page' (cannot provide). Anthony pushed back same day requesting evidence. Mon 11/05 08:24 Anthony escalated deadline ('by today 11 May, 11am SG time') — Tyson 10:16 + 11:21 sent screenshot from ERP director / system admin side showing 8-year configuration (HR department was unaware); Anthony 11:37 acknowledged 'Thanks Tyson'. Parallel chat in Space [VAP & HR & ISMS] Ufinity ODC 8 Monthly Audit had HR (Linh Pham Thi Mai, Lanh Luu Thi), Tung Ngo Quang (VTI.D9), Hung Tran Van 2 (VTI.ISMS) racing to export FaceXpress data: customer rejected initial FaceXpress mobile screenshot, HR then exported the system data-screen for project start month (June 2025) and got customer OK. Follow-up: customer asked if storage-time setting screen exists, and if not what is the max storage limit.",
      "current_problem": "Facial recognition system (FaceXpress vendor app) does not expose a storage-limit setting page from the standard user/admin UI — Tyson initially answered 'no setting page', forcing escalation to ERP director who found system-admin-side config showing 8-year retention (contradicting earlier 3-year statement, and HR was unaware). This inconsistency (3 years stated vs 8 years configured + HR not aware) is a credibility hit with Anthony for the GovTech audit dossier. Knowledge is siloed: faceX vendor + ERP director own system-admin access; HR + ISMS + D9 each only see partial views. Solution path: confirm definitive retention figure with FaceXpress vendor, document VMS vs FaceXpress export distinction, and consolidate evidence pack before next monthly audit cycle. The chat thread also exposed that mobile-app screenshots (FaceXpress iOS app) are not acceptable evidence — customer wants browser-print or system-admin screen.",
      "tasks": [
        {
          "title": "Reconcile facial recognition retention setting (3 years stated vs 8 years configured) with FaceXpress vendor",
          "status": "pending",
          "pic": "Tyson Nguyen (Tung Nguyen Ba) + HR (Linh Pham Thi Mai / Lanh Luu Thi) + Hung Tran Van 2 (VTI.ISMS)",
          "next_action": "Contact FaceXpress vendor for written confirmation of effective retention; align HR + ISMS narrative",
          "deadline": "Tuần 19-23/05/2026",
          "priority": "RED"
        },
        {
          "title": "Provide full screenshot of facial recognition settings page (or vendor letter explaining absence)",
          "status": "in_progress",
          "pic": "Tyson Nguyen (Tung Nguyen Ba)",
          "next_action": "Confirmed 8-year via ERP director 11/05; obtain vendor evidence to formalize",
          "deadline": "Mid W20",
          "priority": "AMBER"
        },
        {
          "title": "Document FaceXpress vs VMS export distinction for monthly audit pack",
          "status": "pending",
          "pic": "Linh Pham Thi Mai (VTI.HR)",
          "next_action": "Standardize export workflow — system data screen (not mobile app) for project start month evidence",
          "deadline": "Before Jun-2026 monthly audit",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "IHL bridge (Ufinity ODC <-> AsiaPac/IHL — context only this week)",
      "priority": "GREEN",
      "weekly_activity": "Week 04-10/05/2026 had NO direct Ufinity-IHL bridging activity. The Ufinity ODC8 workstream is shared physical/governance scope (audit, facial recognition, GovTech visit) and is logically adjacent to AsiaPac IHL Portal activity, but in W19 the two streams ran independently: Ufinity ODC8 audit + facial recognition (above) on the Ufinity governance side, and AsiaPac IHL Portal CR (covered under separate AsiaPac cluster) on the customer-engagement side. The 'bridge' relevance this week is purely the shared Tyson Nguyen / Daniel Goh / Anthony Chen Yijin / VAP-ISMS resource pool. AsiaPac IHL Portal CR meeting on Fri 15/05 is the first customer-facing IHL touch and falls in W20.",
      "current_problem": "No problem to flag W19 — no bridge activity occurred. Watch-item for next week: Tyson workload concentration (KGI v3 + CA Web v2 + IHL CR split + Odoo Q&A + RWS chatbot all hitting 20-22/05), with both Ufinity ODC governance and AsiaPac IHL Portal CR pulling on the same person — escalation candidate to Hung Nguyen Duc (David) or Cuong Nguyen Duc 2.",
      "tasks": [
        {
          "title": "Monitor Tyson Nguyen workload concentration across Ufinity ODC + AsiaPac IHL streams",
          "status": "pending",
          "pic": "Michael Nguyen (VTI.APAC)",
          "next_action": "Re-prioritize Mon 18/05 Operation meeting; escalate IHL CR stream to Hung Nguyen Duc (David) or Cuong Nguyen Duc 2 if needed",
          "deadline": "18/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "GovTech intro (via Ufinity ODC8 facility visit)",
      "priority": "AMBER",
      "weekly_activity": "Week 04-10/05/2026 introduced a NEW GovTech touchpoint via Ufinity's ODC governance. Mon 11/05 (just at W19 close) Anthony Chen Yijin (Ufinity BDG) emailed Tyson Nguyen the finalized BCDR Plan for submission to GovTech for ODC room renewal qualification, with RTO timings as agreed during prior call + offline discussion; also confirmed Tung Ngo Quang's laptop access rights were reviewed and OK. Anthony flagged that GovTech will request an online call requiring VTI support for: facility tour + infrastructure review (invite to be forwarded once GovTech shares). In parallel Space VAP - GovTech visit - Ufinity's ODC was created — early discussion among Michael Nguyen (VTI.APAC), Cuong Nguyen Duc 2, Tyson and Kevin about responding to GovTech queries (Q1, Q2 ref docs sent; Q3 'k có ông nào eng' — no English-speaker, needs check with D1). Tyson also flagged that response should update GovTech on count-per-category of customers AND the services VTI has done / is doing. In Space [VAP & GA & IT & ISMS] Ufinity - ODC Setup: separate but related — a GovTech manager facility visit forecast (later this month), Tung Ngo Quang's admin-rights screenshots audited and customer asked for evidence Tung's account is not in Administrator group (lusrmgr.msc screenshot), FaceXpress LDAP login confirmed.",
      "current_problem": "GovTech facility tour + infrastructure review meeting still TBC (no invite yet) — VTI cannot prep without scope/date. Open question on English-speaker coverage for Q3 response (D1 to confirm). The ODC8 admin-rights audit (Tung Ngo Quang) exposed governance gap: customer wanted proof Tung does not have Administrator-group membership; VTI IT (Ngoc Tran Dang, Chinh Tran Khoa) removed admin rights and re-screenshot with timestamp — historical pattern is deepadmin account separate from user accounts, account 'tung.ngoquang' is on AD domain (not local Administrator group). Coordination across VAP + GA + IT + ISMS + D9 required for clean evidence pack ahead of GovTech visit.",
      "tasks": [
        {
          "title": "Await GovTech meeting invite for facility tour + infrastructure review; prep VTI support",
          "status": "pending",
          "pic": "Tyson Nguyen (Tung Nguyen Ba) + Michael Nguyen (VTI.APAC)",
          "next_action": "Receive invite via Anthony Chen Yijin; assemble facility-walk + infra evidence pack",
          "deadline": "Tuần 19-23/05/2026 (TBC by GovTech)",
          "priority": "AMBER"
        },
        {
          "title": "Respond to GovTech Q1, Q2 (ref docs sent) + Q3 English-speaker check with D1",
          "status": "in_progress",
          "pic": "Tyson Nguyen (Tung Nguyen Ba) + Kevin Nguyen",
          "next_action": "Confirm D1 English-speaker availability; rep customer with #-per-category + services done/doing",
          "deadline": "Mid W20",
          "priority": "AMBER"
        },
        {
          "title": "Remove Tung Ngo Quang admin rights + re-screenshot with timestamp for GovTech evidence",
          "status": "in_progress",
          "pic": "Ngoc Tran Dang (VTI.IT) + Chinh Tran Khoa (VTI.IT)",
          "next_action": "Remove admin rights, screenshot lusrmgr.msc with date/timestamp, store in audit folder",
          "deadline": "Before GovTech visit (TBC May/Jun 2026)",
          "priority": "AMBER"
        },
        {
          "title": "Confirm Tung Ngo Quang account location (AD domain vs local Administrator group)",
          "status": "in_progress",
          "pic": "Tung Ngo Quang (VTI.D9)",
          "next_action": "Provide LDAP screenshot from audit folder 02.2026 confirming AD-domain placement",
          "deadline": "Before GovTech visit",
          "priority": "AMBER"
        },
        {
          "title": "Submit finalized BCDR Plan via Ufinity to GovTech for ODC room renewal qualification",
          "status": "done",
          "pic": "Anthony Chen Yijin (Ufinity BDG)",
          "next_action": "Done — Anthony emailed finalized BCDR 11/05; VTI side has no further action until GovTech invite",
          "deadline": "11/05/2026",
          "priority": "GREEN"
        }
      ]
    },
    {
      "customer": "AsiaPac IPOS Grow",
      "priority": "GREEN",
      "weekly_activity": "W19 (04/05-10/05/2026) — Thứ Hai 04/05/2026 03:48 UTC, Kevin Nguyen (Sales Manager APAC, VTI) gửi mail '[Re: IPOS Grow]' tới Robert Wong (Director Sales, AsiaPac Technology Pte. Ltd., a Keppel company) chính thức chốt: 'VTI drops this request with the revised development budget. Please find ways to work on this request further on your end. Thank you!' Đây là kết quả của chuỗi đàm phán từ 18/03/2026: khách indicative budget chỉ ~SGD 90,000 all-in, dưới mức VTI viable. CC: Dhruv Raj Sahgal, Kieu Dai Tran, Hung Nguyen Duc (VTI.DG), Hung Nguyen Duy (VTI.DG), Michael Nguyen, BDG. Trước đó 27/04/2026 Kevin đã xin gia hạn đến 29/04 để relook; 04/05 quyết định dropping pursuit. KHÔNG có chat space hoặc activity nội bộ liên quan trong tuần này — pursuit đã được formally close.",
      "current_problem": "GREEN (closed). (1) Pursuit IPOS Grow chính thức dropped do giá khách đề xuất (~SGD 90,000) không khả thi với scope VTI đã optimize 2 lần (Mar-Apr 2026). (2) Không có follow-up action; Robert Wong sẽ tự tìm hướng khác. (3) Cần ghi nhận lessons learned cho pricing model SG market — gap giữa VTI minimum và AP indicative budget rất lớn.",
      "tasks": [
        {
          "title": "Ghi nhận lessons learned IPOS Grow pricing gap (SGD 90k vs VTI viable)",
          "status": "Open — sau khi drop pursuit",
          "pic": "Kevin Nguyen + Michael Nguyen",
          "next_action": "Document trong sales CRM/playbook để tham chiếu khi pricing SG SMB tương lai",
          "deadline": "Tuần 18/05-22/05/2026",
          "priority": "GREEN"
        },
        {
          "title": "Giữ relationship với Robert Wong cho future opportunities",
          "status": "Open — pursuit closed nhưng channel mở",
          "pic": "Kevin Nguyen",
          "next_action": "Casual check-in Q3, không push deal mới ngay",
          "deadline": "Ongoing",
          "priority": "GREEN"
        }
      ]
    },
    {
      "customer": "AsiaPac IPOS II New Workbench",
      "priority": "RED",
      "weekly_activity": "W19 (04/05-10/05/2026) là điểm nóng escalation. Thứ Hai 05/05/2026 09:17 UTC, Michael Nguyen reply mail của Linh Tran Quang (PM D1, gửi 29/04/2026) confirm nhận thức 2 vấn đề: VĐ1 underestimation upfront UC06 (VAP đồng ý out of scope vì không nằm trong estimation ban đầu); VĐ2 scope control + rework với customer. VAP commit 'làm việc với khách hàng để lấy được tối đa chi phí trong khả năng có thể'. Michael đặt câu hỏi cụ thể: con số 60 MM phát sinh có thuộc VĐ1 không, đã inform khách chưa, chuẩn bị evidence cho VĐ2. Thứ Hai 12/05/2026 01:56 UTC Linh follow-up gửi effort estimate chi tiết: In Scope 150.00 MM (Underestimate: 50 MMs), GAP 98.19, CR 14.58, Subtotal 262.78; CR chưa confirm ~15 MMs (UC06 + Admin Lock/Use + Admin Report); CR đã confirm (New IDH + Quick HR) 3.75 MDs (69 MDs); thêm CR XML reader chưa estimate (~10 MMs); tổng có thể charge khách ~25 MMs. Thứ Ba 13/05/2026 00:30 UTC Michael chốt directive: 'A nghĩ là mình bắt đầu start việc inform khách hàng về CR 6 luôn thôi'. Song song chat space Space_AsiaPac-IPOS-II New Workbench Application (89 msgs): team Linh + Anh Nguyen Mai + Hang Tran Thi + Tai Do Anh (DG) chạy ticket BQC/QC return-task logic 4 case scenarios, UC03-07 update theo comment Eugene, SIT environment lỗi OOM phải restart pod (Tu Nguyen Anh + Tam Nguyen Thanh điều tra), màn QA Assignment + Policy Management không vào được, file Q&A bị nhân đôi phải dọn. Group Space_AsiaPac-IPOS-II Group xin phép nghỉ-muộn ghi 17 lần xin nghỉ/về sớm trong tuần — burnout signal (1 người xin nghỉ liên tiếp 27/05-29/05/2026 + 01/06-02/06/2026).",
      "current_problem": "RED. (1) Dự án underestimate ~50 MMs (33% over scope 150 MM) — Michael đã chốt 13/05/2026 start inform khách CR6. Risk: AsiaPac (Do Manh Cuong, Alvin See) pushback vì underestimation là internal mistake, không phải scope change. (2) Commercial split chưa quyết: bao nhiêu charge khách (~25 MMs theo Linh đề xuất) vs bao nhiêu VTI tự cover (~25 MMs còn lại do under-est). VAP chờ Michael confirm. (3) SIT environment unstable (OOM, restart pods) ảnh hưởng UAT cadence. (4) Capacity risk: 17 lần xin nghỉ trong tuần (ngộ độc, con ốm, gia đình); 1 dev xin nghỉ 5 ngày cuối 5/đầu 6. (5) Tài liệu logic BQC/QC chưa final — Linh cần Anh Mai + Hang + Tai + Van + Man confirm 4 case scenarios trước khi gửi khách. (6) UC06 vẫn chưa thể chốt requirement do user thuộc phòng ban khác phía II.",
      "tasks": [
        {
          "title": "Soạn formal CR6 letter cho AsiaPac (IPOS underestimate ~50 MMs)",
          "status": "Open — Michael chốt 13/05/2026 start inform; chưa gửi mail formal",
          "pic": "Michael Nguyen + Linh Tran Quang (D1)",
          "next_action": "Soạn CR6 notice với scope/effort/timeline impact; align Do Manh Cuong (VTI VAP) + Kevin Nguyen trước khi gửi Do Manh Cuong (AsiaPac) + Alvin See",
          "deadline": "Tuần 18/05-22/05/2026",
          "priority": "RED"
        },
        {
          "title": "Quyết định commercial split: charge khách ~25 MMs vs VTI cover ~25 MMs",
          "status": "Open — VAP chờ Michael confirm",
          "pic": "Michael Nguyen + VAP commercial (Cuong Nguyen Duc 2)",
          "next_action": "Phân bổ rõ phần CR6 (xin khách) vs phần VTI tự cover; thủ tục CR procedure trước khi gửi letter",
          "deadline": "Trước 22/05/2026",
          "priority": "RED"
        },
        {
          "title": "Điều tra root cause SIT OOM + restart pod thường xuyên",
          "status": "Open — Tam Nguyen Thanh + Tu Nguyen Anh đang xử lý",
          "pic": "Tam Nguyen Thanh + Tu Nguyen Anh (D1)",
          "next_action": "Xem job nào chạy quá nhiều data, optimize query hoặc bổ sung resource SIT pod",
          "deadline": "ASAP — trước UAT round tiếp theo",
          "priority": "AMBER"
        },
        {
          "title": "Confirm 4 case scenarios BQC/QC return-task logic + Re-generation button + Timeliness template",
          "status": "Open — Linh chờ team confirm",
          "pic": "Anh Nguyen Mai + Hang Tran Thi + Tai Do Anh + Van Nguyen Thanh + Man Tu Thi",
          "next_action": "Confirm logic 4 case scenarios để Linh chốt SRS gửi khách",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Capacity risk management — IPOS team xin nghỉ liên tục, có người nghỉ 27/05-02/06/2026",
          "status": "Open — Linh approve nhưng sprint capacity giảm",
          "pic": "Linh Tran Quang + Van Nguyen Thanh",
          "next_action": "Re-plan sprint CR6 với capacity giảm; consider backfill từ D1 pool",
          "deadline": "Ongoing — chốt plan trước 20/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "AsiaPac MOD Smart Cookhouse",
      "priority": "AMBER",
      "weekly_activity": "W19 (04/05-10/05/2026) dự án đang ở giai đoạn close-out. Thứ Năm 08/05/2026 Dat Phan (DS, VTI) gửi mail 'UAT Milestone Sign-off - AsiaPac - MOD Smart Cookhouse Development Project' tới Do Manh Cuong (Keppel/AsiaPac, domanh.cuong@keppel.com) đề xuất chữ ký nghiệm thu: Alvin See đại diện AsiaPac, Viet Anh (Michael) đại diện VTI. CC nội bộ Cuong Nguyen Duc 2 (VTI VAP) + Kevin Nguyen + Michael Nguyen + Hung Nguyen Duc. Thứ Tư 13/05/2026 08:07 UTC Dat gửi updated version v2 sau feedback completion date từ khách. Trong chat space AsiaPac-MOD Management Discussion (4 msgs), Quyen Nguyen Thi Do (VAP) follow up Dat: 'gửi cho a Cường rùi cc Alvin a ui' — flow gửi BBNT Milestone 3 đi qua Do Manh Cuong AsiaPac, CC Alvin See. Song song chat space Support xin CSS dự án AsiaPac_MOD_Cookhouse (18 msgs): VAP team (Dat Phan + Quyen Nguyen Thi Do + Linh Nguyen Thi Hai PQM) lên kế hoạch gửi CSS (Customer Satisfaction Survey) — approach 'xin feedback của AP trong quá trình 2 bên làm dự án cùng nhau'. Khách Keppel rebrand sang email mới (alvin.see@keppel.com, domanh.cuong@keppel.com). Title CSS email: 'AsiaPac_MOD_Cookhouse: Request for Review CSS Mail'. CSS đang waiting review nội bộ trước khi gửi.",
      "current_problem": "AMBER. (1) Đợi feedback UAT Sign-off v2 từ Do Manh Cuong (AsiaPac) — waiting 3+ ngày tính từ 13/05/2026. Nếu khách không reply, không close được Milestone 3 = không bill được. (2) CSS gửi cho Alvin See (người đánh giá) — waiting review nội bộ VAP. Phải gửi sau khi UAT sign-off đóng. (3) Issue rebrand email Keppel — cần dùng email mới @keppel.com thay vì @asiapac.com.sg. (4) Dự án nằm trong list 'Late Deadline' VMS Helpdesk reminder gửi cho Viet Anh.",
      "tasks": [
        {
          "title": "Follow up Do Manh Cuong (AsiaPac) confirm BBNT Milestone 3 v2",
          "status": "Open — waiting external 3+ ngày từ 13/05/2026",
          "pic": "Dat Phan (DS) + Quyen Nguyen Thi Do (VAP)",
          "next_action": "Email/WhatsApp Do Manh Cuong nhắc review; nếu không phản hồi tuần này, escalate qua Alvin See",
          "deadline": "20/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Hoàn tất review nội bộ CSS + gửi Alvin See (CC domanh.cuong@keppel.com)",
          "status": "Open — Quyen chờ team confirm",
          "pic": "Quyen Nguyen Thi Do + Linh Nguyen Thi Hai (PQM)",
          "next_action": "Review xong gửi CSS sau khi UAT sign-off đóng",
          "deadline": "Sau UAT sign-off (ước tuần 18/05-22/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "VTI side ký BBNT (Viet Anh đại diện) — sau khi khách confirm",
          "status": "Pending — chờ khách confirm trước",
          "pic": "Viet Anh (Michael Nguyen) + VAP team gửi DocuSign",
          "next_action": "Chuẩn bị DocuSign khi nhận confirm từ Do Manh Cuong",
          "deadline": "Sau khi khách confirm",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "AsiaPac C99 Sembcorp Phase 1",
      "priority": "RED",
      "weekly_activity": "W19 (04/05-10/05/2026) chat space Space_[VAP & D9] AsiaPac - C99 Sembcorp - System Enhancement (Phase 1) (78 msgs total) cực kỳ active xoay quanh issue 'button Convert to LI không hiển thị'. Ling (khách Sembcorp/C99) báo: 'nhân viên của nó chưa nhìn thấy button Convert'. Team D9 (Hieu Dam Dinh + Thang Nguyen Van 1 + Truong Cao Viet) điều tra: button Convert to LI là phần do VTI làm (Thang xác nhận). Tyson Nguyen yêu cầu Truong confirm yêu cầu với Elvis (bên AsiaPac/AP side). Câu hỏi key: 'chạy migrate DB chưa a?' — gợi ý root cause có thể do DB migration chưa xong. VTI đã làm phần: (1) Delete User (Requestor Organizations), (3) Convert to LI; chưa thấy 'Delete Completed Valuations' trong list Ling. Deploy thì bên Elvis/Anurag (AP) chịu trách nhiệm — Anurag đang setup SMTP server (hạ tầng), 'nghe vẻ là chưa deploy code rồi'. Team VTI confirm: 'mình có deployed đâu... deploy thì bên Elvis nhé'. Tyson + Truong + Thang call internal 3pm + 4pm cùng Hieu để clear 2 bên, sau đó Tyson report lên sếp Thảo. Comment phụ: 'lại rơi vào đống nhùng nhằng bên C99 tiếp', 'keppel đã vậy rồi'. Hieu Dam Dinh ban đầu chưa được add vào WhatsApp customer group (đã được add sau).",
      "current_problem": "RED. (1) Khách (Ling) không thấy button Convert to LI — root cause unclear: VTI đã update source nhưng AsiaPac side (Elvis, Anurag) chưa deploy code; Anurag đang làm hạ tầng SMTP, không rõ có biết deploy app hay không. (2) Hợp đồng C99 không có scope UAT — nhưng vẫn có effort support UAT từ team VTI (cost không charge được). (3) Communication friction: Elvis 'mất hút' khi Ling tag, gọi WhatsApp 2 lần không được, nhắn không trả lời. (4) Risk dự án kéo đến cuối tháng 5/2026 nếu phía AP setup + nghiệm thu chậm. (5) Có khả năng 'Delete Completed Valuations' không nằm trong scope VTI làm — cần verify với contract.",
      "tasks": [
        {
          "title": "Clear 2-side communication với Elvis + Anurag (AP side) về deploy + migrate DB",
          "status": "In progress — Tyson call 3pm + 4pm clear",
          "pic": "Tyson Nguyen + Truong Cao Viet (D9)",
          "next_action": "Tyson clear xong 2 bên, report lên sếp Thảo; xác nhận ai chịu trách nhiệm deploy + migrate DB",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "RED"
        },
        {
          "title": "Confirm Convert to LI button visibility sau khi AP deploy + migrate DB",
          "status": "Blocked — chờ AP deploy",
          "pic": "Hieu Dam Dinh + Thang Nguyen Van 1 (D9)",
          "next_action": "Sau khi AP deploy, verify button hiển thị cho user của Ling; gửi confirmation 'requirements deployed in AVM'",
          "deadline": "ASAP sau AP deploy",
          "priority": "RED"
        },
        {
          "title": "Verify scope 'Delete Completed Valuations' có nằm trong contract VTI không",
          "status": "Open — Truong cần check contract + spec",
          "pic": "Truong Cao Viet (D9) + Tyson Nguyen",
          "next_action": "Check contract C99 Phase 1, reply Ling rõ scope",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "AsiaPac SPPL",
      "priority": "AMBER",
      "weekly_activity": "W19 (04/05-10/05/2026) chat space Space_AsiaPac-SPPL - VTI Project Teams (API GW & Microservices) (75 msgs) cực kỳ active xoay quanh việc soạn + gửi effort sheet cho khách SPPL (Singapore Pipe Pte Ltd, subsidiary Keppel). Debate chính: phân chia effort VTI vs AsiaPac (AP). Tu Tran Thi Ngoc (DG) hướng dẫn Long Chu Ngoc (DG): 'nếu VTI làm chính thì e cứ ghi PIC là VTI. Rồi cột Note thì e note ra cần AP support gì là được'; nếu chỉ review thì note 'AP review' thôi, PIC để VTI; AP customize lại và gửi cho SPPL thì AP tự chỉnh. Phong Tran Hung (DG) confirm: 'AP chỉ có effort trong phần verify/test thôi, chủ yếu là join test cùng mình và verify internal trước khi chuyển sang cho sppl'. NOTE quan trọng: AP đang rebrand thành 'Keppel Tech' (meeting title Ivan đã đổi 'Keppel Tech - VTI'). Sheet assumption: SPPL phải chuẩn bị xong phase pre-work trước khi VTI làm; Keppel Tech cần verify/test cùng VTI; document effort chưa được note. Repo permissions: 'developer, chứ ko đc maintainer'; SPPL phải set hết CI vars, key từ đầu. Long gửi mail 3:45pm thẳng cho khách, không CC Tu — Tu khiển trách 'gửi mail k cc c à'. Sau đó issue technical Argo branch: khách muốn fix trước cách hoạt động pipeline apigw, refactor sau. Issue thứ 2: API gửi đến CRM NLB -> Kong bị Kong reject do check private IP của CRM thay vì public IP trong whitelist (thiếu X-Forwarded-For header). Solution: bật 'Preserve client IP addresses' ở target group; SPPL suggest bỏ ip-restriction plugin ở Kong vì có whitelist ở NLB. Tuan Nguyen Anh 5 (D1) đã warn từ trước: 'nó ko check đc public ip đâu... trước đã bảo là ko bật đc rồi'. Song song Dai Tran Kieu tạo PO AMS_2026 cho SPPL trong chat VAP & DG SPPL Manager (7 msgs).",
      "current_problem": "AMBER. (1) Effort split VTI vs AP đã clarify (AP chỉ verify/test) nhưng chưa khoá hoàn toàn — Tu chưa thấy effort phần document. (2) Rebrand AP -> Keppel Tech cần update tất cả tài liệu/meeting title. (3) Process gap: Long gửi mail customer trực tiếp không CC manager Tu — risk control khi multiple PIC cùng dự án. (4) Issue technical chưa close: IP whitelist Kong/NLB — đang debate bật/tắt Preserve client IP addresses; ip-restriction plugin có nên bỏ. (5) Khách SPPL chấp nhận fix Argo branch + pipeline trước, refactor sau — schedule phải re-plan.",
      "tasks": [
        {
          "title": "Finalize effort sheet (gộp 2 file vào 1, bổ sung effort document) gửi SPPL",
          "status": "In progress — Long + Tu reviewing",
          "pic": "Long Chu Ngoc + Tu Tran Thi Ngoc (DG)",
          "next_action": "Gộp 2 file, bổ sung dòng effort document, Tu review trước khi gửi SPPL",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Update tài liệu/meeting title từ AsiaPac sang Keppel Tech",
          "status": "Open — Ivan đã đổi 1 meeting; còn tài liệu",
          "pic": "Tu Tran Thi Ngoc (DG) + Long Chu Ngoc",
          "next_action": "Rà soát tất cả tài liệu, email signature, repo README",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Resolve IP whitelist issue Kong/NLB (CRM -> Kong bị reject)",
          "status": "In debate — Preserve client IP vs bỏ ip-restriction plugin",
          "pic": "Phong Tran Hung + Tuan Nguyen Anh 5 (D1)",
          "next_action": "Test bật Preserve client IP ở target group; nếu không work, bỏ ip-restriction plugin (chấp nhận chỉ whitelist NLB)",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Re-plan schedule: fix Argo branch + pipeline trước, refactor sau",
          "status": "Open — khách SPPL accepted",
          "pic": "Long Chu Ngoc + Phong Tran Hung",
          "next_action": "Update plan + share lại với SPPL stakeholder",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Process control: Long gửi customer email phải CC Tu",
          "status": "Open — Tu đã khiển trách 1 lần",
          "pic": "Long Chu Ngoc + Tu Tran Thi Ngoc",
          "next_action": "Long commit CC manager mọi outbound mail; Tu set rule trong group",
          "deadline": "Immediate",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "AsiaPac IHL Portal",
      "priority": "AMBER",
      "weekly_activity": "W19 (04/05-10/05/2026) KHÔNG có IHL Portal CR Part 1/Part 2/Odoo/Ariba activity nào — toàn bộ scope expansion (Kit Yi Chow 5 deliverables, James Wai NEW capacity doc, Peyton accessory doc, Odoo 13 portals, SAP Ariba) chỉ phát sinh tại meeting IHL Portal CR Fri 15/05/2026 (TUẦN SAU window này). Memory baseline đã document đầy đủ nhưng các task 8013cbd1, d13c94f4, fdbe1661, 64decd04 đều có date_opened=15/05/2026 (postdate W19). Trong tuần W19 hệ sub-project lân cận Keppel (cùng cluster AsiaPac) gồm: (a) KTS (AsiaPac) E-commerce Portal ĐÃ ĐÓNG — Tam Tran Thi Thanh (D8) yêu cầu evidence để close + ký BBNT Milestone Go-live; Tuoi Dang Thi Xuan (PQM) hướng dẫn 5 việc: confirm gửi CSS, create case study, create CAR cho metric xấu (EE, CSS), allocate billable 0.14 còn lại, warranty info (start 28/11/2025, 6 tháng). Project ký 3 lần với khách (1 hợp đồng gốc + 2 phụ lục, chỉ hợp đồng gốc có bảo hành). (b) Keppel Wordpress Maintenance (49 msgs): D9 (Truong Cao Viet + Thang Nguyen Van 1) xử lý VAPT report HPT cho hanoicentre.com.vn + marinakeppelbay (vào được rồi); banner image cho Amy (hỏi từ lâu); tạo account vendor mới Rafi (Esensi) 06/05/2026 - 12/07/2026 cho SEO Ria Bintan; recurring conflict 'AP mệt lắm r'. (c) Sembcorp AMS Renewal RFX0002041 (8 msgs): Quyen Nguyen Thi Do gửi Linh Tran Quang (D1) check file merge comment legal + khách hàng; Linh gửi file đã fix comment kèm note: 'Sembcorp gửi lại tài liệu define SOW của bên họ, anh phải ảnh vào trong tài liệu rồi, có update tracking' — phần SOW có update quan trọng. (d) Sembcorp Incident One Alert Group Leader (3 msgs): Kevin báo customer pending go-live, không có updates/responses; Tai Do Anh sẽ email push tiếp. (e) AsiaPac credit balance (chat signal): nợ tổng SGD 260,500 — late SGD 102,500 + ready to pay SGD 158,000.",
      "current_problem": "AMBER (mix). (1) IHL Portal CR scope expansion sẽ bùng nổ tuần sau (W20) sau meeting 15/05/2026 — Tyson cần pre-warm. (2) KTS Ecommerce close-out: 5 thủ tục (CSS, case study, CAR, billable 0.14, warranty) cần Tam D8 + Tyson + Tuoi PQM kết thúc. (3) Keppel Wordpress: recurring friction 'AP mệt' + thiếu access UAT server, VAPT issues cần điều tra scope mình hay Royce; banner Amy chưa làm. (4) Sembcorp AMS Renewal: SOW update quan trọng từ Sembcorp, cần gửi AP với update tracking. (5) Sembcorp Incident: khách im lặng pending go-live, không reply WhatsApp/calls. (6) Công nợ AsiaPac CỰC LỚN SGD 260,500 — late SGD 102,500 — cần escalate finance.",
      "tasks": [
        {
          "title": "Pre-warm IHL Portal CR (Part 1 + Part 2 + Odoo + Ariba) trước meeting Fri 15/05/2026",
          "status": "Open — meeting tuần sau",
          "pic": "Tyson Nguyen + Kit Yi Chow + James Wai",
          "next_action": "Chuẩn bị 5 deliverables Kit Yi + capacity doc James + accessory doc Peyton trước meeting",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "KTS Ecommerce close-out: CSS + case study + CAR + billable 0.14 + warranty",
          "status": "Open — Tam D8 + Tuoi PQM dẫn 5 việc",
          "pic": "Tam Tran Thi Thanh (D8) + Tyson Nguyen + Tuoi Dang Thi Xuan (PQM)",
          "next_action": "Hoàn tất 5 thủ tục + ký BBNT Milestone Go-live; warranty start 28/11/2025 6 tháng",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Keppel Wordpress VAPT issues — điều tra scope, fix lên UAT",
          "status": "Open — D9 đã vào được hanoicentre + marinakeppelbay",
          "pic": "Truong Cao Viet + Thang Nguyen Van 1 (D9)",
          "next_action": "Verify scope VTI vs Royce; fix issues lên UAT; xin access nếu cần",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Keppel Wordpress — banner image cho Amy + tạo account Rafi (Esensi vendor SEO Ria Bintan)",
          "status": "Open — Amy hỏi từ lâu",
          "pic": "Truong Cao Viet (D9)",
          "next_action": "Làm banner image; tạo account Rafi window 06/05/2026 - 12/07/2026",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Sembcorp AMS Renewal RFX0002041 — gửi AP file cập nhật SOW (update tracking)",
          "status": "In progress — Linh đã fix comment legal + khách",
          "pic": "Quyen Nguyen Thi Do + Linh Tran Quang (D1)",
          "next_action": "Gửi AP file final với SOW update + tracking changes",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Sembcorp Incident One Alert — push khách phản hồi go-live",
          "status": "Open — khách im lặng",
          "pic": "Kevin Nguyen + Tai Do Anh (DG)",
          "next_action": "Tai Do Anh email push tiếp; Kevin gọi/WhatsApp lần 3",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Công nợ AsiaPac SGD 260,500 (late SGD 102,500 + ready to pay SGD 158,000) — escalate finance",
          "status": "Open — chat signal trong tracker",
          "pic": "Michael Nguyen + Kevin Nguyen + VTI Finance",
          "next_action": "Escalate finance team; gửi reminder formal cho AP CFO/AR; lock service nếu cần",
          "deadline": "Immediate",
          "priority": "RED"
        }
      ]
    },
    {
      "customer": "AsiaPac Cora Cloud & App Migration",
      "priority": "RED",
      "weekly_activity": "W19 (04/05-10/05/2026) là tuần cao điểm escalation. Thứ Hai 04/05/2026 11:43 UTC Tyson Nguyen reply mail 'Re: AsiaPac | VTI - Cora Cloud & App Migration - Documentation' (chuỗi gốc từ Do Manh Cuong @keppeltechsolutions.com gửi 30/04/2026 chasing outstanding documents và handover): Tyson đề nghị resolve step-by-step 3 việc: (1) DocuSign for Appendix 01 — yêu cầu Anthony Tor (@keppel.com) check; (2) VTI Quotation for extension of Day 1 service - 2 headcounts đến 24/04/2026 chưa confirm + PO; (3) Do Manh Cuong cho biết keep resource thêm bao lâu để Tyson update quotation. Cuong AP reply same day 21:50: 'I am chasing for your response to provide the pending works to complete the project'. Thứ Ba 05/05/2026 12:23 UTC Tyson resend bổ sung điểm 2 'extension of Day 1 service - 2 headcounts until April 24 is not yet confirmed and issued any PO'. Cùng ngày 14:29 Cuong AP reply chốt: outstanding documents + handover NẰM TRONG scope of work của VTI theo contract, 'you may need to check with your team how long they can complete'. Thứ Sáu 08/05/2026 02:06 UTC Cuong escalate trực tiếp Tyson + Michael Nguyen (VTI.APAC): 'As discussed yesterday, the outstanding documents and handover are in the scope of work that VTI team to deliver within the contract, please let us know when are they ready for review?' — quote ngày họp Thu 07/05/2026. Calendar W19: Thứ Năm 07/05/2026 15:00 SGT có meeting 'AsiaPac | VTI - Cora Cloud & App Migration - Documentation - Meeting' với 10 attendees (Cuong AP, Tyson, Anthony Tor, Kevin, Cuong VTI VAP, Selvaraj Prabhu, Khu Chun Hong, Alambilat Kaniyat Nibras, Nina Teo, Tuan Nguyen Van 2 D3, Michael, Ong Yong Ming, Leonard Wong). CC list email reveal team mở rộng cả Keppel infra. Khách Cuong đổi domain @keppeltechsolutions.com (rebrand Keppel).",
      "current_problem": "RED. (1) Khách AsiaPac (Do Manh Cuong, Anthony Tor) escalate liên tục 3 email trong 8 ngày (30/04, 05/05, 08/05/2026) đòi outstanding documents + handover — confirm là scope contract VTI deliver, không phải optional. Risk: chậm trễ ảnh hưởng final acceptance + payment. (2) DocuSign Appendix 01 đang chờ Anthony Tor check — process blocker. (3) VTI Quotation for extension of Day 1 service (2 headcounts đến 24/04/2026) chưa confirm + chưa có PO — risk không thu được tiền extension đã làm. (4) Chưa rõ Do Manh Cuong muốn keep resource thêm bao lâu — Tyson không update được quotation tiếp. (5) Documentation list cụ thể chưa được rõ ràng từ phía VTI — team D3 (Tuan Nguyen Van 2) cần ETA cho mỗi tài liệu. (6) Khách rebrand domain @keppeltechsolutions.com — communication channel cần update.",
      "tasks": [
        {
          "title": "Cung cấp ETA cho outstanding documents + handover Cora Cloud Migration",
          "status": "Open — khách escalate 3 lần, chờ VTI commit timeline",
          "pic": "Tyson Nguyen + Tuan Nguyen Van 2 (D3) + Michael Nguyen",
          "next_action": "Tuan D3 list từng document còn thiếu + ETA cụ thể; Tyson reply formal cho Do Manh Cuong + Anthony Tor trong tuần 11/05-15/05/2026",
          "deadline": "15/05/2026",
          "priority": "RED"
        },
        {
          "title": "Hoàn tất DocuSign Appendix 01 (Anthony Tor check)",
          "status": "Open — chờ Anthony Tor (Keppel) ký",
          "pic": "Tyson Nguyen + Anthony Tor (Keppel)",
          "next_action": "Tyson follow up Anthony Tor ký DocuSign; nếu Anthony im lặng, escalate qua Cuong AP",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "RED"
        },
        {
          "title": "VTI Quotation extension Day 1 service - 2 headcounts đến 24/04/2026 + PO",
          "status": "Open — chưa confirm + chưa có PO",
          "pic": "Tyson Nguyen + Kevin Nguyen + Do Manh Cuong (AsiaPac)",
          "next_action": "Do Manh Cuong xác nhận keep resource thêm bao lâu để Tyson update quotation final; sau đó push PO",
          "deadline": "Tuần 11/05-15/05/2026",
          "priority": "RED"
        },
        {
          "title": "Update communication channel với domain mới @keppeltechsolutions.com",
          "status": "Open — khách rebrand",
          "pic": "Tyson Nguyen",
          "next_action": "Update contact list; check tất cả email outbound dùng domain mới",
          "deadline": "Immediate",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "Mitsubishi Corporation (MC HCMC + MC SG)",
      "priority": "RED",
      "weekly_activity": "Tuan W19 (04/05/2026 -> 10/05/2026): (1) MC HCMC IT body-shop 6-month trial - Saoko Miyamoto (Mitsubishi Corp Tokyo HR) thread 'Following up about IT personnel' tiep tuc 29 msgs trao doi ve candidate Nguyen Ngoc Toan; phia TA chi Hoai trong space '[VAP & TA] Mitsubishi Corporation - IT Engineer in MC HCMC & Singapore Office' (42 msgs) push Michael - candidate da doi quyet dinh ~2 tuan. (2) Khanh Tran Duy to chuc Re-hearsal IT MC HCMC ngay 08/05/2026 15:00 ICT (2 calendar invites trung gio) chuan bi candidate Toan cho phong van online Tam-san + Dung-san. (3) Khanh mention Michael trong VTI.VAP chat 08/05/2026 voi Drive folder chot MC HCMC - doi Michael review. (4) MC Singapore - Kondo-san la driver phia MC SG yeu cau mo hinh khac han HCMC (long-term liaison: 1 VTI engineer sang MC SG 2 nam roi ve lam department lead phan hop tac Mitsubishi); Kondo-san chua chot lich phong van; chat group noi bo 'IT for MC Singapore' (Khanh + Khoi Tran Xuan + Ha Pham Thanh BOD + Thanh Nguyen Minh VTI.IT) dang sourcing - chua co internal candidate phu hop.",
      "current_problem": "RED - Khach MC HCMC da doi quyet dinh candidate Toan ~2 tuan; Khanh chua gui email accept 6-month trial cho Tam-san + Dung-san; Charlotte chua draft trial contract. Phia MC SG con cang hon: Kevin + Charlotte owe Kondo-san 2-option deck (body-shop SG vs full-stack VTI engineer onsite 2 nam) deadline 16/05/2026; mo hinh MC SG long-term liaison chua duoc formalize. Noi bo TA raise concern dieu kien 'phai la nguoi VTI' khong ro rang tu dau - mau thuan voi sourcing bodyshop by-name thong thuong.",
      "tasks": [
        {
          "title": "Email MC HCMC accept 6-month IT body-shop trial + cam ket English nang luc candidate Nguyen Ngoc Toan",
          "status": "Open - chua gui",
          "pic": "Khanh Tran Duy (VTI.VAP)",
          "next_action": "Draft email accept trial, ghi ro commitment English level cua candidate Toan, gui Tam-san + Dung-san CC Kondo-san + Kane-san + Saoko Miyamoto",
          "deadline": "12/05/2026",
          "priority": "RED"
        },
        {
          "title": "Phong van online candidate Nguyen Ngoc Toan voi Tam-san + Dung-san (MC HCMC)",
          "status": "Da book lich (calendar invite Kevin Nguyen) Tue 12/05/2026 15:30 ICT",
          "pic": "Michael Nguyen + Khanh Tran Duy",
          "next_action": "Join interview, support candidate, gui feedback noi bo cho VAP team ngay sau buoi; chot go/no-go trong 24h",
          "deadline": "12/05/2026",
          "priority": "RED"
        },
        {
          "title": "Chot quyet dinh candidate Toan - review Drive folder Khanh share trong VTI.VAP 08/05/2026",
          "status": "Dang cho Michael review",
          "pic": "Michael Nguyen",
          "next_action": "Mo Drive folder Khanh mention trong VTI.VAP, dua quyet dinh cuoi, reply chat space MC HCMC + TA chi Hoai",
          "deadline": "12/05/2026",
          "priority": "RED"
        },
        {
          "title": "Draft + send 6-month service trial contract MC HCMC (template body-shop IT)",
          "status": "Chua bat dau",
          "pic": "Charlotte (Quyen Nguyen Thi Do)",
          "next_action": "Soan trial contract dung template VTI APAC body-shop IT (Legal-first format theo phong cach Nhat), gui Saoko Miyamoto + Tam-san review; HD template hoan chinh 20/05/2026",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Propose 2-option deck cho MC Singapore (body-shop SG vs full-stack VTI engineer onsite 2 nam + ve liaison)",
          "status": "Chua bat dau",
          "pic": "Kevin Nguyen + Charlotte (Quyen Nguyen Thi Do)",
          "next_action": "Build deck so sanh 2 options: (a) body-shop SG cost-of-living premium, (b) full-stack VTI engineer 2 nam + ve lam liaison department lead; review internal truoc khi pitch Kondo-san; align pricing VN-based vs SG-based",
          "deadline": "16/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Tim internal candidate VTI cho MC SG (skill set IT + Infra knowledge)",
          "status": "Dang sourcing - chua co ai phu hop",
          "pic": "Khanh Tran Duy + Thanh Nguyen Minh (VTI.IT)",
          "next_action": "Khanh tiep tuc lam viec voi Thanh Nguyen Minh tim candidate; backup gui internal pv-pass candidate sang MC pv; xin reference tu BOM/BOD (Khoi Tran Xuan / Ha Pham Thanh) khi co req cu the",
          "deadline": "Khi co req cu the tu Kondo-san (tuan W20-W21)",
          "priority": "AMBER"
        },
        {
          "title": "Push Kondo-san chot lich phong van + scope cu the MC SG",
          "status": "Dang treo - Kondo-san chua chot lich",
          "pic": "Michael Nguyen + Kevin Nguyen",
          "next_action": "WhatsApp Kondo-san hoi lich + confirm long-term liaison model, align voi deck 2-option sau khi pitch",
          "deadline": "Tuan W20 (11/05/2026 -> 15/05/2026)",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "VTI Da Nang Grand Opening Ceremony (22-23/05/2026)",
      "priority": "AMBER",
      "weekly_activity": "Tuan W19 (04/05/2026 -> 10/05/2026): VTI Da Nang Grand Opening Ceremony 22-23/05/2026 - Kevin Nguyen dieu phoi email thread '[MC & VTI] Invitation to VTI Da Nang Grand Opening Ceremony on 22-23 May 2026' voi 3 MC representatives da confirm attending: Kaname Kondo (MC-RCA), Samuel-W-H Ho (MC-SIN), va Seigo Shoda (MC-TOK/PW). Seigo Shoda chot flight 22/05/2026 SQ172 SIN 09:15 -> DAD 11:05 va return 24/05/2026 SQ171 DAD 11:55 -> SIN 15:55; chon Hilton Da Nang river view. MC se tu handle transportation tai Da Nang nhung dung transport VTI cho Hoi An tour ngay 23/05/2026 (pickup hotel lobby 11:00). Kevin update dress code tu business formal -> business casual (no tie) vi thoi tiet Da Nang nong. Space VDN Grand Opening (34 msgs) - BTC push cap nhat gio bay khach (nhieu khach chua update), Linh Nguyen Thi Thuy (VJP) confirm khach BD Nhat o VN tu di chuyen; Giang Phuong Huong (VTI.MKT) confirm thiep in xong, slide intro Da Nang pending convert tu Adobe sang PPTX.",
      "current_problem": "AMBER - Logistics cang vi nhieu khach chua cap nhat gio bay (BTC raise ngay 04/05/2026); slide intro Da Nang lam bang Adobe chua co PPTX de gui khach truoc; BTC can hop chot transportation/dua don truoc event 8 ngay (15/05/2026). 3 MC reps Kondo + Samuel + Shoda da confirm, rieng Shoda da chot day du flight + hotel; con 2 khach khac can Kevin chot flight schedule.",
      "tasks": [
        {
          "title": "Thu du gio bay + hotel cua toan bo MC representatives (Kondo, Samuel con pending update)",
          "status": "In progress - Shoda da chot; Kondo + Samuel chua ro gio bay",
          "pic": "Kevin Nguyen + Linh Nguyen Thi Thuy (VJP)",
          "next_action": "Ping Kondo-san + Samuel-san xin flight schedule + hotel; forward Admin (Giang Phuong Huong VTI.MKT + Ha Nguyen Thi Thu VJP) arrange transportation pickup",
          "deadline": "08/05/2026 (deadline BTC) - truot sang 15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Finalize Hoi An tour 23/05/2026 logistics (pickup Hilton lobby 11:00 dung transport VTI cho ca 3 MC reps)",
          "status": "Confirmed - pickup time + transport mode da thong nhat",
          "pic": "Kevin Nguyen + Linh Nguyen Thi Thuy (VJP)",
          "next_action": "Gui detailed guidelines + agenda Hoi An cho 3 MC reps truoc 15/05/2026; confirm xe + tai xe + tour guide",
          "deadline": "15/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Convert slide gioi thieu Da Nang tu Adobe sang PPTX gui khach MC truoc event",
          "status": "Pending - file goc la Adobe, MKT confirm khong co PPTX",
          "pic": "Giang Phuong Huong (VTI.MKT)",
          "next_action": "Convert/screenshot 1-2 slide intro Da Nang + gui cho Linh Nguyen Thi Thuy (VJP) forward cho khach Nhat truoc event",
          "deadline": "15/05/2026",
          "priority": "GREEN"
        },
        {
          "title": "BTC hop chot logistics tong (dua don, dress code, agenda ngay 22-23/05/2026)",
          "status": "Pending - BTC raise nhu cau hop ngay 04/05/2026",
          "pic": "Linh Nguyen Thi Thuy (VJP) + Kevin Nguyen + Cuong Nguyen Duc 2 (VTI.VAP)",
          "next_action": "Setup hop BTC, fix dress code business casual (no tie) da duoc update, confirm agenda 2 ngay, prep contingency cho khach chua update flight",
          "deadline": "15/05/2026 (8 ngay truoc event)",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "PSA Marine PSAM - DevSecOps Milestone 6 (End-of-Warranty)",
      "priority": "GREEN",
      "weekly_activity": "Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[PSAM & VTI] DevSecOps Project - Payment Review for Milestone 6 - End of Warranty' - Charlotte (Quyen Nguyen Thi Do) gui review chinh thuc ngay 05/05/2026 cho PSAM (Dennis Moy, Adrian); plan follow-up 1 tuan ngay 11/05/2026 -> Dennis approve qua bdg@globalpsa cung ngay 11/05/2026 -> Charlotte submit invoice 1017 vao Oracle portal PSA ngay 12/05/2026. Phase End-of-Warranty closed cleanly khong co blocker.",
      "current_problem": "GREEN - Phase EOW da dong sach, invoice 1017 da vao Oracle portal. Khong co blocker. Chi can monitor payment cycle PSA (thuong 30-45 ngay). Tach rieng: Bank statement cho first electronic payment Global PSA (Evangeline Tan thread) da chuyen sang Operation section vi Michael owe ~10 ngay ke tu reminder 06/05/2026.",
      "tasks": [
        {
          "title": "Theo doi payment Milestone 6 EOW (invoice 1017) sau khi da submit Oracle portal PSA",
          "status": "Da submit Oracle 12/05/2026 - doi payment theo cycle PSA (30-45 ngay)",
          "pic": "Charlotte (Quyen Nguyen Thi Do)",
          "next_action": "Monitor Oracle portal weekly; ping Dennis Moy + bdg@globalpsa khi gan due payment (target 11/06/2026 -> 26/06/2026)",
          "deadline": "Theo PSA payment cycle (typically 30-45 ngay tu 12/05/2026)",
          "priority": "GREEN"
        }
      ]
    },
    {
      "customer": "PSA PSAM Warehouse (Site Visit BQ Follow-Up R13.1/R13.2)",
      "priority": "AMBER",
      "weekly_activity": "Tuan W19 (04/05/2026 -> 10/05/2026): Thread '[Request for BQ] Follow-Up on PSAM Warehouse Site Visit' - sau site visit 28/04/2026, Allen L. (ALLENL@globalpsa.com) gui requirement list; Khanh Tran (Kane) request clarify R13.1/R13.2 (item images, image matching scope); Allen reply ngay 07/05/2026 voi chi tiet ~1100 SKUs + answers; Kane submit BQ + compliance table chinh thuc ngay 08/05/2026. Song song: chat space [VAP & VSL] PSAM-WMS rat active (158 msgs trong tuan) - dang trien khai 15 cap API (Ha Pham Thanh BOD + Tuan Dinh Huy VSL.Delivery), thao luan server tach rieng hay chung; meeting 'PSAM WMS-X Internal Sync-up pre-submission' ngay 07/05/2026 15:00 ICT.",
      "current_problem": "AMBER - BQ Warehouse R13.1/R13.2 da submit 08/05/2026, dang cho Allen L. review noi bo PSA (waiting_days du kien 8 ngay tinh toi 16/05/2026). Scope ~1100 SKUs image matching can clarification them neu PSA push back. PSAM-WMS API delivery cao tai (15 cap API) - can daily sync de khong miss deadline.",
      "tasks": [
        {
          "title": "Follow Allen L. (PSA) feedback BQ Warehouse R13.1/R13.2 (submitted 08/05/2026)",
          "status": "Da submit 08/05/2026 - dang doi PSA review noi bo",
          "pic": "Khanh Tran (Kane)",
          "next_action": "Sau 5-7 ngay khong reply (target 14/05/2026) -> gui follow-up nhe toi Allen L. + CC Bernard + Sean; chuan bi clarification cho ~1100 SKU image matching scope",
          "deadline": "Tuan W20-W21 (11/05/2026 -> 22/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "PSAM WMS API delivery - duy tri cadence 15 cap API",
          "status": "Active development (158 msgs tren chat space trong tuan)",
          "pic": "Khanh Tran (Kane) + Ha Pham Thanh (BOD) + Tuan Dinh Huy (VSL.Delivery)",
          "next_action": "Tiep tuc daily sync tren chat space PSAM-WMS; track API completion list weekly; chot server tach rieng vs chung sau call voi Ha Pham Thanh",
          "deadline": "Theo project schedule",
          "priority": "GREEN"
        },
        {
          "title": "Prep cho PSA review meeting / clarification call ~1100 SKUs",
          "status": "Standby",
          "pic": "Khanh Tran (Kane)",
          "next_action": "Chuan bi technical answers cho image matching algorithm + SKU master mapping; san sang host clarification call neu PSA request",
          "deadline": "Tuan W20-W21 (11/05/2026 -> 22/05/2026)",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "Wiki Labs (NxGen AIOps / Lucid Impact)",
      "priority": "RED",
      "weekly_activity": "Tuần W19 (04-10/05/2026) là tuần kick-off tender response cho NxGen HDB AI: (1) Wed 06/05/2026 Tyson Nguyen chair online 'AI Ops Opportunity Discussion' với Wiki Labs — Danny Thian (danny.thian@wikilabs.asia) + Alban + Azreen Ariff để tìm hiểu use cases AIOps end-client. (2) Mail thread 'Opportunities & Collaboration - VTI X Lucid Impact' (8 msgs, 7 Drive URLs đính kèm) từ Danny Thian, last reply 12/05/2026. (3) Thu 08/05/2026 03:03 ICT Tyson gửi calendar invite 'VAP D3 - 2nd Remind internal - Collect Detailed AI Ops use cases & demo' cho Mon 11/05/2026 với Daniel Nguyen + Tuan Nguyen Van 2 + Chien — internal sprint chuẩn bị demo. (4) Chat space [VAP D3] Wiki Labs - AIOps cực kỳ active (234 msgs trong tuần) — team D3 (Trung Tran Quoc + Justin Nguyen + Ethan Nguyen) dựng demo Dynatrace observability: deploy Dynatrace operator lên k8s (free trial 15 ngày), build MCP server giúp AI agent truy cập dữ liệu Dynatrace. Deadline nội bộ slip từ 'today' sang Mon 11/05/2026. (5) Song song 14/05/2026 cuộc họp [NxGen & VTI] Agentic AI tạo 4 action items (tracker 8087a53a + 3b66f45e + 26bb694c + 2c3db231); 15/05/2026 07:42 ICT Ian Choy gửi RFI chính thức (15 use cases, AWS).",
      "current_problem": "RED — đây là PRIMARY ACTIVE OPP / ESCALATION. (1) Tender deadline 21/05/2026 cực gấp; proposal v1 + budget phải gửi Ian Choy 21/05/2026. (2) Demo materials (Dynatrace observability + AI agent MCP) chưa hoàn thiện, deadline 15/05/2026 internal đã slip — team D3 vẫn loay hoay Dynatrace setup, Justin Nguyen build MCP server chưa rõ tiến độ. (3) Cloud provider cho MCP hosting cần Kevin Nguyen clarify với Ian Choy (chốt AWS) DL 16/05/2026. (4) Customer reference approval (Aura Japanese case) cho external share TBC. (5) Michael Nguyen + Kevin Nguyen chưa sync architecture decision (Qwen vs Gemini model hosting) — DL 19/05/2026. (6) Compile Aura videos + multi-agent case study deck (Kevin Nguyen DL 16/05/2026).",
      "tasks": [
        {
          "title": "Produce AIOps demo (Dynatrace observability + AI agent via MCP) + multi-agent case study deck",
          "status": "In progress — DL nội bộ 15/05/2026 đã slip, team D3 đang setup Dynatrace free trial + k8s deploy",
          "pic": "Daniel Nguyen + Tuan Nguyen Van 2 (lead) + Trung Tran Quoc (VTI.D3) + Justin Nguyen + Ethan Nguyen",
          "next_action": "Hoàn tất Dynatrace operator deploy lên k8s, dựng MCP server cho AI agent query Dynatrace data, record demo video 3-5 phút + slide multi-agent case study; gửi Kevin Nguyen review trước 16/05/2026",
          "deadline": "15/05/2026 (đã slip — push 18/05/2026 hoàn tất)",
          "priority": "RED"
        },
        {
          "title": "NxGen HDB AI Tender — proposal v1 + budget gửi Ian Choy",
          "status": "Open — chưa bắt đầu",
          "pic": "Kevin Nguyen (lead) + Khanh Tran Duy (AI architecture) + Michael Nguyen (sign-off)",
          "next_action": "Build proposal v1: scope (15 use cases Agentic AI trên AWS), approach (multi-agent Qwen/Gemini + AIOps ITSM), team plan, budget high-level; gửi Ian Choy",
          "deadline": "21/05/2026",
          "priority": "RED"
        },
        {
          "title": "Compile + share demo materials (Aura videos + multi-agent presentations) cho NxGen",
          "status": "Open — phụ thuộc customer reference approval Aura case",
          "pic": "Kevin Nguyen",
          "next_action": "Tổng hợp Aura chatbot videos + multi-agent analyst-replacement decks; xin approval Aura cho external share; đóng gói 1 demo package gửi Ian Choy",
          "deadline": "16/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Clarify cloud provider cho MCP hosting với NxGen (confirm AWS)",
          "status": "Open — pending Kevin Nguyen",
          "pic": "Kevin Nguyen",
          "next_action": "Email/call Ian Choy confirm tender yêu cầu AWS (tender đã chỉ định AWS); align với architecture proposal",
          "deadline": "16/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Architecture + model hosting decision sync (Qwen vs Gemini, on-prem vs cloud)",
          "status": "Open — Michael Nguyen chưa align Kevin Nguyen",
          "pic": "Michael Nguyen + Kevin Nguyen + Khanh Tran Duy",
          "next_action": "Họp internal architecture: chốt model (Qwen on-prem vs Gemini cloud), MCP hosting plan AWS, multi-agent orchestration approach; align xong trước submit",
          "deadline": "19/05/2026",
          "priority": "RED"
        },
        {
          "title": "Theo dõi Ian Choy gửi RFI data points bổ sung (post-RFI 15/05/2026)",
          "status": "Waiting external — Ian Choy commit gửi data points Mon 18/05/2026",
          "pic": "Kevin Nguyen (point of contact)",
          "next_action": "Nếu sau 18/05/2026 chưa nhận → ping Ian Choy; data points dùng cho detailed costing + technical scope refinement",
          "deadline": "18/05/2026 (Ian Choy side)",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "SLW Technology — Magento Developers",
      "priority": "AMBER",
      "weekly_activity": "Tuần W19 (04-10/05/2026): SLW Technology là thầu chính (Singapore end-client công ty sản xuất quần áo) — cần 10 Magento 2 Developers, 3+ năm exp, ENG fluent (ít nhất 7-8 ông), 6 tháng service period, target onboard tháng 6/2026. Wed 08/05/2026 Cuong Nguyen Duc 2 + Khanh Tran Duy push 6 CV batch 1 vào folder CV Preparation; Kevin Nguyen gửi mail '[SLW Technology & VTI] CVs for Magento Developers Request' tới Gary (Philip @SLW). Chat VTI.VAP: Khanh Tran Duy ping Michael Nguyen xin review trước khi gửi khách; Michael Nguyen nhận xét pack CV có vấn đề mismatch level (1 ông middle 3 năm lệch trong khi rest 11-15 năm Senior) và cảnh báo điều khoản GITS-candidate (GITS contract chỉ ràng buộc 3 ngày notice — quá ngắn, VTI muốn ≥45 ngày). Sun 11/05/2026 Gary phản hồi nhận info sẽ chuyển khách. Thu 15/05/2026 02:27 ICT Khanh Tran Duy follow-up Gary hỏi feedback — chưa có reply (waiting_days=1).",
      "current_problem": "AMBER. (1) End-client (Singapore) target onboard 10 ông tháng 6/2026 → timeline pressure cao; nếu Gary delay feedback >1 tuần, miss onboarding tháng 6/2026. (2) Mismatch level trong batch 1 (1 ông middle 3 năm lệch vs Senior 11-15 năm) — khách có thể reject batch. (3) Risk hợp đồng GITS-candidate chỉ 3 ngày notice → VTI commit 10 HC mà có thể bị rút bất cứ lúc nào; cần renegotiate với GITS commit notice ≥45 ngày TRƯỚC khi sign hợp đồng với SLW. (4) Khách thầu chính SLW chắc gọi nhiều vendor song song → mỗi vendor có thể chỉ được vài người; phải submit >10 CV để tăng tỉ lệ trúng. (5) Anh Sang Truong Minh (GITS) ngỏ ý lead team nhưng management model (under team SLW hay direct với khách) chưa clear.",
      "tasks": [
        {
          "title": "Follow up Gary (SLW) cho customer feedback batch 1 + batch 2",
          "status": "Waiting external — Khanh Tran Duy đã follow 15/05/2026, chưa có reply",
          "pic": "Khanh Tran Duy (VAP, primary) + Kevin Nguyen (CC mail)",
          "next_action": "Nếu sau 18/05/2026 vẫn chưa reply → gọi điện Gary trực tiếp; hoặc ping Philip @SLW (end-client side)",
          "deadline": "20/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Renegotiate GITS-candidate notice period clause (3 ngày → ≥45 ngày) trước khi ký SLW",
          "status": "Open — chưa start",
          "pic": "Cuong Nguyen Duc 2 + Sang Truong Minh (GITS)",
          "next_action": "Họp với GITS (Luong manager + Sang Truong Minh) chốt điều khoản notice ≥45 ngày trong contract GITS↔candidate Magento, để VTI cam kết được SLW; sửa template hợp đồng GITS",
          "deadline": "Trước khi ký với SLW (target tuần 25/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "Clarify management model (Sang Truong Minh lead team under SLW hay direct khách)",
          "status": "Open — Cuong Nguyen Duc 2 đang confirm với GITS",
          "pic": "Cuong Nguyen Duc 2 + Sang Truong Minh (GITS)",
          "next_action": "Confirm 2 option: (a) Sang Truong Minh lead 10 ông Magento report direct VTI/GITS; (b) 10 ông sit under SLW manager. Ảnh hưởng commercial + Sang involvement",
          "deadline": "Tuần 18-22/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "UPP — Salesforce/NPSP/Drupal RA",
      "priority": "AMBER",
      "weekly_activity": "Tuần W19 (04-10/05/2026) là tuần cao điểm UPP với 3 meetings liên tiếp: (1) Mon 05/05/2026 14:00 ICT '[UPP & VTI] Customer Sync-up on Salesforce, NPSP, and Drupal Resources Augmentation Request' — sync đầu tiên với Tien (UPP). (2) Mon 05/05/2026 16:56 ICT Kevin Nguyen gửi 'Updated invitation: [UPP & VTI] Discuss quote for Salesforce and NPSP Resources Augmentation Request' cho Wed 06/05/2026 11:00 ICT — mở rộng cover thêm Drupal track. (3) Wed 06/05/2026 11:00 ICT meeting Discuss quote diễn ra. (4) Thu 07/05/2026 14:00 ICT '[UPP & VTI] 2nd Customer Sync-up on Salesforce, NPSP, and Drupal Resources Augmentation Request' — sync thứ 2 sau khi review quote. Post-meeting chưa thấy follow-up email nào trong mail_threads. Bối cảnh thêm: trong chat Group_KHOI/CUONG (W19), Cuong Nguyen Duc 2 đề cập 1 case khác 'Salesforce & NPSP tender với bên TF - anh Quân' — Cuong Nguyen Duc 2 hỏi Khoi Tran Xuan nếu drop có sao không vì 'bên họ follow mù mờ, họp đến buổi thứ 2 mà CTO nch như người zời'. Khoi Tran Xuan confirm 'không sao' — đây là case song song KHÁC UPP nhưng cùng tech stack, có thể overlap vendor pool.",
      "current_problem": "AMBER. (1) Sau 3 meetings dày đặc trong tuần (05-07/05/2026), post-meeting chưa có concrete follow-up: chưa gửi quote chi tiết Salesforce + NPSP + Drupal cho Tien (UPP). Risk: deal stale nếu chậm response. (2) Scope final chưa clear — cần Tien confirm tech stack split (chỉ Salesforce/NPSP hay full 3-track Drupal). (3) VAP vendor pool overlap với case TF/anh Quân — nếu drop case TF thì có effort cho UPP nhưng nếu không drop, capacity căng. (4) Không có ai PIC rõ ràng ngoài Kevin Nguyen trong context — cần align ai owns quote-building.",
      "tasks": [
        {
          "title": "Gửi quote chi tiết Salesforce + NPSP + Drupal RA cho Tien (UPP) sau 3 meetings W19",
          "status": "Open — chưa làm post-3-meetings (05/05, 06/05, 07/05/2026)",
          "pic": "Kevin Nguyen (lead) + Cuong Nguyen Duc 2 (vendor coordination)",
          "next_action": "Confirm scope với Tien (call/email), build quote 3-track (Salesforce + NPSP + Drupal) với rate + headcount + ramp-up timeline; gửi formal proposal",
          "deadline": "Tuần 18-22/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Quyết định drop hay không case Salesforce/NPSP tender với TF (anh Quân) song song",
          "status": "Khoi Tran Xuan đã confirm 'không sao' nếu drop",
          "pic": "Cuong Nguyen Duc 2",
          "next_action": "Nếu drop → thông báo TF (anh Quân) chính thức, giải phóng vendor pool cho UPP; nếu giữ → align capacity 2 case",
          "deadline": "Tuần 18-22/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "SWAT Mobility — Customization",
      "priority": "AMBER",
      "weekly_activity": "Tuần W19 (04-10/05/2026): Thu 08/05/2026 06:06 ICT Kevin Nguyen gửi 'Invitation: [SWAT Mobility & VTI] Sync-up on the customizations for enterprise clients' cho Fri 08/05/2026 14:00 ICT với Bing Yang Sim (SWAT). Mail thread '[SWAT Mobility & VTI] Following up meeting in Singapore in Mar 2026' (10 msgs, last 07/05/2026) — chuỗi follow-up từ cuộc gặp Singapore tháng 3/2026. Bing Yang Sim reply cùng ngày confirm muốn share intended framework collaboration. Sync call Fri 08/05/2026 diễn ra — SWAT đang tìm SI partners để customization cho enterprise clients; Bing Yang Sim chuẩn bị materials cho new product launch + engagement model, sẽ comeback trong vài ngày. Mail thread status: 'awaiting_michael_reply' (Michael Nguyen chưa reply confirm follow-up plan).",
      "current_problem": "AMBER. (1) Đang chờ SWAT (Bing Yang Sim) gửi materials new product launch + engagement model — chưa nhận tính đến 16/05/2026. (2) Michael Nguyen chưa reply mail thread của Bing Yang Sim để confirm next steps. (3) Quan hệ chưa có concrete deliverable — vẫn ở stage discovery; cần Bing Yang Sim share materials thì mới có thể đánh giá fit. (4) Anthony's pipeline có ghi SWAT Mobility trong 'Pipeline (light)' — Anthony có thể push update trong Fri sync.",
      "tasks": [
        {
          "title": "Michael Nguyen reply Bing Yang Sim mail thread confirm follow-up plan + interest",
          "status": "Open — Michael Nguyen chưa reply (mail status awaiting_michael_reply)",
          "pic": "Michael Nguyen",
          "next_action": "Reply Bing Yang Sim: thank-you for sync 08/05/2026, confirm VTI interest as SI partner, ask Bing Yang Sim send materials khi sẵn sàng",
          "deadline": "Tuần 18-22/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Follow SWAT (Bing Yang Sim) cho new product launch materials + engagement model",
          "status": "Waiting external — Bing Yang Sim commit comeback",
          "pic": "Kevin Nguyen (primary) + Michael Nguyen",
          "next_action": "Ping nhẹ Bing Yang Sim tuần 22/05/2026 nếu chưa nhận materials; sau khi nhận → đánh giá fit + propose partnership model",
          "deadline": "22/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "Sembcorp IT Infrastructure (separate from C99)",
      "priority": "AMBER",
      "weekly_activity": "Tuần W19 (04-10/05/2026): Chat space [VAP] Sembcorp IT Infrastructure Assessment and Maintenance (27 msgs trong tuần) phát hiện scope MỚI: Sembcorp phản hồi muốn thuê part-time 6 tháng đầu, sau đó xem xét chuyển fulltime, VÀ có ý định 'mua đứt headcount' (buyout) nên cần báo giá. Mail thread 'VTI - IT Infrastructure Project Support in Hanoi' (31 msgs, last 12/05/2026) là backbone trao đổi. Cuong Nguyen Duc 2 (VAP) check với anh Thành (D9/người nội bộ) — anh Thành OK serve case + OK transfer nhân sự nếu NV đồng ý. Khanh Tran Duy đề xuất pricing: charge buyout = x2.5 giá full-time (refer Google Sheet template). Cuong Nguyen Duc 2 soạn draft response gửi khách: 'VTI đồng ý nguyên tắc Sembcorp mua đứt nhân sự sau 1 năm; cần làm rõ quy trình làm việc + thoả thuận 3 bên'. Michael Nguyen chốt: 'nếu bán thì để theo giá full; nếu không bán thì trong contract thêm điều khoản nhân viên sau khi nghỉ VTI thì 1 năm không được làm việc trực tiếp với SembCorp'. Song song W20 (15/05/2026) chị Huyền reject 2 candidates English fluency — cần 2-option re-pitch (Fulltime native EN vs Partime VTI fallback) DL 21/05/2026.",
      "current_problem": "AMBER. (1) Cần align commercial position: keep nguyên giá part-time, charge buyout x2.5 giá fulltime, thêm clause non-solicitation 1 năm — Cuong Nguyen Duc 2 soạn xong draft nhưng chưa gửi khách (tracker 3942b6a7 DL 13/05/2026 — đã quá hạn). (2) VTI chưa có reference quote bán đứt headcount → first-time pricing risk; Khanh Tran Duy dùng x2.5 nhưng cần Michael Nguyen final sign-off. (3) Sembcorp Incident One Alert Group Leader (chat space riêng): Kevin Nguyen báo Tai Do Anh (DG) khách pending go-live, không có updates/responses; chị Tai email push tiếp, Kevin Nguyen gọi bạn ý 2 lần không được → blocking go-live separate engagement. (4) Risk overlap với case English fluency reject — phải xử lý 2 track song song (commercial buyout + 2-option re-pitch English).",
      "tasks": [
        {
          "title": "Confirm Sembcorp commercial — keep giá part-time, charge buyout x2.5 fulltime, thêm clause non-solicitation 1 năm",
          "status": "Open — Cuong Nguyen Duc 2 soạn draft, chưa gửi (tracker 3942b6a7)",
          "pic": "Cuong Nguyen Duc 2 + Khanh Tran Duy (VAP) — Michael Nguyen final sign-off",
          "next_action": "Internal alignment Michael Nguyen; Cuong Nguyen Duc 2 send formal email Sembcorp: 3 điểm — part-time price nguyên giá, buyout x2.5 fulltime, clause restrict NV sau nghỉ VTI 1 năm không work direct với SembCorp",
          "deadline": "13/05/2026 (đã quá hạn — push 20/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "2-option re-pitch English fluency (Fulltime native EN vs Partime VTI fallback) cho chị Huyền",
          "status": "Open — chưa start (sau reject 15/05/2026)",
          "pic": "Cuong Nguyen Duc 2 (direct chat chị Huyền clarify) + VAP team build deck",
          "next_action": "Bước 1: Cuong Nguyen Duc 2 direct chat chị Huyền clarify English requirement chi tiết. Bước 2: VAP team build 2-option deck. Bước 3: gửi chị Huyền 21/05/2026",
          "deadline": "21/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Sembcorp Incident One Alert Group Leader — push khách pending go-live",
          "status": "Blocked — khách không response Kevin Nguyen (gọi 2 lần không bắt máy)",
          "pic": "Tai Do Anh (DG) + Kevin Nguyen",
          "next_action": "Tai Do Anh email escalation; Kevin Nguyen thử trao đổi với bác Jon (alt contact) — nếu vẫn không có response trong tuần 22/05/2026, raise lên management Sembcorp",
          "deadline": "22/05/2026",
          "priority": "AMBER"
        }
      ]
    },
    {
      "customer": "GITS — Offshore Magento Bodyshop",
      "priority": "AMBER",
      "weekly_activity": "Tuần W19 (04-10/05/2026): GITS là recruiting vendor VTI chọn để source CV cho case SLW Technology (đính kèm — case CV Magento Developers 10 HC cho Singapore end-client). Đầu W19 Cuong Nguyen Duc 2 (VAP) brief case cho Sang Truong Minh (GITS) + Thoa Tran Thi Bao 1 (GITS.REC) qua chat space 'Space_[GITS & VAP] Offshore Magento Developers (Bodyshop)' (30 msgs trong tuần) — Operation & Management: cần 10 Magento 2 Developers, 3+ năm exp, ENG, 6 tháng service. GITS chốt đội hình: Luong (manager) + Thoa/Yen/Truc (REC team). Thoa Tran Thi Bao 1 source 6 CV batch 1 (senior + middle), convert template VTI cho khách Sing. Sang Truong Minh ngỏ ý 'có anh có thể lead team luôn'. Mon 12/05/2026 Khanh Tran Duy + Cuong Nguyen Duc 2 xử lý batch 2 (4 CV thêm) — Cuong Nguyen Duc 2 owe verify content/template CV theo template Sing trong Drive (tracker adfcfe09 DL 13/05/2026). Ngoài Magento bodyshop, GITS còn có 3 chat space khác active: 'VAP & GITS - Operation & Management', 'VAP - GITS - SO', 'Space_[VAP & GITS] vitX - Offshore Dedicated Team (French client)' — quan hệ đối tác bodyshop nhiều case song song.",
      "current_problem": "AMBER. (1) Verify CV batch 2 (4 CV) quá hạn — tracker adfcfe09 DL 13/05/2026 chưa done. (2) Mismatch level trong batch 1 — cần GITS source thêm Senior 11-15 năm chuẩn, tránh lẫn middle 3 năm. (3) Điều khoản GITS-candidate chỉ 3 ngày notice là rủi ro lớn cho VTI khi commit 10 HC với SLW — cần renegotiate ≥45 ngày notice (xem task chéo với SLW). (4) Cần chuẩn bị batch 3 CV để total >10 CV submit, tăng tỉ lệ trúng. (5) GITS portfolio đa case (vitX, Operation & Management, SO) — quan hệ bodyshop chiến lược, không chỉ Magento.",
      "tasks": [
        {
          "title": "Verify content + template CV Magento batch 2 (4 CVs) → xuất PDF gửi Gary (SLW)",
          "status": "In progress — Cuong Nguyen Duc 2 owe (tracker adfcfe09 đã quá hạn 13/05/2026)",
          "pic": "Cuong Nguyen Duc 2 (VAP) + Thoa Tran Thi Bao 1 (GITS.REC)",
          "next_action": "Đảm bảo CV format theo template Sing trong Drive folder CV Preparation, fix mismatch level batch 1, xuất PDF, push CV; sẵn sàng batch 3 nếu khách yêu cầu",
          "deadline": "13/05/2026 (đã quá hạn — push 18-22/05/2026)",
          "priority": "AMBER"
        },
        {
          "title": "Chuẩn bị batch 3 CVs Magento (target >10 CV total để tăng tỉ lệ trúng)",
          "status": "Open — preparation phase",
          "pic": "Thoa Tran Thi Bao 1 + Yen Le Hai 1 + Truc Hoang Thanh (GITS.REC)",
          "next_action": "Sau khi nhận feedback batch 1+2 từ Gary, source thêm 4-6 CV chất lượng tương đương, focus ENG fluency",
          "deadline": "Tuần 25/05/2026",
          "priority": "AMBER"
        },
        {
          "title": "Maintain GITS partnership health — đa case song song (Magento + vitX + Ops Management + SO)",
          "status": "Ongoing",
          "pic": "Cuong Nguyen Duc 2 + Sang Truong Minh (GITS)",
          "next_action": "Định kỳ sync với GITS (Luong manager) tổng kết tiến độ các case bodyshop, tránh xung đột resource giữa Magento/vitX",
          "deadline": "Ongoing",
          "priority": "GREEN"
        }
      ]
    },
    {
      "customer": "ALPSoft — SG Cloud Engineer Recruitment",
      "priority": "GREEN",
      "weekly_activity": "Tuần W19 (04-10/05/2026): Mail thread '[ALPSoft & VTI] Recruitment Service for On-site Cloud Engineer in Singapore' (8 msgs, last 04/05/2026) từ Kevin Nguyen — chuỗi trao đổi recruitment service onsite SG. Case opening Tue 12/05/2026 (W20). VAP team assessment 14/05/2026 (tracker f00731df DL 14/05/2026). Cập nhật từ chat space [VAP & D3] ALPSoft - Cloud Engineer in Singapore: Cuong Nguyen Duc 2 báo Tyson Nguyen 'Em ko có update gì con này. Em đang điều người bên ngoài để chạy vụ này rồi, khách họ chỉ muốn mình tuyển người hộ thôi'. Tyson Nguyen: 'Thế con này coi như tạch CV hết nhé'. Cuong Nguyen Duc 2: 'Em đang kiếm con cloud khác từ khách này, có gì e sẽ update a nhe'. KẾT LUẬN: ALPSoft Azure L2 Cloud Engineer batch đã DROPPED — VTI không tuyển được người phù hợp; Cuong Nguyen Duc 2 đang scout role Cloud khác từ chính khách ALPSoft này.",
      "current_problem": "GREEN — case Azure L2 Cloud Engineer không còn active push (CV tạch). Chuyển sang mode tìm cơ hội thay thế từ cùng customer ALPSoft. Không có DL cấp bách trong W19/W20.",
      "tasks": [
        {
          "title": "Scout role Cloud Engineer thay thế từ ALPSoft (sau khi tạch CV Azure L2)",
          "status": "In progress — Cuong Nguyen Duc 2 đang tìm",
          "pic": "Cuong Nguyen Duc 2",
          "next_action": "Tiếp tục liên hệ ALPSoft contact, update Tyson Nguyen + Michael Nguyen khi có role mới",
          "deadline": "Ongoing — TBD",
          "priority": "GREEN"
        }
      ]
    },
    {
      "customer": "Avows — New Development Opportunity",
      "priority": "GREEN",
      "weekly_activity": "Tuần W19 (04-10/05/2026): Không có mail thread Avows / Francis Lim (francis.l@avowstech.com) trong mail_threads.json, không có chat space Avows trong chat_compact.json, không có tracker item Avows, không có calendar event Avows, và không có mention trong memory_baseline.md cho window 04-10/05/2026. Mặc dù prompt đề cập 'Avows New development opportunity (from francis.l@avowstech.com)', toàn bộ data source W19 đã được grep nhưng KHÔNG tìm thấy bất kỳ touchpoint nào với Avows trong tuần này.",
      "current_problem": "GREEN — không có hoạt động Avows nào diễn ra trong W19 dựa trên data sources. Có thể: (a) mail thread Avows nằm ngoài cửa sổ window (trước 04/05/2026 hoặc sau 10/05/2026), hoặc (b) Avows được Michael Nguyen / Anthony track ngoài tooling thu thập. Cần xác nhận với Michael Nguyen / Anthony source mail Francis Lim ở đâu.",
      "tasks": [
        {
          "title": "Locate mail thread Avows (Francis Lim) và xác định status opportunity",
          "status": "Open — chưa có data point trong context W19",
          "pic": "Michael Nguyen + Anthony",
          "next_action": "Search Gmail mailbox Michael Nguyen với keyword 'Avows' hoặc 'francis.l@avowstech.com'; pull thread vào context tuần W20; nếu Avows active → bổ sung trip plan + proposal",
          "deadline": "Tuần 18-22/05/2026",
          "priority": "GREEN"
        },
        {
          "title": "Confirm Avows trong pipeline Anthony — light vs hot lead",
          "status": "Open",
          "pic": "Anthony + Michael Nguyen",
          "next_action": "Sync với Anthony tuần 18/05/2026 update Avows stage; nếu hot → bổ sung vào active opps tuần kế",
          "deadline": "20/05/2026",
          "priority": "GREEN"
        }
      ]
    },
    {
      "customer": "Anthony Tee - Weekly Sync-up + Expense Apr 2026",
      "priority": "GREEN",
      "weekly_activity": "Mr. Anthony & VTI Weekly Sync-up scheduled Fri 08/05/2026 09:00 SGT (Google Meet meet.google.com/gba-yjpt-hoe, organizer Kevin Nguyen, attendees Anthony Tee + Tung Nguyen Ba + Khanh Tran Duy + Cuong Nguyen Duc 2 + Michael Nguyen). Anthony chairs APAC strategic agenda. Anthony Expense Claim Apr 2026 ledger ongoing via BDG/Charlotte ops (referenced in task brief but no fresh email thread in week 04-10/05/2026 extraction window).",
      "current_problem": "Pipeline scaling pressure validated. Anthony network funnel growing fast in week 04-10/05/2026: Volkswagen Group-IT intro 05/05, Anthony Track Records to RWS 06-07/05, Technovation/VTI Meet intro email 06/05, Dialogg AI nudge 08/05, Hellopine Bangkok site-visit logistics 13-14/05. Anthony's NEW RULE: Michael weekly wrap-up TRƯỚC Fri sync (template pending).",
      "tasks": [
        {
          "title": "Michael Nguyen consolidate Singapore admin+sales hire budget deadline 22/05/2026 (tracker 2945eb7d, AMBER)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Michael Nguyen finalize weekly wrap-up template TRƯỚC Anthony sync deadline 22/05/2026 (tracker 90fb7918, AMBER)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Charlotte (Quyen Nguyen Thi Do) / BDG close out Anthony Expense Claim Apr 2026 ledger - confirm reimbursement processed",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Volkswagen Group-IT (NEW intro NOT via Anthony - via Kevin Nguyen + Dung Nguyen Thi forward)",
      "priority": "RED",
      "weekly_activity": "Intro meeting held Tue 05/05/2026 10:30 CEST / 15:30 ICT ([Volkswagen Group-IT & VTI] Introduction Meeting, organizer kevin.nguyen, MS Teams). Counterparts: Son Thanh Pham (Group IT K-DS/C, Volkswagen AG Wolfsburg) + Dr. Timm Neu (K-DET). Agenda: VTI general intro, ODC/BOT engagement models, large-scale automotive experience. Kevin email Wed 06/05/2026 13:00 ICT requested NDA + ODC build-up doc. Son Pham response Thu 07/05/2026 14:48 ICT declined: 'VTI is not currently on our shortlist, as we are looking for potential partners with extensive experience working with large European companies.' Michael Nguyen reply same day kept door open. ORIGIN CONFIRMED: Kevin/Dung Nguyen Thi forwarded the contact request - NOT Anthony Tee network intro.",
      "current_problem": "Customer declined this round - VTI lacks European enterprise track-record proof points. No active follow-up scheduled. Door left open for future. Risk: this declines validates a 'VTI APAC-only credentials' gap for European MNCs that Anthony's strategy needs to address.",
      "tasks": [
        {
          "title": "Michael Nguyen log polite re-engagement plan in CRM (Q4 2026 nudge); no immediate action",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Kevin Nguyen flag outcome to Anthony Tee in Fri sync for strategic awareness",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "BDG/Strategy build European enterprise / automotive case study assets - longer-term gap",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Terrabit Networks Introduction",
      "priority": "AMBER",
      "weekly_activity": "1st intro meeting held Mon 11/05/2026 (carried into next week's window per baseline). Anthony Tee intro to Simon (MD) + Dominic. In meeting NDA two-way agreed. No external customer-facing activity inside week 04-10/05/2026 window itself - this week = pre-meeting prep. Charlotte commit send NDA template Wed 13/05/2026 (tracker e483175f, AMBER, Open). Dominic warm-up email + June Q2 SG coffee plan by 20/05/2026 (Kevin/Michael, tracker 755fcc65, AMBER).",
      "current_problem": "Pre-meeting window quiet but NDA template not yet drafted (cross-week carry). Dominic warm-up email pending. Anthony will follow up in Q2 MY trip 08-12/06/2026.",
      "tasks": [
        {
          "title": "Charlotte (Quyen Nguyen Thi Do) send NDA template to Simon Terrabit deadline 13/05/2026 (tracker e483175f, AMBER)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Kevin Nguyen / Michael Nguyen send warm-up email Dominic + plan June Q2 SG coffee deadline 20/05/2026 (tracker 755fcc65, AMBER)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Dialogg AI (Thao Nguyen)",
      "priority": "AMBER",
      "weekly_activity": "Re-engagement nudge email Fri 08/05/2026 02:00 UTC from thao.nguyen@dialogg.ai to Michael Nguyen + Kevin Nguyen: 'Em hy vọng là vẫn được hai anh quan tâm đến giải pháp AI của Dialogg ạ, nếu tiện anh em mình gặp nhau online tuần sau được không ạ?' Original Anthony Tee intro 16/04/2026 post GITEX Asia (Dialogg solution = Supernova finals). VTI did NOT reply during window 04-10/05/2026.",
      "current_problem": "Michael owes reply 8 days (counting from 08/05) - Anthony's network expects same-day acknowledge pattern. Risk: cooldown post Anthony warm intro. Topic = AI chatbot + voicebot collaboration for Japan market.",
      "tasks": [
        {
          "title": "Michael Nguyen / Kevin Nguyen reply Thao Nguyen Dialogg AI - confirm pursue or polite decline, schedule online discussion week 18-22/05/2026",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Review Dialogg AI Platform Solution deck (attached 16/04 email) for Japan market fit before reply",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Confirm with Anthony Tee in Fri sync if continued engagement vs decline",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Hellopine (Pongsak Kongrattana, Bangkok)",
      "priority": "GREEN",
      "weekly_activity": "Yoshiyama Kotaro (VTI VVN Japan team) Bangkok site visit logistics finalized in week 04-10/05/2026 for Thu 14/05/2026 10:00 Hellopine office meeting: hotel = Easy Planet Bangkok Asok (7 Sukhumvit 14 Alley), driver Mr Somchai +66 81 935 5180 plate 1นช9781 pickup 09:00, Pongsak host lunch, Yoshiyama return SQ flight via Suvarnabhumi 15:55. Email chain: Anthony Tee intro originator 24/04/2026 → Kevin Nguyen + Yoshiyama handover → Pongsak logistics. Latest msg 13/05/2026 = Yoshiyama confirm pickup arrangement.",
      "current_problem": "Site visit logistics handled cleanly. Post-visit opportunity validation TBC after Yoshiyama report-back. Anthony Tee intro served introductory purpose - VTI VVN Japan team now owns relationship operationally.",
      "tasks": [
        {
          "title": "Yoshiyama Kotaro post-visit report to Kevin Nguyen + Anthony Tee (week 11-15/05)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Kevin Nguyen consolidate Hellopine opportunity scope from VVN team feedback",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Anthony Tee circle back with Pongsak via personal channel (Q2 follow-up)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Concentrix (Bich Ngoc Thach Mia + Tuong Vy)",
      "priority": "AMBER",
      "weekly_activity": "Khanh Tran Duy sent VTI corporate deck + resource summary to Bich Ngoc Thach (Mia, Vietnam Lead Consultant Innovation & Transformation) + chi Vy on Tue 05/05/2026 14:53 ICT. Materials covered Magento, Odoo, SAP, Salesforce, M365, low-code/platform capability. Khanh requested: (1) Concentrix corp deck reciprocate, (2) connect with Concentrix tech team. NO reply from Concentrix during week 06-10/05/2026 (5+ days silence). Original Anthony Tee intro Mon 21/04/2026 → cap-assessment call Thu 23/04/2026 15:00.",
      "current_problem": "5-day silence post VTI deck delivery. Risk: cold-out after Anthony warm intro fades. Khanh needs nudge with concrete tech alignment topics.",
      "tasks": [
        {
          "title": "Khanh Tran Duy nudge Bich Ngoc Thach Mia + chi Vy if no reply by Mon 12/05/2026",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Request Concentrix tech team intro with concrete enterprise platform alignment topics",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Add Bich Ngoc Thach + chi Vy + Concentrix tech leads to Memory PIC dimension",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Technovation (SW Tang, Penang)",
      "priority": "AMBER",
      "weekly_activity": "Anthony Tee sent intro email 'Technovation/VTI Meet' Wed 06/05/2026 11:47 ICT to SW Tang (swtang@technovation.com.my) CC Michael Nguyen + Kevin Nguyen + Tung Nguyen Ba - this set up the 1st intro meeting Mon 11/05/2026 (capability assessment). Chat VAP-DG confirms internal coord: 'mai a nhớ vào 1st meeting Technovation 9am vs e nhé' (Sun 10/05 reminder). Kevin commit send VTI corp + AI capability decks by Thu 15/05/2026 (tracker 8a942912, AMBER).",
      "current_problem": "Anthony's email kicked off the cycle in-window 06/05/2026. SW Tang persona at 1st-touch depth only; need ≥1 more touch to qualify. Q2 MY trip 08-12/06/2026 coverage Anthony to follow up.",
      "tasks": [
        {
          "title": "Kevin Nguyen send VTI corp deck + AI capability deck to SW Tang Technovation Penang deadline 15/05/2026 (tracker 8a942912, AMBER); propose follow-up technical session",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Michael Nguyen + Anthony Tee plan Q2 MY trip 08-12/06/2026 coverage Technovation Penang stop",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Tenant City / Flexi Group (Virtual Office Tour - Jason Ong, Santhosh MV)",
      "priority": "GREEN",
      "weekly_activity": "Original thread Jan 2026 (08-13/01): Kevin Nguyen + jason@tenantcity.com.sg + santhosh.mv@theflexigroup.com - Commonground + The Hive office options shortlisting for SG office search. NO activity during week 04-10/05/2026. Thread dormant since Jan 2026 shortlisting.",
      "current_problem": "Dormant since Jan 2026; SG office search either resolved offline OR re-opens in context of Anthony's SG admin+sales hire budget consolidation (Michael 22/05 deliverable). Not Anthony Tee intro - Kevin/Michael office hunt.",
      "tasks": [
        {
          "title": "Michael Nguyen / Kevin Nguyen reconcile Tenant City / Flexi Group shortlist status against SG hire budget plan (22/05 deliverable)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "If office search re-opens, re-contact Jason Ong + Santhosh MV",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "Digital Concierge Solutions for RWS Hospitality (NEW - Anthony's network play)",
      "priority": "AMBER",
      "weekly_activity": "Kevin Nguyen sent Wed 06/05/2026 21:00 UTC email '[Anthony & VTI] VTI Track Records on Digital Concierge Solutions for Hospitality' to Anthony Tee - bundled 7 hospitality case studies (HK + SEA customers). Anthony Tee replied Thu 07/05/2026 00:53 UTC: 'Thanks. This is good. Have forwarded the attached to RWS.' Anthony relayed direct to Eslin / Resort World Sentosa team. THIS IS THE primary Anthony network ENABLEMENT THIS WEEK.",
      "current_problem": "Customer (RWS Eslin) feedback on hospitality deck pending - Anthony forwarded but no direct reply yet. Tyson team owes chatbot demo specs + video deadline 22/05/2026 (tracker 3ac7b902, AMBER) to operationalize. Risk: RWS feedback may want deeper SG-specific cases vs HK.",
      "tasks": [
        {
          "title": "Tyson Nguyen prepare chatbot demo specs + video for Eslin / RWS deadline 22/05/2026 (tracker 3ac7b902, AMBER)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Kevin Nguyen follow up with Anthony Tee on RWS Eslin feedback to the hospitality deck (Fri sync 15/05)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Anthony Tee arrange in-person Q2 SG coffee with Eslin RWS",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "HopeRun Software Singapore - NDA (Tyson - Boon Siang Sim)",
      "priority": "GREEN",
      "weekly_activity": "NO activity in week 04-10/05/2026. Thread history: NDA negotiation started Nov 2025 (Tung Nguyen Ba ↔ boonsiang@hoperun.com.sg), put on hold Dec 2025 due to HopeRun project issues, resumed Jan 2026 with mutual NDA suggestion, last touch 20/01/2026 Tyson commit follow up legal. Thread dormant 4 months.",
      "current_problem": "Dormant since 20/01/2026 - Tyson Nguyen owes legal team follow-up on mutual NDA. HopeRun side ready to resume project discussion when NDA closes. NOT Anthony intro - Tyson direct relationship.",
      "tasks": [
        {
          "title": "Tyson Nguyen reactivate HopeRun NDA - chase Charlotte (Quyen) / Tri Truong Trong Ngoc legal review of mutual NDA wording",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "If legal ready, send signed mutual NDA to Boon Siang Sim and resume project scope discussion",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Add HopeRun Software SG to Memory client dimension once NDA closes",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "The Positive Links - Specialized Talent Pipeline (Geraldine)",
      "priority": "GREEN",
      "weekly_activity": "NOT found in week_context/mail_threads.json nor _mail_p2.json nor chat_signals.json. Referenced in task brief as 'geraldine@thepositivelinks.com' but no thread in extracted data scope for window 04-10/05/2026 or trailing weeks.",
      "current_problem": "Cannot validate from data in scope. Either thread sits in a different mailbox not extracted OR brief reference is from verbal Anthony Tee mention in Fri sync that has not yet generated email. Specialized talent pipeline = complementary to Recruit Express (Karin Chan) MCF flow.",
      "tasks": [
        {
          "title": "Michael Nguyen / Kevin Nguyen confirm with Anthony Tee in Fri sync where 'The Positive Links / Geraldine / Specialized Talent Pipeline' email lives",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Once email surfaces, assess specialized talent pipeline fit vs existing Recruit Express; coordinate with Charlotte before commercial response",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    },
    {
      "customer": "HERE Technologies / DMG Events (Anthony network adjacent)",
      "priority": "AMBER",
      "weekly_activity": "HERE Technologies (Arunee Wongjiratthiti, Bangkok): Khanh Tran Duy nudge Tue 05/05/2026 09:16 ICT. Arunee reply Tue 05/05 09:41 ICT: 'we are still in the process of aligning and confirming the requirements with the end customer ... This may take around two more weeks.' QA Engineer 2 candidates + quotation in limbo. Chat VAP-DG echoes Khanh standby - no candidate replacement until revised req lands. DMG Events (Shashikumar, Dubai - Network Infrastructure Manager): Khanh Tran Duy nudge Mon 11/05 (next-week edge). Shashi reply Tue 12/05 11:56: 'still reviewing the project and other options ... will get back to you on this once we have a decision.' IT Infrastructure Hanoi quotation stalled.",
      "current_problem": "Both in slow-burn: HERE 2-week wait window, DMG indefinite review. Compounds Anthony 'Kevin alone' pressure narrative. Neither account is direct Anthony intro but both ride APAC scaling theme.",
      "tasks": [
        {
          "title": "Khanh Tran Duy follow up Arunee HERE Tech after 19/05/2026 (2-week wait window expires)",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        },
        {
          "title": "Khanh Tran Duy nudge Shashi DMG monthly cadence; flag to Anthony Tee if no decision by 31/05/2026",
          "status": "pending",
          "pic": "",
          "next_action": "",
          "deadline": "",
          "priority": ""
        }
      ]
    }
  ],
  "deferred_or_noisy": [
    "Tenant City / Flexi Group Virtual Office Tour - all email activity Jan 2026 (jason@tenantcity.com.sg + santhosh.mv@theflexigroup.com); ZERO touches in week 04-10/05/2026; dormant unless SG office search re-opens with Michael's 22/05 hire budget.",
    "HopeRun Software Singapore NDA - dormant since 20/01/2026; Tyson Nguyen owes mutual NDA legal review; no W19 touchpoint.",
    "The Positive Links / Geraldine / Specialized Talent Pipeline - referenced in task brief but no email/chat thread found in extracted data scope; verbal-only or out-of-scope mailbox; Michael to clarify with Anthony Tee.",
    "Volkswagen Group-IT origin clarification - task brief flagged as possibly Anthony's network; actual origin = Kevin Nguyen + Dung Nguyen Thi forward of Pham Son Thanh contact request; customer declined Thu 07/05 = closed-loop noise this week.",
    "Anthony Expense Claim Apr 2026 - no fresh email thread found in extracted scope for week 04-10/05/2026; internal finance ops via BDG/Charlotte, not customer-facing.",
    "Wikilabs / Lucid Impact AI Ops (Danny Thian) Wed 06/05 16:00 - belongs to Tyson AIOps cluster (Anthony co-mentioned only as APAC strategy ref), deferred to other agent.",
    "SWAT Mobility sync Fri 08/05 15:00 SGT (Sim Bing Yang) - Kevin's relationship, not Anthony intro; deferred to other agent.",
    "TF / UPP Technology Salesforce + NPSP + Drupal RA (Luanht, Tienpn) Tue 05/05 + Wed 06/05 + Thu 07/05 - Kevin-owned commercial RA opp, not Anthony network; deferred."
  ],
  "stats_compact": {
    "mail_threads_analyzed": 30,
    "chat_spaces_active": 73,
    "chat_messages_total": 3044,
    "calendar_events_week": 27,
    "tracker_open_actions": 43,
    "customers_total": 37,
    "operation_items": 11,
    "tasks_total": 141,
    "red_items": 12,
    "deferred_items": 8
  },
  "cross_week_diff": {
    "baseline_iso_week": "2026-W18",
    "current_iso_week": "2026-W19",
    "baseline_available": false,
    "note": "Snapshot tuần trước (weekly_brief_v2_2026-W18.json) chưa tồn tại — đây là lần đầu chạy format v2. Logic compare đã sẵn sàng cho tuần sau.",
    "operation_diff": [],
    "customers_diff": [],
    "summary_counts": {}
  }
}