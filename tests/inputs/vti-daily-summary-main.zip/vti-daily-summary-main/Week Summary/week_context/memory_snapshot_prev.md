# Meeting Memory — VTI APAC

*Single consolidated memory file. Updated daily by `update_memory_drive.py`.*
*Created: 16/05/2026*

*Last updated: 2026-05-16*
---

## 1. Per-Account profiles (Dimension 1)

<!-- BEGIN: clients -->
### KGI Securities / Ufinity

**Company snapshot**: KGI Securities = Singapore-based brokerage / retail futures trading. Ufinity = SI partner (Singapore-based). Project routed through Ufinity (Mark Choon commercial bridge).

**Account stage**: Active proposal — VTI BQ v2 submitted 14/05/2026 16:17 ICT. Phase 0 demo target end-June 2026. Phase 1 launch 100 concurrent users ramp to 1,500 by Q4 2026. First contact via Ufinity ~Q1 2026.

**Decision-making**: Ufinity → KGI customer; Mark Choon owns commercial signoff; Yen Hock gates technical; final KGI finance review via Alex Chow involvement (Tue 12/05 first appearance). Procurement: direct (no public RFP).

**Budget cycle**: TBC — likely tied to KGI Securities fiscal year (Asia financial services typically Apr-Mar or Jan-Dec).

**Competitive landscape**: Unknown direct competitors yet — Ufinity holds the relationship. Risk: Ufinity may have alternative VTI-substitute SIs.

**Strategic priorities (customer)**: Centralized trading platform replace fragmented current state; MAS compliance posture; on-prem hosting preference; multi-currency (SGD/USD/HKD) + multi-market (HK/TW future).

**Existing engagements (VTI)**: KGI Trading Platform (in proposal), CA Web sub-project (Ufinity portal — separate scope).

**Trigger events**: BRD CA Web v2 sent 14/05 night; Mark hint Internet-facing Client Portal additional scope (week 15/05). Customer fund verification policy = manual (no direct bank integration).

**Risk factors**: VTI no internal financial-domain SME → estimate risk; estimate currently 38-42MM range with explicit assumption list; NinjaTrader SDK chart embed = Phase 1.5 split (not Phase 0 blocker).

**Account team org chart**: KGI side opaque (Yen Hock interfaces tech). Ufinity = Mark (commercial) + Yen Hock (tech) + Alex Chow (commercial finance). VTI = Tyson (Sales Mgr owner) + Hung Nguyen Duc / David (Lead Architect) + Son (FP) + Long Vu Thanh (SDK) + Hieu (chart) + Kevin (account) + Michael (sign-off).

**Recent activity (7d)**: 11/05 D9 internal CA Web BQ review → 12/05 UF×VTI CAWeb #1 10am + post-mortem 15:30 + CAWeb #2 with Alex Chow 16:00 + KGI Trading internal 17:00 → 13/05 2 internal reviews (16:00 + 21:00) → 14/05 UF/VTI KGI Trading joint 10am + post-mortem 21:00 → 15/05 no KGI meeting (Anthony sync recap).

---

### NxGen Communications Pte Ltd

**Company snapshot**: Singapore SI, regional partner. Derrick Chong = MD; Ian Choy = Solution/Tech Lead.

**Account stage**: Active tender response. Capability assessment 14/05 → HDB AI Tender RFI received 15/05 07:42 ICT (15 use cases, AWS). Pipeline status: 'active tender response within 1 week' (target ≤22/05). First substantive contact 14/05.

**Decision-making**: Ian = technical recommendation authority; commercial via NxGen sales (TBC introduction post-proposal).

**Budget cycle**: TBC. Tender-driven (HDB).

**Competitive landscape**: HDB tender = multi-vendor (typical SG GovTech RFP). Specific competitors unknown — Ian to share post-RFI data.

**Strategic priorities (customer)**: SG public-sector AI capability; tender-led pipeline; NxGen partnership angle = front-end relationship + back-end delivery via VTI.

**Existing engagements (VTI)**: None active yet. Partnership exploration only.

**Trigger events**: Ian move-fast — 1 week from cap-assessment to real tender share. Aligns with Anthony's network (Anthony first introduced).

**Risk factors**: First proposal — VTI must hit 22/05 deadline; cloud provider clarification for MCP hosting still pending; customer reference approval (Aura case Japanese) for external share TBC.

**Account team org chart**: NxGen = Derrick (MD) + Ian (tech). VTI = Kevin (organizer/proposal lead) + Khanh Tran Duy (AI lead) + Tyson + Michael (architecture sign-off).

**Recent activity (7d)**: 14/05 NxGen×VTI capability call (60min Fireflies) → 15/05 RFI received → 16/05 Daniel + Tuan demo materials production deadline → 18/05 Ian sends data points + VAP&D3 case study sync → 21/05 proposal v1 + budget → 22/05 submit.

---

### AsiaPac (Keppel group) — IHL Portal / Ecommerce / Odoo migration

**Company snapshot**: AsiaPac = Keppel group subsidiary, Singapore. Retail/ecommerce footprint = 13+ ecommerce portals (IHL, SMU, NUS, others). IT lead Pravin; project sponsor Kit Yi.

**Account stage**: Active delivery (IHL Portal live) + scope expansion (15/05): split CR 2 streams + Odoo migration evaluation + SAP Ariba integration check. Recurring Friday-afternoon meeting cadence proposed.

**Decision-making**: Kit Yi = strategic budget sponsor + scope authority (UPGRADE Fri 15/05 from 'silent CC' hypothesis). Pravin = IT operational. Siew Kuan Wong = Keppel financial review (CC on invoice threads).

**Budget cycle**: TBC — Keppel financial cycle typically calendar year.

**Competitive landscape**: Existing IHL portal vendor = VTI (incumbent). Odoo migration may open to other Odoo SIs — Kit Yi probing capability.

**Strategic priorities (customer)**: Multi-portal consolidation (13 → 1 Odoo); vendor count reduction; standardized UX across institutions; Ariba integration may be Keppel procurement requirement.

**Existing engagements (VTI)**: IHL Portal Ecommerce (live). Appendix 01+02 PO (paid). 3rd Payment Invoice VTI-ASIAPAC/26/0227-05 (pending).

**Trigger events**: Kit Yi 15/05 IHL CR meeting drove scope expansion conversation (massive); James Wai NEW unplanned attendee 15/05.

**Risk factors**: Tyson workload concentration (IHL CR split + Odoo Q&A + other deals); Ariba/SAP capability gap if not confirmed VTI internal.

**Account team org chart**: AsiaPac = Kit Yi (sponsor/driver) + Pravin (IT) + Peyton (accessory SME) + James Wai (delivery SME) + Siew Kuan (financial) + Emily Tan. VTI = Tyson (Sales Mgr) + Vince/Vuong (PM IHL) + Quang (Dev lead) + Tam (BA) + Tram (D8 dev) + Kevin + Charlotte + Michael.

**Recent activity (7d)**: 15/05 IHL Portal CR meeting (49min Fireflies + 12min wrap). Pending Kit Yi 5 deliverables 22/05.

---

### Recruit Express

**Company snapshot**: Singapore-based recruitment firm, specializes EP (Employment Pass) processing.

**Account stage**: Service Agreement near-final. Compromise 45-day termination notice Thu 14/05. Charlotte sends Karin final draft Fri 15/05 morning; target sign 16/05 via Docusign (Karin pattern: signs promptly 1 day ahead deadline when aligned).

**Decision-making**: Karin = primary counterpart; Recruit Express commercial signoff via Karin. VTI side: Charlotte (Legal/Finance) + Tri (Legal sign-off) + Kevin + Michael.

**Budget cycle**: Not budget-driven (service agreement annual).

**Competitive landscape**: Other SG EP service providers exist; Recruit Express specialization = appendix C fee structure understood.

**Strategic priorities (customer)**: Stable recurring service agreement; MCF (Fair Consideration Framework) candidate sourcing pipeline.

**Existing engagements (VTI)**: First commercial agreement in flight. Linked to Michael's EP application.

**Trigger events**: Singapore office signing completed March 2026; EP applications dependent on signed service agreement.

**Risk factors**: Karin slow response 2-3 weeks typical (mitigated by explicit deadlines).

**Recent activity (7d)**: 12/05 EP Agreement Discussion (Charlotte+Tri+Kevin+Michael) → 13/05 Charlotte send Karin redline → 14/05 Karin response on 2 outstanding clauses → 14/05 internal compromise meeting → 15/05 Charlotte send final draft.

---

### Sembcorp

**Company snapshot**: Sembcorp Industries Singapore — IT staff augmentation client. chị Huyền = IT hiring stakeholder.

**Account stage**: Active negotiation. Pivot Fri 15/05: 2 VTI candidates rejected on English fluency; VAP team to propose 2-option re-pitch (Fulltime native EN vs Partime VTI fallback) by 21/05. Cuong direct chat clarification first.

**Decision-making**: chị Huyền owns hiring approval IT group. Quality-bar driven.

**Competitive landscape**: Generic IT staff augmentation; VTI commercial pricing competitive.

**Strategic priorities (customer)**: English fluency = hard line (non-negotiable). Don't push staff who fail English filter.

**Existing engagements (VTI)**: Commercial keep nguyên (per 12/05 chat — commercial accepted; only candidate quality issue).

**Trigger events**: 15/05 reject 2 candidates English requirement.

**Risk factors**: VTI bench thin on native-EN; need fulltime-EN backup pipeline OR partime VTI fallback.

**Recent activity (7d)**: 12/05 commercial confirmed nguyên giá → 14/05 chị Huyền IT group English requirement clarified → 15/05 reject 2 candidates.

---

### Mitsubishi Corporation (HCMC + SG branches)

**Company snapshot**: Mitsubishi Corporation — Japanese trading house. HCMC office + Singapore office. Parent = Mitsubishi Corp (global trading conglomerate).

**Account stage**: HCMC = 6-month service trial accepted (Mon 11/05 + Thu 14/05 confirmed). Toàn placement proceeding. Charlotte HD template by 20/05. SG = NEW scope opened Wed 13/05 WhatsApp Kondo-san; 2-option deck Kevin+Charlotte by 16/05.

**Decision-making**: HCMC: Tam-san + Dung-san interview panel; Kane-san CC; Saoko Miyamoto = day-to-day liaison. SG: Kondo-san senior driver.

**Budget cycle**: Japanese fiscal year April-March.

**Competitive landscape**: Japanese SI partnerships typically go through country-level subsidiaries (Fujitsu Vietnam → Toyota Thailand pattern per Khôi playbook). MC may have internal Japanese vendor preferences.

**Strategic priorities (customer)**: HCMC = IT staff trial framework; SG = different framework (full-stack SG vs body-shop).

**Existing engagements (VTI)**: Pham Tien Loc CV (shortlisted 27/03); anh Toàn confirmed candidate after swap negotiations (04-08/05); MC HCMC trial pending contract.

**Trigger events**: 15/05 Toàn interview positive feedback Tam-san+Dung-san; Kondo-san 13/05 SG IT request initiation.

**Risk factors**: Japanese business etiquette sensitivity (CV format standard, formal email tone); English fluency requirement for some MC SG roles.

**Recent activity (7d)**: 11/05 Khanh email accept 6-month trial → 12/05 Toàn interview → 13/05 Kondo WhatsApp SG → 15/05 contract draft progress.

---

### OBS / Orange Business Services

**Company snapshot**: Orange Business Services Singapore. Don Livingston = senior PIC, intro March 2026. Gerald Lee = AI/Data lead (introduced 27/03).

**Account stage**: Warm follow-up. Awaiting concrete response from Gerald on AI+Data deck + case studies sent 30/03.

**Decision-making**: Don = relationship gateway; Gerald = AI/Data evaluator (TBC depth).

**Recent activity (7d)**: No new touchpoints. Nudge plan after NxGen settles.

---

### Technovation (Malaysia / Penang) — Anthony intro

**Account stage**: 1st intro Mon 11/05. SW Tang = Senior PIC Penang. Kevin send VTI corp + AI capability decks by 15/05. Q2 trip MY 08-12 Jun coverage (Anthony will follow up).

---

### Terrabit Networks — Anthony intro

**Account stage**: 1st intro Mon 11/05. NDA both ways agreed; Charlotte send 13/05. June Q2 coffee planned. Simon (MD) + Dominic (warm-up email by 20/05).

---

### Resort World Sentosa — Eslin (Anthony's personal connection)

**Account stage**: Warm. Eslin = RWS Senior PIC. RWS team growing 10→20+, needs BA1 + offshore PM/dev. Chatbot demo specs + video needed (Tyson by 22/05). Anthony arrange in-person Q2 coffee.

---

### GITS — Magento sourcing

**Account stage**: Active CV pipeline. Gary = GITS sourcing contact. Cuong sent Magento batch 2 (4 CVs) Tue 12/05; awaiting Gary feedback. 1 candidate (Nguyễn Trung Hiệp) flagged different skills.

---

### ALPSoft

**Account stage**: NEW case opening Tue 12/05. Azure L2 Cloud Engineer concept similar to existing ALPSoft engagement. VAP team assessment 14/05 — TBC progress.

---

### Pipeline (light): SWAT Mobility, Starhub, Wikilab, B2B Commerce, Infinite Lab, GovTech rehearsal Saigon Hoàng Việt 07/05 — see Anthony Fri sync recurring updates.
<!-- END: clients -->

## 2. Per-PIC personas (Dimension 2)

<!-- BEGIN: pics -->
### Ufinity / KGI personas

**Mark Choon — mark.choon@ufinity.com — Account Director, Sales & Partnerships, Ufinity**
1. *Role/title/reporting*: Account Director, Sales & Partnerships. Reports inside Ufinity sales org (TBC).
2. *Decision authority*: Commercial bridge — signs off proposal package to customer; doesn't decide tech.
3. *Personality*: Pragmatic, time-driven, results-oriented.
4. *Communication style*: Direct, brief emails; verbal pushes for clarity. Response cadence: same-day for commercial asks.
5. *Areas of interest*: Cost certainty, delivery timeline commitment, clean Customer-ready proposal materials, alternative commercial models if fixed-scope doesn't fit.
6. *Sensitivity topics*: KGI Phase 0 demo end-June commitment (external); CA Web missing requirements (admitted 14/05).
7. *Best-practice*: Bring ready quotation incl. RA fallback; flag risks proactively; brief Yen Hock in parallel; reserve internal review slot 1h after every customer-facing BQ call; default quote +10% buffer for follow-on; treat gap list as 24h SLA.
8. *Sample phrases*: 'let me get some time the customer'; 'I intend to submit tomorrow'; 'In addition to the BRD for CAWeb, there is an Internet-facing Client Portal that needs to be built' (scope-expansion language).
9. *Personal background*: Not directly observed.
10. *Relationship strength*: Warm — Mark drives multiple touchpoints/week.
11. *Mutual contacts*: Yen Hock (Ufinity tech); Alex Chow (Ufinity commercial); KGI customer (opaque).
12. *Career trajectory*: Stable Account Director role.
13. *Pending owes (16/05)*: Mark → VTI: BRD new version + customer alignment. VTI → Mark: revised BQ v3 + cost docs 20/05; gap list response.
14. *Past wins/losses*: First deal in flight — no prior history with VTI.

**Tan Yen Hock — yenhock.tan@ufinity.com — Pre-sales/Tech Lead, Ufinity**
1. *Role*: Pre-sales / Tech Lead Ufinity.
2. *Decision authority*: Technical gatekeeper; recommends to KGI.
3. *Personality*: Concise, decisive, verbal-direct.
4. *Communication style*: Minimal email; verbal in joint calls.
5. *Areas of interest*: Architecture cleanliness; integration boundaries (NinjaTrader, KYC, Singpass, banking); compliance posture.
6. *Sensitivity*: Vendor-specific KYC names in deliverables; integration assumptions un-validated.
7. *Best-practice*: Brief separately before each customer meeting; bring sequence diagrams not just text.
8. *Sample phrases*: Not captured directly this period.
9. *Personal background*: TBC.
10. *Relationship strength*: Warm via Mark.
11. *Mutual contacts*: Mark Choon, Alex Chow.
12. *Career trajectory*: Stable.
13. *Pending owes*: Yen Hock available Mon 18/05 morning meeting per Mark's escalation.
14. *Past wins/losses*: First deal in flight.

**Alex Chow — Ufinity Commercial Director / Finance lead (NEW Tue 12/05 first appearance)**
1. *Role*: Commercial Director / Finance lead Ufinity (inferred from 16:00 Tue call context).
2. *Decision authority*: Commercial validation alongside Mark; likely reports to KGI finance.
3. *Personality*: Accepts range estimates; wants timeline commitment. One-off appearance pattern (didn't return Thu 14/05).
4. *Communication style*: TBC — first observation only.
5. *Sample behavior*: 'Accepts BQ range, wants Phase 0 timeline confirmation' (Tue 16:00 call).
6. *Pending owes*: Internal review with KGI finance.
7. *Past wins/losses*: First deal in flight.

---

### NxGen personas

**Ian Choy — ian.choy@nxgen.asia — Solution/Tech Lead, NxGen**
1. *Role*: Technical evaluator; SG RFI partnership scout; active tender liaison.
2. *Decision authority*: Technical recommend within NxGen; commercial via NxGen sales.
3. *Personality*: Curious, pragmatic, candid; move-fast pattern (1 week from capability assessment to real tender share).
4. *Communication style*: Verbal-fluid in calls; written emails short and to-the-point.
5. *Areas of interest*: Reference-able customers; on-prem model hosting (Qwen); team size + tech leads; cloud provider specifics; iterative cadence; mini-POC; AWS-specific deployment; HDB SG government tender experience.
6. *Sensitivity*: Cloud provider clarification (MCP hosting pending Wed); customer reference approval needs (Aura Japanese case).
7. *Best-practice*: Same-day acknowledge tender + commit proposal date within 7 days; bring SA tech lead next call; demo videos pre-ready.
8. *Sample phrases*: 'this is an AI Agentic Agent project with 15 defined use cases. The solution is to be proposed in AWS' (15/05).
9. *Personal background*: TBC.
10. *Relationship strength*: Warm — fast-moving counterpart.
11. *Mutual contacts*: Anthony Tee (Anthony's network intro), Derrick Chong (NxGen MD).
12. *Career trajectory*: Stable.
13. *Pending owes (16/05)*: Ian → VTI: RFI data points by Mon 18/05. VTI → Ian: proposal v1 + budget by Fri 22/05.
14. *Past wins/losses*: First tender in flight.

**Derrick Chong — derrick.chong@nxgen.asia — MD, NxGen**
1. *Role*: MD, partnership relationship owner.
2. *Personality (light)*: Warm partnership-oriented (Anthony's relay).
3. *Pending owes*: Cloud Engineer + SDM CV feedback (from 22/04); NICE Engineer + PM CVs (Kevin committed 23/04 — confirm).

---

### AsiaPac personas

**Kit Yi Chow — kityi.chow@asiapac.com.sg — Project sponsor → STRATEGIC SCOPE-DRIVER**
1. *Role*: Project sponsor + strategic scope-driver. Bridges Pravin (IT) and Siew Kuan (Keppel financial). Actively shapes deal architecture.
2. *Decision authority*: Strategic budget sponsor + scope authority AsiaPac level.
3. *Personality*: Confident decision-maker, strategic-level thinker. NOT silent — UPGRADE Fri 15/05 reversed earlier 'silent CC-only' hypothesis.
4. *Communication style*: Verbal-direct in meetings; email-recipient for invoice threads (status-aware, doesn't reply unless needed).
5. *Areas of interest*: Multi-portal consolidation, automation, scalability, vendor capability validation, future-proofing.
6. *Sensitivity*: PO Appendix 01+02 delays (didn't raise Fri — silent on legacy); vendor capability validation (Ariba specifics).
7. *Best-practice*: Treat as strategic peer; share roadmap-level options not just operational status; confirm capability commitments quickly.
8. *Sample phrases*: 'Provide recording or details of current IHL portal website for review to understand existing implementation' (process-driven); 'Request splitting the development change request into two parts' (decisive scope-shape).
9. *Personal background*: TBC.
10. *Relationship strength*: Warm — relationship-driving party.
11. *Mutual contacts*: Pravin, Peyton, Siew Kuan, Emily Tan.
12. *Career trajectory*: Stable.
13. *Pending owes (16/05)*: Kit Yi → VTI: 5 deliverables (portal recording + ID prefix requirements + system-assigned confirmation + CR split confirm + Ariba/SAP API check) by 22/05.
14. *Past wins/losses*: Existing IHL Portal delivery = wins.

**Pravin Nimbhorkar — pravin.nimbhorkar@asiapac.com.sg — IT lead AsiaPac (light validated Fri)**
1. *Role*: IT operational lead, technical interface for VTI dev team.
3. *Personality*: Listener; didn't drive Fri conversation (Kit Yi led).
5. *Areas of interest*: Operational/technical.
7. *Best-practice*: Address technical clarification questions directly post-meeting.
13. *Pending owes*: TBC.

**Peyton Chai — peyton.chai@asiapac.com.sg — Accessory & schedule SME**
1. *Role*: Operational; knows screen-protector scheduling (1-2 day buffer), accessory delivery, customer notification + rescheduling logic.
3. *Personality*: Listener; interjects with specific operational constraints.
5. *Areas of interest*: Deep on operational delivery flow.
13. *Pending owes*: Confirm accessory delivery times + buffer days by 20/05.

**James Wai — AsiaPac delivery (NEW — unplanned Fri 15/05)**
1. *Role*: Delivery slot capacity logic SME.
5. *Areas of interest*: Current FCFS + manual override + 40/day cap.
7. *Best-practice*: Expect James in future delivery-related meetings; maintain technical line.
13. *Pending*: Delivery slot capacity doc by 20/05.

**Siew Kuan Wong, Emily Tan — AsiaPac/Keppel financial CC**: Light persona placeholders; CC on invoice threads.

---

### Recruit Express persona

**Karin Chan — karinchan@recruitexpress.com.sg — Business Specialist, EP processing**
1. *Role*: Counterpart for SoW + EP processing.
2. *Decision authority*: Owns commercial terms within agreed pricing band.
3. *Personality*: Helpful, time-pressured.
4. *Communication style*: Email-primary; slow response 2-3 weeks typical; signs Docusign promptly (1 day ahead deadline) when aligned.
5. *Areas of interest*: SoW clause clarity; pricing structure; turnaround SLA.
6. *Sensitivity*: 2 outstanding clauses (Legal); MCF candidate sourcing ahead of EP filing.
7. *Best-practice*: Use explicit deadlines; Charlotte direct line for Legal; Michael interview availability ready for MCF rounds.
13. *Pending owes (16/05)*: Karin → VTI: signed agreement via Docusign target 16/05.

---

### Sembcorp persona

**chị Huyền — Sembcorp IT hiring stakeholder**
1. *Role*: IT group hiring decision-maker Sembcorp.
2. *Decision authority*: Owns hiring approval IT group.
3. *Personality (inferred)*: Quality-bar driven; rejects vendor candidates if English requirement unmet.
4. *Communication style*: Chat-friendly via Cuong direct line.
5. *Sensitivity*: English fluency = hard line (non-negotiable).
7. *Best-practice*: Don't propose VTI candidates without English screen; offer 2 paths (Fulltime native EN vs Partime VTI fallback); keep commercial pricing nguyên.
13. *Pending owes*: VTI → chị Huyền: Cuong English clarification first, then VAP 2-option proposal 21/05.

---

### Mitsubishi personas

**Saoko Miyamoto — saoko.miyamoto@mitsubishicorp.com — HCMC liaison**
1. *Role*: Day-to-day client contact MC HCMC.
3. *Personality*: Polite, formal Japanese-business style; appreciates prompt updates.
4. *Communication style*: Email-primary; warm closing; CCs Kondo + Tam + Dung consistently. Sample: 'Thank you very much for your prompt update! We have taken note of and fully understood all the items shared.'
7. *Best-practice*: CV format Japanese-standard required; HD template Legal-first; commercial after.
13. *Pending owes*: VTI → Saoko: HD mẫu body-shop IT (Charlotte 20/05).

**Kondo-san — Mitsubishi Senior (HCMC CC + SG driver)**
1. *Role*: Senior; CC on HCMC threads; now driving SG IT request (Wed 13/05 WhatsApp).
3. *Personality*: Decisive; country-specific scope thinking (SG ≠ HCMC template per Wed observation).
5. *Areas of interest*: SG IT support full-stack (different framework vs HCMC body-shop).
13. *Pending owes*: VTI → Kondo: 2-option deck SG (body-shop vs full-stack) by 16/05.

**Tam-san, Dung-san — MC HCMC interview panel**: Positive Toàn evaluation Tue 12/05; technical OK, English manageable.

**Kane-san — MC HCMC senior CC** (not always join meetings).

---

### Anthony Tee — VTI APAC Senior Advisor (internal, but operationally critical PIC)

1. *Role*: Senior advisor; chairs Fri 09:00 SGT weekly sync; APAC strategic relay.
3. *Personality*: Drives own agenda; CEO-briefing tone; pointed questions on stalled accounts.
4. *Communication style*: In-person preferred (Q2 SG/MY trip), email follow-ups concise.
5. *Areas of interest*: APAC pipeline scaling; local-hire strategy per country; Khôi Thailand-MY platform-implementation playbook.
7. *Best-practice*: Michael weekly wrap-up TRƯỚC Fri sync (NEW RULE 15/05); don't over-prep status (Anthony drives); DO prep budget/staffing decisions Anthony pushes on.
11. *Mutual contacts*: SW Tang (Technovation), Simon+Dominic (Terabit), Eslin (RWS), Don Livingston (OBS), Khôi (Thailand), Tysum, NTT, Fujitsu, CTC Global, Tech-D KL.
13. *Pending owes*: Michael → Anthony: consolidated SG admin+sales hire budget 22/05.

---

### Light personas (cross-account)

- **SW Tang** — Technovation Penang Senior PIC. 1st intro Mon 11/05; need ≥1 more touch.
- **Simon** — Terabit MD. 1st intro Mon 11/05; collaborative, comfortable offshore.
- **Dominic** — Terabit (Anthony's network); warm-up email by 20/05.
- **Don Livingston** — OBS Senior PIC. Quick reviewer of profiles; concise email.
- **Gerald Lee** — OBS AI/Data lead. TBC depth.
- **Eslin** — RWS Senior PIC (Anthony's personal connection). Open to partnership; needs chatbot demo.
- **Gary** — GITS sourcing contact. Reviews CV batches.
<!-- END: pics -->

## 3. Per-Opportunity tracking (Dimension 3)

<!-- BEGIN: opps -->
### KGI Trading Platform — via Ufinity (PRIMARY ACTIVE OPP)

1. **Parent account**: KGI Securities / Ufinity
2. **Stage**: Active proposal — BQ v2 submitted 14/05, proposal v3 due 20/05
3. **Probability**: Medium-High (Mark engaged, Yen Hock technical aligned)
4. **Estimated value**: 38-42MM total (range due to assumption gaps); Phase 0 demo end-June; Phase 1 web Q3; Phase 1.5 chart embed; Phase 2 mobile Q4
5. **Close target**: TBC — likely commitment late-May / early-June
6. **Champion**: Mark Choon (commercial-side)
7. **Decision-maker**: KGI customer-side (opaque) + Yen Hock (Ufinity tech gate)
8. **Detractor**: None known
9. **Competitive landscape**: TBC — Ufinity may hold alternative VTI-substitute SIs
10. **Customer pain + success criteria**: Need centralized retail futures trading platform replace fragmented current; MAS compliance; multi-currency multi-market; Phase 0 demo external-commit drives timeline urgency
11. **Solution scope**: NinjaTrader white-label platform (web .NET MVC + mobile .NET MAUI + admin + CA Web sub-project). MS SQL Server + .NET. KYC generic (Singpass for funding). Manual fund verification. NO direct bank integration. Master account model with API token scoping demo/live.
12. **Pricing model**: Fixed-scope (range 38-42MM) + RSA fallback option (Tyson prep separate quote 20/05) with PM headcount split. Default +10% buffer for follow-on (Mark scope-expansion pattern)
13. **Timeline / phases**: Phase 0 (web demo end-June), Phase 1 (live web Q3), Phase 1.5 (chart embed post Phase 0), Phase 2 (mobile Q4)
14. **VTI resource plan**: Tyson (Sales Mgr), Hung Nguyen Duc (Lead Architect), Son (FP), Long Vu Thanh (NinjaTrader SDK), Hieu Nguyen Trung 4 (chart), Kevin (account), Michael (sign-off)
15. **Risks + dependencies + next milestone**: Risk: no internal financial-domain SME (mitigated range estimate + assumption list); chart embed Phase 1.5 split chốt; Mark may raise additional scope Internet-facing Client Portal (+10% buffer rule). **Next milestone**: Hung data flow + sequence diagrams 19/05; proposal v3 + cost docs 20/05 → next UF/VTI customer call TBC.

---

### CA Web sub-project — via Ufinity (KGI parallel)

1. **Parent account**: KGI Securities / Ufinity
2. **Stage**: Active BQ — v1 range delivered Tue 12/05 with 10-item gap list
3. **Probability**: Medium (estimate risk acknowledged)
4. **Estimated value**: TBC pending gap list response
5. **Decision-maker**: Mark Choon
6. **Customer pain**: Ufinity needs CA Web portal companion to KGI Trading
7. **Solution scope**: CA Web sub-application (UI + backend integration)
8. **Pricing model**: Range estimate + assumption list
9. **Risks**: Domain expertise gap (financial); Mark may scope-add Internet-facing Client Portal post-BRD
10. **Next milestone**: Kevin gap list response → Mark BRD revised → revised BQ

---

### NxGen HDB AI Tender (PRIMARY ACTIVE OPP — ESCALATION)

1. **Parent account**: NxGen Communications
2. **Stage**: Active tender response — RFI received Fri 15/05, proposal due 22/05
3. **Probability**: Medium (first proposal with NxGen, fast cadence)
4. **Estimated value**: TBC pending RFI data points (Ian gửi Mon 18/05)
5. **Close target**: Tender award post-22/05 submission
6. **Champion**: Ian Choy (NxGen tech)
7. **Decision-maker**: NxGen sales (post-proposal review) + HDB Singapore (final tender award)
8. **Competitive landscape**: HDB tender = multi-vendor SG GovTech RFP
9. **Customer pain + success criteria**: HDB needs Agentic AI for 15 defined use cases on AWS
10. **Solution scope**: Multi-agent LLM (Qwen / Gemini), AWS deployment, Aura chatbot reference, AIOps for ITSM, multi-agent analyst-replacement case studies
11. **Pricing approach**: Budgetary proposal v1 (high-level) + detailed costing post-data-points
12. **Timeline**: Submit 22/05 → iterative review with Ian → tender award timeline TBC
13. **VTI resource plan**: Kevin (proposal lead), Khanh Tran Duy (AI architecture), Michael (architecture sign-off), Tyson, D3 team (Daniel + Tuan + Thang Nguyen Duc 1 + Anh Nguyen Sy Tung — case studies)
14. **Risks + dependencies**: Cloud provider for MCP hosting confirmation pending (Kevin); customer reference approval Aura Japanese (backup cases ready); D3 demo materials production deadline 15/05; Tyson workload concentration
15. **Next milestone**: Daniel + Tuan demo materials ready by 15/05 (production deadline); Ian RFI data points by 18/05; Mon 18/05 VAP&D3 case study sync; Michael+Kevin architecture sync by 19/05; proposal v1 + budget by 21/05; submit by 22/05.

---

### IHL CR Part 1 (data accuracy) — AsiaPac

1. **Parent account**: AsiaPac IHL Portal
2. **Stage**: Scope confirmation — Kit Yi requested CR split 15/05
3. **Estimated value**: Smaller scope (subset of original CR)
4. **Solution scope**: First/last name split + student ID prefix dropdown
5. **Next milestone**: Tyson + Tam draft Part 1 doc by 18/05; Kit Yi confirmation 22/05.

### IHL CR Part 2 (delivery status integration) — AsiaPac

1. **Stage**: Scope confirmation
2. **Estimated value**: Larger scope (delivery slot logic + notifications + EDD)
3. **Solution scope**: System-assigned delivery slots, WhatsApp/SMS notifications, EDD display (laptop vs accessory split), accessory buffer days
4. **Next milestone**: Tyson draft Part 2 doc by 22/05; depends on James Wai capacity doc + Peyton accessory doc by 20/05.

### IHL Odoo Migration (STRATEGIC NEW OPP — Fri 15/05)

1. **Parent account**: AsiaPac (Keppel)
2. **Stage**: Discovery — Kit Yi raised 15/05
3. **Probability**: Low-Medium initially (pending scope confirmation + VTI Odoo capability validation)
4. **Estimated value**: LARGE — 13 portals × ongoing migration + license + maintenance
5. **Champion**: Kit Yi Chow
6. **Customer pain**: 13 fragmented portals; high vendor count; want standardized UX
7. **Solution scope**: Consolidate 13 portals (IHL + SMU + NUS + others) onto Odoo platform with uniform functionality
8. **Dependencies**: VTI Odoo capability assessment internal; Kit Yi Ariba/SAP capability check
9. **Next milestone**: Tyson Q&A doc Odoo migration by 22/05; Kit Yi capability validation discussion ongoing.

### IHL SAP Ariba Integration (NEW — Fri 15/05)

1. **Parent account**: AsiaPac
2. **Stage**: Capability validation pending
3. **Customer pain**: Keppel procurement may require Ariba integration
4. **Next milestone**: Kit Yi internal Ariba/SAP API check by 22/05; VTI internal capability check.

---

### Recruit Express EP Service Agreement

1. **Stage**: Near close — 45-day termination compromise Thu 14/05; final draft sent Fri 15/05; target sign 16/05 Docusign
2. **Probability**: High (Karin signs promptly when aligned)
3. **Estimated value**: Service agreement (annual)
4. **Champion**: Charlotte (Quyen) — VTI side
5. **Decision-maker**: Karin
6. **Solution scope**: EP application services + appendix C fee structure
7. **Next milestone**: Sign 16/05 via Docusign; then MCF candidate interviews 4-6 weeks for Michael's EP.

---

### MC HCMC Body-shop Trial (6-month)

1. **Stage**: Trial accepted Mon 11/05; Toàn confirmed Tue 12/05
2. **Probability**: High
3. **Estimated value**: 6-month trial pricing TBC
4. **Solution scope**: IT body-shop (Toàn placement); 6-month service trial framework
5. **Risks**: Japanese workplace etiquette + CV format standard
6. **Next milestone**: Charlotte contract draft 15/05; HD template 20/05.

### MC SG IT Request (NEW — Wed 13/05)

1. **Stage**: Discovery — Kondo-san WhatsApp call Wed 13/05
2. **Solution scope**: Different from HCMC body-shop — full-stack SG vs body-shop split
3. **Pricing**: SG cost-of-living premium vs VN-based TBC
4. **Next milestone**: Kevin + Charlotte 2-option deck 16/05.

---

### Sembcorp IT Staff Augmentation

1. **Stage**: Active negotiation — pivot after 2 candidates rejected Fri 15/05 English fluency
2. **Probability**: Medium (depends on whether VTI can deliver fulltime-EN bench OR partime fallback acceptable to chị Huyền)
3. **Solution scope**: 2-option re-pitch (Fulltime native EN vs Partime VTI fallback)
4. **Pricing**: Commercial keep nguyên
5. **Next milestone**: Cuong direct chat chị Huyền English clarification; VAP team 2-option proposal 21/05.

---

### GITS Magento batch 2

1. **Stage**: CV submission — batch 2 (4 CVs) sent Tue 12/05
2. **Solution scope**: Magento dev placement (3× 5-10y OK, 1 different skills flagged)
3. **Next milestone**: Gary feedback timeline TBC.

---

### ALPSoft Azure L2 Cloud Engineer (NEW — Tue 12/05)

1. **Stage**: New case opening
2. **Solution scope**: Azure L2 Cloud Engineer concept (similar to existing ALPSoft engagement)
3. **Next milestone**: VAP team assessment 14/05 — TBC.

---

### Anthony's network opps (early-stage)

- **Technovation Penang** (1st intro Mon 11/05): Kevin send decks 15/05; Q2 MY trip 08-12 Jun coverage
- **Terabit Networks** (1st intro Mon 11/05): NDA in progress; June Q2 coffee planned; warm-up email Dominic 20/05
- **Resort World Sentosa Eslin**: chatbot demo specs + video 22/05; in-person Q2 coffee
- **OBS Don/Gerald**: nudge after NxGen settles
- **SWAT Mobility, Starhub, Wikilab/Technovation, B2B Commerce, Infinite Lab, GovTech rehearsal**: see Anthony Fri sync recurring updates.
<!-- END: opps -->

## 4. Per-Meeting-Type Patterns

<!-- BEGIN: meeting_types -->
### 2.1 Mr. Anthony & VTI Weekly Sync-up (recurring Fri 09:00 SGT)
- *Chair*: Anthony Tee.
- *Standard agenda*: APAC pipeline status, win/risk updates, account-specific issues.
- *Behavior (VALIDATED Fri 15/05)*: Anthony drives own agenda — broad strategic content (trip plans, account-by-account status, hiring strategy). Comparable to CEO briefing not status update.
- *NEW RULE (Fri 15/05)*: Michael sends weekly wrap-up TRƯỚC Anthony sync (Fri morning).
- *Best-practice*: Don't over-prep account status (Anthony drives); DO prep budget/staffing decisions Anthony will push on.

### 2.2 KGI Trading proposal lifecycle (Ufinity/KGI)
- *Pattern (CONFIRMED week 11-15/05)*: VTI internal sync → joint customer call → SAME-DAY post-mortem internal → revise → next session.
- *Risk pattern*: Mark may bring additional commercial validators mid-cycle (Alex Chow Tue 12/05). Mark may also raise scope expansion post-BQ (Internet-facing Client Portal hint from Mark Thu 14/05).
- *Best-practice*: Reserve internal review slot 1h after every customer BQ call; default quote +10% buffer.

### 2.3 [VAP] Weekly Operation Meeting (recurring Mon 10:00 ICT)
- *Chair*: Tyson Nguyen Ba.
- *Attendees*: Kevin, Tyson, Cuong, Michael, Quyen, Khanh.
- *Agenda*: opp/lead status (Kevin, Tyson); bidding status (David); team ops.
- *Use*: Michael accepts; useful for VAP coordination Mon morning. Bring weekly red/amber action list.

### 2.4 [VAP] Weekly Meeting (recurring Fri 16:00 ICT)
- Michael declines (per pattern Fri 15/05). Internal ops update.

### 2.5 External capability-assessment meeting (e.g. NxGen 14/05, Technovation 11/05, Terrabit 11/05)
- *Pattern (CONFIRMED Thu 14/05)*: VTI brings capability deck + case studies; customer probes for fit + cadence.
- *Acceleration signal*: 1 week from capability assessment → real tender (NxGen confirmed Thu→Fri).

### 2.6 External CR / scope-expansion meeting (e.g. IHL Portal CR Fri 15/05)
- *NEW Pattern (Fri 15/05)*: Customer brings additional scope beyond invite topic. Expect 30-50% scope expansion during hearing.
- *Critical*: VTI BA must drive post-meeting Q&A summary + estimation pipeline.
- *Risk*: First-time attendees (James Wai Fri) — need expand persona list.

### 2.7 Internal AI Case Study Sync (VAP & D3, ad-hoc)
- *Goal*: prepare AI case-study artifacts for external pitches.
- *Decision (15/05 chat)*: D3 owns AI training case; D8 không gom.

### 2.8 EP Legal sync (Recruit Express, MC HCMC)
- *Pattern*: Charlotte + Tri Legal pair-up; redline → customer review → 2-3 week cycle. Compromise approach (e.g. 45-day termination Recruit Express).

### 2.9 1:1 syncs (Hieu etc.)
- 20-30min Michael 1:1 với tech leads cho status alignment.
<!-- END: meeting_types -->

## 5. General Insights

<!-- BEGIN: general -->
1. **Speed-of-response signaling**: Stable across week. Ian Choy 1-week proposal turnaround locked. Karin signs 1 day ahead deadline. Mark 24h SLA gap list.

2. **Domain expertise gap = estimate risk**: Confirmed CA Web (no financial SME). Rule: range estimate + assumption list = baseline for any deal without internal SME.

3. **Mark Choon scope pattern (REFINED week)**: Tue = scope-add Alex Chow same-day; Thu = BRD revision push; Fri (Mark hint potential Internet-facing Client Portal next week). Default +10% buffer cho follow-on.

4. **NinjaTrader SDK chart embed**: Phase 1.5 split chốt. Long+Hieu joint own. Iframe fallback ready.

5. **NxGen RFI cadence**: 1 week proposal turnaround locked. Demo materials parallel track. Michael owns AI architecture sign-off.

6. **Anthony's network = core pipeline**: Mon 3 of 5 meetings. Stable. Fri sync expanded scope (Khôi Thailand playbook, Q2 trip dates, hire budget).

7. **Tyson workload concentration RED FLAG (Fri)**: Tuần 11-15/05 Tyson chair 8+ meetings. Tuần tới Tyson concurrent: KGI v3 (20/05) + RSA quote (20/05) + IHL CR split (22/05) + Odoo Q&A (22/05) + RWS chatbot (22/05). Michael CẦN re-prioritize Mon Operation — escalate IHL stream sang Hung hoặc Cuong.

8. **Mitsubishi expansion**: HCMC + SG 2 separate frameworks. Kondo-san decisive, country-specific scope thinking.

9. **Conflict management**: Tue Michael chose EP over UF — validated approach (Kevin+Tyson handled UF; Alex Chow one-off).

10. **KGI Trading proposal lifecycle**: VTI internal → joint customer → SAME-DAY post-mortem → revise → next session. Week 11-15/05 fits perfectly.

11. **Mark Choon 24h SLA gap list**: When Mark asks gap list, treat as 24h SLA.

12. **Kit Yi Chow persona FLIP (MAJOR Fri 15/05)**: Initial 'silent CC-only' hypothesis WRONG. Kit Yi = STRATEGIC SCOPE-DRIVER. Treat as peer-level decision-maker AsiaPac roadmap. Memory upgrade required.

13. **Scope expansion 30-50% pattern (NEW Fri)**: Customer brings additional scope beyond invite topic. Pattern observed Mark Choon (multiple weeks) + Kit Yi (Fri). Two-customer evidence = stable pattern. VTI BA must drive Q&A summary + estimation pipeline post-meeting.

14. **NxGen demo materials = cross-deal asset**: Aura + multi-agent + AIOps reusable cho Sembcorp + GovTech. Daniel+Tuan production 15/05 deadline = high leverage.

15. **MC HCMC trial contract = Legal template precedent**: Reusable cho MC SG + future Japanese accounts. Charlotte+Tri Legal velocity = key constraint.

16. **AI architecture sync Michael-Kevin (NEW Thu)**: Cloud provider + model hosting must align Michael+Kevin before any AI proposal submit. Pattern: Michael owns architecture sign-off cho AI deals.

17. **First-week patterns hardening (Day 5 summary)**: All major personas (Mark, Yen Hock, Ian, Karin, Kondo, Saoko, chị Huyền, Kit Yi, Alex Chow, James Wai, Anthony, SW Tang, Simon) now actionable. Prediction muscle building — Thu Prep accuracy high (Anthony sync, NxGen probe questions). Friday Prep accuracy good (Kit Yi flip caught as 'pending validation' — flipped exactly as flagged).

18. **Khôi Thailand-Malaysia playbook (NEW Fri 15/05)**: Position VTI = platform-implementation partner (Power Platform/Odoo/SAP) + retail/manufacturing focus. NOT custom-dev SI. Japanese SI partnerships go through country-level subsidiaries (Fujitsu Vietnam → Toyota Thailand pattern).

19. **Pipeline scaling pressure (NEW Fri)**: Anthony explicit 'Kevin alone can't handle'. Multiple SG accounts simultaneously. Michael cần (a) consolidate SG admin+sales hire budget, (b) plan resource scaling Q3.

20. **Memory week-end snapshot**: 13 client entries, 9 meeting-type patterns, 20 general insights. Memory ~16KB. Quality bar = v2-baseline depth from prior feedback.
<!-- END: general -->

## 6. Change Log

<!-- BEGIN: changelog -->
- **2026-05-11 Day 1 (Mon, week replay v1)**: Memory bootstrapped from baseline. 5 today meetings (Technovation intro, VAP Operation, Terrabit intro, CA Web BQ review, AIOps collect). Tomorrow Tue 12/05 = 6 meetings (UF×VTI CAWeb 2 slots, MC HCMC interview, internal CA Web review, EP Agreement, KGI BQ review). Persona seeds: Mark Choon, Yen Hock, Ian Choy, Derrick Chong, Kit Yi (initial silent hypothesis), Pravin (TBC), Karin Chan, Saoko Miyamoto + Kondo + Tam-san + Dung-san, chị Huyền, SW Tang (NEW), Simon Terrabit (NEW).

- **2026-05-12 Day 2 (Tue, week replay v1)**: 6 today meetings (UF×VTI CAWeb #1, MC HCMC interview Toàn, NEW internal CA Web BQ Review 15:30, EP Agreement, UF×VTI CAWeb #2 with Alex Chow NEW, KGI BQ internal). 3 tomorrow Wed meetings (MC WhatsApp Kondo NEW, 2nd KGI internal review, 21:00 KGI proposal syncup). 10 actions opened (1 red: Charlotte EP redline). Personas added: Alex Chow (Ufinity Commercial — first appearance confirmed Mon prediction). Memory pattern: Mark Choon scope-expansion + same-day attendee additions. Internal CA Web BQ Review 15:30 was NOT on Mon Prep (delta caught). MC HCMC Toàn interview went green per Mon Prep prediction. NEW accounts surfaced: GITS Magento (Gary), ALPSoft Azure L2.

- **2026-05-13 Day 3 (Wed, week replay v1)**: 3 today meetings (MC×WhatsApp Kondo NEW scope, 2nd KGI internal review with Long SDK report, 21:00 KGI proposal final align with full team). 4 tomorrow Thu meetings (UF×VTI joint customer call 10am, NxGen Agentic AI capability 13:30, EP Agreement Karin status, 21:00 post-mortem). 6 new actions opened (1 red: Hung architecture sign-off). Memory enrichment: Long Vu Thanh's SDK deep-dive confirmed chart embed = Phase 1.5; Kondo-san wants DIFFERENT MC SG framework (not HCMC template); Mark pattern confirmed (24h SLA gap list). Personas: Long Vu Thanh added as KGI NinjaTrader SDK SME.

- **2026-05-14 Day 4 (Thu, week replay v1)**: 4 today meetings (UF×VTI KGI Trading 10am — rich Fireflies 37min; NxGen Agentic AI 13:30 — rich Fireflies 59min; EP Agreement continued 15:00; KGI internal debrief 21:00 11min). 4 tomorrow Fri meetings (Anthony Sync 09:00, IHL Portal CR 14:00 — first AsiaPac customer-facing this week, VAP Weekly 16:00, sync up w Hieu 1:1 17:00). 13 actions opened (3 red: Hung data flow KGI, Kevin NxGen proposal, Michael NxGen architecture sync). Memory enrichment: Mark BRD-push pattern refined; NxGen 1-week cadence locked; Kit Yi persona STILL PENDING (Fri IHL CR moment of truth); cross-deal asset (NxGen demo materials reusable).

- **2026-05-15 Day 5 (Fri, week replay v1)**: 5 today meetings (Anthony Sync 09:00 — rich Fireflies 55min strategic; IHL Portal CR 14:00 — rich Fireflies 49min MAJOR Kit Yi persona FLIP + James Wai NEW; IHL CR wrap 14:52 12min; VAP Weekly 16:00 declined; sync up Hieu 17:00 1:1). 2 tomorrow Mon meetings (weekend skip): VAP Weekly Operation 10:00, VAP&D3 AI Case Study 13:00. 8 actions opened (1 red: Tyson IHL CR split + Odoo Q&A). MAJOR Memory updates: Kit Yi STRATEGIC SCOPE-DRIVER upgrade; James Wai persona NEW; AsiaPac massive scope expansion (Odoo migration 13 portals + SAP Ariba); Anthony strategic playbook (Khôi platform-implementation positioning); Q2 trip locked; hire budget Anthony push; weekly wrap-up NEW RULE.

- **2026-05-16 Day 6 (Sat, week replay v1)**: Weekend pause — 0 today meetings. Tomorrow Mon 18/05 prep (2 meetings: VAP Operation + VAP&D3 AI Case Study). 0 new actions opened. Memory at full week-end state: 13 client entries, 9 meeting-type patterns, 20 general insights, ~21KB. Action Tracker 43 open + 18 overdue. Full pipeline replay complete: Mon→Tue→Wed→Thu→Fri all artifacts published in date folders 2026-05-11/ through 2026-05-15/, plus Sat 2026-05-16/. Memory + Action Tracker accumulated sequentially demonstrating prediction muscle build-up: Mon initial seeds → Tue Alex Chow validated → Wed Long SDK confirmed → Thu Mark BRD push validated → Fri Kit Yi flip caught (predicted as 'pending validation' Thu, flipped exactly Fri).

- **2026-05-16 (Memory dimensional expansion)**: Restructured Memory schema from 5 sections → 7 sections. Added 'pics' (standalone Per-PIC personas Dimension 2 with 14 aspects) + 'opps' (Per-Opportunity tracking Dimension 3 with 15 aspects). Re-enriched 'clients' (Per-Account profiles Dimension 1 with 10 aspects per company). Backfilled all accounts from week 11-15/05 data: KGI/Ufinity, NxGen, AsiaPac IHL (+Odoo +Ariba new opps), Recruit Express, Sembcorp, MC HCMC + MC SG, OBS, Technovation, Terabit, RWS, GITS, ALPSoft. PICs documented: 23 personas (13 customer-side + 10 internal/network). Opps tracked: 14 active opps with full 15-aspect coverage.
- **2026-05-16 (Memory dimensional expansion)**: Restructured Memory schema from 5 sections → 7 sections. Added 'pics' (standalone Per-PIC personas Dimension 2 with 14 aspects) + 'opps' (Per-Opportunity tracking Dimension 3 with 15 aspects). Re-enriched 'clients' (Per-Account profiles Dimension 1 with 10 aspects per company). Backfilled all accounts from week 11-15/05 data: KGI/Ufinity, NxGen, AsiaPac IHL (+Odoo +Ariba new opps), Recruit Express, Sembcorp, MC HCMC + MC SG, OBS, Technovation, Terabit, RWS, GITS, ALPSoft. PICs documented: 23 personas (13 customer-side + 10 internal/network). Opps tracked: 14 active opps with full 15-aspect coverage.

- 2026-05-16 (Daily v8 Day 7 — weekend): 0 today + 0 tomorrow Sun meetings. Tomorrow_meetings target = Mon 18/05 per v9 rule (2 internal VTI: VAP Weekly Operation 10:00 + VAP&D3 AI Case Study 13:00). NEW signal RWS (Resorts World Sentosa) demo AI/chatbot — emerging deal from David DM 16/05 (46 msgs, scope 10→20 dev, BA hospitality gap). Michael AI tooling project (Claude-based) now visible to team. ALPSoft fresher training fee 25% still pending. Action Tracker holds 43 open + 18 overdue (no new actions today).

- 2026-05-16 (Daily v9.3 Day 7 — DEEP scan): 0 today + 0 Sun, target Mon 18/05 (2 internal VTI). Gmail DEEP 47 thread (RWS/NxGen/KGI/IHL/ALPSoft/Anthony intros/MC GenAI/Sembcorp). Chat 4 space (VAP+David DM+Nga DM+Anthony Sync) 718 msgs. **RWS upgrade** chat-only → JD-driven (Anthony FW Eminet 13/05); **NxGen 2-deal** track (staff aug Derrick 22/04 + HDB AI tender Ian Choy 15/05 mới); **Anthony intro funnel 2 tuần** (Infor declined, Dialogg push, Terrabit NDA, Technovation Penang, InfiniteX KL); **AsiaPac multi-engagement căng** (IHL CR 15/05 + Keppel issue chị Tu 14/05 + Sembcorp pivot fulltime/partime); MC HCMC swap deadlock 1 tuần (07-15/05); MC GenAI warranty deadline 06/06 surface. 4 internal personas refresh (Tung, David, Kevin, Thang D3).
<!-- END: changelog -->

## 7. AI Analysis Provenance

<!-- BEGIN: provenance -->
- **2026-05-11**: Pipeline v9.2 replay Day 1. Memory bootstrap (clients/meeting_types/general). Sources: Calendar events Mon-Tue, VTI.VAP chat _summary.json 11/05 (105 msgs, D9 CA Web + MC HCMC + Sembcorp topics). Sub-agents: 0 (Day 1 baseline).

- **2026-05-12**: Pipeline v9.2 replay Day 2. Memory enriched (Mark pattern, Alex Chow added, MC SG context, GITS, ALPSoft). Sources: Calendar Tue+Wed, VTI.VAP chat _summary.json 12/05 (50 msgs, GITS Magento + MC HCMC swap + ALPSoft + Sembcorp commercial). Sub-agents: 0 (manual delta-vs-prep).

- **2026-05-13**: Pipeline v9.2 replay Day 3. Memory general section enriched (12 insights). Sources: Calendar Wed+Thu, Fireflies transcript 'VTI Internal - Syncup KGI Trading Platform proposal' (67min 21:00 — rich detail on NinjaTrader integration + cash flow + estimation). Sub-agents: 0.

- **2026-05-14**: Pipeline v9.2 replay Day 4. Memory general (15 insights). Sources: Calendar Thu+Fri, Fireflies transcripts UF/VTI KGI (37m), NxGen Agentic AI (60m), VTI INTERNAL KGI 21:00 (11m). Rich action-items from Fireflies extraction. Sub-agents: 0.

- **2026-05-15**: Pipeline v9.2 replay Day 5. Memory full enrichment (clients/meeting_types/general 20 insights). Sources: Calendar Fri+Mon, Fireflies transcripts Anthony Sync (55m), IHL Portal CR (49m + 12m wrap), sync up Hieu (20m). MAJOR Kit Yi persona flip validated. Sub-agents: 0 (manual delta-vs-prep + persona inference inline).

- **2026-05-16**: Pipeline v9.2 replay Day 6 (final). Weekend run + memory full state. No new touchpoints. Memory ~21KB peak. All 6 daily folders populated. Total deliverables across week: 12 docs (6 Recap + 6 Prep), 1 Action Tracker (43 actions), 1 Memory (21KB).

- **2026-05-16 (Memory expansion)**: Pipeline v9.3 — Memory schema 5→7 sections. 'clients' enriched per-account 10 aspects. NEW 'pics' section 14 aspects/PIC. NEW 'opps' section 15 aspects/opp. Sources: full week replay 11-15/05 (Fireflies transcripts + chat _summary.json + Gmail threads + Calendar). Manual sub-agent inference; no automated sub-agents this pass.
- **2026-05-16 (Memory expansion)**: Pipeline v9.3 — Memory schema 5→7 sections. 'clients' enriched per-account 10 aspects. NEW 'pics' section 14 aspects/PIC. NEW 'opps' section 15 aspects/opp. Sources: full week replay 11-15/05 (Fireflies transcripts + chat _summary.json + Gmail threads + Calendar). Manual sub-agent inference; no automated sub-agents this pass.

- 2026-05-16 (Daily v8): Pipeline v8 first weekend run. Sources: Calendar Sat/Sun (0 events both days), Calendar Mon 18/05 (2 VTI internal active), Drive Google Chat Crawl _stage.json (5/41 spaces done, 36 deferred), DM David _summary.json (rich 16/05 data — RWS + AI tool), Memory baseline read OK. Sub-agents: persona×0 (no external PIC) · action-qc×1 (0 new) · cross-carry×1 (RWS + ALPSoft → Mon) · chat-extractor×1 (David DM) · sanity×1 (publish OK).

- 2026-05-16 (Daily v9.3): Pipeline v9.3 first DEEP run. Sources: Calendar Sat/Sun/Mon, Fireflies recap notifications (KGI 13-14/05, IHL CR 15/05 2x, NxGen Agentic AI 14/05), Gmail 47 thread (5-query/topic: RWS+NxGen+KGI+IHL/AsiaPac+ALPSoft+Anthony Tee), Drive Google Chat Crawl _stage.json (5/41 done, 36 deferred), DM David _summary 14d, Space VTI.VAP _summary 14d (718 msgs aggregate). Sub-agents: persona×4 internal (Tung/David/Kevin/Thang) · action-qc×1 (0 new actions) · cross-carry×1 (RWS+NxGen tender+ALPSoft+AsiaPac→Mon) · mail-and-chat-deep-extractor×1 · sanity×1. Effort metric: 47 mail thread + 718 chat msg + 5-pass reasoning.
<!-- END: provenance -->
