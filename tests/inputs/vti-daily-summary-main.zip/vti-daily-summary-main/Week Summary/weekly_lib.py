#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""weekly_lib.py — Shared utilities cho weekly-summary-monday-3am pipeline.

Pattern: Reuse từ Meeting Preparation (sibling folder) để KHÔNG duplicate
OAuth/Drive helpers. Override TOKEN_FILE + CREDENTIALS_FILE để dùng shared
file của Meeting Prep (1 OAuth flow, 2 project hưởng).

Files quan trọng (trong workspace folder Week Summary):
    _state.json                           — local state (week label, doc fileId, snapshot fileId)
    week_context/_window.json             — Bước 2 output (Mon-Sun window)
    week_context/mail_threads.json        — Bước 3a
    week_context/chat_signals.json        — Bước 3b
    week_context/daily_briefs.json        — Bước 3c
    week_context/tracker_snapshot.json    — Bước 3d
    week_context/memory_changes.md        — Bước 3e (changelog filter only)
    week_context/memory_baseline.md       — Bước 3e (full Memory.md hiện tại)
    week_context/memory_snapshot_prev.md  — Bước 3e (snapshot W-1, nếu có)
    week_context/weekly_brief.json        — Claude reasoning output
    outputs/weekly_doc.docx               — Render output trước upload
    outputs/discord_posts.json            — Build Discord trước POST
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timedelta, date, timezone
from pathlib import Path
from typing import Any, Optional

# Relax OAuth scope strict-check (giống meeting_lib)
os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

PROJECT_DIR = Path(__file__).resolve().parent
_MP_DIR = PROJECT_DIR.parent / "Meeting Preparation"

if not (_MP_DIR / "meeting_lib.py").exists():
    raise RuntimeError(
        f"Meeting Preparation sibling folder not found at {_MP_DIR}.\n"
        "Week Summary depends on Meeting Prep for OAuth + Drive helpers.\n"
        "Make sure both folders are siblings under Projects/."
    )

# Inject Meeting Prep dir into sys.path để import meeting_lib
sys.path.insert(0, str(_MP_DIR))

# Re-export shared bits from meeting_lib
from meeting_lib import (  # noqa: E402
    LOCAL_TZ,
    MICHAEL_EMAILS,
    VTI_DOMAIN,
    DISCORD_WEBHOOK,
    DISCORD_USER_AGENT,
    DISCORD_POST_MAX_CHARS,
    SCOPES,
    load_json,
    save_json,
    get_drive,
    find_folder,
    ensure_folder,
    find_file,
    download_text,
    upload_text,
    slugify,
    shorten,
)

# Local paths (Week Summary specific) -----------------------------------------
LOG_FILE = PROJECT_DIR / "run.log"
STATE_FILE = PROJECT_DIR / "_state.json"

CONTEXT_DIR = PROJECT_DIR / "week_context"
OUTPUTS_DIR = PROJECT_DIR / "outputs"

WINDOW_PATH = CONTEXT_DIR / "_window.json"
MAIL_THREADS_PATH = CONTEXT_DIR / "mail_threads.json"
CHAT_SIGNALS_PATH = CONTEXT_DIR / "chat_signals.json"
DAILY_BRIEFS_PATH = CONTEXT_DIR / "daily_briefs.json"
TRACKER_SNAPSHOT_PATH = CONTEXT_DIR / "tracker_snapshot.json"
MEMORY_CHANGES_PATH = CONTEXT_DIR / "memory_changes.md"
MEMORY_BASELINE_PATH = CONTEXT_DIR / "memory_baseline.md"
MEMORY_SNAPSHOT_PREV_PATH = CONTEXT_DIR / "memory_snapshot_prev.md"
BRIEF_PATH = CONTEXT_DIR / "weekly_brief.json"

DOCX_PATH = OUTPUTS_DIR / "weekly_doc.docx"
DISCORD_POSTS_PATH = OUTPUTS_DIR / "discord_posts.json"

for d in (CONTEXT_DIR, OUTPUTS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# OAuth files — prefer LOCAL copies (if Michael copied), else SHARED with Meeting Prep
_LOCAL_CRED = PROJECT_DIR / "credentials.json"
_LOCAL_TOKEN = PROJECT_DIR / "token.json"
_SHARED_CRED = _MP_DIR / "credentials.json"
_SHARED_TOKEN = _MP_DIR / "token.json"

CREDENTIALS_FILE = _LOCAL_CRED if _LOCAL_CRED.exists() else _SHARED_CRED
TOKEN_FILE = _LOCAL_TOKEN if _LOCAL_TOKEN.exists() else _SHARED_TOKEN

# ---------------------------------------------------------------------------
# Drive folder constants (Weekly Summary specific)
# ---------------------------------------------------------------------------

DAILY_PREP_FOLDER = "Daily Meeting Prep"        # Parent (kế thừa Meeting Prep)
WEEKLY_FOLDER = "Weekly Summary"                 # Sub-folder bên trong Daily Meeting Prep
SNAPSHOTS_FOLDER = "_snapshots"                  # Memory snapshots theo ISO week
CHAT_CRAWL_FOLDER = "Google Chat Crawl"          # Sibling root (read-only)
TRACKER_FILE_NAME = "Action_Tracker.xlsx"        # Trong Daily Meeting Prep
MEMORY_FILE_NAME = "Meeting_Memory.md"           # Trong Daily Meeting Prep

# ---------------------------------------------------------------------------
# Logging (override để dùng LOG_FILE local của Week Summary)
# ---------------------------------------------------------------------------


def log(msg: str) -> None:
    ts = datetime.now(LOCAL_TZ).strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


# ---------------------------------------------------------------------------
# State helpers (override để dùng STATE_FILE local)
# ---------------------------------------------------------------------------


def load_state() -> dict:
    return load_json(STATE_FILE, default={}) or {}


def save_state(state: dict) -> None:
    save_json(STATE_FILE, state)


# ---------------------------------------------------------------------------
# OAuth — bản local của Week Summary (dùng TOKEN_FILE đã resolve ở trên)
# ---------------------------------------------------------------------------


def load_credentials():
    """Load Google OAuth credentials. Auto-refresh if expired.

    Sử dụng TOKEN_FILE đã resolve (local hoặc shared với Meeting Prep).
    """
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
    except ImportError as e:
        raise RuntimeError(
            "Missing google-auth packages. Install: pip install --user "
            "google-auth google-auth-oauthlib google-api-python-client"
        ) from e

    if not TOKEN_FILE.exists():
        raise FileNotFoundError(
            f"Missing {TOKEN_FILE} — chạy `python auth_setup.py --auth-url` trước.\n"
            f"(Đã check cả local {_LOCAL_TOKEN} và shared {_SHARED_TOKEN}.)"
        )
    creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)
    if not creds.valid:
        if creds.expired and creds.refresh_token:
            log(f"Refreshing OAuth token from {TOKEN_FILE.name}...")
            creds.refresh(Request())
            TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
        else:
            raise RuntimeError(
                f"Credentials in {TOKEN_FILE} not refreshable — re-run auth_setup."
            )
    return creds


# ---------------------------------------------------------------------------
# Week window helpers — NEW (specific cho Weekly Summary)
# ---------------------------------------------------------------------------


def compute_week_window(run_dt: Optional[datetime] = None) -> dict:
    """Compute Mon-Sun của TUẦN TRƯỚC (relative to run_dt).

    Args:
        run_dt: datetime when running (default: now in LOCAL_TZ).
                Nếu run_dt là Monday, week trước = Mon-7d → Sun-1d.

    Returns:
        {
          "run_date": "2026-05-18",
          "run_dow": "Mon",
          "week_start": "2026-05-11",        # Monday tuần trước
          "week_end": "2026-05-17",          # Sunday tuần trước
          "week_label": "11/05 → 17/05/2026",
          "iso_week": "2026-W20",            # ISO week của week_start
          "iso_week_prev": "2026-W19",       # Để load snapshot Memory W-1 cho diff
          "tz_offset": "+07:00"
        }
    """
    if run_dt is None:
        run_dt = datetime.now(LOCAL_TZ)
    run_date = run_dt.date()
    # weekday: Mon=0, Sun=6. Nếu run_date là Mon (0), this_monday = run_date.
    # Nếu run_date là Wed (2), this_monday = run_date - 2.
    days_since_monday = run_date.weekday()
    this_monday = run_date - timedelta(days=days_since_monday)
    week_start = this_monday - timedelta(days=7)   # Monday tuần trước
    week_end = week_start + timedelta(days=6)       # Sunday tuần trước
    iso_year, iso_week, _ = week_start.isocalendar()
    prev_start = week_start - timedelta(days=7)
    prev_iso_year, prev_iso_week, _ = prev_start.isocalendar()
    return {
        "run_date": run_date.isoformat(),
        "run_dow": run_date.strftime("%a"),
        "week_start": week_start.isoformat(),
        "week_end": week_end.isoformat(),
        "week_label": f"{week_start.strftime('%d/%m')} → {week_end.strftime('%d/%m/%Y')}",
        "iso_week": f"{iso_year}-W{iso_week:02d}",
        "iso_week_prev": f"{prev_iso_year}-W{prev_iso_week:02d}",
        "tz_offset": "+07:00",
    }


def gmail_window_query(window: dict, extras: str = "") -> str:
    """Build Gmail search query for the window. Gmail dùng local-day boundary.

    `after:` inclusive, `before:` exclusive → cộng 1 ngày vào week_end.
    """
    end_exclusive = (date.fromisoformat(window["week_end"]) + timedelta(days=1)).isoformat()
    after = window["week_start"].replace("-", "/")
    before = end_exclusive.replace("-", "/")
    base = f"after:{after} before:{before} -in:draft -in:trash"
    if extras:
        base = f"{base} {extras}"
    return base


def days_in_window(window: dict) -> list[str]:
    """List ISO date strings từ week_start đến week_end inclusive."""
    start = date.fromisoformat(window["week_start"])
    return [(start + timedelta(days=i)).isoformat() for i in range(7)]


def memory_snapshot_filename(iso_week: str) -> str:
    """Tên file snapshot Memory cho ISO week (vd 'Meeting_Memory_2026-W20.md')."""
    return f"Meeting_Memory_{iso_week}.md"


def docx_filename(window: dict, version: int = 1) -> str:
    """Tên file docx upload Drive."""
    start = date.fromisoformat(window["week_start"])
    end = date.fromisoformat(window["week_end"])
    base = f"Weekly Summary — {start.strftime('%d-%m')} → {end.strftime('%d-%m-%Y')}"
    if version > 1:
        base += f" (v{version})"
    return f"{base}.docx"


# ---------------------------------------------------------------------------
# Drive folder navigation cho Week Summary
# ---------------------------------------------------------------------------


def get_weekly_folder_id(drive) -> str:
    """Resolve fileId của folder 'Daily Meeting Prep / Weekly Summary'.

    Cache vào _state.json. Nested folder → ensure cả parent + child.
    """
    state = load_state()
    cached = state.get("weekly_folder_id")
    if cached:
        try:
            meta = drive.files().get(fileId=cached, fields="trashed").execute()
            if not meta.get("trashed"):
                return cached
        except Exception:
            log(f"Cached weekly_folder_id {cached} invalid — re-resolving")

    parent_id = ensure_folder(drive, DAILY_PREP_FOLDER, parent_id="root")
    weekly_id = ensure_folder(drive, WEEKLY_FOLDER, parent_id=parent_id)
    state["weekly_folder_id"] = weekly_id
    state["daily_prep_folder_id"] = parent_id
    save_state(state)
    return weekly_id


def get_snapshots_folder_id(drive) -> str:
    """Resolve fileId của folder '..../Weekly Summary/_snapshots'."""
    state = load_state()
    cached = state.get("snapshots_folder_id")
    if cached:
        try:
            meta = drive.files().get(fileId=cached, fields="trashed").execute()
            if not meta.get("trashed"):
                return cached
        except Exception:
            log(f"Cached snapshots_folder_id {cached} invalid — re-resolving")

    weekly_id = get_weekly_folder_id(drive)
    snap_id = ensure_folder(drive, SNAPSHOTS_FOLDER, parent_id=weekly_id)
    state = load_state()
    state["snapshots_folder_id"] = snap_id
    save_state(state)
    return snap_id


def get_daily_prep_folder_id(drive) -> str:
    """Resolve folder 'Daily Meeting Prep' (chứa Action_Tracker.xlsx + Meeting_Memory.md)."""
    state = load_state()
    cached = state.get("daily_prep_folder_id")
    if cached:
        try:
            meta = drive.files().get(fileId=cached, fields="trashed").execute()
            if not meta.get("trashed"):
                return cached
        except Exception:
            pass
    fid = ensure_folder(drive, DAILY_PREP_FOLDER, parent_id="root")
    state = load_state()
    state["daily_prep_folder_id"] = fid
    save_state(state)
    return fid


def get_chat_crawl_folder_id(drive) -> Optional[str]:
    """Resolve folder 'Google Chat Crawl' (root). Returns None nếu chưa có."""
    state = load_state()
    cached = state.get("chat_crawl_folder_id")
    if cached:
        try:
            meta = drive.files().get(fileId=cached, fields="trashed").execute()
            if not meta.get("trashed"):
                return cached
        except Exception:
            pass
    fid = find_folder(drive, CHAT_CRAWL_FOLDER, parent_id="root")
    if fid:
        state = load_state()
        state["chat_crawl_folder_id"] = fid
        save_state(state)
    return fid


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _cli_window():
    """CLI: print computed window."""
    win = compute_week_window()
    save_json(WINDOW_PATH, win)
    print(json.dumps(win, ensure_ascii=False, indent=2))
    log(f"Week window: {win['week_label']} (ISO {win['iso_week']}) → {WINDOW_PATH}")


def _cli_test_auth():
    """CLI: test OAuth + drive folder resolution."""
    creds = load_credentials()
    drive = get_drive(creds)
    about = drive.about().get(fields="user(emailAddress,displayName)").execute()
    print(f"OAuth OK: {about['user']['emailAddress']}")
    weekly_id = get_weekly_folder_id(drive)
    snap_id = get_snapshots_folder_id(drive)
    daily_prep_id = get_daily_prep_folder_id(drive)
    chat_id = get_chat_crawl_folder_id(drive)
    print(f"Daily Meeting Prep folder: {daily_prep_id}")
    print(f"Weekly Summary folder:     {weekly_id}")
    print(f"_snapshots subfolder:      {snap_id}")
    print(f"Google Chat Crawl folder:  {chat_id or '(NOT FOUND)'}")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "window"
    if cmd == "window":
        _cli_window()
    elif cmd == "test-auth":
        _cli_test_auth()
    else:
        print(f"Usage: python weekly_lib.py [window|test-auth]", file=sys.stderr)
        sys.exit(2)
