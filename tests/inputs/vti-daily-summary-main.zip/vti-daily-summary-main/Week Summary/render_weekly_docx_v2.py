#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_weekly_docx_v2.py — Render weekly_brief_v2.json (focused format).

Schema:
  - meta (week_label, iso_week, run_date)
  - summary[]: bullets
  - operation[]: { title, context?, tasks[]: { title, status, pic, next_action?, deadline, priority } }
  - customers[]: { name, weekly_activity, current_problem, tasks[] }
  - deferred_or_noisy[]: bullets
  - stats_compact: dict
"""

from __future__ import annotations
import json, sys
from pathlib import Path
from weekly_lib import (
    load_json, get_drive, load_credentials,
    load_state, save_state, log,
    PROJECT_DIR, OUTPUTS_DIR, CONTEXT_DIR, STATE_FILE,
)

BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2.json"
DOCX_PATH = OUTPUTS_DIR / "weekly_doc_v2.docx"
WINDOW_PATH = CONTEXT_DIR / "_window.json"


def docx_filename(win, version=1):
    a = win["week_start"].replace("-", "")
    b = win["week_end"].replace("-", "")
    ws = win["week_start"][8:10] + "-" + win["week_start"][5:7]
    we = win["week_end"][8:10] + "-" + win["week_end"][5:7] + "-" + win["week_end"][0:4]
    base = f"Weekly Summary — {ws} → {we}"
    if version > 1:
        return f"{base} (v{version}).docx"
    return f"{base}.docx"


def get_weekly_folder_id(drive):
    # Reuse logic from weekly_lib via state
    state = load_state()
    fid = state.get("weekly_folder_id")
    if not fid:
        log("ERROR: weekly_folder_id missing in _state.json")
        sys.exit(2)
    return fid


# --- doc helpers -----------------------------------------------------------
def _set_doc_style(doc):
    from docx.shared import Pt
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(11)


def _h1(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(18)
    r.font.color.rgb = RGBColor(0x05, 0x19, 0x34)


def _h2(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(14)
    r.font.color.rgb = RGBColor(0x1F, 0x3A, 0x68)


def _h3(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(12)
    r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)


def _para(doc, text, italic=False, bold=False):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.italic = italic
    r.bold = bold


def _bullet(doc, text, level=0):
    style = "List Bullet" if level == 0 else "List Bullet 2"
    try:
        doc.add_paragraph(text, style=style)
    except KeyError:
        # fallback
        p = doc.add_paragraph(("    " * level) + "• " + text)


def _priority_emoji(p):
    p = (p or "").upper()
    return {"RED": "🔴", "AMBER": "🟡", "GREEN": "🟢"}.get(p, "⚪")


# --- section renderers -----------------------------------------------------
def render_cover(doc, brief):
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    meta = brief.get("meta", {})

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("WEEKLY SUMMARY")
    r.bold = True
    r.font.size = Pt(26)
    r.font.color.rgb = RGBColor(0x05, 0x19, 0x34)

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run(meta.get("week_label", ""))
    r2.font.size = Pt(15)
    r2.italic = True

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r3 = p3.add_run(f"ISO {meta.get('iso_week','')} · Run {meta.get('run_date','')}")
    r3.font.size = Pt(10)
    doc.add_paragraph()


def render_summary(doc, brief):
    _h1(doc, "Summary")
    for item in brief.get("summary", []):
        _bullet(doc, item)
    doc.add_paragraph()


def render_task(doc, t):
    """Render a single task as bullet-with-sub-bullets."""
    title = t.get("title", "Untitled task")
    pri = t.get("priority", "")
    emoji = _priority_emoji(pri)
    _para(doc, f"• {emoji} {title}", bold=True)
    if t.get("status"):
        _bullet(doc, f"Status: {t['status']}", level=1)
    pic_line = []
    if t.get("pic"): pic_line.append(f"PIC: {t['pic']}")
    if t.get("next_action"): pic_line.append(f"Việc sẽ làm: {t['next_action']}")
    if t.get("deadline"): pic_line.append(f"Deadline: {t['deadline']}")
    if pic_line:
        _bullet(doc, " · ".join(pic_line), level=1)


def render_operation(doc, brief):
    _h1(doc, "Operation (Vận hành nội bộ)")
    items = brief.get("operation", [])
    if not items:
        _para(doc, "(không có item)", italic=True)
        return
    for it in items:
        _h2(doc, f"• {it.get('title', '?')}")
        if it.get("context"):
            _para(doc, it["context"], italic=True)
        for t in it.get("tasks", []):
            render_task(doc, t)
        doc.add_paragraph()


def render_customers(doc, brief):
    _h1(doc, "Khách hàng / Opportunity")
    items = brief.get("customers", [])
    if not items:
        _para(doc, "(không có opp)", italic=True)
        return
    for c in items:
        _h2(doc, f"• {c.get('name', '?')}")
        if c.get("weekly_activity"):
            _para(doc, "Đã làm / trao đổi trong tuần:", bold=True)
            _para(doc, c["weekly_activity"])
        if c.get("current_problem"):
            _para(doc, "Vấn đề hiện tại / Giải pháp:", bold=True)
            _para(doc, c["current_problem"])
        tasks = c.get("tasks", [])
        if tasks:
            _para(doc, "Tasks:", bold=True)
            for t in tasks:
                render_task(doc, t)
        else:
            _para(doc, "(không có task tuần này)", italic=True)
        doc.add_paragraph()


def render_appendix(doc, brief):
    deferred = brief.get("deferred_or_noisy", [])
    stats = brief.get("stats_compact", {})
    if deferred:
        _h1(doc, "Phụ lục — Deferred / Noisy items")
        for d in deferred:
            _bullet(doc, d)
        doc.add_paragraph()
    if stats:
        _h3(doc, "Stats compact")
        for k, v in stats.items():
            _bullet(doc, f"{k}: {v}")


# --- main ------------------------------------------------------------------
def render(brief_path: Path, out_path: Path):
    from docx import Document
    brief = load_json(brief_path)
    if not brief:
        log(f"ERROR: brief not found at {brief_path}")
        sys.exit(2)
    doc = Document()
    _set_doc_style(doc)
    render_cover(doc, brief)
    render_summary(doc, brief)
    render_operation(doc, brief)
    render_customers(doc, brief)
    render_appendix(doc, brief)
    doc.save(out_path)
    log(f"Rendered docx v2 -> {out_path} ({out_path.stat().st_size} bytes)")
    return out_path


def upload_docx(out_path: Path):
    from googleapiclient.http import MediaFileUpload
    creds = load_credentials()
    drive = get_drive(creds)
    folder_id = get_weekly_folder_id(drive)
    win = load_json(WINDOW_PATH)
    state = load_state()
    last_run_window = state.get("last_run_window")
    version = 1
    if last_run_window == win["week_label"]:
        version = int(state.get("last_run_version", 1)) + 1
    name = docx_filename(win, version=version)

    media = MediaFileUpload(
        str(out_path),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        resumable=False,
    )
    body = {
        "name": name,
        "parents": [folder_id],
        "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }
    f = drive.files().create(body=body, media_body=media, fields="id,webViewLink").execute()
    log(f"Uploaded {name} -> id={f['id']}")
    state["last_run_window"] = win["week_label"]
    state["last_run_version"] = version
    state["last_docx_id"] = f["id"]
    state["last_docx_link"] = f.get("webViewLink")
    save_state(state)
    return {"file_id": f["id"], "name": name, "link": f.get("webViewLink")}


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "render-and-upload"
    if cmd == "render":
        render(BRIEF_PATH, DOCX_PATH)
    elif cmd == "upload":
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    elif cmd == "render-and-upload":
        render(BRIEF_PATH, DOCX_PATH)
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    else:
        print("Usage: render_weekly_docx_v2.py [render|upload|render-and-upload]", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
