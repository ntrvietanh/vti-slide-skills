#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""crawl_chat.py — Aggregate Google Chat messages tuần qua từ Drive.

Drive structure (từ crawl_gchat.py v2):
    Google Chat Crawl/spaces/<Type>_<Name>_<sid>/YYYY-MM-DD.jsonl

Parallel-fetch để giảm wall time (~5min serial → ~1min với 8 workers).
"""
from __future__ import annotations
import json, sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from weekly_lib import (
    CHAT_SIGNALS_PATH, MICHAEL_EMAILS, WINDOW_PATH,
    days_in_window, find_folder, get_chat_crawl_folder_id, get_drive,
    load_credentials, load_json, log, save_json,
)
from googleapiclient.discovery import build

MAX_MSGS_PER_SPACE = 50
MAX_WORKERS = 8


def _list_subfolders(drive, parent_id):
    out, page_token = [], None
    while True:
        q = f"'{parent_id}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
        resp = drive.files().list(q=q, fields="nextPageToken, files(id,name)", pageSize=100, pageToken=page_token).execute()
        out.extend(resp.get("files", []))
        page_token = resp.get("nextPageToken")
        if not page_token: break
    return out


def _list_files(drive, parent_id):
    out, page_token = [], None
    while True:
        q = f"'{parent_id}' in parents and mimeType != 'application/vnd.google-apps.folder' and trashed = false"
        resp = drive.files().list(q=q, fields="nextPageToken, files(id,name)", pageSize=100, pageToken=page_token).execute()
        out.extend(resp.get("files", []))
        page_token = resp.get("nextPageToken")
        if not page_token: break
    return out


def _download_text(drive, fid):
    try:
        raw = drive.files().get_media(fileId=fid).execute()
        return raw.decode("utf-8") if isinstance(raw, bytes) else raw
    except Exception as e:
        log(f"  ! download {fid}: {e}")
        return ""


def _parse_jsonl(text):
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line: continue
        try: out.append(json.loads(line))
        except json.JSONDecodeError: continue
    return out


def _aggregate(space_name, all_msgs):
    if not all_msgs:
        return {"space_name": space_name, "msg_count": 0, "skipped": True}
    michael_set = {e.lower() for e in MICHAEL_EMAILS}
    sender_counts = {}
    michael_msgs, other_msgs = [], []
    for m in all_msgs:
        email = (m.get("sender_email") or "").lower()
        sender_counts[email] = sender_counts.get(email, 0) + 1
        (michael_msgs if email in michael_set else other_msgs).append(m)
    other_msgs.sort(key=lambda m: m.get("create_time", ""), reverse=True)
    cap = MAX_MSGS_PER_SPACE
    sample = michael_msgs + other_msgs[:max(0, cap - len(michael_msgs))]
    sample.sort(key=lambda m: m.get("create_time", ""))
    trimmed = []
    for m in sample:
        text = (m.get("text") or "")[:500]
        trimmed.append({
            "msg_id": m.get("msg_id"),
            "thread_id": m.get("thread_id"),
            "create_time": m.get("create_time"),
            "sender_name": m.get("sender_name"),
            "sender_email": m.get("sender_email"),
            "text": text,
            "is_michael": (m.get("sender_email") or "").lower() in michael_set,
        })
    return {
        "space_name": space_name,
        "msg_count": len(all_msgs),
        "michael_msg_count": len(michael_msgs),
        "unique_senders": len(sender_counts),
        "top_senders": dict(sorted(sender_counts.items(), key=lambda kv: -kv[1])[:5]),
        "messages_sample": trimmed,
        "messages_truncated": len(all_msgs) > len(trimmed),
    }


def _process_space(creds, sf, target_filenames):
    """Worker: list+download per space. Build own Drive client (thread-safe)."""
    drive = build("drive", "v3", credentials=creds, cache_discovery=False)
    sname, sid = sf["name"], sf["id"]
    files = _list_files(drive, sid)
    jsonl_in = [f for f in files if f["name"] in target_filenames]
    if not jsonl_in:
        return sid, None
    all_msgs = []
    for jf in jsonl_in:
        text = _download_text(drive, jf["id"])
        all_msgs.extend(_parse_jsonl(text))
    if not all_msgs:
        return sid, None
    agg = _aggregate(sname, all_msgs)
    return sid, agg


def crawl():
    win = load_json(WINDOW_PATH)
    if not win:
        log("ERROR: window not computed")
        sys.exit(2)
    days_iso = days_in_window(win)
    target_filenames = {f"{d}.jsonl" for d in days_iso}
    creds = load_credentials()
    drive = get_drive(creds)
    chat_root = get_chat_crawl_folder_id(drive)
    if not chat_root:
        log("WARN: 'Google Chat Crawl' not found")
        save_json(CHAT_SIGNALS_PATH, {"window": win, "chat_root_found": False})
        return
    spaces_folder = find_folder(drive, "spaces", parent_id=chat_root) or chat_root
    log(f"Listing space folders dưới {spaces_folder}...")
    space_folders = _list_subfolders(drive, spaces_folder)
    log(f"Found {len(space_folders)} space folders — parallel fetch with {MAX_WORKERS} workers")

    by_space = {}
    skipped = 0
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as exe:
        futures = {exe.submit(_process_space, creds, sf, target_filenames): sf for sf in space_folders}
        for i, fut in enumerate(as_completed(futures), 1):
            sf = futures[fut]
            try:
                sid, agg = fut.result()
                if agg:
                    by_space[sid] = agg
                    if i % 10 == 0 or agg["msg_count"] > 20:
                        log(f"  [{i}/{len(space_folders)}] {agg['space_name']}: {agg['msg_count']} msgs")
                else:
                    skipped += 1
            except Exception as e:
                log(f"  ! {sf['name']}: {e}")
                skipped += 1

    out = {
        "window": win, "chat_root_found": True, "chat_root_id": chat_root,
        "spaces_total_listed": len(space_folders),
        "spaces_active_in_window": len(by_space),
        "spaces_skipped_no_msgs": skipped,
        "stats": {
            "total_msgs": sum(s["msg_count"] for s in by_space.values()),
            "total_michael_msgs": sum(s.get("michael_msg_count", 0) for s in by_space.values()),
        },
        "by_space": by_space,
    }
    save_json(CHAT_SIGNALS_PATH, out)
    log(f"Chat signals -> {CHAT_SIGNALS_PATH}")
    log(f"  Active: {len(by_space)}/{len(space_folders)} spaces, {out['stats']['total_msgs']} msgs (Michael: {out['stats']['total_michael_msgs']})")


if __name__ == "__main__":
    crawl()
