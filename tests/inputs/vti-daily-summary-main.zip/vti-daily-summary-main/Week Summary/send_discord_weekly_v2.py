#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""send_discord_weekly_v2.py — Discord webhook poster cho weekly_brief_v2.json.

Schema input: weekly_brief_v2.json (Summary + Operation + Customers + cross_week_diff).

Output: 4-6 posts (smart split, mỗi post < 1900 chars):
  1. Header — week label + Summary bullets + Doc link
  2. Operation — đầu việc nội bộ với tasks
  3. Customer (1 hoặc nhiều post tùy size) — opps với tasks
  4. Cross-week diff highlights (nếu baseline available)

CLI:
  python3 send_discord_weekly_v2.py dry-run                # in posts ra stdout
  python3 send_discord_weekly_v2.py build                  # save posts to outputs/discord_posts_v2.json
  python3 send_discord_weekly_v2.py build-and-send         # build + POST
  python3 send_discord_weekly_v2.py send                   # POST từ file đã build

  --webhook=<URL>  override default webhook URL
"""

from __future__ import annotations
import json, sys, time, urllib.request
from pathlib import Path
from weekly_lib import (
    load_json, log,
    CONTEXT_DIR, OUTPUTS_DIR,
)

BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2.json"
DISCORD_POSTS_PATH = OUTPUTS_DIR / "discord_posts_v2.json"

# ---- Hardcoded webhook (Michael's new webhook for v2 reports, set 16/05/2026) ----
DEFAULT_WEBHOOK = "https://discord.com/api/webhooks/1505405696987107408/fuBjjz0NGlBIQh9pPaQMSiwIoWBIkfv33pUg_qdbBzQdBA8gqm68N_1pgiDSlASrWDcY"
DISCORD_USER_AGENT = "VTI Weekly Summary Bot / v2 (Python urllib)"
MAX_POST_CHARS = 1900  # buffer below Discord 2000 limit


# ---------------------------------------------------------------------------
# Format helpers
# ---------------------------------------------------------------------------
def task_line(t: dict) -> str:
    """One-line compact task for Discord."""
    pri = (t.get("priority") or "").upper()
    pri_tag = f"`[{pri}]` " if pri in ("RED", "AMBER", "GREEN") else ""
    title = t.get("title", "?").strip()
    pieces = [f"• {pri_tag}**{title}**"]
    sub = []
    if t.get("status"):
        sub.append(f"_Status:_ {t['status']}")
    if t.get("pic"):
        sub.append(f"_PIC:_ {t['pic']}")
    if t.get("next_action"):
        sub.append(f"_Việc sẽ làm:_ {t['next_action']}")
    if t.get("deadline"):
        sub.append(f"_Deadline:_ {t['deadline']}")
    if sub:
        pieces.append("  " + " · ".join(sub))
    return "\n".join(pieces)


def truncate(s: str, n: int, suffix: str = " …") -> str:
    if len(s) <= n:
        return s
    return s[: n - len(suffix)].rstrip() + suffix


# ---------------------------------------------------------------------------
# Build posts
# ---------------------------------------------------------------------------
def build_header_post(brief: dict, doc_link: str = "") -> dict:
    meta = brief.get("meta", {})
    lines = [
        f"# Weekly Summary — {meta.get('week_label', '?')}",
        f"_ISO {meta.get('iso_week', '?')} · Run {meta.get('run_date', '?')}_",
        "",
        "## Summary",
    ]
    for s in brief.get("summary", []):
        lines.append(f"• {s}")
    if doc_link:
        lines.append("")
        lines.append(f"📄 [Full doc trên Drive]({doc_link})")
    content = "\n".join(lines)
    if len(content) > MAX_POST_CHARS:
        content = truncate(content, MAX_POST_CHARS)
    return {"label": "header", "content": content}


def chunk_text_into_posts(label_prefix: str, header: str, body_blocks: list[str]) -> list[dict]:
    """Distribute body_blocks across posts, each post starts with header.

    body_blocks is a list of pre-formatted strings (one "unit", e.g. one operation item
    or one customer opp). Each post: header + accumulated blocks until limit reached.
    """
    posts = []
    current_blocks = []
    base_len = len(header) + 2  # +2 for trailing \n\n
    current_len = base_len

    def flush(idx_suffix=""):
        if not current_blocks:
            return
        content = header + ("\n" if header else "") + "\n\n".join(current_blocks)
        posts.append({"label": f"{label_prefix}{idx_suffix}", "content": content})

    for blk in body_blocks:
        blk_len = len(blk) + 2  # +2 for separator \n\n
        if current_len + blk_len > MAX_POST_CHARS and current_blocks:
            flush(f"_{len(posts)+1}")
            current_blocks = []
            current_len = base_len
        # If single block alone exceeds limit, truncate it
        if blk_len > MAX_POST_CHARS - base_len:
            blk = truncate(blk, MAX_POST_CHARS - base_len - 50)
            blk_len = len(blk) + 2
        current_blocks.append(blk)
        current_len += blk_len
    flush(f"_{len(posts)+1}" if posts else "")
    return posts


def build_operation_posts(brief: dict) -> list[dict]:
    items = brief.get("operation", []) or []
    if not items:
        return [{"label": "operation", "content": "## Operation (vận hành nội bộ)\n_(không có item tuần này)_"}]

    header = "## Operation (vận hành nội bộ)"
    blocks = []
    for it in items:
        lines = [f"### {it.get('title', '?')}"]
        if it.get("context"):
            lines.append(f"_{it['context']}_")
        for t in it.get("tasks", []):
            lines.append(task_line(t))
        blocks.append("\n".join(lines))
    return chunk_text_into_posts("operation", header, blocks)


def build_customer_posts(brief: dict) -> list[dict]:
    items = brief.get("customers", []) or []
    if not items:
        return [{"label": "customers", "content": "## Khách hàng / Opportunity\n_(không có opp tuần này)_"}]

    header = "## Khách hàng / Opportunity"
    blocks = []
    for c in items:
        lines = [f"### {c.get('name', '?')}"]
        if c.get("weekly_activity"):
            lines.append(f"**Đã làm trong tuần:** {c['weekly_activity']}")
        if c.get("current_problem"):
            lines.append(f"**Vấn đề / Giải pháp:** {c['current_problem']}")
        tasks = c.get("tasks", [])
        if tasks:
            lines.append("**Tasks:**")
            for t in tasks:
                lines.append(task_line(t))
        else:
            lines.append("_(không có task tuần này)_")
        blocks.append("\n".join(lines))
    return chunk_text_into_posts("customers", header, blocks)


def build_cross_week_post(brief: dict) -> list[dict]:
    cwd = brief.get("cross_week_diff")
    if not cwd:
        return []
    if not cwd.get("baseline_available"):
        # First run — informational note only
        note = cwd.get("note", "(baseline tuần trước chưa có)")
        return [{"label": "cross_week", "content": f"## So với tuần trước (W-1)\n_{note}_"}]

    sc = cwd.get("summary_counts", {})
    lines = [
        f"## So với tuần trước (baseline {cwd.get('baseline_iso_week','?')} → current {cwd.get('current_iso_week','?')})",
        (
            f"**Operation:** updated {sc.get('op_updated_tasks',0)} · "
            f"no-update {sc.get('op_no_update_tasks',0)} · "
            f"dropped {sc.get('op_dropped_tasks',0)} · "
            f"new {sc.get('op_new_tasks',0)}"
        ),
        (
            f"**Customer:** updated {sc.get('cust_updated_tasks',0)} · "
            f"no-update {sc.get('cust_no_update_tasks',0)} · "
            f"dropped {sc.get('cust_dropped_tasks',0)} · "
            f"new {sc.get('cust_new_tasks',0)}"
        ),
        "",
    ]

    # Top "dropped" highlights — flag tasks present in W-1 but missing in W
    dropped_highlights = []
    for od in cwd.get("operation_diff", []):
        td = od.get("tasks_diff", {})
        for d in td.get("dropped", []):
            dropped_highlights.append(f"  • [Op/{od.get('operation_title','?')[:30]}] {d.get('title','?')[:80]}")
    for cd in cwd.get("customers_diff", []):
        td = cd.get("tasks_diff", {})
        for d in td.get("dropped", []):
            dropped_highlights.append(f"  • [Cust/{cd.get('customer_name','?')[:25]}] {d.get('title','?')[:80]}")

    if dropped_highlights:
        lines.append("### ⚠️ Tuần trước có — tuần này KHÔNG nhắc (cần verify)")
        # cap to fit
        for line in dropped_highlights[:15]:
            lines.append(line)
        if len(dropped_highlights) > 15:
            lines.append(f"  …và {len(dropped_highlights) - 15} item nữa (xem doc).")

    content = "\n".join(lines)
    if len(content) > MAX_POST_CHARS:
        content = truncate(content, MAX_POST_CHARS)
    return [{"label": "cross_week", "content": content}]


def build_all_posts(brief: dict, doc_link: str = "") -> list[dict]:
    posts = []
    posts.append(build_header_post(brief, doc_link=doc_link))
    posts.extend(build_operation_posts(brief))
    posts.extend(build_customer_posts(brief))
    posts.extend(build_cross_week_post(brief))
    return posts


# ---------------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------------
def get_doc_link():
    """Read last_docx_link from _state.json (set by render_v3 upload)."""
    state_path = Path(__file__).parent / "_state.json"
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text())
            return state.get("last_docx_link", "")
        except Exception:
            pass
    return ""


def post(webhook: str, content: str, label: str) -> bool:
    body = json.dumps({"content": content}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        webhook, data=body, method="POST",
        headers={"Content-Type": "application/json", "User-Agent": DISCORD_USER_AGENT},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            code = resp.getcode()
            log(f"  POST {label} ({len(content)} chars) → {code}")
            return 200 <= code < 300
    except Exception as e:
        log(f"  POST {label} FAIL: {e}")
        return False


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def parse_args(argv):
    cmd = "build-and-send"
    webhook = DEFAULT_WEBHOOK
    rest = []
    for a in argv:
        if a.startswith("--webhook="):
            webhook = a.split("=", 1)[1]
        elif a in ("build", "send", "dry-run", "build-and-send"):
            cmd = a
        else:
            rest.append(a)
    return cmd, webhook


def main():
    cmd, webhook = parse_args(sys.argv[1:])
    brief = load_json(BRIEF_PATH)
    if not brief:
        log(f"ERROR: brief not found at {BRIEF_PATH}")
        sys.exit(2)

    doc_link = get_doc_link()
    posts = build_all_posts(brief, doc_link=doc_link)

    if cmd == "dry-run":
        for p in posts:
            print(f"\n{'='*60}\nPOST: {p['label']} ({len(p['content'])} chars)\n{'='*60}")
            print(p["content"])
        log(f"Dry-run: {len(posts)} posts ready (max chars: {max(len(p['content']) for p in posts)})")
        return

    if cmd in ("build", "build-and-send"):
        OUTPUTS_DIR.mkdir(exist_ok=True)
        DISCORD_POSTS_PATH.write_text(json.dumps(posts, ensure_ascii=False, indent=2))
        log(f"Built {len(posts)} posts → {DISCORD_POSTS_PATH}")

    if cmd in ("send", "build-and-send"):
        if cmd == "send":
            posts = json.loads(DISCORD_POSTS_PATH.read_text())
        ok = fail = 0
        for p in posts:
            if post(webhook, p["content"], p["label"]):
                ok += 1
            else:
                fail += 1
            time.sleep(1.2)  # gentle rate-limit
        log(f"Discord v2: {ok} ok, {fail} fail")


if __name__ == "__main__":
    main()
