#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""compare_brief_v2.py — Cross-week diff cho Weekly Summary v2 format.

Pipeline:
  1. Đọc weekly_brief_v2.json (tuần hiện tại) từ week_context/.
  2. Download snapshot W-1 brief (file `weekly_brief_v2_<ISO_WEEK_PREV>.json`)
     từ Drive folder snapshots/.
  3. Compare:
     - Operation items: match by title (case-insensitive, fuzzy) → status change?
     - Customer opps: match by name → list tasks diff
     - Tasks within opp/operation: match by title → status change / no update / dropped / new
  4. Emit cross_week_diff block ghi đè vào weekly_brief_v2.json (cùng path).

CLI:
  python3 compare_brief_v2.py
"""

from __future__ import annotations
import json, sys, re
from pathlib import Path
from difflib import SequenceMatcher

from weekly_lib import (
    load_json, save_json, get_drive, load_credentials,
    get_snapshots_folder_id, find_file, download_text, log,
    ensure_folder, find_folder, load_state,
    CONTEXT_DIR,
)


def week_folder_name(iso_week: str) -> str:
    if not iso_week: return "Wxx-yyyy"
    s = iso_week.strip()
    if "-W" in s:
        year, w = s.split("-W", 1)
        return f"W{w}-{year}"
    return s


def get_weekly_folder_id(drive):
    state = load_state()
    return state.get("weekly_folder_id")

BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2.json"
WINDOW_PATH = CONTEXT_DIR / "_window.json"
PREV_BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2_prev.md"  # cached copy


# ---------------------------------------------------------------------------
# Snapshot filename convention
# ---------------------------------------------------------------------------
def snapshot_filename(iso_week: str) -> str:
    return f"weekly_brief_v2_{iso_week}.json"


# ---------------------------------------------------------------------------
# Fuzzy matching
# ---------------------------------------------------------------------------
def _norm(s: str) -> str:
    """Normalize string for fuzzy matching."""
    if not s:
        return ""
    s = s.lower().strip()
    # Remove common punctuation, keep accented chars
    s = re.sub(r"[\.,;:!\?\(\)\[\]\{\}\"\'\-/]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, _norm(a), _norm(b)).ratio()


def _match_in_list(target_title: str, candidates: list, key="title", threshold=0.65):
    """Return (best_candidate, score) or (None, 0) if no match above threshold."""
    best, best_score = None, 0.0
    nt = _norm(target_title)
    for c in candidates:
        ct = _norm(c.get(key, ""))
        if not ct:
            continue
        # Exact substring shortcut
        if nt and (nt in ct or ct in nt) and abs(len(nt) - len(ct)) <= max(8, int(0.5 * max(len(nt), len(ct)))):
            score = max(0.85, _similarity(target_title, c.get(key, "")))
        else:
            score = _similarity(target_title, c.get(key, ""))
        if score > best_score:
            best, best_score = c, score
    if best_score >= threshold:
        return best, best_score
    return None, best_score


# ---------------------------------------------------------------------------
# Diff a single task list (operation.tasks or customer.tasks)
# ---------------------------------------------------------------------------
def diff_tasks(curr_tasks: list, prev_tasks: list) -> dict:
    """Diff 2 task lists by title. Returns dict:
       { updated: [...], no_update: [...], dropped: [...], new: [...] }
       Each entry has shape { title, prev_status, curr_status, prev_pic, curr_pic, prev_deadline, curr_deadline, similarity }
    """
    out = {"updated": [], "no_update": [], "dropped": [], "new": []}
    if not isinstance(curr_tasks, list): curr_tasks = []
    if not isinstance(prev_tasks, list): prev_tasks = []
    matched_prev_ids = set()

    for ct in curr_tasks:
        title = ct.get("title", "")
        match, score = _match_in_list(title, prev_tasks, key="title", threshold=0.65)
        if match is None:
            out["new"].append({"title": title, "status": ct.get("status"), "pic": ct.get("pic"),
                                "deadline": ct.get("deadline"), "priority": ct.get("priority")})
            continue
        matched_prev_ids.add(id(match))
        # Detect change
        same_status = _norm(match.get("status", "")) == _norm(ct.get("status", ""))
        same_pic = _norm(match.get("pic", "")) == _norm(ct.get("pic", ""))
        same_deadline = _norm(match.get("deadline", "")) == _norm(ct.get("deadline", ""))
        entry = {
            "title": title,
            "matched_prev_title": match.get("title"),
            "similarity": round(score, 2),
            "prev_status": match.get("status"),
            "curr_status": ct.get("status"),
            "prev_pic": match.get("pic"),
            "curr_pic": ct.get("pic"),
            "prev_deadline": match.get("deadline"),
            "curr_deadline": ct.get("deadline"),
        }
        if same_status and same_pic and same_deadline:
            out["no_update"].append(entry)
        else:
            out["updated"].append(entry)

    # Tasks in prev not matched in curr → dropped
    for pt in prev_tasks:
        if id(pt) in matched_prev_ids:
            continue
        out["dropped"].append({
            "title": pt.get("title"),
            "prev_status": pt.get("status"),
            "prev_pic": pt.get("pic"),
            "prev_deadline": pt.get("deadline"),
            "note": "Tuần trước có nhắc, tuần này không thấy update — cần verify đã đóng / drop / quên?"
        })
    return out


# ---------------------------------------------------------------------------
# Build cross_week_diff for entire brief
# ---------------------------------------------------------------------------
def build_cross_week_diff(curr_brief: dict, prev_brief: dict) -> dict:
    """Build complete diff block."""
    diff = {
        "baseline_iso_week": prev_brief.get("meta", {}).get("iso_week"),
        "current_iso_week": curr_brief.get("meta", {}).get("iso_week"),
        "operation_diff": [],
        "customers_diff": [],
        "summary_counts": {}
    }

    # Operation: match by title across operation items
    curr_ops = curr_brief.get("operation", []) or []
    prev_ops = prev_brief.get("operation", []) or []
    matched_prev_op_ids = set()

    for cop in curr_ops:
        match, score = _match_in_list(cop.get("title", ""), prev_ops, key="title", threshold=0.55)
        prev_tasks = match.get("tasks", []) if match else []
        if match:
            matched_prev_op_ids.add(id(match))
        td = diff_tasks(cop.get("tasks", []) or [], prev_tasks)
        diff["operation_diff"].append({
            "operation_title": cop.get("title"),
            "matched_prev_title": match.get("title") if match else None,
            "similarity": round(score, 2),
            "is_new_operation_item": match is None,
            "tasks_diff": td
        })

    # Operations in prev not matched in curr → entire item dropped
    for pop in prev_ops:
        if id(pop) in matched_prev_op_ids:
            continue
        diff["operation_diff"].append({
            "operation_title": pop.get("title"),
            "matched_prev_title": pop.get("title"),
            "similarity": 1.0,
            "is_new_operation_item": False,
            "is_entirely_dropped": True,
            "tasks_diff": {"dropped": [
                {"title": t.get("title"), "prev_status": t.get("status"),
                 "prev_pic": t.get("pic"), "prev_deadline": t.get("deadline")}
                for t in (pop.get("tasks", []) or [])
            ], "updated": [], "no_update": [], "new": []}
        })

    # Customers
    curr_cs = curr_brief.get("customers", []) or []
    prev_cs = prev_brief.get("customers", []) or []
    matched_prev_c_ids = set()

    for cc in curr_cs:
        match, score = _match_in_list(cc.get("name", ""), prev_cs, key="name", threshold=0.55)
        prev_tasks = match.get("tasks", []) if match else []
        if match:
            matched_prev_c_ids.add(id(match))
        td = diff_tasks(cc.get("tasks", []) or [], prev_tasks)
        diff["customers_diff"].append({
            "customer_name": cc.get("name"),
            "matched_prev_name": match.get("name") if match else None,
            "similarity": round(score, 2),
            "is_new_customer": match is None,
            "tasks_diff": td
        })

    for pc in prev_cs:
        if id(pc) in matched_prev_c_ids:
            continue
        diff["customers_diff"].append({
            "customer_name": pc.get("name"),
            "matched_prev_name": pc.get("name"),
            "similarity": 1.0,
            "is_new_customer": False,
            "is_entirely_dropped": True,
            "tasks_diff": {"dropped": [
                {"title": t.get("title"), "prev_status": t.get("status"),
                 "prev_pic": t.get("pic"), "prev_deadline": t.get("deadline")}
                for t in (pc.get("tasks", []) or [])
            ], "updated": [], "no_update": [], "new": []}
        })

    # Summary counts
    sc = {"op_updated_tasks": 0, "op_no_update_tasks": 0, "op_dropped_tasks": 0, "op_new_tasks": 0,
          "cust_updated_tasks": 0, "cust_no_update_tasks": 0, "cust_dropped_tasks": 0, "cust_new_tasks": 0,
          "dropped_op_items": 0, "dropped_customers": 0, "new_op_items": 0, "new_customers": 0}
    for od in diff["operation_diff"]:
        if od.get("is_entirely_dropped"): sc["dropped_op_items"] += 1
        if od.get("is_new_operation_item"): sc["new_op_items"] += 1
        sc["op_updated_tasks"] += len(od["tasks_diff"].get("updated", []))
        sc["op_no_update_tasks"] += len(od["tasks_diff"].get("no_update", []))
        sc["op_dropped_tasks"] += len(od["tasks_diff"].get("dropped", []))
        sc["op_new_tasks"] += len(od["tasks_diff"].get("new", []))
    for cd in diff["customers_diff"]:
        if cd.get("is_entirely_dropped"): sc["dropped_customers"] += 1
        if cd.get("is_new_customer"): sc["new_customers"] += 1
        sc["cust_updated_tasks"] += len(cd["tasks_diff"].get("updated", []))
        sc["cust_no_update_tasks"] += len(cd["tasks_diff"].get("no_update", []))
        sc["cust_dropped_tasks"] += len(cd["tasks_diff"].get("dropped", []))
        sc["cust_new_tasks"] += len(cd["tasks_diff"].get("new", []))
    diff["summary_counts"] = sc
    return diff


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    curr_brief = load_json(BRIEF_PATH)
    if not curr_brief:
        log(f"ERROR: current brief not found at {BRIEF_PATH}")
        sys.exit(2)
    window = load_json(WINDOW_PATH)
    iso_prev = window.get("iso_week_prev", "")
    if not iso_prev:
        log("ERROR: iso_week_prev missing in _window.json")
        sys.exit(2)

    # Download W-1 snapshot from Drive
    creds = load_credentials()
    drive = get_drive(creds)
    # Look in W-1 subfolder under Weekly Summary parent
    weekly_parent = get_weekly_folder_id(drive)
    prev_wf_name = week_folder_name(iso_prev)
    fname = snapshot_filename(iso_prev)
    log(f"Looking for previous-week snapshot: {prev_wf_name}/{fname}")
    prev_folder_id = find_folder(drive, prev_wf_name, weekly_parent) if weekly_parent else None
    fid = find_file(drive, fname, prev_folder_id) if prev_folder_id else None
    # Backward-compat: also look in legacy flat snapshots/ folder
    if not fid:
        legacy = get_snapshots_folder_id(drive)
        fid = find_file(drive, fname, legacy)
        if fid:
            log(f"  Found in legacy flat snapshots/ folder (will be migrated next snapshot run)")
    if not fid:
        log(f"  No W-1 snapshot found ({fname}). First v2 run — emitting empty cross_week_diff.")
        curr_brief["cross_week_diff"] = {
            "baseline_iso_week": iso_prev,
            "current_iso_week": window.get("iso_week"),
            "baseline_available": False,
            "note": f"Snapshot tuần trước ({fname}) chưa tồn tại — đây là lần đầu chạy format v2. Logic compare đã sẵn sàng cho tuần sau.",
            "operation_diff": [],
            "customers_diff": [],
            "summary_counts": {}
        }
        save_json(BRIEF_PATH, curr_brief)
        log(f"  Brief updated -> {BRIEF_PATH}")
        return

    # Download and parse
    log(f"  Found snapshot id={fid}, downloading...")
    content = download_text(drive, fid)
    try:
        prev_brief = json.loads(content)
    except Exception as e:
        log(f"  ERROR parsing W-1 snapshot: {e}")
        sys.exit(2)

    # Cache locally for debug
    PREV_BRIEF_PATH.write_text(content, encoding="utf-8")

    diff = build_cross_week_diff(curr_brief, prev_brief)
    diff["baseline_available"] = True
    curr_brief["cross_week_diff"] = diff
    save_json(BRIEF_PATH, curr_brief)
    log(f"  Cross-week diff written. Counts: {diff['summary_counts']}")


if __name__ == "__main__":
    main()
