#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""snapshot_memory.py — Lưu snapshot Meeting_Memory.md vào Drive `_snapshots/`
để tuần sau có baseline diff (Cách B).

Naming: Meeting_Memory_<ISO_WEEK>.md
Vị trí: Daily Meeting Prep / Weekly Summary / _snapshots /
"""
from __future__ import annotations
import sys
from pathlib import Path
from weekly_lib import (
    MEMORY_FILE_NAME, MEMORY_BASELINE_PATH, WINDOW_PATH,
    download_text, find_file, get_daily_prep_folder_id,
    get_drive, get_snapshots_folder_id,
    load_credentials, load_json, log,
    memory_snapshot_filename, upload_text,
)


def save_snapshot():
    """Save current Meeting_Memory.md as snapshot for current ISO week."""
    win = load_json(WINDOW_PATH)
    if not win:
        log("ERROR: window not computed")
        sys.exit(2)
    creds = load_credentials()
    drive = get_drive(creds)

    # Use baseline if already downloaded (avoid re-fetch)
    if MEMORY_BASELINE_PATH.exists():
        content = MEMORY_BASELINE_PATH.read_text(encoding="utf-8")
        log(f"Using cached baseline {MEMORY_BASELINE_PATH} ({len(content)} chars)")
    else:
        parent = get_daily_prep_folder_id(drive)
        mem_id = find_file(drive, MEMORY_FILE_NAME, parent)
        if not mem_id:
            log(f"ERROR: {MEMORY_FILE_NAME} not on Drive")
            sys.exit(3)
        content = download_text(drive, mem_id) or ""
        log(f"Downloaded current Memory ({len(content)} chars)")

    snap_folder = get_snapshots_folder_id(drive)
    snap_name = memory_snapshot_filename(win["iso_week"])

    # Check if snapshot already exists (re-run safe)
    existing = find_file(drive, snap_name, snap_folder)
    fid = upload_text(
        drive, snap_folder, snap_name, content,
        existing_id=existing, mimetype="text/markdown",
    )
    action = "updated" if existing else "created"
    log(f"Snapshot {action}: {snap_name} (id={fid})")
    print(fid)
    return fid


def load_prev_snapshot():
    """Load snapshot W-1 (or None). Print info, used for diff."""
    win = load_json(WINDOW_PATH)
    if not win:
        sys.exit(2)
    creds = load_credentials()
    drive = get_drive(creds)
    snap_folder = get_snapshots_folder_id(drive)
    prev_name = memory_snapshot_filename(win["iso_week_prev"])
    fid = find_file(drive, prev_name, snap_folder)
    if not fid:
        log(f"No snapshot W-1: {prev_name}")
        return None
    text = download_text(drive, fid) or ""
    log(f"Loaded W-1 snapshot {prev_name} ({len(text)} chars)")
    return text


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "save"
    if cmd == "save":
        save_snapshot()
    elif cmd == "load-prev":
        text = load_prev_snapshot()
        if text:
            print(text[:500])
    else:
        print("Usage: snapshot_memory.py [save|load-prev]", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
