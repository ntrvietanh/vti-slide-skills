#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""send_discord_weekly.py — Build + send Discord recap cho Weekly Summary.

Mỗi tuần 5 post (≤2000 char/post):
  Post 1 — Header + Exec Summary + Doc link
  Post 2 — By Client (top 5)
  Post 3 — Action Tracker Delta + Overdue top 3
  Post 4 — Next Week Focus
  Post 5 — Risk Register (optional, chỉ post nếu có RED items)

Webhook + User-Agent dùng từ meeting_lib.py (chung Meeting Prep webhook).
"""
from __future__ import annotations
import json, sys, time, urllib.request
from pathlib import Path
from weekly_lib import (
    BRIEF_PATH, DISCORD_POST_MAX_CHARS, DISCORD_POSTS_PATH,
    DISCORD_USER_AGENT, DISCORD_WEBHOOK,
    load_json, load_state, log, save_json,
)


def _trunc(s, n=120):
    s = str(s or "")
    return s if len(s) <= n else s[:n - 1] + "…"


def _safe_pct(num, den):
    if not den: return "0%"
    return f"{round(100 * num / den)}%"


def build_post_1_header(brief, doc_link=None):
    meta = brief.get("meta", {})
    counts = meta.get("counts", {})
    lines = [
        f"# 📊 WEEKLY SUMMARY — {meta.get('week_label','')}",
        f"_ISO {meta.get('iso_week','')} · Generated {meta.get('generated_at_local','')}_",
        "",
        f"**Stats:** {counts.get('meetings_total',0)} meetings · {counts.get('mail_threads_reviewed',0)} mails · {counts.get('chat_spaces_active',0)} chat spaces · {counts.get('actions_opened',0)} opened / {counts.get('actions_closed',0)} closed",
        "",
        "## 🌟 Top Highlights",
    ]
    for item in brief.get("executive_summary", [])[:5]:
        lines.append(f"• {_trunc(item, 250)}")
    if doc_link:
        lines.append("")
        lines.append(f"📄 **Full Doc:** {doc_link}")
    return "\n".join(lines)


def build_post_2_clients(brief):
    lines = ["## 🏢 By Client (top 5)"]
    risk_emoji = {"red": "🔴", "amber": "🟡", "green": "🟢"}
    for c in brief.get("by_client", [])[:5]:
        r = risk_emoji.get(c.get("risk_level", "").lower(), "⚪")
        lines.append("")
        lines.append(f"### {r} {c.get('name','?')} — {c.get('meetings_count',0)} mtgs · {c.get('mail_threads_count',0)} mails")
        sent = c.get("sentiment_shift", {})
        if sent.get("this_week"):
            lines.append(f"_Sentiment: {sent.get('this_week','-')} ({sent.get('vs_last_week','-')})_")
        if c.get("risk_reason"):
            lines.append(f"⚠️ {_trunc(c['risk_reason'], 200)}")
        if c.get("next_step"):
            lines.append(f"➡️ Next: {_trunc(c['next_step'], 200)}")
    return "\n".join(lines)


def build_post_3_tracker(brief):
    td = brief.get("action_tracker_delta", {})
    lines = [
        "## ✅ Action Tracker Delta",
        f"**Opened** this week: **{td.get('opened_this_week',0)}**  ·  "
        f"**Closed:** **{td.get('closed_this_week',0)}** "
        f"({_safe_pct(td.get('closed_this_week',0), td.get('opened_this_week',1))})",
        f"**Still open:** {td.get('still_open',0)}  ·  **Overdue:** ⚠️ {td.get('overdue_count',0)}",
    ]
    if td.get("overdue_items"):
        lines.append("")
        lines.append("**🔴 Overdue (top 3):**")
        for item in td["overdue_items"][:3]:
            lines.append(f"• [{item.get('pic','?')}] {_trunc(item.get('task',''), 100)} — due {item.get('deadline','?')}")
    if td.get("closed_items_top"):
        lines.append("")
        lines.append("**🟢 Closed (top 3):**")
        for item in td["closed_items_top"][:3]:
            lines.append(f"• [{item.get('pic','?')}] {_trunc(item.get('task',''), 100)}")
    return "\n".join(lines)


def build_post_4_next_week(brief):
    lines = ["## 🎯 Next Week Focus"]
    for item in brief.get("next_week_focus", [])[:6]:
        lines.append(f"• {_trunc(item, 250)}")
    md = brief.get("memory_diff", {})
    if md.get("changelog_this_week"):
        lines.append("")
        lines.append("**📝 Memory updates this week:**")
        for line in md["changelog_this_week"][:5]:
            lines.append(f"• {_trunc(line, 200)}")
    return "\n".join(lines)


def build_post_5_risks(brief):
    risks = brief.get("risk_register", [])
    red_risks = [r for r in risks if (r.get("severity", "").lower() == "red")]
    if not red_risks:
        return None
    lines = ["## 🚨 Risk Register (RED only)"]
    for r in red_risks:
        lines.append(
            f"• **{_trunc(r.get('item',''), 100)}** — owner: {r.get('owner','?')} · due: {r.get('deadline','?')}"
        )
    return "\n".join(lines)


def build():
    brief = load_json(BRIEF_PATH)
    if not brief:
        log("ERROR: weekly_brief.json missing")
        sys.exit(2)
    state = load_state()
    doc_link = state.get("last_docx_link")

    posts = []
    p1 = build_post_1_header(brief, doc_link=doc_link)
    posts.append({"label": "header", "content": p1})
    p2 = build_post_2_clients(brief)
    posts.append({"label": "by_client", "content": p2})
    p3 = build_post_3_tracker(brief)
    posts.append({"label": "tracker_delta", "content": p3})
    p4 = build_post_4_next_week(brief)
    posts.append({"label": "next_week", "content": p4})
    p5 = build_post_5_risks(brief)
    if p5:
        posts.append({"label": "risks_red", "content": p5})

    # Verify char limits
    issues = []
    for p in posts:
        if len(p["content"]) > DISCORD_POST_MAX_CHARS:
            issues.append(f'{p["label"]}: {len(p["content"])} > {DISCORD_POST_MAX_CHARS}')
    if issues:
        log(f"WARN: posts too long: {issues}")
        # Truncate
        for p in posts:
            if len(p["content"]) > DISCORD_POST_MAX_CHARS:
                p["content"] = p["content"][:DISCORD_POST_MAX_CHARS - 100] + "\n…[truncated]"

    save_json(DISCORD_POSTS_PATH, posts)
    log(f"Built {len(posts)} posts -> {DISCORD_POSTS_PATH}")
    return posts


def send():
    posts = load_json(DISCORD_POSTS_PATH)
    if not posts:
        log("ERROR: no posts built. Run `build` first.")
        sys.exit(2)
    ok = 0
    fail = 0
    for p in posts:
        body = json.dumps({"content": p["content"]}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            DISCORD_WEBHOOK, data=body, method="POST",
            headers={"Content-Type": "application/json", "User-Agent": DISCORD_USER_AGENT},
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                code = resp.getcode()
                if 200 <= code < 300:
                    log(f"  POST {p['label']} -> {code}")
                    ok += 1
                else:
                    log(f"  POST {p['label']} -> {code} (non-2xx)")
                    fail += 1
        except Exception as e:
            log(f"  POST {p['label']} FAIL: {e}")
            fail += 1
        time.sleep(1.0)  # rate limit safety
    log(f"Discord: {ok} ok, {fail} fail")
    return ok, fail


def dry_run():
    posts = build()
    print("=" * 60)
    for p in posts:
        print(f"\n--- POST: {p['label']} ({len(p['content'])} chars) ---")
        print(p["content"])
    print("=" * 60)
    log(f"Dry run: {len(posts)} posts ready")


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "build-and-send"
    if cmd == "build":
        build()
    elif cmd == "send":
        send()
    elif cmd == "dry-run":
        dry_run()
    elif cmd == "build-and-send":
        build()
        send()
    else:
        print("Usage: send_discord_weekly.py [build|send|dry-run|build-and-send]", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
