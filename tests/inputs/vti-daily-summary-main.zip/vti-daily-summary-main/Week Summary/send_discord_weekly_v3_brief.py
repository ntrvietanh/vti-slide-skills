#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""send_discord_weekly_v3_brief.py — BRIEF Discord version (~2-3 posts only).

Format: header + RED items + optional cross-week diff post.
Webhook RIENG cho Weekly Summary (KHONG dung chung Meeting Prep).
"""
from __future__ import annotations
import json, sys, time, urllib.request, urllib.error
from pathlib import Path
from weekly_lib import load_json, CONTEXT_DIR, OUTPUTS_DIR, log, load_state

DEFAULT_WEBHOOK = "https://discord.com/api/webhooks/1505405696987107408/fuBjjz0NGlBIQh9pPaQMSiwIoWBIkfv33pUg_qdbBzQdBA8gqm68N_1pgiDSlASrWDcY"
BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2.json"
POSTS_PATH = OUTPUTS_DIR / "discord_posts_v3.json"
MAX_LEN = 1900


def post(webhook, content, label=""):
    if not webhook:
        log(f"  [DRY] {label}: {len(content)} chars (no webhook configured)")
        return True
    data = json.dumps({"content": content[:1990]}).encode("utf-8")
    req = urllib.request.Request(webhook, data=data, headers={"Content-Type": "application/json", "User-Agent": "VTI-WeeklySummary/1.0 (compatible; python)"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            if r.status in (200, 204):
                log(f"  OK {label}: {len(content)} chars")
                return True
            log(f"  FAIL {label}: HTTP {r.status}")
            return False
    except urllib.error.HTTPError as e:
        log(f"  FAIL {label}: HTTP {e.code} {e.reason}")
        return False
    except Exception as e:
        log(f"  FAIL {label}: {e}")
        return False


def build_header_post(brief, doc_link=None):
    m = brief.get("meta", {})
    sc = brief.get("stats_compact", {})
    label = m.get("week_label", "?")
    iso = m.get("iso_week", "?")
    lines = [
        f"# Weekly Summary — {label} ({iso})",
        f"_Format: v2 deep-research (5 opus sub-agents)_",
        "",
        f"**Stats:** {sc.get('customers_total',0)} customers · {sc.get('operation_items',0)} ops · {sc.get('tasks_total',0)} tasks · **{sc.get('red_items',0)} RED**",
        f"**Sources:** {sc.get('mail_threads_analyzed',0)} mail threads · {sc.get('chat_spaces_active',0)} chat spaces ({sc.get('chat_messages_total',0)} msgs) · {sc.get('calendar_events_week',0)} cal events · {sc.get('tracker_open_actions',0)} tracker actions",
    ]
    if doc_link:
        lines.append("")
        lines.append(f"**[Full doc]({doc_link})**")
    return "\n".join(lines)


def build_red_post(brief):
    sc = brief.get("summary_categorized", {}) or brief.get("summary", {})
    red = sc.get("issues_blockers_red", []) if isinstance(sc, dict) else []
    if not red:
        return None
    lines = [f"## RED items ({len(red)})"]
    for r in red[:14]:
        lines.append(f"- {r[:180]}")
    return "\n".join(lines)


def build_cross_week_post(brief):
    cwd = brief.get("cross_week_diff")
    if not cwd:
        return None
    sc = cwd.get("summary_counts", {})
    lines = [
        f"## So với tuần trước (W-1 → W)",
        f"Op: updated {sc.get('op_updated_tasks',0)} · dropped {sc.get('op_dropped_tasks',0)} · new {sc.get('op_new_tasks',0)}",
        f"Cust: updated {sc.get('cust_updated_tasks',0)} · dropped {sc.get('cust_dropped_tasks',0)} · new {sc.get('cust_new_tasks',0)}",
    ]
    dropped = []
    for od in cwd.get("operation_diff", []):
        for d in od.get("tasks_diff", {}).get("dropped", []):
            if d:
                dropped.append(f"[Op] {(d.get('title','?') or '?')[:80]}")
    for cd in cwd.get("customers_diff", []):
        for d in cd.get("tasks_diff", {}).get("dropped", []):
            if d:
                cname = (cd.get('customer_name') or cd.get('customer') or '?')[:20]
                dropped.append(f"[Cust/{cname}] {(d.get('title','?') or '?')[:80]}")
    if dropped:
        lines.append("")
        lines.append(f"**Can verify (W-1 co, W silent):**")
        for d in dropped[:6]:
            lines.append(f"  - {d}")
        if len(dropped) > 6:
            lines.append(f"  ... va {len(dropped) - 6} item nua (xem doc).")
    return "\n".join(lines)


def build_all_posts(brief, doc_link=None):
    posts = []
    p1 = build_header_post(brief, doc_link)
    posts.append({"label": "header", "content": p1})
    p2 = build_red_post(brief)
    if p2:
        posts.append({"label": "red_items", "content": p2})
    p3 = build_cross_week_post(brief)
    if p3:
        posts.append({"label": "cross_week", "content": p3})
    return posts


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "build-and-send"
    brief = load_json(BRIEF_PATH)
    state = load_state()
    doc_link = state.get("last_docx_link")
    posts = build_all_posts(brief, doc_link=doc_link)
    POSTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    POSTS_PATH.write_text(json.dumps(posts, ensure_ascii=False, indent=1))
    log(f"Built {len(posts)} posts -> {POSTS_PATH}")
    for p in posts:
        log(f"  {p['label']}: {len(p['content'])} chars")
    if cmd == "dry-run":
        log("(dry-run mode, not sending)")
        return
    webhook = DEFAULT_WEBHOOK
    ok = fail = 0
    for p in posts:
        if post(webhook, p["content"], p["label"]):
            ok += 1
        else:
            fail += 1
        time.sleep(1.0)
    log(f"Discord v3-brief: {ok} ok, {fail} fail")


if __name__ == "__main__":
    main()
