#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""week_prelude.py — Dispatcher cho 4 deterministic crawler + window compute.

5 nguồn data tuần qua:
1. Window:        weekly_lib.py window         → week_context/_window.json
2. Daily Briefs:  crawl_briefs.py              → week_context/daily_briefs.json
3. Tracker:       crawl_tracker.py             → week_context/tracker_snapshot.json
4. Memory:        crawl_memory.py              → week_context/memory_*.{md,json}
5. Chat:          crawl_chat.py                → week_context/chat_signals.json

Mail (nguồn thứ 6) — KHÔNG xử lý ở đây. Claude reasoning trong SKILL.md gọi
Gmail MCP trực tiếp pagination + thread fetch, dump vào mail_threads.json.

Usage:
  python week_prelude.py window         # compute Mon-Sun window
  python week_prelude.py briefs         # crawl 7 daily Doc
  python week_prelude.py tracker        # download Action_Tracker.xlsx
  python week_prelude.py memory         # download Memory.md + snapshot W-1
  python week_prelude.py chat           # aggregate chat per space
  python week_prelude.py crawl-all      # window + briefs + tracker + memory + chat
"""

from __future__ import annotations

import sys
import time

from weekly_lib import _cli_window, log


def cmd_window():
    _cli_window()


def cmd_briefs():
    from crawl_briefs import crawl
    crawl()


def cmd_tracker():
    from crawl_tracker import crawl
    crawl()


def cmd_memory():
    from crawl_memory import crawl
    crawl()


def cmd_chat():
    from crawl_chat import crawl
    crawl()


def cmd_crawl_all():
    """Run window + all 4 crawlers in sequence. Total ~5-15 phút tuỳ data."""
    t0 = time.time()
    log("=" * 60)
    log("Bước 1: Compute window")
    cmd_window()

    log("=" * 60)
    log("Bước 2: Daily Briefs")
    try:
        cmd_briefs()
    except Exception as e:
        log(f"  briefs FAILED: {e}")

    log("=" * 60)
    log("Bước 3: Action Tracker")
    try:
        cmd_tracker()
    except Exception as e:
        log(f"  tracker FAILED: {e}")

    log("=" * 60)
    log("Bước 4: Memory + snapshot")
    try:
        cmd_memory()
    except Exception as e:
        log(f"  memory FAILED: {e}")

    log("=" * 60)
    log("Bước 5: Chat signals")
    try:
        cmd_chat()
    except Exception as e:
        log(f"  chat FAILED: {e}")

    elapsed = time.time() - t0
    log("=" * 60)
    log(f"crawl-all DONE in {elapsed:.1f}s")
    log("Next: Claude reasoning trong SKILL.md (mail MCP + compile weekly_brief.json)")


COMMANDS = {
    "window": cmd_window,
    "briefs": cmd_briefs,
    "tracker": cmd_tracker,
    "memory": cmd_memory,
    "chat": cmd_chat,
    "crawl-all": cmd_crawl_all,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__, file=sys.stderr)
        sys.exit(2)
    cmd = sys.argv[1]
    if cmd not in COMMANDS:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        print(__doc__, file=sys.stderr)
        sys.exit(2)
    COMMANDS[cmd]()


if __name__ == "__main__":
    main()
