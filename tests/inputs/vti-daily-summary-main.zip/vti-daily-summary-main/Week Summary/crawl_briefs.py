#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""crawl_briefs.py — Read Daily Recap + Prep Docs từ Drive cho window Mon-Sun.

Drive structure mới (per-day subfolder):
    Daily Meeting Prep/
    └── YYYY-MM-DD/
        ├── Recap — DD-MM-YYYY      (recap ngày đó)
        └── Prep — DD-MM-YYYY       (prep cho ngày kế)

Fallback structure cũ (root-level, _archived/):
    Daily Meeting Prep/_archived/
    └── Daily Recap & Prep — DD/MM/YYYY  (single Doc gộp)
"""
from __future__ import annotations
import io, json, sys
from datetime import date
from pathlib import Path
from weekly_lib import (
    CONTEXT_DIR, DAILY_BRIEFS_PATH, WINDOW_PATH,
    days_in_window, get_daily_prep_folder_id, get_drive,
    load_credentials, load_json, log, save_json,
)


def _find_day_subfolder(drive, parent_id, iso_date):
    safe = iso_date.replace("'", "\\'")
    q = (f"'{parent_id}' in parents and name = '{safe}' and "
         f"mimeType = 'application/vnd.google-apps.folder' and trashed = false")
    resp = drive.files().list(q=q, fields="files(id,name)", pageSize=2).execute()
    files = resp.get("files", [])
    return files[0]["id"] if files else None


def _list_recap_prep_docs(drive, folder_id):
    q = (f"'{folder_id}' in parents and trashed = false and ("
         f"mimeType = 'application/vnd.google-apps.document' or "
         f"mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'"
         f")")
    resp = drive.files().list(
        q=q,
        fields="files(id,name,mimeType,modifiedTime,webViewLink,size)",
        orderBy="modifiedTime desc", pageSize=20,
    ).execute()
    return resp.get("files", [])


def _classify_doc(name):
    n = name.lower().strip()
    if n.startswith("recap"):
        return "recap"
    if n.startswith("prep"):
        return "prep"
    if "recap" in n and "prep" in n:
        return "combined"
    return "other"


def _export_text(drive, doc):
    mime = doc["mimeType"]
    doc_id = doc["id"]
    if mime == "application/vnd.google-apps.document":
        text = drive.files().export(fileId=doc_id, mimeType="text/plain").execute()
        if isinstance(text, bytes):
            text = text.decode("utf-8", errors="replace")
        return text, len(text)
    if mime == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        from googleapiclient.http import MediaIoBaseDownload
        req = drive.files().get_media(fileId=doc_id)
        buf = io.BytesIO()
        dl = MediaIoBaseDownload(buf, req)
        done = False
        while not done:
            _, done = dl.next_chunk()
        buf.seek(0)
        size = buf.getbuffer().nbytes
        try:
            from docx import Document
            d = Document(buf)
            paras = [p.text for p in d.paragraphs]
            for tbl in d.tables:
                for row in tbl.rows:
                    paras.append(" | ".join(c.text for c in row.cells))
            return "\n".join(paras), size
        except Exception as e:
            return f"(.docx parse error: {e})", size
    return f"(unsupported mime: {mime})", 0


def _detect_sections(text):
    sections = []
    low = text.lower()
    if "hôm nay" in low or "recap" in low: sections.append("today_meetings")
    if "ngày mai" in low or "prep" in low: sections.append("tomorrow_meetings")
    if "action" in low or "phụ lục a" in low: sections.append("actions")
    if "gap" in low or "phụ lục b" in low: sections.append("gaps")
    return sections


def crawl():
    win = load_json(WINDOW_PATH)
    if not win:
        log("ERROR: window not computed. Run weekly_lib.py window first.")
        sys.exit(2)
    creds = load_credentials()
    drive = get_drive(creds)
    parent_id = get_daily_prep_folder_id(drive)
    days_iso = days_in_window(win)
    log(f"Crawling daily briefs for {len(days_iso)} days: {days_iso[0]} -> {days_iso[-1]}")

    days_data = []
    missing = []
    for d_iso in days_iso:
        log(f"  Day {d_iso}...")
        sfid = _find_day_subfolder(drive, parent_id, d_iso)
        if not sfid:
            log(f"    (no subfolder {d_iso})")
            missing.append(d_iso)
            days_data.append({"date": d_iso, "subfolder_found": False})
            continue
        docs = _list_recap_prep_docs(drive, sfid)
        if not docs:
            log(f"    (subfolder empty)")
            days_data.append({"date": d_iso, "subfolder_found": True, "subfolder_id": sfid, "docs": []})
            continue
        recap_doc = prep_doc = None
        for d in docs:
            k = _classify_doc(d["name"])
            if k == "recap" and not recap_doc: recap_doc = d
            elif k == "prep" and not prep_doc: prep_doc = d
            elif k == "combined" and not recap_doc: recap_doc = d
        entry = {"date": d_iso, "subfolder_found": True, "subfolder_id": sfid, "docs_count": len(docs)}
        if recap_doc:
            try:
                t, s = _export_text(drive, recap_doc)
                entry["recap"] = {
                    "doc_id": recap_doc["id"], "doc_name": recap_doc["name"],
                    "doc_link": recap_doc.get("webViewLink"),
                    "mime": recap_doc["mimeType"].split(".")[-1],
                    "modified_time": recap_doc.get("modifiedTime"),
                    "raw_text": t, "raw_text_size": len(t), "byte_size": s,
                    "sections_detected": _detect_sections(t),
                }
                log(f"    Recap: '{recap_doc['name']}' ({len(t)} chars)")
            except Exception as e:
                log(f"    Recap error: {e}")
                entry["recap"] = {"error": str(e), "doc_name": recap_doc["name"]}
        if prep_doc:
            try:
                t, s = _export_text(drive, prep_doc)
                entry["prep"] = {
                    "doc_id": prep_doc["id"], "doc_name": prep_doc["name"],
                    "doc_link": prep_doc.get("webViewLink"),
                    "mime": prep_doc["mimeType"].split(".")[-1],
                    "modified_time": prep_doc.get("modifiedTime"),
                    "raw_text": t, "raw_text_size": len(t), "byte_size": s,
                    "sections_detected": _detect_sections(t),
                }
                log(f"    Prep:  '{prep_doc['name']}' ({len(t)} chars)")
            except Exception as e:
                log(f"    Prep error: {e}")
                entry["prep"] = {"error": str(e), "doc_name": prep_doc["name"]}
        if not recap_doc and not prep_doc:
            missing.append(d_iso)
            entry["all_docs_names"] = [d["name"] for d in docs]
            log(f"    No Recap/Prep match: {entry['all_docs_names']}")
        days_data.append(entry)

    out = {
        "window": win, "days": days_data,
        "missing_dates": missing,
        "stats": {"total_days": 7, "found": 7 - len(missing), "missing": len(missing)},
    }
    save_json(DAILY_BRIEFS_PATH, out)
    log(f"Daily briefs -> {DAILY_BRIEFS_PATH} (found {out['stats']['found']}/7)")
    return out


if __name__ == "__main__":
    crawl()
