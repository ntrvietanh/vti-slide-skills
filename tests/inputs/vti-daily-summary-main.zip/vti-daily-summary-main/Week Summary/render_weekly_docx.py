#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_weekly_docx.py — Render weekly_brief.json thành .docx native.

Layout (theo schema v2 trong PLAN.md):
  - Cover title + window + counts
  - Executive Summary (top 5)
  - Stats Dashboard (mail/chat/meetings/tracker counts)
  - By Client (per client: meetings, decisions, actions, sentiment, risk)
  - By Meeting Type
  - Mail Intel (top threads, pending replies, new contacts)
  - Chat Intel (per space + trending + Michael persona samples)
  - Action Tracker Delta (opened/closed/overdue/carry)
  - Memory Diff (per section)
  - Next Week Focus
  - Risk Register
  - AI Log

Style: clean professional, Times New Roman 11, headings dark navy.

Output: outputs/weekly_doc.docx + upload Drive folder Daily Meeting Prep / Weekly Summary
"""
from __future__ import annotations
import io, json, sys
from datetime import date
from pathlib import Path

from weekly_lib import (
    BRIEF_PATH, DOCX_PATH, WINDOW_PATH,
    docx_filename, find_file, get_drive, get_weekly_folder_id,
    load_credentials, load_json, load_state, log, save_state,
)


# -------- python-docx builders --------------------------------------------
def _set_doc_style(doc):
    from docx.shared import Pt, RGBColor
    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(11)


def _add_h1(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_heading(text, level=1)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0x05, 0x19, 0x34)  # VTI navy
        r.font.size = Pt(16)
    return p


def _add_h2(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_heading(text, level=2)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0x05, 0x19, 0x34)
        r.font.size = Pt(13)
    return p


def _add_h3(doc, text):
    from docx.shared import Pt, RGBColor
    p = doc.add_heading(text, level=3)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0x05, 0x19, 0x34)
        r.font.size = Pt(11)
    return p


def _add_para(doc, text, bold=False, italic=False):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    r.italic = italic
    return p


def _add_bullet(doc, text):
    return doc.add_paragraph(text, style="List Bullet")


def _add_table_kv(doc, rows):
    """Add a 2-col table from list of (key, value)."""
    from docx.shared import Inches
    t = doc.add_table(rows=len(rows), cols=2)
    t.style = "Light Grid"
    for i, (k, v) in enumerate(rows):
        t.cell(i, 0).text = str(k)
        t.cell(i, 1).text = str(v)
        for r in t.cell(i, 0).paragraphs[0].runs:
            r.bold = True
    return t


def _add_table_data(doc, headers, rows):
    """Add a data table from headers + list of rows."""
    if not rows:
        _add_para(doc, "(empty)", italic=True)
        return
    t = doc.add_table(rows=len(rows) + 1, cols=len(headers))
    t.style = "Light Grid Accent 1"
    for i, h in enumerate(headers):
        c = t.cell(0, i)
        c.text = h
        for r in c.paragraphs[0].runs:
            r.bold = True
    for ri, row in enumerate(rows, start=1):
        for ci, h in enumerate(headers):
            val = row.get(h) if isinstance(row, dict) else (row[ci] if ci < len(row) else "")
            t.cell(ri, ci).text = str(val) if val is not None else ""
    return t


# -------- Section renderers ------------------------------------------------
def render_cover(doc, brief):
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    meta = brief.get("meta", {})
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("WEEKLY SUMMARY")
    r.bold = True
    r.font.size = Pt(28)
    r.font.color.rgb = RGBColor(0x05, 0x19, 0x34)

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run(meta.get("week_label", ""))
    r2.font.size = Pt(16)
    r2.italic = True

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r3 = p3.add_run(f"ISO {meta.get('iso_week','')} · Generated {meta.get('generated_at_local','')}")
    r3.font.size = Pt(10)

    counts = meta.get("counts", {})
    if counts:
        doc.add_paragraph()
        _add_table_kv(doc, [
            ("Meetings", counts.get("meetings_total", "?")),
            ("Mail threads reviewed", counts.get("mail_threads_reviewed", "?")),
            ("Chat spaces active", counts.get("chat_spaces_active", "?")),
            ("Actions opened", counts.get("actions_opened", "?")),
            ("Actions closed", counts.get("actions_closed", "?")),
        ])
    doc.add_page_break()


def render_executive_summary(doc, brief):
    _add_h1(doc, "1. Executive Summary")
    for item in brief.get("executive_summary", []):
        _add_bullet(doc, item)


def render_by_client(doc, brief):
    _add_h1(doc, "2. By Client")
    for client in brief.get("by_client", []):
        _add_h2(doc, client.get("name", "Unknown"))
        _add_table_kv(doc, [
            ("Meetings count", client.get("meetings_count", 0)),
            ("Mail threads", client.get("mail_threads_count", 0)),
            ("Open actions (carry)", client.get("carry_open_actions_count", 0)),
            ("Risk level", client.get("risk_level", "-").upper()),
            ("Risk reason", client.get("risk_reason", "-")),
            ("Sentiment shift", f"{client.get('sentiment_shift',{}).get('this_week','-')} ({client.get('sentiment_shift',{}).get('vs_last_week','-')})"),
            ("Next step", client.get("next_step", "-")),
        ])

        meetings = client.get("meetings_detail", [])
        if meetings:
            _add_h3(doc, "Meetings")
            for m in meetings:
                _add_para(doc, f"{m.get('date','')} - {m.get('title','')}", bold=True)
                attendees = ", ".join(m.get("attendees_external", []))
                if attendees:
                    _add_para(doc, f"External: {attendees}", italic=True)
                for s in m.get("summary_bullets", []):
                    _add_bullet(doc, s)
                if m.get("decisions"):
                    _add_para(doc, "Decisions:", bold=True)
                    for d in m["decisions"]:
                        _add_bullet(doc, d)

        if client.get("decisions_aggregate"):
            _add_h3(doc, "Key decisions (client-level)")
            for d in client["decisions_aggregate"]:
                _add_bullet(doc, d)

        if client.get("top_mail_threads"):
            _add_h3(doc, "Top mail threads")
            for t in client["top_mail_threads"]:
                line = f"[{t.get('priority','?').upper()}] {t.get('subject','')} - {t.get('status','')}"
                _add_para(doc, line, bold=True)
                if t.get("summary"):
                    _add_para(doc, t["summary"])

        if client.get("chat_signals"):
            _add_h3(doc, "Chat signals")
            for s in client["chat_signals"]:
                if isinstance(s, dict):
                    _add_bullet(doc, f"[{s.get('type','?')}] {s.get('summary','')} - space:{s.get('space','?')}/{s.get('date','?')}")
                else:
                    _add_bullet(doc, str(s))

        if client.get("actions_open"):
            _add_h3(doc, "Open actions")
            _add_table_data(doc, ["pic", "task", "deadline", "priority"], client["actions_open"])
        if client.get("actions_closed"):
            _add_h3(doc, "Closed this week")
            _add_table_data(doc, ["pic", "task", "deadline"], client["actions_closed"])


def render_by_meeting_type(doc, brief):
    types = brief.get("by_meeting_type", [])
    if not types: return
    _add_h1(doc, "3. By Meeting Type")
    for t in types:
        _add_h3(doc, f"{t.get('type','?')} ({t.get('count',0)})")
        for d in t.get("key_decisions", []):
            _add_bullet(doc, d)


def render_mail_intel(doc, brief):
    _add_h1(doc, "4. Mail Intelligence")
    mi = brief.get("mail_intel", {})
    _add_table_kv(doc, [
        ("Total threads in window", mi.get("total_threads_in_window", 0)),
        ("After smart filter", mi.get("filtered_after_smart_filter", 0)),
    ])
    by_client = mi.get("thread_volume_by_client", {})
    if by_client:
        _add_h3(doc, "Thread volume by client")
        rows = [(k, v) for k, v in by_client.items()]
        _add_table_data(doc, ["client", "count"],
                        [{"client": k, "count": v} for k, v in rows])

    if mi.get("top_threads_detail"):
        _add_h3(doc, "Top threads (detail)")
        for t in mi["top_threads_detail"]:
            _add_para(doc, f"[{t.get('priority','?').upper()}] {t.get('subject','')}", bold=True)
            _add_para(doc, f"From: {t.get('from','?')} | Client: {t.get('client','?')} | Status: {t.get('status','?')} | Waiting: {t.get('waiting_days',0)}d", italic=True)
            if t.get("summary"):
                _add_para(doc, t["summary"])

    if mi.get("pending_replies_michael"):
        _add_h3(doc, "Pending replies (Michael owes)")
        _add_table_data(doc, ["subject", "client", "waiting_days"], mi["pending_replies_michael"])
    if mi.get("pending_replies_external"):
        _add_h3(doc, "Pending replies (External owes)")
        _add_table_data(doc, ["subject", "who", "waiting_days"], mi["pending_replies_external"])
    if mi.get("new_external_contacts"):
        _add_h3(doc, "New external contacts")
        _add_table_data(doc, ["name", "company", "first_thread_subject"], mi["new_external_contacts"])


def render_chat_intel(doc, brief):
    _add_h1(doc, "5. Chat Intelligence")
    ci = brief.get("chat_intel", {})
    _add_table_kv(doc, [
        ("Active spaces", ci.get("spaces_active_count", 0)),
        ("Total messages", ci.get("messages_total_in_window", 0)),
    ])
    if ci.get("trending_topics_global"):
        _add_h3(doc, "Trending topics (global)")
        for t in ci["trending_topics_global"]:
            _add_bullet(doc, t)
    if ci.get("decisions_made_global"):
        _add_h3(doc, "Decisions made")
        for d in ci["decisions_made_global"]:
            _add_bullet(doc, d)
    if ci.get("urgent_unaddressed"):
        _add_h3(doc, "Urgent unaddressed")
        for u in ci["urgent_unaddressed"]:
            if isinstance(u, dict):
                _add_bullet(doc, f"[{u.get('space','?')}/{u.get('date','?')}] {u.get('summary','')}")
            else:
                _add_bullet(doc, str(u))
    if ci.get("by_space_detail"):
        _add_h3(doc, "By space (detail)")
        for s in ci["by_space_detail"]:
            _add_para(doc, f"{s.get('space_name','?')} ({s.get('msg_count',0)} msgs)", bold=True)
            if s.get("trending_topics"):
                _add_para(doc, f"Topics: {', '.join(s['trending_topics'])}")
            if s.get("michael_pending_replies"):
                _add_para(doc, "Michael's pending replies:", italic=True)
                for r in s["michael_pending_replies"]:
                    if isinstance(r, dict):
                        _add_bullet(doc, f"To {r.get('to','?')}: {r.get('topic','')}")
    if ci.get("michael_persona_language_samples"):
        _add_h3(doc, "Michael's voice samples (for persona tuning)")
        for sample in ci["michael_persona_language_samples"]:
            _add_para(doc, f'“{sample}”', italic=True)


def render_tracker_delta(doc, brief):
    _add_h1(doc, "6. Action Tracker Delta")
    td = brief.get("action_tracker_delta", {})
    _add_table_kv(doc, [
        ("Opened this week", td.get("opened_this_week", 0)),
        ("Closed this week", td.get("closed_this_week", 0)),
        ("Still open", td.get("still_open", 0)),
        ("Overdue count", td.get("overdue_count", 0)),
    ])
    if td.get("overdue_items"):
        _add_h3(doc, "Overdue (top 5)")
        _add_table_data(doc, ["pic", "task", "deadline", "priority"], td["overdue_items"])
    if td.get("closed_items_top"):
        _add_h3(doc, "Closed (top 5)")
        _add_table_data(doc, ["pic", "task", "deadline"], td["closed_items_top"])
    if td.get("carry_to_next_week"):
        _add_h3(doc, "Carry to next week (top 10)")
        _add_table_data(doc, ["pic", "task", "deadline", "priority"], td["carry_to_next_week"])


def render_memory_diff(doc, brief):
    _add_h1(doc, "7. Memory Diff")
    md = brief.get("memory_diff", {})
    if not md.get("baseline_available"):
        _add_para(doc, "(First run — no W-1 baseline. Snapshot saved for next week's diff.)", italic=True)
    _add_para(doc, f"Baseline ISO week: {md.get('baseline_iso_week','-')}", italic=True)
    for sec_name in ("clients", "meeting_types"):
        sec = md.get(sec_name, [])
        if not sec: continue
        _add_h3(doc, sec_name.replace("_", " ").title())
        for entry in sec:
            _add_para(doc, entry.get("name") or entry.get("type", "?"), bold=True)
            for a in entry.get("added", []):
                _add_bullet(doc, f"+ {a}")
            for m in entry.get("modified", []):
                if isinstance(m, dict):
                    _add_bullet(doc, f"~ {m.get('before','')} -> {m.get('after','')}")
                else:
                    _add_bullet(doc, f"~ {m}")
            for r in entry.get("removed", []):
                _add_bullet(doc, f"- {r}")
    if md.get("changelog_this_week"):
        _add_h3(doc, "Changelog this week")
        for line in md["changelog_this_week"]:
            _add_bullet(doc, line)
    if md.get("provenance_counts"):
        _add_h3(doc, "Provenance counts (sub-agent invocations)")
        rows = [{"agent": k, "count": v} for k, v in md["provenance_counts"].items()]
        _add_table_data(doc, ["agent", "count"], rows)


def render_next_week(doc, brief):
    _add_h1(doc, "8. Next Week Focus")
    for item in brief.get("next_week_focus", []):
        _add_bullet(doc, item)


def render_risk_register(doc, brief):
    risks = brief.get("risk_register", [])
    if not risks: return
    _add_h1(doc, "9. Risk Register")
    _add_table_data(doc, ["item", "severity", "owner", "deadline"], risks)


def render_ai_log(doc, brief):
    log_lines = brief.get("ai_log", [])
    if not log_lines: return
    _add_h1(doc, "10. AI Log")
    for line in log_lines:
        _add_bullet(doc, line)


# -------- Main render flow -------------------------------------------------
def render(brief_path: Path, out_path: Path):
    from docx import Document
    brief = load_json(brief_path)
    if not brief:
        log(f"ERROR: brief.json not found at {brief_path}")
        sys.exit(2)
    doc = Document()
    _set_doc_style(doc)
    render_cover(doc, brief)
    render_executive_summary(doc, brief)
    render_by_client(doc, brief)
    render_by_meeting_type(doc, brief)
    render_mail_intel(doc, brief)
    render_chat_intel(doc, brief)
    render_tracker_delta(doc, brief)
    render_memory_diff(doc, brief)
    render_next_week(doc, brief)
    render_risk_register(doc, brief)
    render_ai_log(doc, brief)
    doc.save(out_path)
    log(f"Rendered docx -> {out_path} ({out_path.stat().st_size} bytes)")
    return out_path


def upload_docx(out_path: Path):
    creds = load_credentials()
    drive = get_drive(creds)
    folder_id = get_weekly_folder_id(drive)
    win = load_json(WINDOW_PATH)
    # Determine version: check if file with v1 name exists
    state = load_state()
    last_run_window = state.get("last_run_window")
    version = 1
    if last_run_window == win["week_label"]:
        version = int(state.get("last_run_version", 1)) + 1
    name = docx_filename(win, version=version)

    from googleapiclient.http import MediaFileUpload
    media = MediaFileUpload(
        str(out_path),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        resumable=False,
    )
    body = {
        "name": name,
        "parents": [folder_id],
        "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }
    f = drive.files().create(body=body, media_body=media, fields="id,webViewLink").execute()
    log(f"Uploaded {name} -> id={f['id']}")
    state["last_run_window"] = win["week_label"]
    state["last_run_version"] = version
    state["last_docx_id"] = f["id"]
    state["last_docx_link"] = f.get("webViewLink")
    save_state(state)
    return {"file_id": f["id"], "name": name, "link": f.get("webViewLink")}


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "render-and-upload"
    if cmd == "render":
        render(BRIEF_PATH, DOCX_PATH)
    elif cmd == "upload":
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    elif cmd == "render-and-upload":
        render(BRIEF_PATH, DOCX_PATH)
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    else:
        print("Usage: render_weekly_docx.py [render|upload|render-and-upload]", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
