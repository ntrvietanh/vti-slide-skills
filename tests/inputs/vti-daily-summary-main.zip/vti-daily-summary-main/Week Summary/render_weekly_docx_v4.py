#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_weekly_docx_v4.py — VTI-brand styled docx renderer cho weekly_brief_v2.json.

VTI brand applied to native python-docx output (NOT html):
  - Navy header bar with logo + white title (filter inverted PNG)
  - Section H1 with navy bg, bright blue accent
  - Tables with blue header row (--blue #004AAD), light alternating rows
  - Priority pills: RED (#b02020), AMBER (#b05a00), GREEN (#1a7a4a) — text color only (docx no native pill)
  - Body: Calibri 10pt (Barlow not standard in MS Office); Headings: Calibri Light 18/14/11pt
  - Card-style sections: light blue panel via cell shading + 1px gray border
"""

from __future__ import annotations
import json, sys, base64
from pathlib import Path
from weekly_lib import (
    load_json, get_drive, load_credentials,
    load_state, save_state, log, ensure_folder,
    PROJECT_DIR, OUTPUTS_DIR, CONTEXT_DIR,
)

BRIEF_PATH = CONTEXT_DIR / "weekly_brief_v2.json"
DOCX_PATH = OUTPUTS_DIR / "weekly_doc_v4.docx"
WINDOW_PATH = CONTEXT_DIR / "_window.json"
LOGO_PATH = Path("/sessions/festive-quirky-lovelace/mnt/.claude/skills/vti-brief-doc/assets/logo-horizontal-white.png")


def week_folder_name(iso_week: str) -> str:
    if not iso_week: return "Wxx-yyyy"
    s = iso_week.strip()
    if "-W" in s:
        year, w = s.split("-W", 1)
        return f"W{w}-{year}"
    return s


def docx_filename(win, version=1):
    ws = win["week_start"][8:10] + "-" + win["week_start"][5:7]
    we = win["week_end"][8:10] + "-" + win["week_end"][5:7] + "-" + win["week_end"][0:4]
    base = f"Weekly Summary — {ws} → {we}"
    if version > 1:
        return f"{base} (v{version}).docx"
    return f"{base}.docx"


def get_weekly_folder_id(drive):
    state = load_state()
    fid = state.get("weekly_folder_id")
    if not fid:
        log("ERROR: weekly_folder_id missing in _state.json")
        sys.exit(2)
    return fid


# --- VTI Brand colors (RGB tuples) -----------------------------------------
NAVY    = (0x05, 0x19, 0x34)   # primary dark
BLUE    = (0x00, 0x4A, 0xAD)   # primary brand blue
BRIGHT  = (0x04, 0x68, 0xE6)   # active/bright
SKY     = (0x07, 0x82, 0xFF)   # gradient end
LIGHT   = (0xDA, 0xE9, 0xF6)   # light blue bg
AMBER   = (0xF8, 0xC3, 0x79)
AMBER_DK = (0x6B, 0x3D, 0x00)
MUTED   = (0x6B, 0x7A, 0x8D)
BG      = (0xF0, 0xF5, 0xFB)
BORDER  = (0xC8, 0xDC, 0xF0)
GREEN   = (0x1A, 0x7A, 0x4A)
GREEN_BG = (0xE6, 0xF4, 0xED)
RED     = (0xB0, 0x20, 0x20)
RED_BG  = (0xFF, 0xF0, 0xF0)
ORANGE  = (0xB0, 0x5A, 0x00)
ORANGE_BG = (0xFF, 0xF4, 0xE6)
WHITE   = (0xFF, 0xFF, 0xFF)

# Font names — Word fallback (Barlow not installed by default)
FONT_BODY = "Calibri"           # body
FONT_HEAD = "Calibri Light"     # headings (semi-bold weight available)


# --- xml helpers -----------------------------------------------------------
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

def _hex(rgb):
    return f"{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"

def _shade_cell(cell, rgb):
    """Apply background fill to a table cell."""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), _hex(rgb))
    tcPr.append(shd)

def _set_cell_border(cell, color=BORDER, sz="6"):
    """Set 1px border around a cell with given color (sz in eighths of pt)."""
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement('w:tcBorders')
    for edge in ('top', 'left', 'bottom', 'right'):
        b = OxmlElement(f'w:{edge}')
        b.set(qn('w:val'), 'single')
        b.set(qn('w:sz'), sz)
        b.set(qn('w:color'), _hex(color))
        tcBorders.append(b)
    tcPr.append(tcBorders)

def _remove_table_borders(table):
    from docx.oxml import OxmlElement
    tbl = table._tbl
    tblPr = tbl.tblPr
    tblBorders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        border = OxmlElement(f'w:{edge}')
        border.set(qn('w:val'), 'nil')
        tblBorders.append(border)
    tblPr.append(tblBorders)

def _set_table_border_all(table, color=BORDER, sz="6"):
    from docx.oxml import OxmlElement
    tbl = table._tbl
    tblPr = tbl.tblPr
    tblBorders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        border = OxmlElement(f'w:{edge}')
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), sz)
        border.set(qn('w:color'), _hex(color))
        tblBorders.append(border)
    tblPr.append(tblBorders)

def _set_page_margins(doc, top=2, right=2, bottom=2, left=2):
    """Set page margins in cm."""
    from docx.shared import Cm
    for section in doc.sections:
        section.top_margin = Cm(top)
        section.right_margin = Cm(right)
        section.bottom_margin = Cm(bottom)
        section.left_margin = Cm(left)

def _add_horizontal_rule(doc, color=BRIGHT, thickness_pt=2):
    """Insert a horizontal line via paragraph borders."""
    from docx.shared import Pt
    p = doc.add_paragraph()
    p_pr = p._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), str(int(thickness_pt * 8)))
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), _hex(color))
    pBdr.append(bottom)
    p_pr.append(pBdr)
    return p


# --- typography helpers ----------------------------------------------------
def _run(p, text, *, bold=False, italic=False, color=None, size=None, font=None):
    from docx.shared import Pt, RGBColor
    r = p.add_run(text)
    r.bold = bold
    r.italic = italic
    if color:
        r.font.color.rgb = RGBColor(*color)
    if size:
        r.font.size = Pt(size)
    if font:
        r.font.name = font
        # set asian font fallback
        rpr = r._element.get_or_add_rPr()
        rFonts = rpr.find(qn('w:rFonts'))
        if rFonts is None:
            rFonts = OxmlElement('w:rFonts')
            rpr.append(rFonts)
        rFonts.set(qn('w:eastAsia'), font)
    return r

def _para(doc, text, *, bold=False, italic=False, color=None, size=None, font=None,
          space_before=None, space_after=None, left_indent=None, alignment=None):
    from docx.shared import Pt, Cm, RGBColor
    p = doc.add_paragraph()
    if space_before is not None:
        p.paragraph_format.space_before = Pt(space_before)
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    if left_indent is not None:
        p.paragraph_format.left_indent = Cm(left_indent)
    if alignment is not None:
        p.alignment = alignment
    if text:
        _run(p, text, bold=bold, italic=italic, color=color, size=size, font=font)
    return p


# --- section: cover header (logo + title bar) -------------------------------
def render_cover_header(doc, brief):
    """Navy header: 2-col table (logo | title), no borders, full width, navy bg."""
    from docx.shared import Cm, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    meta = brief.get("meta", {})
    tbl = doc.add_table(rows=1, cols=2)
    tbl.autofit = False
    _remove_table_borders(tbl)
    # Compute usable width
    sec = doc.sections[0]
    usable = sec.page_width - sec.left_margin - sec.right_margin
    tbl.columns[0].width = Cm(3.5)
    tbl.columns[1].width = usable - Cm(3.5)
    row = tbl.rows[0]
    for cell in row.cells:
        _shade_cell(cell, NAVY)
        # remove cell padding
        tcPr = cell._tc.get_or_add_tcPr()
        tcMar = OxmlElement('w:tcMar')
        for edge, val in [('top','120'), ('left','120'), ('bottom','120'), ('right','120')]:
            m = OxmlElement(f'w:{edge}')
            m.set(qn('w:w'), val)
            m.set(qn('w:type'), 'dxa')
            tcMar.append(m)
        tcPr.append(tcMar)

    # Cell 0 = logo
    if LOGO_PATH.exists():
        p = row.cells[0].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run = p.add_run()
        try:
            run.add_picture(str(LOGO_PATH), width=Cm(3.0))
        except Exception as e:
            log(f"  (logo embed failed: {e})")
            _run(p, "VTI", bold=True, color=WHITE, size=18, font=FONT_HEAD)
    else:
        p = row.cells[0].paragraphs[0]
        _run(p, "VTI", bold=True, color=WHITE, size=18, font=FONT_HEAD)

    # Cell 1 = title + meta
    p_title = row.cells[1].paragraphs[0]
    p_title.paragraph_format.space_after = Pt(0)
    _run(p_title, "VTI APAC", bold=True, color=AMBER, size=11, font=FONT_HEAD)
    _run(p_title, "   ·   ", color=WHITE, size=11)
    _run(p_title, "WEEKLY SUMMARY", bold=True, color=WHITE, size=14, font=FONT_HEAD)

    p_meta = row.cells[1].add_paragraph()
    p_meta.paragraph_format.space_before = Pt(2)
    _run(p_meta, f"{meta.get('week_label', '')}  ·  ISO {meta.get('iso_week', '')}  ·  Run {meta.get('run_date', '')}",
         italic=True, color=LIGHT, size=10, font=FONT_BODY)

    # Bright blue accent line under header (mimics 3px border-bottom)
    _add_horizontal_rule(doc, color=BRIGHT, thickness_pt=2.5)


def render_section_label(doc, label):
    """Uppercase, letter-spaced section label in bright blue."""
    from docx.shared import Pt
    p = _para(doc, "", space_before=14, space_after=2)
    _run(p, label.upper(), bold=True, color=BRIGHT, size=10, font=FONT_HEAD)


def render_h2(doc, text, color=NAVY):
    """Card heading."""
    from docx.shared import Pt
    p = _para(doc, "", space_before=8, space_after=2)
    _run(p, text.upper(), bold=True, color=color, size=12, font=FONT_HEAD)


def render_h3(doc, text):
    from docx.shared import Pt
    p = _para(doc, "", space_before=4, space_after=1)
    _run(p, text, bold=True, color=MUTED, size=10, font=FONT_HEAD)


# --- priority helpers ------------------------------------------------------
def priority_color(p):
    p = (p or "").upper()
    return {"RED": RED, "AMBER": ORANGE, "GREEN": GREEN}.get(p)

def priority_bg(p):
    p = (p or "").upper()
    return {"RED": RED_BG, "AMBER": ORANGE_BG, "GREEN": GREEN_BG}.get(p, LIGHT)


# --- task card render ------------------------------------------------------
def render_task_card(doc, task):
    """Render task as a small bordered table with priority badge column."""
    from docx.shared import Cm, Pt
    pri = (task.get("priority") or "").upper()
    pri_color = priority_color(pri) or MUTED
    pri_bg = priority_bg(pri)

    # 1-row 2-col table: priority pill cell | content cell
    tbl = doc.add_table(rows=1, cols=2)
    tbl.autofit = False
    _set_table_border_all(tbl, color=BORDER, sz="4")
    # widths
    sec = doc.sections[0]
    usable = sec.page_width - sec.left_margin - sec.right_margin - Cm(0.4)
    tbl.columns[0].width = Cm(2.2)
    tbl.columns[1].width = usable - Cm(2.2)
    row = tbl.rows[0]
    # priority cell
    pc = row.cells[0]
    _shade_cell(pc, pri_bg)
    pp = pc.paragraphs[0]
    pp.paragraph_format.space_after = Pt(0)
    if pri:
        _run(pp, pri, bold=True, color=pri_color, size=9, font=FONT_HEAD)
    else:
        _run(pp, "—", color=MUTED, size=9, font=FONT_HEAD)

    # content cell
    cc = row.cells[1]
    p_title = cc.paragraphs[0]
    p_title.paragraph_format.space_after = Pt(1)
    _run(p_title, task.get("title", "Untitled task"), bold=True, color=NAVY, size=10, font=FONT_BODY)

    # Field-list rows (Status / PIC / Việc sẽ làm / Deadline)
    fields = []
    if task.get("status"): fields.append(("Status", task["status"]))
    if task.get("pic"): fields.append(("PIC", task["pic"]))
    if task.get("next_action"): fields.append(("Việc sẽ làm", task["next_action"]))
    if task.get("deadline"): fields.append(("Deadline", task["deadline"]))
    for lbl, val in fields:
        pf = cc.add_paragraph()
        pf.paragraph_format.space_after = Pt(0)
        pf.paragraph_format.space_before = Pt(0)
        _run(pf, f"{lbl}: ", bold=True, color=MUTED, size=9, font=FONT_BODY)
        _run(pf, val, color=NAVY, size=9, font=FONT_BODY)

    # 4pt spacer paragraph after the task
    sp = doc.add_paragraph()
    sp.paragraph_format.space_after = Pt(0)
    sp.paragraph_format.space_before = Pt(2)


# --- sections --------------------------------------------------------------
def render_summary(doc, brief):
    render_section_label(doc, "Summary")
    items = brief.get("summary", [])
    for i, s in enumerate(items, 1):
        p = _para(doc, "", space_before=2, space_after=2, left_indent=0.3)
        _run(p, f"{i}.  ", bold=True, color=BRIGHT, size=10, font=FONT_HEAD)
        _run(p, s, color=NAVY, size=10, font=FONT_BODY)


def render_operation(doc, brief):
    render_section_label(doc, "Operation (vận hành nội bộ)")
    items = brief.get("operation", []) or []
    if not items:
        _para(doc, "(không có item)", italic=True, color=MUTED, size=10)
        return
    for it in items:
        render_h2(doc, "▸ " + it.get("title", "?"), color=NAVY)
        if it.get("context"):
            _para(doc, it["context"], italic=True, color=MUTED, size=9.5,
                  left_indent=0.3, space_before=1, space_after=4)
        for t in it.get("tasks", []):
            render_task_card(doc, t)


def render_customers(doc, brief):
    render_section_label(doc, "Khách hàng / Opportunity")
    items = brief.get("customers", []) or []
    if not items:
        _para(doc, "(không có opp)", italic=True, color=MUTED, size=10)
        return
    for c in items:
        render_h2(doc, "▸ " + c.get("name", "?"), color=NAVY)
        if c.get("weekly_activity"):
            render_h3(doc, "Đã làm / trao đổi trong tuần")
            _para(doc, c["weekly_activity"], color=NAVY, size=10,
                  left_indent=0.3, space_before=0, space_after=4)
        if c.get("current_problem"):
            render_h3(doc, "Vấn đề hiện tại / Giải pháp")
            _para(doc, c["current_problem"], color=NAVY, size=10,
                  left_indent=0.3, space_before=0, space_after=4)
        tasks = c.get("tasks", [])
        if tasks:
            render_h3(doc, "Tasks")
            for t in tasks:
                render_task_card(doc, t)
        else:
            _para(doc, "(không có task tuần này)", italic=True, color=MUTED,
                  size=9.5, left_indent=0.3, space_after=4)


def render_cross_week_diff(doc, brief):
    cwd = brief.get("cross_week_diff")
    if not cwd:
        return
    render_section_label(doc, "So với tuần trước (W-1 baseline)")
    if not cwd.get("baseline_available"):
        _para(doc, cwd.get("note", "(baseline tuần trước chưa có)"),
              italic=True, color=MUTED, size=10, left_indent=0.3)
        return

    sc = cwd.get("summary_counts", {})
    p = _para(doc, "", left_indent=0.3, space_after=4)
    _run(p, f"Baseline: {cwd.get('baseline_iso_week','?')} → Current: {cwd.get('current_iso_week','?')}",
         italic=True, color=MUTED, size=10)
    p = _para(doc, "", left_indent=0.3, space_after=8)
    _run(p, "Operation — ", bold=True, color=BLUE, size=10)
    _run(p, f"updated {sc.get('op_updated_tasks',0)} · no-update {sc.get('op_no_update_tasks',0)} · dropped {sc.get('op_dropped_tasks',0)} · new {sc.get('op_new_tasks',0)}",
         color=NAVY, size=10)
    p = _para(doc, "", left_indent=0.3, space_after=8)
    _run(p, "Customer — ", bold=True, color=BLUE, size=10)
    _run(p, f"updated {sc.get('cust_updated_tasks',0)} · no-update {sc.get('cust_no_update_tasks',0)} · dropped {sc.get('cust_dropped_tasks',0)} · new {sc.get('cust_new_tasks',0)}",
         color=NAVY, size=10)

    # render diff details (omitted in W19 since baseline missing — will render in W20+)
    for od in cwd.get("operation_diff", []):
        render_h3(doc, od.get("operation_title", "?"))
        # ... (same as v3) — keep simple for now
    for cd in cwd.get("customers_diff", []):
        render_h3(doc, cd.get("customer_name", "?"))


def render_appendix(doc, brief):
    deferred = brief.get("deferred_or_noisy", [])
    stats = brief.get("stats_compact", {})
    if deferred:
        render_section_label(doc, "Phụ lục — Deferred / Noisy items")
        for d in deferred:
            p = _para(doc, "", space_before=1, space_after=1, left_indent=0.5)
            _run(p, "• ", color=BRIGHT, size=10)
            _run(p, d, color=MUTED, size=9.5, font=FONT_BODY)
    if stats:
        render_section_label(doc, "Stats compact")
        for k, v in stats.items():
            p = _para(doc, "", space_before=1, space_after=1, left_indent=0.5)
            _run(p, f"{k}: ", bold=True, color=BLUE, size=9, font=FONT_BODY)
            _run(p, str(v), color=NAVY, size=9, font=FONT_BODY)


def _set_doc_style(doc):
    from docx.shared import Pt
    style = doc.styles['Normal']
    style.font.name = FONT_BODY
    style.font.size = Pt(10)
    rpr = style.element.get_or_add_rPr()
    rFonts = rpr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rpr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), FONT_BODY)


def render(brief_path: Path, out_path: Path):
    from docx import Document
    brief = load_json(brief_path)
    if not brief:
        log(f"ERROR: brief not found at {brief_path}")
        sys.exit(2)
    doc = Document()
    _set_doc_style(doc)
    _set_page_margins(doc, top=1.2, right=1.5, bottom=1.5, left=1.5)
    render_cover_header(doc, brief)
    render_summary(doc, brief)
    render_operation(doc, brief)
    render_customers(doc, brief)
    render_cross_week_diff(doc, brief)
    render_appendix(doc, brief)
    doc.save(out_path)
    log(f"Rendered docx v4 (VTI brand) -> {out_path} ({out_path.stat().st_size} bytes)")
    return out_path


def upload_docx(out_path: Path):
    from googleapiclient.http import MediaFileUpload
    creds = load_credentials()
    drive = get_drive(creds)
    parent_folder_id = get_weekly_folder_id(drive)
    win = load_json(WINDOW_PATH)
    wf_name = week_folder_name(win.get("iso_week", ""))
    folder_id = ensure_folder(drive, wf_name, parent_folder_id)
    log(f"Target folder: {wf_name} (id={folder_id})")
    state = load_state()
    last_run_window = state.get("last_run_window")
    version = 1
    if last_run_window == win["week_label"]:
        version = int(state.get("last_run_version", 1)) + 1
    name = docx_filename(win, version=version)
    media = MediaFileUpload(
        str(out_path),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        resumable=False,
    )
    body = {
        "name": name,
        "parents": [folder_id],
        "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }
    f = drive.files().create(body=body, media_body=media, fields="id,webViewLink").execute()
    log(f"Uploaded {name} -> id={f['id']}")
    state["last_run_window"] = win["week_label"]
    state["last_run_version"] = version
    state["last_docx_id"] = f["id"]
    state["last_docx_link"] = f.get("webViewLink")
    save_state(state)
    return {"file_id": f["id"], "name": name, "link": f.get("webViewLink")}


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "render-and-upload"
    if cmd == "render":
        render(BRIEF_PATH, DOCX_PATH)
    elif cmd == "upload":
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    elif cmd == "render-and-upload":
        render(BRIEF_PATH, DOCX_PATH)
        result = upload_docx(DOCX_PATH)
        print(json.dumps(result, ensure_ascii=False))
    else:
        print("Usage: render_weekly_docx_v4.py [render|upload|render-and-upload]", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
