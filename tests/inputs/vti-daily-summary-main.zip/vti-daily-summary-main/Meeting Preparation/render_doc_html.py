#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_doc_html.py — brief.json → Doc HTML VTI brand (DETERMINISTIC).

Mục đích: tách hoàn toàn việc build HTML khỏi reasoning của Claude.
Mỗi lần Claude pass cùng 1 brief.json → output HTML bytes-identical.
Brand tokens, layout structure, color rules — tất cả định nghĩa trong file
này, KHÔNG nằm trong prompt.

Subcommands:
  render            — đọc meeting_context/brief.json → outputs/doc_daily.html
  upload            — upload HTML đã render lên Drive (tạo Google Doc mới)
  render-and-upload — render + upload, in ra fileId + webViewLink

Brief schema (xem `brief_schema_example()` cuối file).
"""

from __future__ import annotations

import argparse
import html as html_lib
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from meeting_lib import (
    BRIEF_PATH,
    DOC_HTML_PATH,
    DRIVE_FOLDER_NAME,
    LOCAL_TZ,
    ensure_folder,
    get_drive,
    load_credentials,
    load_json,
    load_state,
    log,
    save_state,
    upload_html_as_gdoc,
)

# ---------------------------------------------------------------------------
# VTI brand tokens (BƯỚC 5.5 từ SKILL v7)
# ---------------------------------------------------------------------------

C = {
    "navy":       "#051934",
    "blue":       "#004AAD",
    "bright":     "#0468E6",
    "light":      "#DAE9F6",
    "amber":      "#F8C379",
    "amber_bg":   "#FFF8E6",
    "amber_dk":   "#6B3D00",
    "green":      "#1A7A4A",
    "green_bg":   "#E6F4ED",
    "red":        "#B02020",
    "red_bg":     "#FFF0F0",
    "text":       "#1F2937",
    "text_lt":    "#4B5563",
    "muted":      "#6B7A8D",
    "border":     "#E5E9EE",
    "chat":       "#6B46C1",   # chat-purple
    "chat_bg":    "#F3EEFC",
    "chat_border":"#D8C7F0",
    "white":      "#FFFFFF",
    "bg_lt":      "#F8FAFC",
}

RISK_DOT = {
    "red":   f'<span style="color:{C["red"]};font-weight:bold">●</span>',
    "amber": f'<span style="color:{C["amber_dk"]};font-weight:bold">●</span>',
    "green": f'<span style="color:{C["green"]};font-weight:bold">●</span>',
}

WEEKDAYS_VI = ["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ Nhật"]

# ---------------------------------------------------------------------------
# HTML escape + builders
# ---------------------------------------------------------------------------


def esc(s: Any) -> str:
    if s is None:
        return ""
    return html_lib.escape(str(s), quote=True)


def section_bar(title: str, bg: str = None, fg: str = None) -> str:
    bg = bg or C["navy"]
    fg = fg or C["white"]
    return (
        f'<div style="background:{bg};color:{fg};padding:10px 16px;'
        f'margin:24px 0 12px;font-family:Arial,sans-serif;font-size:16px;'
        f'font-weight:bold;letter-spacing:0.5px;border-radius:2px;">{esc(title)}</div>'
    )


def callout(body_html: str, bg: str, border: str, fg: str = None) -> str:
    fg = fg or C["text"]
    return (
        f'<div style="background:{bg};border-left:4px solid {border};'
        f'color:{fg};padding:10px 14px;margin:8px 0;font-family:Arial,sans-serif;'
        f'font-size:13px;line-height:1.55;">{body_html}</div>'
    )


def chip(text: str, bg: str, fg: str = None) -> str:
    fg = fg or C["white"]
    return (
        f'<span style="display:inline-block;background:{bg};color:{fg};'
        f'padding:2px 8px;margin:0 4px 4px 0;font-family:Arial,sans-serif;'
        f'font-size:11px;font-weight:bold;border-radius:3px;">{esc(text)}</span>'
    )


def sub_label(text: str, color: str = None) -> str:
    color = color or C["bright"]
    return (
        f'<div style="font-family:Arial,sans-serif;font-size:12px;font-weight:bold;'
        f'color:{color};letter-spacing:0.5px;margin:12px 0 6px;text-transform:uppercase;">'
        f'{esc(text)}</div>'
    )


def para(text: str, color: str = None, italic: bool = False, size: int = 13) -> str:
    color = color or C["text"]
    style = (
        f'font-family:Arial,sans-serif;font-size:{size}px;line-height:1.55;'
        f'color:{color};margin:6px 0;'
    )
    if italic:
        style += "font-style:italic;"
    return f'<div style="{style}">{text}</div>'


def bullet_table(items: list[str], color: str = None, italic: bool = False) -> str:
    """Render bullets as a borderless table (Drive strips <ul> formatting)."""
    if not items:
        return ""
    color = color or C["text"]
    rows = []
    for it in items:
        i_style = "font-style:italic;" if italic else ""
        rows.append(
            f'<tr><td style="vertical-align:top;padding:2px 8px 2px 0;'
            f'font-family:Arial;font-size:13px;color:{color}">•</td>'
            f'<td style="padding:2px 0;font-family:Arial;font-size:13px;'
            f'color:{color};{i_style}">{it}</td></tr>'
        )
    return (
        '<table cellspacing="0" cellpadding="0" '
        'style="border-collapse:collapse;margin:4px 0;">'
        + "".join(rows)
        + "</table>"
    )


# ---------------------------------------------------------------------------
# Specific block builders
# ---------------------------------------------------------------------------


def cover_html(brief: dict) -> str:
    meta = brief["meta"]
    date_obj = datetime.fromisoformat(meta["date"])  # "YYYY-MM-DD"
    weekday = WEEKDAYS_VI[date_obj.weekday()]
    big_date = date_obj.strftime("%d/%m/%Y")
    gen = meta.get("generated_at_local", "")
    version = meta.get("version", 1)
    today = meta.get("counts", {}).get("today_meetings", 0)
    tomorrow = meta.get("counts", {}).get("tomorrow_meetings", 0)
    red_actions = meta.get("counts", {}).get("red_actions", 0)
    chat_spaces = meta.get("counts", {}).get("chat_spaces_active", 0)

    grid = (
        '<table cellspacing="0" cellpadding="0" '
        'style="border-collapse:collapse;width:100%;margin-top:16px;">'
        '<tr>'
        + _cell_summary("Meetings hôm nay", str(today), C["blue"])
        + _cell_summary("Meetings ngày mai", str(tomorrow), C["bright"])
        + _cell_summary("RED actions Michael", str(red_actions), C["red"])
        + _cell_summary("Chat spaces 24h", str(chat_spaces), C["chat"])
        + '</tr></table>'
    )
    return (
        f'<div style="background:{C["navy"]};color:{C["white"]};padding:24px 20px;">'
        f'<div style="font-family:Arial;font-size:13px;letter-spacing:1px;'
        f'text-transform:uppercase;color:{C["light"]};">VTI APAC · Daily Recap & Prep</div>'
        f'<div style="font-family:Arial;font-size:18px;margin-top:6px;color:{C["light"]};">'
        f'{esc(weekday)}</div>'
        f'<div style="font-family:Arial;font-size:48px;font-weight:bold;margin-top:4px;">'
        f'{esc(big_date)}</div>'
        f'<div style="font-family:Arial;font-size:12px;margin-top:12px;color:{C["light"]};'
        f'font-style:italic;">Generated {esc(gen)} · Owner: Michael · Version v{esc(version)}</div>'
        f'{grid}'
        f'</div>'
    )


def _cell_summary(label: str, value: str, fg: str) -> str:
    return (
        f'<td style="background:{C["white"]};color:{C["text"]};padding:12px;'
        f'text-align:center;border:1px solid {C["border"]};width:25%;">'
        f'<div style="font-family:Arial;font-size:11px;color:{C["muted"]};'
        f'text-transform:uppercase;letter-spacing:0.5px;">{esc(label)}</div>'
        f'<div style="font-family:Arial;font-size:24px;font-weight:bold;color:{fg};'
        f'margin-top:4px;">{esc(value)}</div></td>'
    )


def attendee_chip_row(attendees: list[dict]) -> str:
    if not attendees:
        return ""
    chips = []
    for a in attendees:
        is_internal = a.get("internal", False)
        bg = C["green"] if is_internal else C["blue"]
        role = a.get("role", "")
        company = a.get("company", "")
        if role or company:
            label = f"{a.get('name','?')} — {role}@{company}".strip(" —@")
        else:
            label = a.get("name", "?")
        chips.append(chip(label, bg))
    return f'<div style="margin:6px 0;">{"".join(chips)}</div>'


def persona_card(personas: list[dict]) -> str:
    if not personas:
        return ""
    cells = []
    for p in personas:
        rows = []
        fields = [
            ("Role", p.get("role")),
            ("Personality", p.get("personality")),
            ("Areas of interest", p.get("areas_of_interest")),
            ("Detail level", p.get("detail_level")),
            ("Communication style", p.get("communication_style")),
            ("Decision authority", p.get("decision_authority")),
            ("Sensitivity topics", p.get("sensitivity_topics")),
            ("Best-practice approach", p.get("best_practice_approach")),
            ("Pending owes", p.get("pending_owes")),
        ]
        for k, v in fields:
            rows.append(
                f'<tr><td style="vertical-align:top;padding:2px 12px 2px 0;'
                f'font-family:Arial;font-size:11px;color:{C["muted"]};'
                f'white-space:nowrap;font-weight:bold;text-transform:uppercase;'
                f'letter-spacing:0.3px;">{esc(k)}</td>'
                f'<td style="padding:2px 0;font-family:Arial;font-size:12px;'
                f'color:{C["text"]};line-height:1.5;">{esc(v) or "—"}</td></tr>'
            )
        cells.append(
            f'<div style="border:1px solid {C["border"]};background:{C["bg_lt"]};'
            f'padding:10px 12px;margin:6px 0;border-radius:2px;">'
            f'<div style="font-family:Arial;font-size:13px;font-weight:bold;'
            f'color:{C["navy"]};margin-bottom:6px;">{esc(p.get("name","?"))}'
            f' <span style="color:{C["muted"]};font-weight:normal;font-size:11px;">'
            f'· {esc(p.get("company",""))}</span></div>'
            f'<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;">'
            f'{"".join(rows)}</table></div>'
        )
    return "".join(cells)


def action_table(actions: list[dict]) -> str:
    """Phụ lục A — ACTION_TABLE. PIC | Việc | Output | Deadline | Meeting | Trạng thái."""
    if not actions:
        return para("Không có action mới.", italic=True, color=C["muted"])
    header_bg = C["navy"]
    cols = ["#", "PIC", "Việc cụ thể", "Output expect", "Deadline", "Từ meeting", "Trạng thái"]
    head = (
        '<tr>' + "".join(
            f'<th style="background:{header_bg};color:{C["white"]};'
            f'font-family:Arial;font-size:11px;text-align:left;padding:8px 10px;'
            f'border:1px solid {header_bg};text-transform:uppercase;letter-spacing:0.5px;">'
            f'{esc(c)}</th>'
            for c in cols
        ) + '</tr>'
    )
    rows = []
    for i, a in enumerate(actions, 1):
        prio = (a.get("priority") or "green").lower()
        dot_color = {"red": C["red"], "amber": C["amber_dk"], "green": C["green"]}.get(
            prio, C["green"]
        )
        status = a.get("status", "Open")
        rows.append(
            "<tr>"
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["muted"]};">{i}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["text"]};">'
            f'<span style="color:{dot_color};font-weight:bold;">●</span> {esc(a.get("pic","?"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["text"]};">{esc(a.get("task","?"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["text"]};">{esc(a.get("output","—"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["text"]};white-space:nowrap;">{esc(a.get("deadline","—"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:11px;color:{C["text_lt"]};">{esc(a.get("from_meeting","—"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:11px;color:{C["text_lt"]};">{esc(status)}</td>'
            "</tr>"
        )
    return (
        '<table cellspacing="0" cellpadding="0" '
        'style="border-collapse:collapse;width:100%;margin:8px 0;">'
        + head + "".join(rows) + "</table>"
    )


def meeting_recap_block(m: dict) -> str:
    """PHẦN 1 — meeting hôm nay."""
    time_chip = chip(m.get("time", "—"), C["blue"])
    title = m.get("title", "?")
    parts = [
        f'<div style="margin-top:18px;">'
        f'<div style="font-family:Arial;font-size:14px;font-weight:bold;color:{C["navy"]};">'
        f'{time_chip} {esc(title)}</div>'
    ]
    parts.append(attendee_chip_row(m.get("attendees", [])))

    if m.get("summary"):
        parts.append(sub_label("Tóm tắt"))
        parts.append(bullet_table([esc(s) for s in m["summary"]]))

    if m.get("decisions"):
        parts.append(sub_label("Quyết định chốt", color=C["amber_dk"]))
        body = bullet_table([esc(d) for d in m["decisions"]], color=C["amber_dk"])
        parts.append(callout(body, C["amber_bg"], C["amber"], C["amber_dk"]))

    if m.get("actions"):
        parts.append(sub_label("Action items"))
        parts.append(action_table(m["actions"]))

    if m.get("vs_yesterday"):
        parts.append(sub_label("So với prep hôm qua"))
        parts.append(_vs_yesterday_grid(m["vs_yesterday"]))

    chat_sig = m.get("chat_signals") or []
    if chat_sig:
        parts.append(sub_label("💬 Chat signal (recap)", color=C["chat"]))
        body = bullet_table([esc(s) for s in chat_sig], italic=True, color=C["chat"])
        parts.append(callout(body, C["chat_bg"], C["chat_border"], C["text"]))

    pic_obs = m.get("pic_observation") or []
    if pic_obs:
        parts.append(sub_label("PIC observation"))
        parts.append(bullet_table([esc(o) for o in pic_obs], italic=True, color=C["text_lt"]))

    risk = (m.get("risk_level") or "green").lower()
    parts.append(
        para(
            f'{RISK_DOT.get(risk, RISK_DOT["green"])} '
            f'<b>Risk:</b> {esc(m.get("risk_reason","—"))}'
            f' · <b>Carry:</b> {esc(m.get("carry_count",0))} action chưa close',
            color=C["text"],
        )
    )
    parts.append("</div>")
    return "".join(parts)


def _vs_yesterday_grid(vs: dict) -> str:
    cells = []
    for key, label in [
        ("hit", "Hit"),
        ("miss", "Miss"),
        ("new", "New"),
        ("insight", "Insight"),
    ]:
        items = vs.get(key) or []
        body = bullet_table([esc(i) for i in items], color=C["text"]) if items else (
            para("—", color=C["muted"], italic=True)
        )
        cells.append(
            f'<td style="vertical-align:top;width:25%;padding:8px;'
            f'border:1px solid {C["border"]};background:{C["bg_lt"]};">'
            f'<div style="font-family:Arial;font-size:11px;font-weight:bold;'
            f'color:{C["muted"]};text-transform:uppercase;letter-spacing:0.5px;'
            f'margin-bottom:4px;">{esc(label)}</div>{body}</td>'
        )
    return (
        '<table cellspacing="0" cellpadding="0" '
        'style="border-collapse:collapse;width:100%;margin:4px 0;">'
        f'<tr>{"".join(cells)}</tr></table>'
    )


def meeting_prep_block(m: dict) -> str:
    """PHẦN 2 — meeting ngày mai."""
    time_chip = chip(m.get("time", "—"), C["bright"])
    title = m.get("title", "?")
    mode = m.get("mode", "")
    title_line = f'{time_chip} {esc(title)}'
    if mode:
        title_line += f' <span style="color:{C["muted"]};font-size:12px;">({esc(mode)})</span>'
    parts = [
        f'<div style="margin-top:18px;">'
        f'<div style="font-family:Arial;font-size:14px;font-weight:bold;color:{C["navy"]};">'
        f'{title_line}</div>'
    ]

    if m.get("attendees"):
        parts.append(sub_label("Người tham gia"))
        parts.append(_attendee_table(m["attendees"]))

    if m.get("personas"):
        parts.append(sub_label("Persona snapshot"))
        parts.append(persona_card(m["personas"]))

    if m.get("objectives"):
        parts.append(sub_label("Mục tiêu chính", color=C["blue"]))
        parts.append(
            callout(
                bullet_table([esc(o) for o in m["objectives"]], color=C["text"]),
                C["light"], C["blue"], C["text"],
            )
        )

    if m.get("customer_story"):
        parts.append(sub_label("Câu chuyện khách có thể quan tâm"))
        parts.append(
            callout(
                bullet_table([esc(s) for s in m["customer_story"]], color=C["text"]),
                C["bg_lt"], C["border"], C["text"],
            )
        )

    if m.get("vti_prep"):
        parts.append(sub_label("VTI cần chuẩn bị", color=C["green"]))
        parts.append(
            callout(
                bullet_table([esc(s) for s in m["vti_prep"]], color=C["text"]),
                C["green_bg"], C["green"], C["text"],
            )
        )

    if m.get("popups"):
        parts.append(sub_label("Có thể pop-up trong buổi"))
        parts.append(bullet_table([esc(s) for s in m["popups"]], color=C["text"]))

    chat_sig = m.get("chat_signals") or []
    if chat_sig:
        parts.append(sub_label("💬 Chat signal", color=C["chat"]))
        body = bullet_table([esc(s) for s in chat_sig], italic=True, color=C["chat"])
        parts.append(callout(body, C["chat_bg"], C["chat_border"], C["text"]))

    risk = (m.get("risk_level") or "green").lower()
    parts.append(
        para(
            f'{RISK_DOT.get(risk, RISK_DOT["green"])} '
            f'<b>Risk:</b> {esc(m.get("risk_reason","—"))}',
            color=C["text"],
        )
    )
    parts.append("</div>")
    return "".join(parts)


def _attendee_table(attendees: list[dict]) -> str:
    head = (
        '<tr>' + "".join(
            f'<th style="background:{C["bg_lt"]};color:{C["muted"]};'
            f'font-family:Arial;font-size:11px;text-align:left;padding:6px 10px;'
            f'border:1px solid {C["border"]};text-transform:uppercase;letter-spacing:0.5px;">'
            f'{esc(c)}</th>'
            for c in ["Tên", "Role", "Công ty", "Note"]
        ) + '</tr>'
    )
    rows = []
    for a in attendees:
        rows.append(
            "<tr>"
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["text"]};">{esc(a.get("name","?"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["text"]};">{esc(a.get("role","—"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:12px;color:{C["text"]};">{esc(a.get("company","—"))}</td>'
            f'<td style="border:1px solid {C["border"]};padding:6px 10px;font-family:Arial;font-size:11px;color:{C["muted"]};">{esc(a.get("note","—"))}</td>'
            "</tr>"
        )
    return (
        '<table cellspacing="0" cellpadding="0" '
        'style="border-collapse:collapse;width:100%;margin:6px 0;">'
        + head + "".join(rows) + "</table>"
    )


# ---------------------------------------------------------------------------
# Phụ lục E — Chat Intelligence
# ---------------------------------------------------------------------------


def chat_intel_block(chat_intel: dict) -> str:
    if not chat_intel:
        return callout(
            para("Google Chat pipeline unavailable hôm nay.", color=C["muted"], italic=True),
            C["bg_lt"], C["border"], C["text"],
        )
    parts = []
    sub_sections = [
        ("E.1 — Trending topics", chat_intel.get("trending_topics") or []),
        ("E.2 — Pending replies Michael", chat_intel.get("pending_replies_michael") or []),
        ("E.3 — Persona language samples", chat_intel.get("persona_language_samples") or {}),
        ("E.4 — Sentiment shifts", chat_intel.get("sentiment_shifts") or []),
        ("E.5 — Urgency flags", chat_intel.get("urgency_flags") or []),
    ]
    for title, data in sub_sections:
        parts.append(sub_label(title, color=C["chat"]))
        if isinstance(data, dict):
            # persona_language_samples — {pic_name: [phrases]}
            if not data:
                parts.append(para("—", color=C["muted"], italic=True))
            else:
                rows = []
                for pic, phrases in data.items():
                    phrase_html = "<br>".join(f'<i>"{esc(p)}"</i>' for p in (phrases or []))
                    rows.append(
                        f'<tr><td style="vertical-align:top;padding:4px 12px 4px 0;'
                        f'font-family:Arial;font-size:12px;font-weight:bold;color:{C["navy"]};">{esc(pic)}</td>'
                        f'<td style="padding:4px 0;font-family:Arial;font-size:12px;'
                        f'color:{C["text_lt"]};line-height:1.5;">{phrase_html or "—"}</td></tr>'
                    )
                parts.append(
                    f'<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;">'
                    f'{"".join(rows)}</table>'
                )
        else:
            if not data:
                parts.append(para("—", color=C["muted"], italic=True))
            else:
                parts.append(
                    callout(
                        bullet_table([_format_chat_item(it) for it in data], color=C["text"]),
                        C["chat_bg"], C["chat_border"], C["text"],
                    )
                )
    return "".join(parts)


def _format_chat_item(item) -> str:
    if isinstance(item, str):
        return esc(item)
    if isinstance(item, dict):
        # Heuristic: pull common fields
        prefix = ""
        if item.get("priority"):
            prio = item["priority"].lower()
            prefix = (RISK_DOT.get(prio, "") + " ")
        head_bits = [item.get("pic_name") or item.get("topic") or ""]
        if item.get("space_short"):
            head_bits.append(f'@ {item["space_short"]}')
        head = " ".join(b for b in head_bits if b)
        snippet = item.get("snippet") or item.get("observation") or item.get("issue") or ""
        cite = item.get("sample_cite") or item.get("evidence_cite") or item.get("cite") or ""
        cite_html = f' <span style="color:{C["muted"]};font-style:italic;">{esc(cite)}</span>' if cite else ""
        return f'{prefix}<b>{esc(head)}</b> · {esc(snippet)}{cite_html}'
    return esc(str(item))


# ---------------------------------------------------------------------------
# Top-level render
# ---------------------------------------------------------------------------


def render(brief: dict) -> str:
    sections = [cover_html(brief)]

    # PHẦN 1
    sections.append(section_bar("PHẦN 1 — TỔNG KẾT HÔM NAY"))
    today_meetings = brief.get("today_meetings") or []
    if not today_meetings:
        sections.append(para("Không có meeting hôm nay.", italic=True, color=C["muted"]))
    else:
        for m in today_meetings:
            sections.append(meeting_recap_block(m))

    # PHẦN 2
    sections.append(section_bar("PHẦN 2 — CHUẨN BỊ CHO NGÀY MAI"))
    tomorrow_meetings = brief.get("tomorrow_meetings") or []
    if not tomorrow_meetings:
        sections.append(para("Không có meeting ngày mai.", italic=True, color=C["muted"]))
    else:
        for m in tomorrow_meetings:
            sections.append(meeting_prep_block(m))

    # PHỤ LỤC A — Actions
    sections.append(section_bar("PHỤ LỤC A — Action Items của Michael"))
    sections.append(action_table(brief.get("actions") or []))

    # PHỤ LỤC B — Cảnh báo & Gap
    sections.append(section_bar("PHỤ LỤC B — Cảnh báo & Gap"))
    gaps = brief.get("gaps") or []
    if gaps:
        sections.append(
            callout(
                bullet_table([esc(g) for g in gaps], color=C["text"]),
                C["red_bg"], C["red"], C["text"],
            )
        )
    else:
        sections.append(para("Không có cảnh báo.", italic=True, color=C["muted"]))

    # PHỤ LỤC C — Insight cập nhật cho Memory
    sections.append(section_bar("PHỤ LỤC C — Insight cập nhật cho Memory"))
    insights = brief.get("memory_insights") or []
    if insights:
        sections.append(
            callout(
                bullet_table([esc(i) for i in insights], color=C["text"]),
                C["light"], C["blue"], C["text"],
            )
        )
    else:
        sections.append(para("Không có insight mới.", italic=True, color=C["muted"]))

    # PHỤ LỤC D — AI Analysis Log
    sections.append(section_bar("PHỤ LỤC D — AI Analysis Log"))
    ai_log = brief.get("ai_log") or []
    if ai_log:
        sections.append(
            callout(
                bullet_table([esc(line) for line in ai_log], color=C["text_lt"]),
                C["bg_lt"], C["border"], C["text"],
            )
        )
    else:
        sections.append(para("—", italic=True, color=C["muted"]))

    # PHỤ LỤC E — Chat Intelligence (v7+)
    sections.append(
        section_bar(
            "PHỤ LỤC E — Chat Intelligence",
            bg=C["chat_bg"], fg=C["chat"],
        )
    )
    sections.append(chat_intel_block(brief.get("chat_intel") or {}))

    body = "".join(sections)
    # Wrap in a single root div with system font fallback
    return (
        f'<div style="font-family:Arial,Helvetica,sans-serif;color:{C["text"]};">'
        f'{body}</div>'
    )


# ---------------------------------------------------------------------------
# Pre-publish verify (BƯỚC 5.5)
# ---------------------------------------------------------------------------


def verify_html(html: str) -> list[str]:
    issues: list[str] = []
    # No markdown raw
    if "**" in html:
        issues.append('Found raw markdown "**" in HTML')
    if "\n### " in html or html.startswith("### "):
        issues.append('Found raw markdown "### " in HTML')
    # No <html><head><body> wrapping
    for forbidden in ("<html", "<head", "<body", "<style"):
        if forbidden in html.lower():
            issues.append(f'Forbidden tag/attr found: {forbidden}')
    # No 🔴🟡🟢 in doc (use ● instead)
    for em in ("🔴", "🟡", "🟢"):
        if em in html:
            issues.append(f'Forbidden emoji {em} in Doc HTML (use ● instead — Drive strips emoji color)')
    return issues


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _build_filename(brief: dict) -> str:
    meta = brief.get("meta", {})
    date_obj = datetime.fromisoformat(meta["date"])
    base = f'Daily Recap & Prep — {date_obj.strftime("%d/%m/%Y")}'
    v = int(meta.get("version", 1))
    if v >= 2:
        base += f' (v{v})'
    return base


def cmd_render(args: argparse.Namespace) -> int:
    brief = load_json(Path(args.brief) if args.brief else BRIEF_PATH)
    if not brief:
        print(f"FAIL: brief.json missing at {args.brief or BRIEF_PATH}", file=sys.stderr)
        return 2
    html = render(brief)
    issues = verify_html(html)
    if issues:
        print("VERIFY FAILED:", file=sys.stderr)
        for i in issues:
            print(f"  - {i}", file=sys.stderr)
        if not args.force:
            return 3
    out = Path(args.out) if args.out else DOC_HTML_PATH
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"✅ Wrote {out} ({len(html)} chars)")
    return 0


def cmd_upload(args: argparse.Namespace) -> int:
    brief_path = Path(args.brief) if args.brief else BRIEF_PATH
    brief = load_json(brief_path)
    if not brief:
        print(f"FAIL: brief.json missing at {brief_path}", file=sys.stderr)
        return 2
    html_path = Path(args.html) if args.html else DOC_HTML_PATH
    if not html_path.exists():
        print(f"FAIL: HTML not rendered yet at {html_path}", file=sys.stderr)
        return 2
    html = html_path.read_text(encoding="utf-8")

    creds = load_credentials()
    drive = get_drive(creds)
    folder_id = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
    # Cache folder_id in state
    state = load_state()
    state["doc_folder_id"] = folder_id
    save_state(state)

    filename = _build_filename(brief)
    new_id = upload_html_as_gdoc(drive, folder_id, filename, html)
    link = f"https://docs.google.com/document/d/{new_id}/edit"
    print(json.dumps({"file_id": new_id, "name": filename, "link": link}, ensure_ascii=False))
    log(f"Uploaded Doc Daily '{filename}' → {new_id}")
    return 0


def cmd_render_and_upload(args: argparse.Namespace) -> int:
    rc = cmd_render(args)
    if rc != 0:
        return rc
    return cmd_upload(args)


def brief_schema_example() -> dict:
    """Return a minimal example of brief.json — for documentation only."""
    return {
        "meta": {
            "date": "2026-05-16",
            "generated_at_local": "23:45",
            "version": 1,
            "counts": {
                "today_meetings": 0,
                "tomorrow_meetings": 0,
                "red_actions": 0,
                "chat_spaces_active": 0,
            },
        },
        "today_meetings": [],
        "tomorrow_meetings": [],
        "actions": [],
        "gaps": [],
        "memory_insights": [],
        "ai_log": [],
        "chat_intel": {},
    }


def main() -> int:
    p = argparse.ArgumentParser(description="Render Doc Daily HTML from brief.json")
    sub = p.add_subparsers(dest="cmd", required=True)

    pr = sub.add_parser("render", help="Render HTML to outputs/doc_daily.html")
    pr.add_argument("--brief", help="Path to brief.json (default: meeting_context/brief.json)")
    pr.add_argument("--out", help="Output HTML path (default: outputs/doc_daily.html)")
    pr.add_argument("--force", action="store_true", help="Write even if verify fails")
    pr.set_defaults(func=cmd_render)

    pu = sub.add_parser("upload", help="Upload rendered HTML as Google Doc")
    pu.add_argument("--brief", help="Path to brief.json")
    pu.add_argument("--html", help="Path to rendered HTML")
    pu.set_defaults(func=cmd_upload)

    pa = sub.add_parser("render-and-upload", help="Render + Upload in one go")
    pa.add_argument("--brief")
    pa.add_argument("--out")
    pa.add_argument("--html")
    pa.add_argument("--force", action="store_true")
    pa.set_defaults(func=cmd_render_and_upload)

    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
