#!/usr/bin/env python3
"""render_docx.py — v9.2 native .docx renderer (VTI brand).

Produces enterprise-quality Recap + Prep .docx files using python-docx.
Uploads to Drive (Drive opens .docx natively in Google Docs editor).
"""
from __future__ import annotations
import argparse, base64, io, json, sys
from datetime import datetime
from pathlib import Path
import re

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_PARAGRAPH_ALIGNMENT
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsmap
from docx.oxml import OxmlElement

from meeting_lib import (
    DRIVE_FOLDER_NAME, ensure_folder, get_drive, load_credentials, log,
)

ROOT = Path(__file__).resolve().parent
BRIEF_PATH = ROOT / "meeting_context" / "brief.json"
OUT_DIR = ROOT / "outputs"
LOGO_JSON = "/sessions/affectionate-sleepy-hamilton/mnt/.claude/skills/vti-brief-doc/assets/logos_b64.json"

# VTI palette (hex w/o #)
NAVY     = RGBColor(0x05, 0x19, 0x34)
BLUE     = RGBColor(0x00, 0x4A, 0xAD)
BRIGHT   = RGBColor(0x04, 0x68, 0xE6)
LIGHT    = RGBColor(0xDA, 0xE9, 0xF6)
AMBER    = RGBColor(0xF8, 0xC3, 0x79)
AMBER_DK = RGBColor(0x6B, 0x3D, 0x00)
AMBER_BG = RGBColor(0xFF, 0xFB, 0xF0)
GREEN    = RGBColor(0x1A, 0x7A, 0x4A)
GREEN_BG = RGBColor(0xE6, 0xF4, 0xED)
RED      = RGBColor(0xB0, 0x20, 0x20)
RED_BG   = RGBColor(0xFF, 0xF0, 0xF0)
VIOLET   = RGBColor(0x6B, 0x46, 0xC1)
VIOLET_BG= RGBColor(0xF3, 0xEE, 0xFC)
CHAT     = RGBColor(0x1A, 0x7A, 0xB8)
CHAT_BG  = RGBColor(0xE8, 0xF4, 0xFB)
MUTED    = RGBColor(0x6B, 0x7A, 0x8D)
TEXT     = RGBColor(0x1F, 0x29, 0x37)
TEXT_LT  = RGBColor(0x4B, 0x55, 0x63)
BORDER   = "C8DCF0"
BG_ALT   = "F0F5FB"
WHITE    = RGBColor(0xFF, 0xFF, 0xFF)

FONT     = "Arial"  # Drive-safe


def _shade_cell(cell, fill_hex):
    """Apply background fill to a table cell."""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill_hex)
    tcPr.append(shd)


def _set_cell_borders(cell, color="C8DCF0", size="4"):
    """Apply borders to a single cell."""
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        b = OxmlElement(f"w:{edge}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), size)
        b.set(qn("w:space"), "0")
        b.set(qn("w:color"), color)
        tcBorders.append(b)
    tcPr.append(tcBorders)


def _set_cell_margins(cell, top=80, bottom=80, left=120, right=120):
    """Cell internal padding (DXA: 20 = 1pt, 80 ~= 4pt)."""
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement("w:tcMar")
    for edge, val in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:w"), str(val))
        e.set(qn("w:type"), "dxa")
        tcMar.append(e)
    tcPr.append(tcMar)


def _set_paragraph_shade(paragraph, fill_hex):
    """Background fill on an entire paragraph (full width band)."""
    pPr = paragraph._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill_hex)
    pPr.append(shd)


def _set_paragraph_border(paragraph, top=None, bottom=None, left=None):
    """Add borders to a paragraph (used for accent stripes on cards)."""
    pPr = paragraph._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    for edge, spec in [("top", top), ("bottom", bottom), ("left", left)]:
        if spec is None: continue
        b = OxmlElement(f"w:{edge}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), spec.get("size", "24"))  # 24 = 3pt
        b.set(qn("w:space"), spec.get("space", "1"))
        b.set(qn("w:color"), spec["color"])
        pBdr.append(b)
    pPr.append(pBdr)


def _add_run(p, text, *, font=None, size=11, bold=False, italic=False, color=None, uppercase=False):
    if uppercase:
        text = text.upper()
    r = p.add_run(text)
    r.font.name = font or FONT
    r.font.size = Pt(size)
    r.bold = bold
    r.italic = italic
    if color: r.font.color.rgb = color
    # also set East Asian font fallback
    rPr = r._r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), font or FONT)
    rFonts.set(qn("w:hAnsi"), font or FONT)
    rFonts.set(qn("w:cs"), font or FONT)
    return r


def _para(doc, text="", *, size=11, bold=False, italic=False, color=None,
          align=None, space_before=0, space_after=4, indent_left=0, font=None,
          uppercase=False, line_spacing=1.15, shade=None):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(space_before)
    pf.space_after = Pt(space_after)
    pf.line_spacing = line_spacing
    if indent_left:
        pf.left_indent = Cm(indent_left)
    if align:
        p.alignment = align
    if shade:
        _set_paragraph_shade(p, shade)
    if text:
        _add_run(p, text, font=font, size=size, bold=bold, italic=italic, color=color, uppercase=uppercase)
    return p


def _setup_styles(doc):
    """Override default + heading styles for Arial + tighter spacing."""
    # Default font
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = FONT
    normal.font.size = Pt(11)
    rPr = normal.element.find(qn("w:rPr"))
    if rPr is not None:
        rFonts = rPr.find(qn("w:rFonts"))
        if rFonts is None:
            rFonts = OxmlElement("w:rFonts")
            rPr.insert(0, rFonts)
        for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rFonts.set(qn(attr), FONT)


def _setup_page(doc):
    """A4 landscape-ish margins; tight top/bottom for header."""
    s = doc.sections[0]
    s.page_height = Cm(29.7)
    s.page_width = Cm(21.0)
    s.top_margin = Cm(0)       # header div fills top
    s.bottom_margin = Cm(1.5)
    s.left_margin = Cm(1.5)
    s.right_margin = Cm(1.5)
    s.header_distance = Cm(0)
    s.footer_distance = Cm(0.6)


def _navy_header(doc, title_main, title_sub):
    """Navy full-width header band with VTI logo + title + accent stripe.
    Built as a 1-row 2-col table to guarantee full-width navy background."""
    # Insert via single-cell table for reliable full-width fill
    tbl = doc.add_table(rows=1, cols=2)
    tbl.autofit = False
    tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
    # Width: full page width minus margins (A4: 21cm - 3cm = 18cm)
    total_w = Cm(18)
    tbl.columns[0].width = Cm(4.0)
    tbl.columns[1].width = Cm(14.0)
    row = tbl.rows[0]
    row.height = Cm(2.2)
    # Cell 1: logo
    c0 = row.cells[0]
    _shade_cell(c0, "051934")
    _set_cell_margins(c0, top=240, bottom=240, left=300, right=120)
    c0.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    c0.width = Cm(4.0)
    # Try to embed logo image
    try:
        with open(LOGO_JSON) as f:
            logos = json.load(f)
        b64 = logos.get("logo-horizontal-white", "")
        if b64:
            img_bytes = base64.b64decode(b64)
            p_logo = c0.paragraphs[0]
            p_logo.paragraph_format.space_before = Pt(0)
            p_logo.paragraph_format.space_after = Pt(0)
            run = p_logo.add_run()
            run.add_picture(io.BytesIO(img_bytes), height=Cm(1.1))
    except Exception as e:
        # Fallback: text logo
        p_logo = c0.paragraphs[0]
        _add_run(p_logo, "VTI APAC", size=16, bold=True, color=WHITE, uppercase=True)
    # Cell 2: title
    c1 = row.cells[1]
    _shade_cell(c1, "051934")
    _set_cell_margins(c1, top=240, bottom=240, left=240, right=300)
    c1.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    c1.width = Cm(14.0)
    p_title = c1.paragraphs[0]
    p_title.paragraph_format.space_before = Pt(0)
    p_title.paragraph_format.space_after = Pt(2)
    _add_run(p_title, title_main, size=20, bold=True, color=WHITE, uppercase=True)
    p_sub = c1.add_paragraph()
    p_sub.paragraph_format.space_before = Pt(0)
    p_sub.paragraph_format.space_after = Pt(0)
    _add_run(p_sub, title_sub, size=12, color=LIGHT, italic=False)
    # Remove default borders, then add bright accent on bottom of both cells
    for c in row.cells:
        tcPr = c._tc.get_or_add_tcPr()
        tcBorders = OxmlElement("w:tcBorders")
        for edge in ("top", "left", "right"):
            b = OxmlElement(f"w:{edge}")
            b.set(qn("w:val"), "nil")
            tcBorders.append(b)
        b_bot = OxmlElement("w:bottom")
        b_bot.set(qn("w:val"), "single")
        b_bot.set(qn("w:sz"), "32")   # 4pt accent
        b_bot.set(qn("w:color"), "0468E6")
        tcBorders.append(b_bot)
        tcPr.append(tcBorders)


def _meta_strip(doc, items):
    """Light-grey band with metadata labels + values."""
    p = _para(doc, "", space_before=0, space_after=0, line_spacing=1.0, shade=BG_ALT)
    pf = p.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    # add a bit of padding via empty top run? Use border-spacing approximation
    for i, (label, value) in enumerate(items):
        if i > 0:
            _add_run(p, "    ", size=10)
        _add_run(p, label.upper() + " ", size=9, bold=True, color=MUTED)
        _add_run(p, str(value), size=11, bold=True, color=NAVY)
    # Apply some padding via a hack — paragraph border bottom for separation
    _set_paragraph_border(p, bottom={"size": "4", "color": BORDER})
    # add some extra indent via para format
    pf.left_indent = Cm(0.4)
    pf.right_indent = Cm(0.4)
    pf.space_before = Pt(8)
    pf.space_after = Pt(8)
    return p


def _card_title(doc, text, accent_color="0468E6"):
    """Section/card title — bold uppercase navy with top accent border + bottom thin border."""
    p = _para(doc, "", space_before=14, space_after=6, line_spacing=1.0)
    pf = p.paragraph_format
    pf.left_indent = Cm(0)
    _add_run(p, text, size=13, bold=True, color=NAVY, uppercase=True)
    # Top accent stripe
    _set_paragraph_border(p,
        top={"size": "32", "color": accent_color, "space": "4"},
        bottom={"size": "4", "color": BORDER, "space": "4"})
    return p


def _section_label(doc, text, color=BLUE):
    """Small uppercase letter-spaced section label inside a card."""
    p = _para(doc, "", space_before=10, space_after=2)
    _add_run(p, text, size=10, bold=True, color=color, uppercase=True)
    # Add character spacing via run-level XML — letter-spacing approximation:
    for r in p.runs:
        rPr = r._r.get_or_add_rPr()
        spacing = OxmlElement("w:spacing")
        spacing.set(qn("w:val"), "30")  # 30 twips = 1.5pt letter spacing
        rPr.append(spacing)
    return p


def _meeting_strip(doc, meeting, bg_hex="004AAD"):
    """Blue full-width strip with time + title + risk pill."""
    tbl = doc.add_table(rows=1, cols=2)
    tbl.autofit = False
    tbl.columns[0].width = Cm(14.5)
    tbl.columns[1].width = Cm(3.5)
    row = tbl.rows[0]
    # Cell 1: time + title
    c0 = row.cells[0]
    _shade_cell(c0, bg_hex)
    _set_cell_margins(c0, top=120, bottom=120, left=160, right=160)
    c0.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    p0 = c0.paragraphs[0]
    p0.paragraph_format.space_before = Pt(0); p0.paragraph_format.space_after = Pt(0)
    _add_run(p0, meeting.get("time", "") + "   ", size=11, bold=True, color=WHITE)
    _add_run(p0, meeting.get("title", ""), size=13, bold=True, color=WHITE)
    # Cell 2: risk pill
    c1 = row.cells[1]
    _shade_cell(c1, bg_hex)
    _set_cell_margins(c1, top=120, bottom=120, left=120, right=160)
    c1.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    p1 = c1.paragraphs[0]
    p1.paragraph_format.space_before = Pt(0); p1.paragraph_format.space_after = Pt(0)
    p1.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    risk = meeting.get("risk_level", "green").upper()
    risk_colors = {"RED": (RED, RED_BG), "AMBER": (AMBER_DK, AMBER_BG), "GREEN": (GREEN, GREEN_BG)}
    fg, bg = risk_colors.get(risk, (GREEN, GREEN_BG))
    _add_run(p1, "● " + risk, size=10, bold=True, color=fg)
    # Borders: none on this strip, just bg
    for c in row.cells:
        tcPr = c._tc.get_or_add_tcPr()
        tcBorders = OxmlElement("w:tcBorders")
        for edge in ("top", "left", "right", "bottom"):
            b = OxmlElement(f"w:{edge}")
            b.set(qn("w:val"), "nil")
            tcBorders.append(b)
        tcPr.append(tcBorders)
    # Meta line below
    p_meta = _para(doc, "", space_before=4, space_after=8)
    _add_run(p_meta, meeting.get("mode", "") + "  ·  " + meeting.get("duration", "") + "  ·  ",
             size=10, color=TEXT_LT)
    _add_run(p_meta, meeting.get("risk_reason", ""), size=10, italic=True, color=TEXT_LT)


def _bullet_list(doc, items, color=None, italic=False, size=11):
    """Simple hanging-indent bullet paragraphs."""
    if not items:
        _para(doc, "—", italic=True, color=MUTED)
        return
    for it in items:
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.space_before = Pt(1)
        pf.space_after = Pt(3)
        pf.left_indent = Cm(0.75)
        pf.first_line_indent = Cm(-0.4)
        pf.line_spacing = 1.3
        _add_run(p, "•  ", size=size, bold=True, color=color or BLUE)
        _add_run(p, it, size=size, italic=italic, color=color or TEXT)


def _callout(doc, items, kind="info"):
    """Single-cell shaded table that acts as a callout box."""
    palette = {
        "info":    ("E6F2FF", "004AAD", TEXT),
        "warning": ("FFFBF0", "F8C379", AMBER_DK),
        "success": ("E6F4ED", "1A7A4A", TEXT),
        "delta":   ("F3EEFC", "6B46C1", TEXT),
        "chat":    ("E8F4FB", "1A7AB8", TEXT),
    }
    bg_hex, border_hex, fg = palette.get(kind, palette["info"])
    tbl = doc.add_table(rows=1, cols=1)
    tbl.autofit = False
    tbl.columns[0].width = Cm(18)
    cell = tbl.rows[0].cells[0]
    _shade_cell(cell, bg_hex)
    _set_cell_margins(cell, top=120, bottom=120, left=180, right=180)
    # Border: left-only thick + thin all
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for edge in ("top", "bottom", "right"):
        b = OxmlElement(f"w:{edge}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), "4")
        b.set(qn("w:color"), border_hex)
        tcBorders.append(b)
    b_left = OxmlElement("w:left")
    b_left.set(qn("w:val"), "single")
    b_left.set(qn("w:sz"), "32")  # 4pt thick left accent
    b_left.set(qn("w:color"), border_hex)
    tcBorders.append(b_left)
    tcPr.append(tcBorders)
    # Items inside the cell
    first = True
    if not items:
        items = ["—"]
    for it in items:
        if first:
            p = cell.paragraphs[0]; first = False
        else:
            p = cell.add_paragraph()
        pf = p.paragraph_format
        pf.space_before = Pt(0)
        pf.space_after = Pt(2)
        pf.left_indent = Cm(0.5)
        pf.first_line_indent = Cm(-0.4)
        pf.line_spacing = 1.3
        _add_run(p, "•  ", size=11, bold=True, color=RGBColor(int(border_hex[0:2],16),int(border_hex[2:4],16),int(border_hex[4:6],16)))
        _add_run(p, it, size=11, color=fg)
    _para(doc, "", space_before=0, space_after=4)  # spacer


def _attendees_table(doc, attendees, mode="recap"):
    if not attendees:
        _para(doc, "—", italic=True, color=MUTED)
        return
    if mode == "recap":
        headers = ["Name", "Role (general)", "Role in meeting", "Company", "Int.", "Persona"]
        widths_cm = [2.8, 2.8, 3.2, 2.4, 1.0, 4.8]
    else:
        headers = ["Name", "Role", "Company", "Persona summary"]
        widths_cm = [3.8, 3.8, 3.4, 6.0] if mode == "prep" else [3.8, 3.8, 3.4, 6.0]
    n_cols = len(headers)
    tbl = doc.add_table(rows=1 + len(attendees), cols=n_cols)
    tbl.autofit = False
    # Set total + column widths
    for i, w in enumerate(widths_cm):
        tbl.columns[i].width = Cm(w)
    # Header row
    for i, (h, w) in enumerate(zip(headers, widths_cm)):
        c = tbl.rows[0].cells[i]
        c.width = Cm(w)
        _shade_cell(c, "051934")
        _set_cell_borders(c, color="051934", size="4")
        _set_cell_margins(c, top=100, bottom=100, left=140, right=140)
        c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = c.paragraphs[0]; p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
        _add_run(p, h, size=9, bold=True, color=WHITE, uppercase=True)
    # Data rows
    for ri, a in enumerate(attendees):
        row_bg = "FFFFFF" if ri % 2 == 0 else BG_ALT
        if mode == "recap":
            cells_data = [
                ("name", a.get("name", "")),
                ("role", a.get("role", "")),
                ("rim", a.get("role_in_meeting", "")),
                ("company", a.get("company", "")),
                ("int", "VTI" if a.get("internal") else "EXT"),
                ("persona", a.get("persona_summary", "")),
            ]
        else:
            cells_data = [
                ("name", a.get("name", "")),
                ("role", a.get("role", "")),
                ("company", a.get("company", "")),
                ("persona", a.get("persona_summary", "")),
            ]
        for ci, (key, val) in enumerate(cells_data):
            c = tbl.rows[ri + 1].cells[ci]
            c.width = Cm(widths_cm[ci])
            _shade_cell(c, row_bg)
            _set_cell_borders(c, color=BORDER, size="4")
            _set_cell_margins(c, top=80, bottom=80, left=140, right=140)
            c.vertical_alignment = WD_ALIGN_VERTICAL.TOP
            p = c.paragraphs[0]; p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.25
            if key == "name":
                _add_run(p, val, size=10, bold=True, color=TEXT)
            elif key == "persona":
                _add_run(p, val, size=10, italic=True, color=TEXT_LT)
            elif key == "int":
                pill_color = BLUE if val == "VTI" else AMBER_DK
                _add_run(p, val, size=9, bold=True, color=pill_color)
            else:
                _add_run(p, val, size=10, color=TEXT)
    _para(doc, "", space_before=0, space_after=4)


def _actions_table(doc, actions):
    if not actions:
        _para(doc, "—", italic=True, color=MUTED)
        return
    headers = ["PIC", "Task", "Output", "Deadline", "Priority"]
    widths_cm = [3.0, 6.0, 4.6, 2.4, 2.0]
    tbl = doc.add_table(rows=1 + len(actions), cols=5)
    tbl.autofit = False
    for i, w in enumerate(widths_cm):
        tbl.columns[i].width = Cm(w)
    for i, h in enumerate(headers):
        c = tbl.rows[0].cells[i]
        c.width = Cm(widths_cm[i])
        _shade_cell(c, "051934")
        _set_cell_borders(c, color="051934", size="4")
        _set_cell_margins(c, top=100, bottom=100, left=140, right=140)
        c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = c.paragraphs[0]; p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
        _add_run(p, h, size=9, bold=True, color=WHITE, uppercase=True)
    prio_colors = {"red": (RED, "FFF0F0"), "amber": (AMBER_DK, "FFFBF0"), "green": (GREEN, "E6F4ED")}
    for ri, a in enumerate(actions):
        row_bg = "FFFFFF" if ri % 2 == 0 else BG_ALT
        prio = a.get("priority", "").lower()
        fg_p, bg_p = prio_colors.get(prio, (TEXT, row_bg))
        cells_data = [
            ("pic", a.get("pic", ""), False),
            ("task", a.get("task", ""), False),
            ("out", a.get("output", ""), False),
            ("dl", a.get("deadline", ""), False),
            ("prio", a.get("priority", "").upper(), True),
        ]
        for ci, (key, val, is_prio) in enumerate(cells_data):
            c = tbl.rows[ri + 1].cells[ci]
            c.width = Cm(widths_cm[ci])
            _shade_cell(c, bg_p if is_prio else row_bg)
            _set_cell_borders(c, color=BORDER, size="4")
            _set_cell_margins(c, top=80, bottom=80, left=140, right=140)
            c.vertical_alignment = WD_ALIGN_VERTICAL.TOP
            p = c.paragraphs[0]; p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.25
            if key == "pic":
                _add_run(p, val, size=10, bold=True, color=TEXT)
            elif key == "dl":
                _add_run(p, val, size=10, bold=True, color=NAVY)
            elif key == "prio":
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                _add_run(p, val, size=9, bold=True, color=fg_p)
            else:
                _add_run(p, val, size=10, color=TEXT)
    _para(doc, "", space_before=0, space_after=4)


def _footer_line(doc, brief):
    m = brief["meta"]
    p = _para(doc, "", space_before=14, space_after=0)
    _set_paragraph_border(p, top={"size": "4", "color": BORDER})
    p2 = _para(doc, "", space_before=4)
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _add_run(p2, f'VTI APAC · Meeting Prep Assistant · Pipeline {m.get("pipeline_version","v9")} · '
                 f'Generated {m["generated_at_local"]} ICT · v{m["version"]}',
             size=8, color=MUTED, italic=True)


# ---------------------------------------------------------------------------
# Top-level renderers
# ---------------------------------------------------------------------------


def _split_evaluation(text):
    """v9.3: split chat_evaluation thành multi-line readable bullets.
    Tách tại các marker: [likely], [possible], [unlikely], Risk:, Michael nên:.
    Mỗi marker bắt đầu 1 bullet mới."""
    if not text:
        return []
    # Insert newline marker BEFORE each split keyword (keep keyword in result)
    # Order matters: prefix-style markers first, then sentence-mid markers
    patterns = [
        (r'\s+\[likely\]', '\n[likely]'),
        (r'\s+\[possible\]', '\n[possible]'),
        (r'\s+\[unlikely\]', '\n[unlikely]'),
        (r'\.\s+Risk:', '.\nRisk:'),
        (r'\.\s+Michael n[êe]n', lambda m: '.\n' + m.group(0).lstrip('. ').strip()),
        (r'\.\s+Cu[oô]ng n[êe]n', lambda m: '.\n' + m.group(0).lstrip('. ').strip()),
        (r'\.\s+Kevin n[êe]n', lambda m: '.\n' + m.group(0).lstrip('. ').strip()),
    ]
    work = text
    for pat, repl in patterns:
        if callable(repl):
            work = re.sub(pat, repl, work)
        else:
            work = re.sub(pat, repl, work)
    segs = [s.strip() for s in work.split('\n') if s.strip()]
    # Cap segment length 600 chars per bullet for readability
    out = []
    for s in segs:
        if len(s) <= 600:
            out.append(s)
        else:
            # If still too long, try split at ". "
            sentences = re.split(r'\.\s+(?=[A-ZĐ\[])', s)
            buf = ""
            for snt in sentences:
                if len(buf) + len(snt) + 2 < 600:
                    buf = (buf + ". " + snt).strip(". ")
                else:
                    if buf: out.append(buf + ".")
                    buf = snt
            if buf: out.append(buf if buf.endswith('.') else buf + '.')
    return out


def _chat_block(doc, meeting):
    """v9.1+v9.3: render mail_signals[] + chat_signals[] + chat_evaluation cho 1 meeting (docx).
    v9.3.1: chat_evaluation được split thành multi-bullet theo marker [likely]/Risk:/Michael nên."""
    mail_signals = meeting.get("mail_signals") or []
    signals = meeting.get("chat_signals") or []
    evaluation = (meeting.get("chat_evaluation") or "").strip()
    if not mail_signals and not signals and not evaluation:
        return
    if mail_signals:
        _section_label(doc, "Mail signals liên quan (v9.3)", color=BLUE)
        _callout(doc, mail_signals, kind="info")
    if signals:
        _section_label(doc, "Chat signals liên quan", color=CHAT)
        _callout(doc, signals, kind="chat")
    if evaluation:
        _section_label(doc, "Đánh giá chat + mail (Claude)", color=VIOLET)
        bullets = _split_evaluation(evaluation)
        _callout(doc, bullets if bullets else [evaluation], kind="delta")


def _day_chat_summary_block(doc, brief):
    """v9.1: render 'Chat Radar hôm nay' card ở đầu Recap docx."""
    ci = brief.get("chat_intel") or {}
    day_summary = ci.get("day_summary")
    trending = ci.get("trending_topics") or []
    urgency = ci.get("urgency_flags") or []
    pending = ci.get("pending_replies_michael") or []
    if not (day_summary or trending or urgency or pending):
        return
    _card_title(doc, "Chat Radar hôm nay", accent_color="1A7AB8")
    if day_summary:
        _section_label(doc, "Câu chuyện chính hôm nay", color=CHAT)
        if isinstance(day_summary, list):
            _bullet_list(doc, day_summary)
        else:
            _para(doc, str(day_summary), size=11)
    if trending:
        _section_label(doc, "Topic đang trending", color=CHAT)
        _bullet_list(doc, trending)
    if urgency:
        _section_label(doc, "Cảnh báo urgency", color=AMBER_DK)
        _callout(doc, urgency, kind="warning")
    if pending:
        _section_label(doc, "Tin nhắn chờ Michael reply", color=AMBER_DK)
        _bullet_list(doc, pending)



def render_recap_docx(brief, out_path):
    doc = Document()
    _setup_styles(doc); _setup_page(doc)
    m = brief["meta"]; c = m["counts"]
    today = brief.get("today_meetings") or []
    _navy_header(doc, "Daily Recap", m["date_today_label"])
    _meta_strip(doc, [
        ("Meetings", c["today_meetings"]),
        ("Chốt", sum(len(t.get("decisions", [])) for t in today)),
        ("Actions opened", c["open_actions_total"]),
        ("Red", str(c["red_actions"])),
        ("Pipeline", m.get("pipeline_version", "v9")),
    ])
    # v9.1: Chat Radar block ở đầu Recap (render ngay cả khi không có meeting)
    _day_chat_summary_block(doc, brief)
    if not today:
        _card_title(doc, "Tổng kết hôm nay", accent_color="6B7A8D")
        _callout(doc, [f'Không có meeting hôm nay — {m["date_today_label"]} là cuối tuần. '
                       f'Pipeline vẫn cập nhật Action Tracker và Memory; xem Prep cho ngày làm việc kế.'],
                 kind="info")
    else:
        for mtg in today:
            _card_title(doc, mtg.get("title", "Meeting"))
            _meeting_strip(doc, mtg)
            _section_label(doc, "Attendees & vai trò")
            _attendees_table(doc, mtg.get("attendees", []), mode="recap")
            _section_label(doc, "Nội dung trao đổi")
            _bullet_list(doc, mtg.get("summary", []))
            _section_label(doc, "Chốt (decisions)", color=GREEN)
            _callout(doc, mtg.get("decisions", []) or ["Không có chốt mới."], kind="success")
            _section_label(doc, "Pending actions opened in this meeting")
            _actions_table(doc, mtg.get("actions", []))
            _section_label(doc, "Delta vs Prep yesterday", color=VIOLET)
            deltas = mtg.get("delta_vs_prep", []) or []
            if deltas:
                _callout(doc, deltas, kind="delta")
            else:
                _para(doc, "Không có delta — meeting đi đúng prep hôm trước.", italic=True, color=MUTED)
            # v9.1: per-meeting chat signals + Claude đánh giá
            _chat_block(doc, mtg)
    _footer_line(doc, brief)
    doc.save(out_path)


def render_prep_docx(brief, out_path):
    doc = Document()
    _setup_styles(doc); _setup_page(doc)
    m = brief["meta"]; c = m["counts"]
    tomorrow = brief.get("tomorrow_meetings") or []
    _navy_header(doc, "Daily Prep", m["date_target_prep_label"])
    _meta_strip(doc, [
        ("Meetings", c["tomorrow_meetings"]),
        ("Open actions", c["open_actions_total"]),
        ("Red", str(c["red_actions"])),
        ("Pipeline", m.get("pipeline_version", "v9")),
    ])
    if not tomorrow:
        _card_title(doc, "Prep tomorrow", accent_color="6B7A8D")
        _callout(doc, [f'Không có meeting trong {m["date_target_prep_label"]}.'], kind="info")
    else:
        for mtg in tomorrow:
            _card_title(doc, mtg.get("title", "Meeting"))
            _meeting_strip(doc, mtg)
            _section_label(doc, "Attendees")
            _attendees_table(doc, mtg.get("attendees", []), mode="prep")
            _section_label(doc, "Câu chuyện sẽ trao đổi")
            _bullet_list(doc, mtg.get("story", []))
            _section_label(doc, "Tài liệu / nội dung cần chuẩn bị", color=BLUE)
            _callout(doc, mtg.get("prep_materials", []), kind="info")
            _section_label(doc, "Pop-ups dự kiến", color=AMBER_DK)
            _callout(doc, mtg.get("popups_anticipated", []), kind="warning")
            # v9.1: per-meeting chat signals + Claude đánh giá
            _chat_block(doc, mtg)
            if mtg.get("vti_brings"):
                _section_label(doc, "VTI mang theo")
                p = _para(doc, "", space_before=2, space_after=8)
                _add_run(p, mtg["vti_brings"], size=11, bold=True, color=TEXT)
    _footer_line(doc, brief)
    doc.save(out_path)


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------


def upload_docx(drive, path, filename, parent_folder_id):
    from googleapiclient.http import MediaFileUpload
    media = MediaFileUpload(str(path),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        resumable=False)
    body = {"name": filename,
            "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "parents": [parent_folder_id]}
    q = f"'{parent_folder_id}' in parents and name = '{filename}' and trashed = false"
    existing = drive.files().list(q=q, fields="files(id,name,mimeType)").execute().get("files", [])
    if existing:
        # If existing file was converted to Google Doc previously, delete it and create fresh as docx
        fid = existing[0]["id"]
        mt = existing[0].get("mimeType", "")
        if mt != "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            drive.files().delete(fileId=fid).execute()
            existing = []
        else:
            drive.files().update(fileId=fid, media_body=media, body={"name": filename}).execute()
            link = f"https://docs.google.com/document/d/{fid}/edit"
            return {"file_id": fid, "name": filename, "link": link, "updated": True, "was_replaced": False}
    f = drive.files().create(body=body, media_body=media, fields="id,name").execute()
    link = f"https://docs.google.com/document/d/{f['id']}/edit"
    return {"file_id": f["id"], "name": f["name"], "link": link, "updated": False, "was_replaced": True}


def cmd_recap(args):
    brief = json.load(open(BRIEF_PATH))
    out = OUT_DIR / "recap.docx"
    out.parent.mkdir(parents=True, exist_ok=True)
    render_recap_docx(brief, out)
    print(f"✅ Wrote {out} ({out.stat().st_size} bytes)")
    if args.upload:
        creds = load_credentials(); drive = get_drive(creds)
        root = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
        day_folder = ensure_folder(drive, brief["meta"]["date_today"], parent_id=root)
        d = datetime.fromisoformat(brief["meta"]["date_today"])
        fname = f'Recap — {d.strftime("%d-%m-%Y")}'
        result = upload_docx(drive, out, fname, day_folder)
        print(json.dumps(result, ensure_ascii=False))
        log(f"Recap docx uploaded → {result['link']}")
    return 0


def cmd_prep(args):
    brief = json.load(open(BRIEF_PATH))
    out = OUT_DIR / "prep.docx"
    out.parent.mkdir(parents=True, exist_ok=True)
    render_prep_docx(brief, out)
    print(f"✅ Wrote {out} ({out.stat().st_size} bytes)")
    if args.upload:
        creds = load_credentials(); drive = get_drive(creds)
        root = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
        day_folder = ensure_folder(drive, brief["meta"]["date_today"], parent_id=root)
        d_target = datetime.fromisoformat(brief["meta"]["date_target_prep"])
        fname = f'Prep — {d_target.strftime("%d-%m-%Y")}'
        result = upload_docx(drive, out, fname, day_folder)
        print(json.dumps(result, ensure_ascii=False))
        log(f"Prep docx uploaded → {result['link']}")
    return 0


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    pr = sub.add_parser("recap"); pr.add_argument("--upload", action="store_true"); pr.set_defaults(func=cmd_recap)
    pp = sub.add_parser("prep"); pp.add_argument("--upload", action="store_true"); pp.set_defaults(func=cmd_prep)
    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
