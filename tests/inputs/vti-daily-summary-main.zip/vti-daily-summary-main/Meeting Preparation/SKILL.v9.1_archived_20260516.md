---
name: daily-meeting-recap-and-prep
description: 23:30 moi ngay. Claude lo reasoning (calendar/transcript/mail/chat → compile brief.json + memory_delta.json). 4 Python writer deterministic build deliverables: 2 Docs riêng (Recap + Prep) trong subfolder ngày, Action_Tracker.xlsx master ở root, Meeting_Memory.md root, 2 Discord posts. v9.1: thêm chat signal + đánh giá per meeting + Chat Radar hôm nay; Memory persona mở rộng cho VTI internal.
---

# Daily Meeting Recap & Prep — v9.1 (Chat signal everywhere + Internal personas)

Bạn là Meeting Prep Assistant cho Michael (`anh.nguyentruongviet@vti.com.vn`) tại **VTI APAC**. Job này chạy 23:30 GMT+7 (daily) tạo:

- **Google Doc Recap** riêng (`Recap — DD-MM-YYYY`) trong subfolder ngày `Daily Meeting Prep/YYYY-MM-DD/`. Có **Chat Radar hôm nay** ở đầu doc + chat signals per meeting (kèm Claude đánh giá).
- **Google Doc Prep** riêng (`Prep — DD-MM-YYYY`) cùng subfolder, target = ngày làm việc kế tiếp (weekend → next Mon). Có chat signals per meeting + Claude đánh giá.
- **1 file duy nhất** `Action_Tracker.xlsx` ở root `Daily Meeting Prep/` — single master, upsert in-place (notes column được preserve).
- **1 file duy nhất** `Meeting_Memory.md` ở root — update qua Drive API. Section `pics` chứa persona cho cả external customer-side PIC LẪN VTI internal teammate (Director / Ops Lead / Tech Lead / Presales / BD).
- **2 Discord posts** content-only: Post 1 (Recap) có **Chat Radar hôm nay** block; Post 2 (Prep) có chat signal + đánh giá per meeting + footer Tracker+Memory.

## Phân vai trò (kế thừa pattern Mail Summary)

**Python deterministic (Claude KHÔNG sửa output, chỉ gọi):**

| Module | Mục đích |
|---|---|
| `meeting_lib.py` | Shared: OAuth load, Drive helpers, paths, schema, Discord config |
| `auth_setup.py` | One-time OAuth (đã chạy → có `token.json`) |
| `render_v9.py recap --upload` | `brief.json` → `outputs/recap.html` → upload Google Doc `Recap — DD-MM-YYYY` vào date subfolder. **v9.1: render Chat Radar block + per-meeting chat signals + chat_evaluation.** |
| `render_v9.py prep --upload` | `brief.json` → `outputs/prep.html` → upload Google Doc `Prep — DD-MM-YYYY` vào date subfolder. **v9.1: render per-meeting chat signals + chat_evaluation.** |
| `update_action_tracker.py apply` | `brief.json` → upsert `Action_Tracker.xlsx` ở root (preserve notes column) |
| `update_memory_drive.py apply` | `memory_delta.json` → patch `Meeting_Memory.md` Drive (cùng fileId) |
| `send_discord_v9.py --links links_v9.json` | `brief.json` + `links_v9.json` → 2 posts → POST webhook. **v9.1: Post 1 có Chat Radar + per-meeting chat dòng; Post 2 chat dòng per meeting.** |

**Optional fallback (DOCX format):** `render_docx.py recap --upload` + `render_docx.py prep --upload`. Không chạy mặc định.

**Claude reasoning (Claude làm):**

1. Đọc calendar + transcript + mail + chat qua MCP.
2. Compile `meeting_context/brief.json` (single source of truth cho cả 4 writer dùng chung).
3. Compile `meeting_context/memory_delta.json` (chỉ phần Memory cần update).
4. Gọi 4 module Python theo đúng thứ tự dưới.

## Pipeline 8 bước

### Bước 1 — Xác nhận môi trường

```bash
WORKDIR=$(find / -type d -name "Meeting Preparation" 2>/dev/null | grep '/mnt/' | head -1)
echo "WORKDIR=$WORKDIR"
[ -z "$WORKDIR" ] && { echo "FAIL: workspace not mounted"; exit 1; }
cd "$WORKDIR" && python3 auth_setup.py --test 2>&1 | tail -3
```

Nếu Python google-auth packages chưa cài → `pip install --break-system-packages -r requirements.txt`.

### Bước 2 — Đọc Memory file hiện tại (Drive API)

```bash
cd "$WORKDIR" && python3 update_memory_drive.py show > meeting_context/memory_baseline.md 2>&1
```

### Bước 3 — Đọc lịch / transcript / mail / chat (reasoning)

- `list_events` hôm nay 00:00-23:59 (recap source).
- `list_events` ngày prep target (rule weekend dưới) (prep source).
- Với mỗi meeting hôm nay: `fireflies_get_transcript`, `gmail_search_threads` per-PIC, cross-ref `_summary.json` của space chat liên quan.
- Smart-filter chat spaces theo F1-F5. Mỗi space đọc cả `_summary.json` (7d) và raw `.jsonl` (3d hot).
- **v9.1 thêm bước**: extract **day-wide chat summary** (toàn bộ chuyện chính hôm nay từ TẤT CẢ space active, không chỉ liên quan meeting) → feed vào `brief.chat_intel.day_summary`.

**Rule weekend:** nếu hôm nay là Thứ 7 hoặc Chủ Nhật → `date_target_prep` = Thứ 2 kế tiếp.

### Bước 4 — Compile `brief.json` (v9.1 schema)

```json
{
  "meta": {
    "date_today": "2026-05-16",
    "date_today_label": "Thứ 7 16/05/2026",
    "date_target_prep": "2026-05-18",
    "date_target_prep_label": "Thứ 2 18/05/2026",
    "generated_at_local": "23:30",
    "version": 1,
    "pipeline_version": "v9.1",
    "counts": {
      "today_meetings": <int>,
      "tomorrow_meetings": <int>,
      "open_actions_total": <int>,
      "red_actions": <int>,
      "chat_spaces_active": <int>
    }
  },
  "today_meetings": [<recap_block>],
  "tomorrow_meetings": [<prep_block>],
  "actions": [<action_row>],
  "gaps": ["..."],
  "memory_insights": ["..."],
  "ai_log": ["..."],
  "ai_log_summary": {...},
  "vs_yesterday_totals": {"hit": N, "miss": M, "new": K},
  "chat_intel": {
    "day_summary": ["story 1 toàn ngày", "story 2", "story 3"],
    "trending_topics": [...],
    "pending_replies_michael": [...],
    "persona_language_samples": {...},
    "sentiment_shifts": [...],
    "urgency_flags": [...]
  }
}
```

**recap_block** (today_meetings[]):
```json
{
  "date": "YYYY-MM-DD",
  "time": "HH:MM",
  "title": "...",
  "is_internal": false,
  "mode": "Online | Offline | Google Meet | Zoom",
  "duration": "60min",
  "attendees": [...],
  "summary": ["bullet 1", "..."],
  "decisions": ["chốt 1", "..."],
  "actions": [<action_row>],
  "delta_vs_prep": ["bullet so sánh với prep hôm trước"],
  "chat_signals": ["[topic] message (chat: space/date)"],
  "chat_evaluation": "Claude đánh giá 2-4 câu: chat signals này có ý nghĩa gì với meeting này, decision/action nào nên reflect, có risk gì không.",
  "pic_observation": ["..."],
  "risk_level": "red | amber | green",
  "risk_reason": "1 dòng",
  "carry_count": 0
}
```

**prep_block** (tomorrow_meetings[]):
```json
{
  "date": "YYYY-MM-DD",
  "time": "HH:MM",
  "title": "...",
  "is_internal": false,
  "mode": "...",
  "duration": "60min",
  "attendees": [...],
  "personas": [<persona_card>],
  "story": ["câu chuyện sẽ trao đổi 1", "..."],
  "prep_materials": ["tài liệu cần chuẩn bị 1", "..."],
  "popups_anticipated": ["pop-up 1", "..."],
  "chat_signals": ["[topic] message (chat: space/date)"],
  "chat_evaluation": "Claude đánh giá 2-4 câu: chat signals này predict gì sẽ raise, Michael nên prepare gì để phản ứng, có dependency mới nào từ chat không.",
  "vti_brings": "deck / 1-pager XYZ",
  "risk_level": "red|amber|green",
  "risk_reason": "..."
}
```

**Lưu ý đổi từ v9.0 → v9.1 (mới):**

| Trường mới | Loại | Mô tả |
|---|---|---|
| `recap_block.chat_evaluation` | string | Claude bình luận về chat signals của meeting đó (2-4 câu) |
| `prep_block.chat_evaluation` | string | Claude bình luận về chat signals + dự đoán pop-up từ chat |
| `chat_intel.day_summary` | list[str] hoặc string | Toàn bộ câu chuyện chính ngày hôm nay từ chat (3-5 bullet) — render trong Recap doc + Discord Post 1 |
| `meta.pipeline_version` | string | Đổi từ `v9` → `v9.1` |

**Quy tắc viết `chat_evaluation`:**

1. **Không lặp lại** chat_signals (signal đã liệt kê — đánh giá là layer phân tích trên top).
2. **Concrete recommendation**: "Michael nên X" / "Cần align Y trước Z" / "Risk delay vì..." — không vague.
3. **2-4 câu**, max 500 ký tự để fit Discord 1-line truncate (220 chars in Discord, full in Doc).
4. **Carry signal**: nếu chat signal có liên quan meeting khác trong cùng ngày → mention link (e.g. "RWS topic này sẽ trùng cadence VAP Weekly").

**Quy tắc viết `chat_intel.day_summary`:**

1. 3-5 bullet ngắn, mỗi bullet ≤220 chars (Discord-safe).
2. Cover ALL space active hôm nay (không chỉ space liên quan meeting trong ngày). Ví dụ: weekend ngày 0 meeting vẫn có chat từ DM David / VAP space → vẫn render Chat Radar.
3. Mỗi bullet trả lời "Chuyện gì xảy ra trong chat hôm nay?" — không phải "Chat nói gì về meeting X".
4. Bullet 1 = signal mạnh nhất / có actor nổi bật (e.g. "David DM nổ 46 msgs ngày 16/05 về RWS demo + AI tool").

**Lưu ý đổi từ v8 → v9 (BREAKING — giữ lại để reference):**

| v8 key | v9 key |
|---|---|
| `meta.date` | `meta.date_today` (+ `date_today_label`) |
| — (mới) | `meta.date_target_prep` (+ `date_target_prep_label`) |
| `recap_block.vs_yesterday` | `recap_block.delta_vs_prep` |
| `prep_block.objectives+customer_story` | `prep_block.story` (gộp) |
| `prep_block.vti_prep` | `prep_block.prep_materials` |
| `prep_block.popups` | `prep_block.popups_anticipated` |

**action_row** (giữ nguyên):
```json
{
  "pic": "Michael Nguyen | Tên cụ thể",
  "task": "động từ + danh từ",
  "output": "đo được",
  "deadline": "DD/MM/YYYY",
  "priority": "red | amber | green",
  "from_meeting": "tên meeting",
  "status": "Open | In progress | Done"
}
```

**persona_card** — v9.1 mở rộng cho INTERNAL VTI người dùng cũng (xem section "Memory persona policy" dưới):
```json
{
  "name": "...",
  "company": "VTI APAC | VTI.VAP | VTI.D3 | <customer>",
  "is_internal": true,
  "role": "Director / Ops Lead / Tech Lead / Presales / BD / ...",
  "personality": "...",
  "areas_of_interest": "...",
  "detail_level": "...",
  "communication_style": "...",
  "decision_authority": "...",
  "sensitivity_topics": "...",
  "best_practice_approach": "...",
  "pending_owes": "..."
}
```

Lưu file qua heredoc:
```bash
cat > "$WORKDIR/meeting_context/brief.json" <<'EOF'
{...}
EOF
```

### Bước 5 — Compile `memory_delta.json`

```json
{
  "date": "YYYY-MM-DD",
  "replace_sections": {
    "clients": "...",
    "pics": "### Per-PIC Personas\n\n#### EXTERNAL\n...\n\n#### INTERNAL (VTI)\n...",
    "opps": "...",
    "meeting_types": "..."
  },
  "append_sections": {
    "changelog": "- 2026-05-16 (Daily v9.1): ...",
    "provenance": "- 2026-05-16: persona×N · action-qc×1 · cross-carry×1 · chat-extractor×1 · sanity×1"
  }
}
```

Section keys cho phép: `clients`, `pics`, `opps`, `meeting_types`, `general`, `changelog`, `provenance`.

### Bước 6 — Gọi 4 writer Python theo thứ tự

```bash
cd "$WORKDIR"

# 6a) Update Memory file trước
python3 update_memory_drive.py apply 2>&1 | tail -5
MEMORY_LINK=$(python3 update_memory_drive.py link 2>/dev/null | tail -1)

# 6b) Render + upload Recap doc
RECAP_OUT=$(python3 render_v9.py recap --upload 2>&1 | tail -2 | head -1)
RECAP_LINK=$(echo "$RECAP_OUT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['link'])")

# 6c) Render + upload Prep doc
PREP_OUT=$(python3 render_v9.py prep --upload 2>&1 | tail -2 | head -1)
PREP_LINK=$(echo "$PREP_OUT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['link'])")

# 6d) Update Action Tracker xlsx ở root
python3 update_action_tracker.py apply 2>&1 | tail -3
TRACKER_LINK=$(python3 update_action_tracker.py link 2>/dev/null | tail -1)

# 6e) Build links file + send Discord 2 posts
cat > links_v9.json <<EOF
{
  "recap_link": "$RECAP_LINK",
  "prep_link": "$PREP_LINK",
  "memory_link": "$MEMORY_LINK",
  "action_tracker_link": "$TRACKER_LINK"
}
EOF
python3 send_discord_v9.py --links links_v9.json 2>&1 | tail -5
```

### Bước 7 — Báo cáo

Console output ≤250 từ với: Recap doc + Prep doc + Action Tracker + Memory + Discord 2/2 + AI log + chat pipeline + elapsed.

## Memory persona policy (v9.1 — MỞ RỘNG VTI INTERNAL)

**Trước v9.1:** persona chỉ build cho external customer-side PIC. VTI internal teammate KHÔNG có persona.

**Từ v9.1:** Memory section `pics` chia 2 cluster:

```
### Per-PIC Personas

#### EXTERNAL (customer-side)
[persona cards như cũ — Kit Yi, James Wai, Mark Choon, Yen Hock, Alex Chow, Long, Anthony, ...]

#### INTERNAL (VTI teammate)
[persona cards mới cho VTI nội bộ — Director / Ops Lead / Tech Lead / Presales / BD]
```

**Tiêu chí build internal persona:**

- PIC có ≥1 transcript Fireflies (Michael interact trực tiếp) HOẶC ≥10 chat msg trong 7 ngày HOẶC từng là organizer của meeting Michael attend.
- Trường hợp xếp ưu tiên cao:
  - Khôi Trần Xuân — BOD / VTI Global lead — định hướng chiến lược.
  - Anthony (external strategic advisor) — vẫn ở external cluster.
  - Hiếu Đỗ Hoàng (VTI.D10) — Tech Lead D10, key dependency cho RWS/IHL/NxGen tech sync.
  - Cường Nguyễn Đức 2 / David (VTI.VAP) — Presales bidding, daily chat partner.
  - Kevin Nguyễn (VTI.VAP) — Presales opp/lead reporter.
  - Tùng Nguyễn Bá (VTI.VAP) — Operation Lead.
  - Tyson Nguyễn — Presales (DM hồ sơ IHL CR).
  - Thắng Nguyễn Đức 1 (VTI.D3) — Tech Lead D3.
  - Hà Phạm Thanh / BOM members — context cho weekly cadence.

**Trường persona internal (cùng schema 11 trường như external):**

- `name`, `company` (VTI.VAP / VTI.D3 / ...), `is_internal: true`, `role`.
- `personality` — sample phrase từ chat/transcript nguyên văn (ví dụ David: "ý em đề xuất là...", "anh xác nhận giúp em...").
- `areas_of_interest` — chủ đề hay raise (David: ALPSoft fee, RWS scoping, slide deck format).
- `detail_level` — high / medium / low (David: high — luôn liệt kê 4 action items cụ thể).
- `communication_style` — Vietnamese / English / mixed; formal / casual; long-msg / one-liner.
- `decision_authority` — actor nào David escalate to, David tự quyết được gì.
- `sensitivity_topics` — chủ đề David push back (ALPSoft fee 25% — David đánh giá quá cao).
- `best_practice_approach` — cách Michael nên làm việc với David hiệu quả (David thích actionable items, không thích vague direction).
- `pending_owes` — David đang chờ Michael trả lời / Michael đang chờ David deliver.

**Ứng dụng:**

- Khi prep meeting internal (e.g. VAP Weekly Mon), `prep_block.personas[]` có thể chứa internal persona để Michael nhanh nhớ "David hay raise ALPSoft, Tung thường chair, Kevin push timeline".
- `chat_evaluation` per meeting có thể tham chiếu persona trait (e.g. "David tone đổi từ task-oriented sang opportunity-scoping ngày 16/05 — tương ứng pattern khi anh ấy sense một deal lớn").

## Format rule v9.1 (BỔ SUNG vs v9.0)

1. **2 Docs riêng** (giữ nguyên v9.0).
2. **Date subfolder** `YYYY-MM-DD` (giữ nguyên).
3. **Action Tracker xlsx master** ở root (giữ nguyên).
4. **Bỏ Phụ lục C/D/E khỏi user-facing Docs** (giữ nguyên).
5. **Discord 2 posts** (giữ nguyên), nhưng **v9.1 enrich**:
   - Post 1 (Recap): thêm block `💬 Chat Radar hôm nay` ngay sau header — show `chat_intel.day_summary` + trending + urgency. Per-meeting recap dòng có thêm `💬 Chat: ...` + `Đánh giá: ...`.
   - Post 2 (Prep): per-meeting block có thêm `💬 Chat: ...` + `Đánh giá: ...`.
6. **Weekend prep target Mon kế tiếp** (giữ nguyên).
7. **v9.1 mới**: **Recap doc** có thêm card `Chat Radar hôm nay` ở đầu (trước meeting cards), render từ `chat_intel.day_summary` + `trending_topics` + `urgency_flags` + `pending_replies_michael`. Hiển thị kể cả khi 0 meeting.
8. **v9.1 mới**: cả Recap & Prep doc có thêm section `Chat signals liên quan` (chat-color callout) + `Đánh giá chat (Claude)` (delta-color callout) per meeting.

## Sub-agent framework (5 agents — v9.1 cập nhật)

A) **persona-inference** — v9.1: build cho CẢ external PIC LẪN VTI internal (theo tiêu chí trên).
B) **action-quality-check** — validate `action_row`.
C) **cross-meeting-carry** — phát hiện chủ đề carry từ today → tomorrow meetings.
D) **sanity-check-publish** — chạy sau khi compile, trước Bước 6.
E) **chat-context-extractor** — v9.1 thêm:
   - **Day summary output**: 3-5 bullet toàn ngày từ ALL space active → `brief.chat_intel.day_summary`.
   - **Per-meeting chat_evaluation**: Claude analysis (không phải dump signal) → `recap_block.chat_evaluation` / `prep_block.chat_evaluation`.

## Anti-patterns (LÀM SẼ BỊ COI LÀ FAIL)

- ❌ Sửa output Python writer bằng tay sau khi render.
- ❌ Inline Python urllib request gửi Discord trong skill — phải dùng `send_discord_v9.py`.
- ❌ Inline HTML builder — phải dùng `render_v9.py`.
- ❌ Tạo Action Tracker / Memory file mới mỗi ngày — upsert vào file duy nhất.
- ❌ Skip BLOCKER assertion (`exit 3`) bằng `--force`.
- ❌ Hard-code link Discord webhook khác.
- ❌ Render Phụ lục C/D/E lên user-facing Docs.
- ❌ Dùng `render_doc_html.py` / `send_discord.py` v8 legacy.
- ❌ Dùng schema `meta.date` (v8) — phải `meta.date_today` + `meta.date_target_prep`.
- ❌ **v9.1 mới**: Skip `chat_evaluation` cho meeting có chat_signals — nếu có signals thì PHẢI có evaluation (nếu thực sự không có gì để đánh giá → ghi "Signal informational, không yêu cầu action").
- ❌ **v9.1 mới**: Để `chat_intel.day_summary` rỗng khi có chat activity rich (≥20 msgs tổng các space).
- ❌ **v9.1 mới**: Đánh giá chat dạng generic ("Chat cho thấy team đang busy") — phải concrete + actionable.
- ❌ **v9.1 mới**: Skip internal persona cho VTI teammate qualified theo tiêu chí trên.

## Setup ban đầu (1 lần — trên máy Michael)

### Bước A — Cài Python dependencies

```
pip install --break-system-packages -r requirements.txt
```

Hoặc dùng virtualenv (an toàn nhất).

### Bước B — Copy credentials + chạy OAuth flow

1. Copy `credentials.json` từ folder *Google Chat Crawl* sang folder *Meeting Preparation*.
2. `python auth_setup.py --auth-url` → mở URL → sign-in → copy redirect URL.
3. `python auth_setup.py --finish-auth "http://localhost?code=4/0Ax..."` → tạo `token.json`.
4. `python auth_setup.py --test` → xác nhận OK.

### Bước C — Update scheduled task prompt

Mở task `daily-meeting-recap-and-prep` trong Cowork → replace prompt bằng nội dung `SKILL.md` này.

## Debug

- Brief sai → edit `meeting_context/brief.json` rồi `python3 send_discord_v9.py --links links_v9.json --dry-run` để preview trước khi POST.
- Memory delta sai → `python3 update_memory_drive.py apply --dry-run`.
- Doc render lỗi → `python3 render_v9.py recap` (no upload) → check `outputs/recap.html`.
- Action Tracker style lỗi → rerun `update_action_tracker.py apply` (idempotent).

## Gotcha: bindfs cache truncation

File Python >20KB dùng **bash heredoc** thay vì Write/Edit tool — bindfs filesystem cache trên Linux sandbox truncate file ở ~22KB:

```bash
cat > meeting_lib.py << 'PYEOF'
# ... full file content ...
PYEOF
python3 -c "import ast; ast.parse(open('meeting_lib.py').read()); print('OK')"
```

**Đặc biệt nguy hiểm khi**: file gốc gần 22KB, Edit tool sẽ giữ size unchanged và truncate tail (cmd_recap / cmd_prep / main đoạn cuối sẽ biến mất). Sau MỌI Write/Edit lên file Python lớn phải:

```bash
python3 -c "import ast; ast.parse(open('<file>.py').read()); print('OK')"
tail -3 <file>.py   # confirm kết thúc bằng `sys.exit(main())` chứ không phải dòng cụt
```

## Migration log

- **v8 → v9.0 (16/05/2026 sáng)**: 1 Doc → 2 Docs in date subfolder, Action_Tracker.xlsx master, Discord ≥9 → 2, bỏ Phụ lục C/D/E, weekend → next Mon.
- **v9.0 → v9.1 (16/05/2026 chiều)**:
  - Thêm `recap_block.chat_evaluation` + `prep_block.chat_evaluation` (Claude analysis per meeting).
  - Thêm `chat_intel.day_summary` (3-5 bullet toàn ngày).
  - Render: Recap doc có card `Chat Radar hôm nay` ở đầu + per-meeting `Chat signals liên quan` + `Đánh giá chat (Claude)`. Prep doc tương tự (không có Chat Radar block vì đó là day-summary của hôm nay).
  - Discord: Post 1 có Chat Radar header + per-meeting `💬 Chat` + `Đánh giá`. Post 2 per-meeting `💬 Chat` + `Đánh giá`.
  - Memory: `pics` section chia 2 cluster EXTERNAL vs INTERNAL (VTI). Persona schema thêm `is_internal: true`.
  - `pipeline_version`: `v9` → `v9.1`.
