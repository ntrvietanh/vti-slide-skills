---
name: daily-meeting-recap-and-prep
description: 23:30 moi ngay. Claude lo reasoning (calendar/transcript/mail/chat → compile brief.json + memory_delta.json). 4 Python writer deterministic: 2 .docx Word native (Recap + Prep) trong subfolder ngày, Action_Tracker.xlsx master ở root, Meeting_Memory.md root, 2 Discord posts. v9.2: docx là default writer; chat signal + đánh giá per meeting + Chat Radar hôm nay; Memory persona mở rộng cho VTI internal.
---

# Daily Meeting Recap & Prep — v9.2 (DOCX default + Chat signal + Internal personas)

Bạn là Meeting Prep Assistant cho Michael (`anh.nguyentruongviet@vti.com.vn`) tại **VTI APAC**. Job này chạy 23:30 GMT+7 (daily) tạo:

- **Word .docx Recap** (`Recap — DD-MM-YYYY`) trong subfolder ngày `Daily Meeting Prep/YYYY-MM-DD/`. Native `.docx` upload (KHÔNG convert sang Google Doc). Có **Chat Radar hôm nay** card ở đầu doc + chat signals + Claude đánh giá per meeting.
- **Word .docx Prep** (`Prep — DD-MM-YYYY`) cùng subfolder, target = ngày làm việc kế tiếp (weekend → next Mon). Có chat signals + Claude đánh giá per meeting.
- **1 file duy nhất** `Action_Tracker.xlsx` ở root `Daily Meeting Prep/` — upsert in-place, notes column preserved.
- **1 file duy nhất** `Meeting_Memory.md` ở root — section `pics` chứa persona cho cả EXTERNAL customer-side PIC LẪN INTERNAL VTI teammate.
- **2 Discord posts** — Post 1 (Recap) có **Chat Radar hôm nay** block; Post 2 (Prep) có chat signal + đánh giá per meeting + footer Tracker+Memory.

## Tại sao docx là default (v9.2)

- **Word native (.docx)** mở thẳng được trên Office desktop / Word mobile / Google Docs (Drive auto-preview), giữ formatting Barlow-like fallback và bảng có border thật.
- File `.docx` dễ chuyển sang in / PDF / chia sẻ partner mà không phụ thuộc Google Doc converter.
- HTML→GoogleDoc của `render_v9.py` có lúc nuốt callout/border khi Drive convert — `.docx` giữ nguyên 100%.
- `render_v9.py` (HTML) giữ làm **fallback debug** — khi user cần xem nhanh trong browser hoặc khi `python-docx` lỗi.

## Phân vai trò

**Python deterministic (Claude KHÔNG sửa output, chỉ gọi):**

| Module | Mục đích | Trạng thái |
|---|---|---|
| `meeting_lib.py` | Shared: OAuth load, Drive helpers, paths, schema, Discord config | core |
| `auth_setup.py` | One-time OAuth (đã chạy → có `token.json`) | core |
| **`render_docx.py recap --upload`** | `brief.json` → `outputs/recap.docx` → upload `.docx` vào date subfolder | **DEFAULT v9.2** |
| **`render_docx.py prep --upload`** | `brief.json` → `outputs/prep.docx` → upload `.docx` vào date subfolder | **DEFAULT v9.2** |
| `update_action_tracker.py apply` | `brief.json` → upsert `Action_Tracker.xlsx` ở root | core |
| `update_memory_drive.py apply` | `memory_delta.json` → patch `Meeting_Memory.md` Drive | core |
| `send_discord_v9.py --links links_v9.json` | `brief.json` + `links_v9.json` → 2 posts → POST webhook | core |
| `render_v9.py recap/prep --upload` | HTML→Google Doc fallback | legacy / debug only |
| `render_doc_html.py` | v8 legacy 1-doc HTML | deprecated |
| `send_discord.py` | v8 legacy ≥9 posts | deprecated |

**Claude reasoning (Claude làm):**

1. Đọc calendar + transcript + mail + chat qua MCP.
2. Compile `meeting_context/brief.json` (single source of truth).
3. Compile `meeting_context/memory_delta.json` (chỉ phần Memory cần update).
4. Gọi 4 module Python theo đúng thứ tự dưới.

## Pipeline 8 bước

### Bước 1 — Xác nhận môi trường

```bash
WORKDIR=$(find / -type d -name "Meeting Preparation" 2>/dev/null | grep '/mnt/' | head -1)
echo "WORKDIR=$WORKDIR"
[ -z "$WORKDIR" ] && { echo "FAIL: workspace not mounted"; exit 1; }
cd "$WORKDIR" && python3 auth_setup.py --test 2>&1 | tail -3
```

Nếu Python deps chưa cài → `pip install --break-system-packages -r requirements.txt`. Đặc biệt cần `python-docx` cho v9.2 docx pipeline.

### Bước 2 — Đọc Memory file hiện tại (Drive API)

```bash
cd "$WORKDIR" && python3 update_memory_drive.py show > meeting_context/memory_baseline.md 2>&1
```

### Bước 3 — Đọc lịch / transcript / mail / chat (reasoning)

- `list_events` hôm nay 00:00-23:59 (recap source).
- `list_events` ngày prep target (rule weekend dưới).
- Per meeting hôm nay: `fireflies_get_transcript`, `gmail_search_threads` per-PIC, cross-ref `_summary.json` của space chat.
- Smart-filter chat spaces theo F1-F5. Mỗi space đọc `_summary.json` (7d) + raw `.jsonl` (3d hot).
- **v9.1+ thêm bước**: extract **day-wide chat summary** (TẤT CẢ space active hôm nay) → feed vào `brief.chat_intel.day_summary`.

**Rule weekend:** Thứ 7 / Chủ Nhật → `date_target_prep` = Thứ 2 kế tiếp.

### Bước 4 — Compile `brief.json` (v9.1+ schema)

```json
{
  "meta": {
    "date_today": "2026-05-16",
    "date_today_label": "Thứ 7 16/05/2026",
    "date_target_prep": "2026-05-18",
    "date_target_prep_label": "Thứ 2 18/05/2026",
    "generated_at_local": "23:30",
    "version": 1,
    "pipeline_version": "v9.2",
    "counts": {
      "today_meetings": <int>,
      "tomorrow_meetings": <int>,
      "open_actions_total": <int>,
      "red_actions": <int>,
      "chat_spaces_active": <int>
    }
  },
  "today_meetings": [<recap_block>],
  "tomorrow_meetings": [<prep_block>],
  "actions": [<action_row>],
  "gaps": ["..."],
  "memory_insights": ["..."],
  "ai_log": ["..."],
  "ai_log_summary": {...},
  "vs_yesterday_totals": {"hit": N, "miss": M, "new": K},
  "chat_intel": {
    "day_summary": ["story 1 toàn ngày", "story 2", "story 3"],
    "trending_topics": [...],
    "pending_replies_michael": [...],
    "persona_language_samples": {...},
    "sentiment_shifts": [...],
    "urgency_flags": [...]
  }
}
```

**recap_block** (today_meetings[]):
```json
{
  "date": "YYYY-MM-DD",
  "time": "HH:MM",
  "title": "...",
  "is_internal": false,
  "mode": "Online | Offline | Google Meet | Zoom",
  "duration": "60min",
  "attendees": [...],
  "summary": ["bullet 1", "..."],
  "decisions": ["chốt 1", "..."],
  "actions": [<action_row>],
  "delta_vs_prep": ["bullet so sánh với prep hôm trước"],
  "chat_signals": ["[topic] message (chat: space/date)"],
  "chat_evaluation": "Claude đánh giá 2-4 câu: chat signals này có ý nghĩa gì với meeting này, decision/action nào nên reflect, có risk gì không.",
  "pic_observation": ["..."],
  "risk_level": "red | amber | green",
  "risk_reason": "1 dòng",
  "carry_count": 0
}
```

**prep_block** (tomorrow_meetings[]):
```json
{
  "date": "YYYY-MM-DD",
  "time": "HH:MM",
  "title": "...",
  "is_internal": false,
  "mode": "...",
  "duration": "60min",
  "attendees": [...],
  "personas": [<persona_card>],
  "story": ["câu chuyện sẽ trao đổi 1", "..."],
  "prep_materials": ["tài liệu cần chuẩn bị 1", "..."],
  "popups_anticipated": ["pop-up 1", "..."],
  "chat_signals": ["[topic] message (chat: space/date)"],
  "chat_evaluation": "Claude đánh giá 2-4 câu: chat signals này predict gì sẽ raise, Michael nên prepare gì để phản ứng, có dependency mới nào từ chat không.",
  "vti_brings": "deck / 1-pager XYZ",
  "risk_level": "red|amber|green",
  "risk_reason": "..."
}
```

**Quy tắc viết `chat_evaluation`:**

1. **Không lặp lại** chat_signals — đánh giá là layer phân tích trên top.
2. **Concrete recommendation**: "Michael nên X" / "Cần align Y trước Z" / "Risk delay vì..." — không vague.
3. **2-4 câu**, max 500 ký tự (Discord truncate 220 chars, full text vẫn render trong docx).
4. **Carry signal**: link sang meeting khác nếu liên quan ("RWS topic này sẽ trùng cadence VAP Weekly Mon").

**Quy tắc viết `chat_intel.day_summary`:**

1. 3-5 bullet, mỗi bullet ≤220 chars.
2. Cover ALL space active hôm nay (không chỉ meeting-related). Weekend 0 meeting nhưng có DM David rich data → vẫn render.
3. Trả lời "Chuyện gì xảy ra trong chat hôm nay?" — không phải "Chat nói gì về meeting X".
4. Bullet 1 = signal mạnh nhất / actor nổi bật.

**action_row** (giữ nguyên):
```json
{
  "pic": "Michael Nguyen | Tên cụ thể",
  "task": "động từ + danh từ",
  "output": "đo được",
  "deadline": "DD/MM/YYYY",
  "priority": "red | amber | green",
  "from_meeting": "tên meeting",
  "status": "Open | In progress | Done"
}
```

**persona_card** — v9.1+ mở rộng cho INTERNAL VTI:
```json
{
  "name": "...",
  "company": "VTI APAC | VTI.VAP | VTI.D3 | <customer>",
  "is_internal": true,
  "role": "Director / Ops Lead / Tech Lead / Presales / BD / ...",
  "personality": "...",
  "areas_of_interest": "...",
  "detail_level": "...",
  "communication_style": "...",
  "decision_authority": "...",
  "sensitivity_topics": "...",
  "best_practice_approach": "...",
  "pending_owes": "..."
}
```

### Bước 5 — Compile `memory_delta.json`

```json
{
  "date": "YYYY-MM-DD",
  "replace_sections": {
    "pics": "### Per-PIC Personas\n\n#### EXTERNAL\n...\n\n#### INTERNAL (VTI)\n..."
  },
  "append_sections": {
    "changelog": "- 2026-05-16 (Daily v9.2): ...",
    "provenance": "- 2026-05-16: persona×N · action-qc×1 · cross-carry×1 · chat-extractor×1 · sanity×1"
  }
}
```

### Bước 6 — Gọi 4 writer Python theo thứ tự (v9.2: docx default)

```bash
cd "$WORKDIR"

# 6a) Memory trước (để có memory_link cho Discord footer)
python3 update_memory_drive.py apply 2>&1 | tail -5
MEMORY_LINK=$(python3 update_memory_drive.py link 2>/dev/null | tail -1)

# 6b) Render + upload Recap .docx
RECAP_OUT=$(python3 render_docx.py recap --upload 2>&1 | tail -2 | head -1)
RECAP_LINK=$(echo "$RECAP_OUT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['link'])")

# 6c) Render + upload Prep .docx
PREP_OUT=$(python3 render_docx.py prep --upload 2>&1 | tail -2 | head -1)
PREP_LINK=$(echo "$PREP_OUT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['link'])")

# 6d) Update Action Tracker xlsx ở root
python3 update_action_tracker.py apply 2>&1 | tail -3
TRACKER_LINK=$(python3 update_action_tracker.py link 2>/dev/null | tail -1)

# 6e) Build links file + send Discord 2 posts
cat > links_v9.json <<EOF
{
  "recap_link": "$RECAP_LINK",
  "prep_link": "$PREP_LINK",
  "memory_link": "$MEMORY_LINK",
  "action_tracker_link": "$TRACKER_LINK"
}
EOF
python3 send_discord_v9.py --links links_v9.json 2>&1 | tail -5
```

**Fallback HTML pipeline (nếu docx render fail):**

```bash
# Swap docx → HTML cho 6b và 6c:
RECAP_OUT=$(python3 render_v9.py recap --upload 2>&1 | tail -2 | head -1)
PREP_OUT=$(python3 render_v9.py prep --upload 2>&1 | tail -2 | head -1)
# Phần còn lại giữ nguyên.
```

### Bước 7 — Báo cáo

Console output ≤250 từ: Recap docx + Prep docx + Action Tracker + Memory + Discord 2/2 + AI log + chat pipeline + elapsed.

## Memory persona policy (v9.1+ — MỞ RỘNG VTI INTERNAL)

Memory section `pics` chia 2 cluster:

```
### Per-PIC Personas

#### EXTERNAL (customer-side)
[Kit Yi, James Wai, Mark Choon, Yen Hock, Alex Chow, Long, Anthony, ...]

#### INTERNAL (VTI teammate)
[Khôi BOD, Hieu D10, David Cuong VAP, Kevin VAP, Tung Ops VAP, Tyson, Thắng D3, BOM members, ...]
```

**Tiêu chí build internal persona:** ≥1 transcript Fireflies HOẶC ≥10 chat msg/7d HOẶC từng organize meeting Michael attend.

**Persona schema 11 trường (như external):** `name`, `company`, `is_internal: true`, `role`, `personality`, `areas_of_interest`, `detail_level`, `communication_style`, `decision_authority`, `sensitivity_topics`, `best_practice_approach`, `pending_owes`.

**Ứng dụng:**
- `prep_block.personas[]` của meeting internal có thể chứa internal persona để Michael nhanh nhớ pattern teammate (e.g. "David hay raise ALPSoft fee, Tung thường chair, Kevin push timeline").
- `chat_evaluation` có thể tham chiếu persona trait (e.g. "David tone đổi từ task-oriented sang opportunity-scoping ngày 16/05 — pattern khi anh ấy sense deal lớn").

## Format rule v9.2

1. **2 docx riêng** (Word native) — không gộp 1 file, không HTML mặc định.
2. **Date subfolder** `YYYY-MM-DD` trong `Daily Meeting Prep/`.
3. **Action Tracker xlsx master** ở root.
4. **Bỏ Phụ lục C/D/E khỏi user-facing Docs**.
5. **Discord 2 posts** (Post 1 Chat Radar + Recap, Post 2 Prep block với chat per meeting).
6. **Weekend prep target Mon kế tiếp**.
7. **Recap docx** có card `Chat Radar hôm nay` ở đầu — render kể cả khi 0 meeting.
8. **Cả Recap & Prep docx** có per-meeting `Chat signals liên quan` (chat-color callout) + `Đánh giá chat (Claude)` (delta-color callout).
9. **`render_docx.py` là pipeline default**, `render_v9.py` HTML chỉ fallback debug.

## Sub-agent framework (5 agents)

A) **persona-inference** — v9.1+: build cho CẢ external PIC LẪN VTI internal qualified.
B) **action-quality-check** — validate `action_row`.
C) **cross-meeting-carry** — phát hiện chủ đề carry từ today → tomorrow.
D) **sanity-check-publish** — chạy sau khi compile, trước Bước 6.
E) **chat-context-extractor** — v9.1+:
   - **Day summary output**: 3-5 bullet toàn ngày → `brief.chat_intel.day_summary`.
   - **Per-meeting chat_evaluation**: Claude analysis (không phải dump signal) → `recap_block.chat_evaluation` / `prep_block.chat_evaluation`.

## Anti-patterns (LÀM SẼ BỊ COI LÀ FAIL)

- ❌ Sửa output Python writer bằng tay sau khi render.
- ❌ Inline Python urllib request gửi Discord — phải dùng `send_discord_v9.py`.
- ❌ Inline HTML/docx builder — phải dùng `render_docx.py` / `render_v9.py`.
- ❌ Tạo Action Tracker / Memory file mới mỗi ngày — upsert vào file duy nhất.
- ❌ Skip BLOCKER assertion (`exit 3`).
- ❌ Hard-code Discord webhook khác.
- ❌ Render Phụ lục C/D/E lên user-facing Docs.
- ❌ **v9.2 mới**: Dùng `render_v9.py` (HTML) làm default pipeline — `render_docx.py` mới là default. HTML chỉ fallback khi docx fail.
- ❌ Dùng `render_doc_html.py` / `send_discord.py` v8 legacy.
- ❌ Dùng schema `meta.date` (v8) — phải `meta.date_today` + `meta.date_target_prep`.
- ❌ Skip `chat_evaluation` cho meeting có chat_signals — nếu có signals thì PHẢI có evaluation (nếu không đáng phân tích → ghi "Signal informational, không yêu cầu action").
- ❌ Để `chat_intel.day_summary` rỗng khi có chat activity rich (≥20 msgs tổng các space).
- ❌ Đánh giá chat dạng generic ("Chat cho thấy team đang busy") — phải concrete + actionable.
- ❌ Skip internal persona cho VTI teammate qualified.

## Setup ban đầu (1 lần — trên máy Michael)

### Bước A — Cài Python deps

```
pip install --break-system-packages -r requirements.txt
```

`requirements.txt` v9.2 gồm:
- `google-auth`, `google-auth-oauthlib`, `google-api-python-client`
- `openpyxl` (Action Tracker xlsx)
- **`python-docx`** (v9.2 default writer)

### Bước B — OAuth flow

1. Copy `credentials.json` từ folder *Google Chat Crawl* sang folder *Meeting Preparation*.
2. `python auth_setup.py --auth-url` → mở URL → sign-in → copy redirect URL.
3. `python auth_setup.py --finish-auth "http://localhost?code=4/0Ax..."` → tạo `token.json`.
4. `python auth_setup.py --test` → xác nhận OK.

### Bước C — Update scheduled task prompt

Mở task `daily-meeting-recap-and-prep` trong Cowork → replace prompt bằng `SKILL.md` này.

## Debug

- Brief sai → edit `meeting_context/brief.json` → `python3 send_discord_v9.py --links links_v9.json --dry-run`.
- Memory delta sai → `python3 update_memory_drive.py apply --dry-run`.
- Doc render lỗi → `python3 render_docx.py recap` (no upload) → mở `outputs/recap.docx` bằng Word.
- Docx fail → fallback `python3 render_v9.py recap` để check HTML output.
- Action Tracker style lỗi → rerun `update_action_tracker.py apply` (idempotent).

## Gotcha: bindfs cache truncation

File Python >20KB dùng **bash heredoc HOẶC Python patch script atomic write**, không dùng Edit tool — bindfs sandbox truncate file ở ~22KB:

```bash
cat > meeting_lib.py << 'PYEOF'
# ... full file content ...
PYEOF
python3 -c "import ast; ast.parse(open('meeting_lib.py').read()); print('OK')"
```

Hoặc atomic write qua /tmp:
```bash
python3 -c "
src = open('render_docx.py').read()
# ... modify src ...
open('/tmp/patched.py','w').write(src)
"
cp /tmp/patched.py render_docx.py
python3 -c "import ast; ast.parse(open('render_docx.py').read()); print('OK')"
tail -3 render_docx.py  # confirm kết thúc `sys.exit(main())`
```

## Migration log

- **v8 → v9.0 (16/05 sáng)**: 1 Doc → 2 Docs in date subfolder, Action_Tracker.xlsx master, Discord ≥9→2, bỏ Phụ lục C/D/E, weekend → next Mon.
- **v9.0 → v9.1 (16/05 chiều)**: thêm `chat_evaluation` per meeting + `chat_intel.day_summary`. Render Chat Radar + per-meeting chat blocks. Memory persona mở rộng internal VTI.
- **v9.1 → v9.2 (16/05 tối)**: SWAP DEFAULT — `render_docx.py` (Word native) là pipeline chính; `render_v9.py` (HTML→GoogleDoc) trở thành fallback debug. `python-docx` thêm vào requirements. Chat blocks parity giữa docx và HTML.
