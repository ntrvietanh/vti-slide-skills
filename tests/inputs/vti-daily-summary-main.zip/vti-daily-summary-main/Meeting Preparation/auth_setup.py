#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""auth_setup.py — One-time OAuth flow để sinh token.json.

Usage:
  1. Copy `credentials.json` từ Google Chat Crawl project sang đây (cùng OAuth client).
  2. Run:  python auth_setup.py --auth-url
     → mở URL trong browser bằng VTI Workspace account, approve scopes.
     → browser redirect về http://localhost?code=... → copy FULL URL.
  3. Run:  python auth_setup.py --finish-auth "<full redirect URL>"
     → token.json được tạo + scope mở rộng từ Chat Crawl sang Drive/Docs/Calendar/Gmail.

Tái sử dụng được token cũ từ Chat Crawl nếu copy `token.json` từ đó sang,
NHƯNG vì scope mở rộng (drive full + calendar + gmail) → cần re-auth lần đầu.
Sau khi consent xong, refresh_token sẽ tự renew access token mãi.
"""

from __future__ import annotations

import os
# Must be set BEFORE importing google_auth_oauthlib — Google often returns extra
# scopes (openid, userinfo.email, userinfo.profile, drive.file) than we requested,
# and oauthlib strict-check raises Warning-as-error without this flag.
os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")
# Allow http://localhost redirect for OAuth installed-app flow
os.environ.setdefault("OAUTHLIB_INSECURE_TRANSPORT", "1")

import sys
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from meeting_lib import (
    CREDENTIALS_FILE,
    SCOPES,
    TOKEN_FILE,
    log,
)

OOB_REDIRECT_URI = "http://localhost"
PKCE_VERIFIER_FILE = Path(__file__).resolve().parent / ".pkce_verifier"


def _build_flow():
    from google_auth_oauthlib.flow import Flow

    if not CREDENTIALS_FILE.exists():
        raise FileNotFoundError(
            f"Missing {CREDENTIALS_FILE}. Copy credentials.json từ Google Chat Crawl."
        )
    return Flow.from_client_secrets_file(
        str(CREDENTIALS_FILE), scopes=SCOPES, redirect_uri=OOB_REDIRECT_URI
    )


def cmd_auth_url() -> int:
    flow = _build_flow()
    auth_url, _ = flow.authorization_url(
        access_type="offline", include_granted_scopes="true", prompt="consent"
    )
    verifier = getattr(flow, "code_verifier", None)
    if verifier:
        PKCE_VERIFIER_FILE.write_text(verifier, encoding="utf-8")
    print("\n" + "=" * 72)
    print("OPEN IN BROWSER (sign in with anh.nguyentruongviet@vti.com.vn):")
    print(auth_url)
    print("=" * 72)
    print(
        "\nAfter approving, browser will redirect to http://localhost?code=...\n"
        "Copy the FULL URL from address bar and run:\n"
        '  python auth_setup.py --finish-auth "<full URL>"\n'
    )
    return 0


def cmd_finish_auth(redirect_url: str) -> int:
    parsed = urlparse(redirect_url)
    code = parse_qs(parsed.query).get("code", [None])[0]
    if not code:
        print("ERROR: No ?code= in URL.", file=sys.stderr)
        return 2
    flow = _build_flow()
    if PKCE_VERIFIER_FILE.exists():
        flow.code_verifier = PKCE_VERIFIER_FILE.read_text(encoding="utf-8").strip()
    flow.fetch_token(code=code)
    TOKEN_FILE.write_text(flow.credentials.to_json(), encoding="utf-8")
    log(f"Token saved → {TOKEN_FILE}")
    print(f"\n✅ token.json created with scopes:\n  " + "\n  ".join(SCOPES))
    return 0


def cmd_test() -> int:
    """Quick smoke test: load creds → list Drive root → print user email."""
    from meeting_lib import load_credentials, get_drive

    creds = load_credentials()
    drive = get_drive(creds)
    about = drive.about().get(fields="user(emailAddress,displayName)").execute()
    print(f"✅ Drive auth OK: {about['user']['emailAddress']} ({about['user']['displayName']})")
    return 0


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__, file=sys.stderr)
        return 2
    cmd = args[0]
    if cmd == "--auth-url":
        return cmd_auth_url()
    if cmd == "--finish-auth":
        if len(args) < 2:
            print("ERROR: --finish-auth requires the redirect URL", file=sys.stderr)
            return 2
        return cmd_finish_auth(args[1])
    if cmd == "--test":
        return cmd_test()
    print(f"Unknown command: {cmd}", file=sys.stderr)
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
