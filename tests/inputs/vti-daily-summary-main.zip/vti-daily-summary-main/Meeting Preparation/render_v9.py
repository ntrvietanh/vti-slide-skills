#!/usr/bin/env python3
"""render_v9.py — v9.1 VTI-brand Drive-compatible Recap & Prep docs.

Style guide: VTI Brief Doc (navy header, bright blue accents, amber warnings,
section cards with top accent stripe, Drive-safe inline styles).
"""
from __future__ import annotations
import argparse, json, sys, base64
from datetime import datetime
from pathlib import Path
from html import escape as esc
from meeting_lib import (
    DRIVE_FOLDER_NAME, ensure_folder, get_drive, load_credentials, log,
    save_state, load_state,
)

ROOT = Path(__file__).resolve().parent
BRIEF_PATH = ROOT / "meeting_context" / "brief.json"
OUT_DIR = ROOT / "outputs"
LOGO_PATH = "/sessions/affectionate-sleepy-hamilton/mnt/.claude/skills/vti-brief-doc/assets/logos_b64.json"

# VTI brand palette (from vti-brief-doc skill)
C = {
    "navy":      "#051934",
    "blue":      "#004AAD",
    "bright":    "#0468E6",
    "sky":       "#0782FF",
    "light":     "#DAE9F6",
    "amber":     "#F8C379",
    "amber_dk":  "#6B3D00",
    "amber_bg":  "#FFFBF0",
    "white":     "#FFFFFF",
    "muted":     "#6B7A8D",
    "bg":        "#F0F5FB",
    "border":    "#C8DCF0",
    "green":     "#1A7A4A",
    "green_bg":  "#E6F4ED",
    "red":       "#B02020",
    "red_bg":    "#FFF0F0",
    "orange":    "#B05A00",
    "orange_bg": "#FFF4E6",
    "violet":    "#6B46C1",
    "violet_bg": "#F3EEFC",
    "chat":      "#1A7AB8",
    "chat_bg":   "#E8F4FB",
    "text":      "#1F2937",
    "text_lt":   "#4B5563",
}
FONT = "Arial, 'Helvetica Neue', sans-serif"  # Drive falls back to Arial regardless
FONT_HEAD = "Arial, 'Helvetica Neue', sans-serif"  # Drive doesn't support Barlow → use Arial bold

# Risk indicators (colored dot inside pill)
RISK_PILL = {
    "red":   f'<span style="display:inline-block;background:{C["red_bg"]};color:{C["red"]};border:1px solid {C["red"]};border-radius:11px;padding:2px 10px;font-size:11px;font-weight:bold;letter-spacing:0.04em;">● RED</span>',
    "amber": f'<span style="display:inline-block;background:{C["amber_bg"]};color:{C["amber_dk"]};border:1px solid {C["amber"]};border-radius:11px;padding:2px 10px;font-size:11px;font-weight:bold;letter-spacing:0.04em;">● AMBER</span>',
    "green": f'<span style="display:inline-block;background:{C["green_bg"]};color:{C["green"]};border:1px solid {C["green"]};border-radius:11px;padding:2px 10px;font-size:11px;font-weight:bold;letter-spacing:0.04em;">● GREEN</span>',
}

PRIORITY_PILL = {
    "red":   f'<span style="display:inline-block;background:{C["red_bg"]};color:{C["red"]};padding:1px 8px;border-radius:4px;font-size:11px;font-weight:bold;">RED</span>',
    "amber": f'<span style="display:inline-block;background:{C["amber_bg"]};color:{C["amber_dk"]};padding:1px 8px;border-radius:4px;font-size:11px;font-weight:bold;">AMBER</span>',
    "green": f'<span style="display:inline-block;background:{C["green_bg"]};color:{C["green"]};padding:1px 8px;border-radius:4px;font-size:11px;font-weight:bold;">GREEN</span>',
}


def _load_logo_b64():
    try:
        with open(LOGO_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def header(doc_title_main, doc_title_sub, accent_color=None):
    """Navy header bar with white VTI logo + title + accent stripe bottom."""
    accent = accent_color or C["bright"]
    logos = _load_logo_b64()
    logo_b64 = logos.get("logo-horizontal-white", "")
    logo_html = ""
    if logo_b64:
        logo_html = (
            f'<img src="data:image/png;base64,{logo_b64}" alt="VTI APAC" '
            f'style="height:32px;width:auto;vertical-align:middle;margin-right:14px;">'
        )
    return (
        f'<div style="background:{C["navy"]};padding:18px 28px;border-bottom:4px solid {accent};'
        f'margin-bottom:0;">'
        f'<div style="font-family:{FONT_HEAD};">'
        f'{logo_html}'
        f'<span style="display:inline-block;width:1px;height:22px;background:rgba(255,255,255,0.25);'
        f'vertical-align:middle;margin:0 14px 0 0;"></span>'
        f'<span style="color:#FFF;font-family:{FONT_HEAD};font-size:18px;font-weight:bold;'
        f'letter-spacing:0.08em;text-transform:uppercase;vertical-align:middle;">'
        f'{esc(doc_title_main)}</span>'
        f'<span style="color:{C["amber"]};font-family:{FONT_HEAD};font-size:18px;font-weight:bold;'
        f'letter-spacing:0.04em;vertical-align:middle;margin:0 8px;">·</span>'
        f'<span style="color:{C["light"]};font-family:{FONT_HEAD};font-size:14px;font-weight:normal;'
        f'letter-spacing:0.05em;vertical-align:middle;">{esc(doc_title_sub)}</span>'
        f'</div>'
        f'</div>'
    )


def meta_strip(items):
    """Light grey strip below header with metadata pills."""
    parts = []
    for label, value in items:
        parts.append(
            f'<span style="display:inline-block;margin-right:24px;font-family:{FONT};">'
            f'<span style="color:{C["muted"]};font-size:11px;letter-spacing:0.1em;'
            f'text-transform:uppercase;font-weight:bold;">{esc(label)}</span> '
            f'<span style="color:{C["navy"]};font-size:13px;font-weight:bold;">{value}</span>'
            f'</span>'
        )
    return (
        f'<div style="background:{C["bg"]};border-bottom:1px solid {C["border"]};'
        f'padding:12px 28px;font-family:{FONT};">{"".join(parts)}</div>'
    )


def card_open(title, accent=None):
    """Start a card section — top accent stripe + bordered container + header bar."""
    accent = accent or C["bright"]
    return (
        f'<div style="border:1px solid {C["border"]};border-top:4px solid {accent};'
        f'background:{C["white"]};margin:20px 0 0 0;">'
        f'<div style="padding:14px 24px 12px 24px;border-bottom:1px solid {C["border"]};">'
        f'<div style="font-family:{FONT_HEAD};font-size:14px;font-weight:bold;color:{C["navy"]};'
        f'letter-spacing:0.12em;text-transform:uppercase;">{esc(title)}</div>'
        f'</div>'
        f'<div style="padding:18px 24px;">'
    )


def card_close():
    return '</div></div>'


def section_label(text, color=None):
    """Small uppercase section label inside a card."""
    color = color or C["blue"]
    return (
        f'<div style="font-family:{FONT_HEAD};font-size:11px;font-weight:bold;color:{color};'
        f'letter-spacing:0.14em;text-transform:uppercase;margin:14px 0 6px 0;">{esc(text)}</div>'
    )


def para(text, color=None, italic=False, size=13):
    color = color or C["text"]
    istyle = "font-style:italic;" if italic else ""
    return (
        f'<p style="font-family:{FONT};font-size:{size}px;color:{color};margin:6px 0;'
        f'line-height:1.6;{istyle}">{text}</p>'
    )


def bullets(items, color=None, italic=False, size=13):
    """Hanging-indent bullet paragraphs (Drive-safe — no tables)."""
    if not items:
        return para("—", italic=True, color=C["muted"])
    color = color or C["text"]
    istyle = "font-style:italic;" if italic else ""
    return "".join(
        f'<p style="font-family:{FONT};font-size:{size}px;color:{color};'
        f'margin:5px 0 5px 22px;text-indent:-14px;line-height:1.6;{istyle}">• {it}</p>'
        for it in items
    )


def callout(body, kind="info"):
    """Sidebar callout with left accent border — Drive-friendly.
    kind: info (blue), warning (amber), success (green), delta (violet), chat (sky-blue)."""
    styles = {
        "info":    (C["light"],     C["blue"],   C["text"]),
        "warning": (C["amber_bg"],  C["amber"],  C["amber_dk"]),
        "success": (C["green_bg"],  C["green"],  C["text"]),
        "delta":   (C["violet_bg"], C["violet"], C["text"]),
        "chat":    (C["chat_bg"],   C["chat"],   C["text"]),
    }
    bg, border, fg = styles.get(kind, styles["info"])
    return (
        f'<div style="background:{bg};border-left:4px solid {border};padding:12px 16px;'
        f'margin:8px 0;color:{fg};font-family:{FONT};font-size:13px;line-height:1.6;">'
        f'{body}'
        f'</div>'
    )


def attendees_table(att_list, mode="recap"):
    """Attendees table with navy header, alternating row bg, explicit borders."""
    if not att_list:
        return para("—", italic=True, color=C["muted"])
    if mode == "recap":
        cols = ["Name", "Role (general)", "Role in meeting", "Company", "Int."]
        widths = ["22%", "22%", "26%", "20%", "10%"]
    else:
        cols = ["Name", "Role", "Company", "Persona summary"]
        widths = ["22%", "22%", "20%", "36%"]
    th = "".join(
        f'<th style="background:{C["navy"]};color:{C["white"]};font-family:{FONT};font-size:11px;'
        f'font-weight:bold;letter-spacing:0.08em;text-transform:uppercase;'
        f'padding:9px 12px;text-align:left;border:1px solid {C["navy"]};width:{w};">{esc(c)}</th>'
        for c, w in zip(cols, widths)
    )
    rows = []
    for i, a in enumerate(att_list):
        bg = C["white"] if i % 2 == 0 else C["bg"]
        if mode == "recap":
            internal_pill = (
                f'<span style="background:{C["light"]};color:{C["blue"]};padding:1px 7px;'
                f'border-radius:3px;font-size:10px;font-weight:bold;">VTI</span>'
                if a.get("internal")
                else f'<span style="background:{C["amber_bg"]};color:{C["amber_dk"]};padding:1px 7px;'
                     f'border-radius:3px;font-size:10px;font-weight:bold;">EXT</span>'
            )
            tds = [
                f'<b>{esc(a.get("name",""))}</b>',
                esc(a.get("role", "")),
                esc(a.get("role_in_meeting", "")),
                esc(a.get("company", "")),
                internal_pill,
            ]
        else:
            tds = [
                f'<b>{esc(a.get("name",""))}</b>',
                esc(a.get("role", "")),
                esc(a.get("company", "")),
                f'<i style="color:{C["text_lt"]};">{esc(a.get("persona_summary",""))}</i>',
            ]
        rows.append(
            "<tr>"
            + "".join(
                f'<td style="background:{bg};font-family:{FONT};font-size:12px;padding:8px 12px;'
                f'border:1px solid {C["border"]};vertical-align:top;color:{C["text"]};line-height:1.45;">{t}</td>'
                for t in tds
            )
            + "</tr>"
        )
    return (
        f'<table cellspacing="0" cellpadding="0" '
        f'style="border-collapse:collapse;width:100%;margin:8px 0;">'
        f'<thead><tr>{th}</tr></thead><tbody>{"".join(rows)}</tbody></table>'
    )


def actions_table(actions):
    """Actions table — Drive-safe."""
    if not actions:
        return para("—", italic=True, color=C["muted"])
    cols = ["PIC", "Task", "Output", "Deadline", "Priority"]
    widths = ["18%", "32%", "26%", "12%", "12%"]
    th = "".join(
        f'<th style="background:{C["navy"]};color:{C["white"]};font-family:{FONT};font-size:11px;'
        f'font-weight:bold;letter-spacing:0.08em;text-transform:uppercase;'
        f'padding:9px 12px;text-align:left;border:1px solid {C["navy"]};width:{w};">{esc(c)}</th>'
        for c, w in zip(cols, widths)
    )
    rows = []
    for i, a in enumerate(actions):
        bg = C["white"] if i % 2 == 0 else C["bg"]
        prio = a.get("priority", "").lower()
        tds = [
            f'<b>{esc(a.get("pic",""))}</b>',
            esc(a.get("task", "")),
            esc(a.get("output", "")),
            f'<b>{esc(a.get("deadline",""))}</b>',
            PRIORITY_PILL.get(prio, esc(a.get("priority",""))),
        ]
        rows.append(
            "<tr>"
            + "".join(
                f'<td style="background:{bg};font-family:{FONT};font-size:12px;padding:8px 12px;'
                f'border:1px solid {C["border"]};vertical-align:top;color:{C["text"]};line-height:1.45;">{t}</td>'
                for t in tds
            )
            + "</tr>"
        )
    return (
        f'<table cellspacing="0" cellpadding="0" '
        f'style="border-collapse:collapse;width:100%;margin:8px 0;">'
        f'<thead><tr>{th}</tr></thead><tbody>{"".join(rows)}</tbody></table>'
    )


def meeting_header_strip(meeting, accent):
    """Strip at top of each meeting card: time, title, mode, risk pill."""
    risk = meeting.get("risk_level", "green")
    return (
        f'<div style="background:{accent};color:{C["white"]};padding:12px 18px;'
        f'margin:0 0 14px 0;border-left:5px solid {C["navy"]};">'
        f'<table cellspacing="0" cellpadding="0" style="width:100%;border:none;">'
        f'<tr>'
        f'<td style="width:78%;border:none;font-family:{FONT_HEAD};font-size:15px;'
        f'font-weight:bold;color:{C["white"]};letter-spacing:0.03em;">'
        f'<span style="background:rgba(255,255,255,0.18);padding:2px 9px;border-radius:3px;'
        f'font-size:12px;font-weight:bold;letter-spacing:0.05em;margin-right:10px;">{esc(meeting.get("time",""))}</span>'
        f'{esc(meeting.get("title",""))}'
        f'</td>'
        f'<td style="width:22%;border:none;text-align:right;">{RISK_PILL.get(risk,"")}</td>'
        f'</tr>'
        f'</table>'
        f'<div style="font-family:{FONT};font-size:11px;color:{C["light"]};margin-top:6px;'
        f'letter-spacing:0.04em;">{esc(meeting.get("mode",""))} · {esc(meeting.get("duration",""))}'
        f' · <i>{esc(meeting.get("risk_reason",""))}</i></div>'
        f'</div>'
    )


# ---------------------------------------------------------------------------
# Chat signal blocks (v9.1)
# ---------------------------------------------------------------------------


def chat_block(meeting):
    """Render chat_signals[] + chat_evaluation cho 1 meeting.
    Returns empty string if both are missing."""
    signals = meeting.get("chat_signals") or []
    evaluation = (meeting.get("chat_evaluation") or "").strip()
    if not signals and not evaluation:
        return ""
    parts = []
    if signals:
        parts.append(section_label("Chat signals liên quan", color=C["chat"]))
        parts.append(callout(bullets([esc(s) for s in signals]), kind="chat"))
    if evaluation:
        parts.append(section_label("Đánh giá chat (Claude)", color=C["violet"]))
        parts.append(callout(para(esc(evaluation), color=C["text"]), kind="delta"))
    return "".join(parts)


def day_chat_summary_block(brief):
    """Render 'Chat Radar hôm nay' section ở đầu Recap doc.
    Reads brief.chat_intel.day_summary (string OR list) + trending_topics + urgency_flags.
    Returns empty string if no chat_intel data."""
    ci = brief.get("chat_intel") or {}
    day_summary = ci.get("day_summary")
    trending = ci.get("trending_topics") or []
    urgency = ci.get("urgency_flags") or []
    pending = ci.get("pending_replies_michael") or []
    if not (day_summary or trending or urgency or pending):
        return ""

    inner = []
    if day_summary:
        if isinstance(day_summary, list):
            inner.append(section_label("Câu chuyện chính hôm nay", color=C["chat"]))
            inner.append(bullets([esc(s) for s in day_summary]))
        else:
            inner.append(section_label("Câu chuyện chính hôm nay", color=C["chat"]))
            inner.append(para(esc(str(day_summary)), color=C["text"]))
    if trending:
        inner.append(section_label("Topic đang trending", color=C["chat"]))
        inner.append(bullets([esc(t) for t in trending]))
    if urgency:
        inner.append(section_label("Cảnh báo urgency", color=C["red"]))
        inner.append(callout(bullets([esc(u) for u in urgency]), kind="warning"))
    if pending:
        inner.append(section_label("Tin nhắn chờ Michael reply", color=C["amber_dk"]))
        inner.append(bullets([esc(p) for p in pending]))

    out = []
    out.append(card_open("Chat Radar hôm nay", accent=C["chat"]))
    out.append("".join(inner))
    out.append(card_close())
    return "".join(out)


# ---------------------------------------------------------------------------
# Top-level renderers
# ---------------------------------------------------------------------------


def render_recap(brief):
    m = brief["meta"]
    c = m["counts"]
    today = brief.get("today_meetings") or []
    parts = []
    parts.append(header("Daily Recap", m["date_today_label"], accent_color=C["bright"]))
    parts.append(meta_strip([
        ("Meetings", c["today_meetings"]),
        ("Decisions chốt", sum(len(t.get("decisions", [])) for t in today)),
        ("Actions opened", c["open_actions_total"]),
        ("Red", f'<span style="color:{C["red"]};">{c["red_actions"]}</span>'),
        ("Pipeline", m.get("pipeline_version", "v9")),
    ]))

    body_parts = []

    # Chat Radar hôm nay — render kể cả khi không có meeting (weekend chat still matters)
    radar = day_chat_summary_block(brief)
    if radar:
        body_parts.append(radar)

    if not today:
        body_parts.append(card_open("Tổng kết hôm nay", accent=C["muted"]))
        body_parts.append(callout(
            f'<b>Không có meeting hôm nay</b> — {esc(m["date_today_label"])} là cuối tuần / ngày nghỉ. '
            f'Pipeline vẫn cập nhật Action Tracker và Memory; xem Prep cho ngày làm việc kế.',
            kind="info"
        ))
        body_parts.append(card_close())
    else:
        for mtg in today:
            body_parts.append(card_open(mtg.get("title", "Meeting")))
            body_parts.append(meeting_header_strip(mtg, accent=C["blue"]))
            body_parts.append(section_label("Attendees & vai trò"))
            body_parts.append(attendees_table(mtg.get("attendees", []), mode="recap"))
            body_parts.append(section_label("Nội dung trao đổi"))
            body_parts.append(bullets([esc(s) for s in mtg.get("summary", [])]))
            body_parts.append(section_label("Chốt (decisions)", color=C["green"]))
            if mtg.get("decisions"):
                body_parts.append(callout(bullets([esc(d) for d in mtg["decisions"]]), kind="success"))
            else:
                body_parts.append(para("—", italic=True, color=C["muted"]))
            body_parts.append(section_label("Pending actions opened in this meeting"))
            body_parts.append(actions_table(mtg.get("actions", [])))
            body_parts.append(section_label("Delta vs Prep yesterday", color=C["violet"]))
            deltas = mtg.get("delta_vs_prep", []) or []
            if deltas:
                body_parts.append(callout(bullets([esc(d) for d in deltas]), kind="delta"))
            else:
                body_parts.append(para("Không có delta — meeting đi đúng prep hôm trước.", italic=True, color=C["muted"]))
            # Per-meeting chat signals + Claude đánh giá (v9.1)
            chat_html = chat_block(mtg)
            if chat_html:
                body_parts.append(chat_html)
            body_parts.append(card_close())

    body_parts.append(footer_html(brief))
    parts.append(f'<div style="background:{C["bg"]};padding:18px 24px;">{"".join(body_parts)}</div>')
    return wrap(parts)


def render_prep(brief):
    m = brief["meta"]
    c = m["counts"]
    tomorrow = brief.get("tomorrow_meetings") or []
    parts = []
    parts.append(header("Daily Prep", m["date_target_prep_label"], accent_color=C["bright"]))
    parts.append(meta_strip([
        ("Meetings", c["tomorrow_meetings"]),
        ("Open actions feeding", c["open_actions_total"]),
        ("Red", f'<span style="color:{C["red"]};">{c["red_actions"]}</span>'),
        ("Pipeline", m.get("pipeline_version", "v9")),
    ]))

    body_parts = []
    if not tomorrow:
        body_parts.append(card_open("Prep tomorrow", accent=C["muted"]))
        body_parts.append(callout(
            f'<b>Không có meeting trong {esc(m["date_target_prep_label"])}</b>.',
            kind="info"
        ))
        body_parts.append(card_close())
    else:
        for mtg in tomorrow:
            body_parts.append(card_open(mtg.get("title", "Meeting")))
            body_parts.append(meeting_header_strip(mtg, accent=C["blue"]))
            body_parts.append(section_label("Attendees"))
            body_parts.append(attendees_table(mtg.get("attendees", []), mode="prep"))
            body_parts.append(section_label("Câu chuyện sẽ trao đổi"))
            body_parts.append(bullets([esc(s) for s in mtg.get("story", [])]))
            body_parts.append(section_label("Tài liệu / nội dung cần chuẩn bị", color=C["blue"]))
            body_parts.append(callout(bullets([esc(p) for p in mtg.get("prep_materials", [])]), kind="info"))
            body_parts.append(section_label("Pop-ups dự kiến", color=C["amber_dk"]))
            body_parts.append(callout(bullets([esc(p) for p in mtg.get("popups_anticipated", [])]), kind="warning"))
            # Per-meeting chat signals + Claude đánh giá (v9.1)
            chat_html = chat_block(mtg)
            if chat_html:
                body_parts.append(chat_html)
            if mtg.get("vti_brings"):
                body_parts.append(section_label("VTI mang theo"))
                body_parts.append(para(f'<b>{esc(mtg["vti_brings"])}</b>'))
            body_parts.append(card_close())

    body_parts.append(footer_html(brief))
    parts.append(f'<div style="background:{C["bg"]};padding:18px 24px;">{"".join(body_parts)}</div>')
    return wrap(parts)


def footer_html(brief):
    m = brief["meta"]
    return (
        f'<div style="margin-top:28px;padding:14px 0;border-top:1px solid {C["border"]};'
        f'font-family:{FONT};font-size:11px;color:{C["muted"]};letter-spacing:0.04em;text-align:center;">'
        f'VTI APAC · Meeting Prep Assistant · Pipeline {m.get("pipeline_version","v9")} · '
        f'Generated {m["generated_at_local"]} ICT · v{m["version"]}'
        f'</div>'
    )


def wrap(parts):
    return (
        f'<div style="font-family:{FONT};color:{C["text"]};max-width:1080px;margin:0 auto;">'
        f'{"".join(parts)}'
        f'</div>'
    )


# ---------------------------------------------------------------------------
# Upload helpers (unchanged from v9.0)
# ---------------------------------------------------------------------------


def upload_doc(drive, html, filename, parent_folder_id):
    """Upload HTML as a new Google Doc into parent_folder_id.
    If a doc with the same name exists in that folder, REPLACE (delete + recreate)
    so we have idempotent overwrites without spawning (v2)/(v3) duplicates."""
    from googleapiclient.http import MediaIoBaseUpload
    import io
    # Find existing
    q = (
        f"name = '{filename}' and "
        f"'{parent_folder_id}' in parents and "
        f"mimeType = 'application/vnd.google-apps.document' and trashed = false"
    )
    existing = drive.files().list(q=q, fields="files(id,name)", pageSize=5).execute().get("files", [])
    for f in existing:
        try:
            drive.files().delete(fileId=f["id"]).execute()
        except Exception:
            pass
    body = {
        "name": filename,
        "parents": [parent_folder_id],
        "mimeType": "application/vnd.google-apps.document",
    }
    media = MediaIoBaseUpload(io.BytesIO(html.encode("utf-8")), mimetype="text/html", resumable=False)
    f = drive.files().create(body=body, media_body=media, fields="id,name").execute()
    return {"file_id": f["id"], "name": f["name"], "link": f"https://docs.google.com/document/d/{f['id']}/edit", "updated": False}


def cmd_recap(args):
    brief = json.load(open(BRIEF_PATH))
    html = render_recap(brief)
    out = OUT_DIR / "recap.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"✅ Wrote {out} ({len(html)} chars)")
    if args.upload:
        creds = load_credentials(); drive = get_drive(creds)
        root = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
        day_folder = ensure_folder(drive, brief["meta"]["date_today"], parent_id=root)
        d = datetime.fromisoformat(brief["meta"]["date_today"])
        fname = f'Recap — {d.strftime("%d-%m-%Y")}'
        result = upload_doc(drive, html, fname, day_folder)
        print(json.dumps(result, ensure_ascii=False))
        log(f"Recap uploaded → {result['link']}")
    return 0


def cmd_prep(args):
    brief = json.load(open(BRIEF_PATH))
    html = render_prep(brief)
    out = OUT_DIR / "prep.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"✅ Wrote {out} ({len(html)} chars)")
    if args.upload:
        creds = load_credentials(); drive = get_drive(creds)
        root = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
        day_folder = ensure_folder(drive, brief["meta"]["date_today"], parent_id=root)
        d_target = datetime.fromisoformat(brief["meta"]["date_target_prep"])
        fname = f'Prep — {d_target.strftime("%d-%m-%Y")}'
        result = upload_doc(drive, html, fname, day_folder)
        print(json.dumps(result, ensure_ascii=False))
        log(f"Prep uploaded → {result['link']}")
    return 0


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    pr = sub.add_parser("recap"); pr.add_argument("--upload", action="store_true"); pr.set_defaults(func=cmd_recap)
    pp = sub.add_parser("prep"); pp.add_argument("--upload", action="store_true"); pp.set_defaults(func=cmd_prep)
    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
