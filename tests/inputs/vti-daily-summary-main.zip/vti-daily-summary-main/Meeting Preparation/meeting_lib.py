#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""meeting_lib.py — Shared utilities cho daily-meeting-recap-and-prep pipeline v8.

Phân vai trò (giống Mail Summary pattern):

  Python (deterministic, không reasoning):
    - meeting_lib.py        — shared: OAuth, Drive helpers, paths, schema
    - auth_setup.py         — one-time OAuth flow (run interactively)
    - render_doc_html.py    — brief.json → Doc HTML VTI brand
    - send_discord.py       — brief.json → 9 posts content-only → POST
    - update_memory_drive.py — memory_delta.json → patch single Meeting_Memory.md trên Drive

  Claude (reasoning):
    - Đọc calendar/transcript/mail/chat (qua MCP) → compile brief.json
    - Đọc memory_baseline.md → output memory_delta.json
    - 3 writer Python consume brief.json/memory_delta.json → deterministic output

Files quan trọng (trong workspace folder):
    credentials.json        — OAuth client (copy từ Google Chat Crawl)
    token.json              — access + refresh token (sau auth_setup)
    _state.json             — local state (memory_file_id, doc_folder_id, last_run)
    meeting_context/brief.json        — Claude's compiled brief
    meeting_context/memory_delta.json — Claude's memory section diff
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

# Relax OAuth scope strict-check — Google sometimes returns extra scopes
# (openid, userinfo.email, userinfo.profile, drive.file) than we requested.
# Without this, oauthlib raises Warning-as-error during token refresh.
os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

PROJECT_DIR = Path(__file__).resolve().parent
CREDENTIALS_FILE = PROJECT_DIR / "credentials.json"
TOKEN_FILE = PROJECT_DIR / "token.json"
STATE_FILE = PROJECT_DIR / "_state.json"
LOG_FILE = PROJECT_DIR / "run.log"

CONTEXT_DIR = PROJECT_DIR / "meeting_context"
BRIEF_PATH = CONTEXT_DIR / "brief.json"
MEMORY_DELTA_PATH = CONTEXT_DIR / "memory_delta.json"
MEMORY_BASELINE_PATH = CONTEXT_DIR / "memory_baseline.md"

OUTPUTS_DIR = PROJECT_DIR / "outputs"
DOC_HTML_PATH = OUTPUTS_DIR / "doc_daily.html"
DISCORD_POSTS_PATH = OUTPUTS_DIR / "discord_posts.json"

# Ensure dirs (safe even if exists)
for d in (CONTEXT_DIR, OUTPUTS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

LOCAL_TZ = timezone(timedelta(hours=7))  # Asia/Ho_Chi_Minh
MICHAEL_EMAILS = {
    "anh.nguyentruongviet@vti.com.vn",
    "michael.nguyen@vti.com.vn",
}
VTI_DOMAIN = "@vti.com.vn"

DRIVE_FOLDER_NAME = "Daily Meeting Prep"
MEMORY_FILE_NAME = "Meeting_Memory.md"

DISCORD_WEBHOOK = (
    "https://discord.com/api/webhooks/1503962837301858335/"
    "Z68O_mMa6vt7oXVdguhav9GQoDtKwnG3pwhZy3Zmb1AZUMlFC_QSh27rgihc2gxJkK4q"
)
DISCORD_USER_AGENT = "Mozilla/5.0 VTI-MeetingPrepBot/1.0 (+https://vti.com.vn)"
DISCORD_POST_MAX_CHARS = 2000

# OAuth scopes — superset of Chat Crawl scopes + drive (full, để update Memory file
# tạo bởi project khác nếu cần) + calendar.readonly (đọc lịch) + gmail.readonly (đọc mail).
# Vì Memory file luôn do app này tạo, drive.file đủ — nhưng dùng drive full để
# tương thích nếu Michael muốn move file thủ công.
SCOPES = [
    "https://www.googleapis.com/auth/chat.spaces.readonly",
    "https://www.googleapis.com/auth/chat.messages.readonly",
    "https://www.googleapis.com/auth/chat.memberships.readonly",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/directory.readonly",
    "https://www.googleapis.com/auth/contacts.readonly",
    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/gmail.readonly",
]

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------


def log(msg: str) -> None:
    ts = datetime.now(LOCAL_TZ).strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


# ---------------------------------------------------------------------------
# JSON I/O helpers
# ---------------------------------------------------------------------------


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_state() -> dict:
    return load_json(STATE_FILE, default={}) or {}


def save_state(state: dict) -> None:
    save_json(STATE_FILE, state)


# ---------------------------------------------------------------------------
# OAuth — same pattern as Google Chat Crawl crawl_gchat.py
# ---------------------------------------------------------------------------


def load_credentials():
    """Load Google OAuth credentials. Auto-refresh if expired.

    Raises FileNotFoundError if token.json missing → user must run auth_setup.py first.
    """
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
    except ImportError as e:
        raise RuntimeError(
            "Missing google-auth packages. Install: pip install --break-system-packages "
            "google-auth google-auth-oauthlib google-api-python-client"
        ) from e

    if not TOKEN_FILE.exists():
        raise FileNotFoundError(
            f"Missing {TOKEN_FILE.name} — run `python auth_setup.py` first."
        )
    creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)
    if not creds.valid:
        if creds.expired and creds.refresh_token:
            log("Refreshing OAuth token...")
            creds.refresh(Request())
            TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
        else:
            raise RuntimeError(
                "Credentials not refreshable — re-run `python auth_setup.py`."
            )
    return creds


def get_drive(creds):
    from googleapiclient.discovery import build
    return build("drive", "v3", credentials=creds, cache_discovery=False)


# ---------------------------------------------------------------------------
# Drive helpers (mirror Chat Crawl pattern — files().create / files().update)
# ---------------------------------------------------------------------------


def find_folder(drive, name: str, parent_id: str = "root") -> Optional[str]:
    """Find a folder by name under parent. Returns folder_id or None."""
    q = (
        f"name = '{name}' and "
        f"mimeType = 'application/vnd.google-apps.folder' and "
        f"'{parent_id}' in parents and trashed = false"
    )
    resp = drive.files().list(q=q, fields="files(id, name)", pageSize=10).execute()
    files = resp.get("files", [])
    return files[0]["id"] if files else None


def ensure_folder(drive, name: str, parent_id: str = "root") -> str:
    fid = find_folder(drive, name, parent_id)
    if fid:
        return fid
    body = {
        "name": name,
        "mimeType": "application/vnd.google-apps.folder",
        "parents": [parent_id],
    }
    f = drive.files().create(body=body, fields="id").execute()
    log(f"Created Drive folder '{name}' → {f['id']}")
    return f["id"]


def find_file(drive, name: str, parent_id: str) -> Optional[str]:
    q = (
        f"name = '{name}' and "
        f"'{parent_id}' in parents and trashed = false"
    )
    resp = drive.files().list(q=q, fields="files(id, name)", pageSize=10).execute()
    files = resp.get("files", [])
    return files[0]["id"] if files else None


def download_text(drive, file_id: str) -> Optional[str]:
    """Download a file's content as UTF-8 text. Returns None on error."""
    try:
        raw = drive.files().get_media(fileId=file_id).execute()
        return raw.decode("utf-8") if isinstance(raw, bytes) else raw
    except Exception as e:
        log(f"  ! download_text({file_id}): {e}")
        return None


def upload_text(
    drive,
    parent_id: str,
    filename: str,
    content: str,
    existing_id: Optional[str] = None,
    mimetype: str = "text/markdown",
) -> str:
    """Upload (create or update) a text file. If existing_id → update same file_id.

    Returns file_id of the resulting file (same as existing_id if provided).
    """
    from googleapiclient.http import MediaInMemoryUpload

    data = content.encode("utf-8")
    media = MediaInMemoryUpload(data, mimetype=mimetype, resumable=False)
    if existing_id:
        f = drive.files().update(
            fileId=existing_id, media_body=media, fields="id"
        ).execute()
    else:
        body = {"name": filename, "parents": [parent_id]}
        f = drive.files().create(
            body=body, media_body=media, fields="id"
        ).execute()
    return f["id"]


def upload_html_as_gdoc(
    drive,
    parent_id: str,
    filename: str,
    html_content: str,
) -> str:
    """Upload HTML and let Drive convert it to a native Google Doc.

    Returns the new Google Doc's file_id. Always creates a NEW doc per run
    (Doc Daily is versioned by name, never overwritten).
    """
    from googleapiclient.http import MediaInMemoryUpload

    data = html_content.encode("utf-8")
    media = MediaInMemoryUpload(data, mimetype="text/html", resumable=False)
    body = {
        "name": filename,
        "parents": [parent_id],
        "mimeType": "application/vnd.google-apps.document",
    }
    f = drive.files().create(body=body, media_body=media, fields="id, webViewLink").execute()
    return f["id"]


# ---------------------------------------------------------------------------
# Memory file resolution — single file pattern
# ---------------------------------------------------------------------------


def get_memory_file_id(drive, doc_folder_id: str) -> tuple[str, bool]:
    """Resolve the single Meeting_Memory.md fileId.

    Order:
      1. _state.json cache → verify still exists
      2. find_file in doc_folder
      3. create empty + cache

    Returns (file_id, was_created_now).
    """
    state = load_state()
    cached_id = state.get("memory_file_id")
    if cached_id:
        try:
            drive.files().get(fileId=cached_id, fields="id, trashed").execute()
            # verify not trashed
            meta = drive.files().get(fileId=cached_id, fields="trashed").execute()
            if not meta.get("trashed"):
                return cached_id, False
        except Exception:
            log(f"Cached memory_file_id {cached_id} no longer valid — re-resolving")

    found_id = find_file(drive, MEMORY_FILE_NAME, doc_folder_id)
    if found_id:
        state["memory_file_id"] = found_id
        save_state(state)
        return found_id, False

    # Create new with seed content
    seed = _memory_seed()
    new_id = upload_text(
        drive, doc_folder_id, MEMORY_FILE_NAME, seed, existing_id=None
    )
    state["memory_file_id"] = new_id
    save_state(state)
    log(f"Created new Meeting_Memory.md → {new_id}")
    return new_id, True


def _memory_seed() -> str:
    today = datetime.now(LOCAL_TZ).strftime("%d/%m/%Y")
    return f"""# Meeting Memory — VTI APAC

*Single consolidated memory file. Updated daily by `update_memory_drive.py`.*
*Created: {today}*

---

## 1. Per-Account profiles (Dimension 1)

<!-- BEGIN: clients -->
<!-- END: clients -->

## 2. Per-PIC personas (Dimension 2)

<!-- BEGIN: pics -->
<!-- END: pics -->

## 3. Per-Opportunity tracking (Dimension 3)

<!-- BEGIN: opps -->
<!-- END: opps -->

## 4. Per-Meeting-Type Patterns

<!-- BEGIN: meeting_types -->
<!-- END: meeting_types -->

## 5. General Insights

<!-- BEGIN: general -->
<!-- END: general -->

## 6. Change Log

<!-- BEGIN: changelog -->
<!-- END: changelog -->

## 7. AI Analysis Provenance

<!-- BEGIN: provenance -->
<!-- END: provenance -->
"""


# ---------------------------------------------------------------------------
# Markdown section patch — between `<!-- BEGIN: X -->` / `<!-- END: X -->`
# ---------------------------------------------------------------------------

_SECTION_RE = re.compile(
    r"(<!-- BEGIN: (?P<name>[a-zA-Z0-9_-]+) -->)(?P<body>.*?)(<!-- END: (?P=name) -->)",
    re.DOTALL,
)


def replace_section(markdown: str, name: str, new_body: str) -> str:
    """Replace content between BEGIN/END markers. Idempotent + safe.

    If section markers missing → append a new section at the end.
    """
    def _repl(m: re.Match) -> str:
        if m.group("name") != name:
            return m.group(0)
        # preserve newlines around body
        return f"{m.group(1)}\n{new_body.strip()}\n{m.group(4)}"

    out, n = _SECTION_RE.subn(
        lambda m: _repl(m) if m.group("name") == name else m.group(0),
        markdown,
        count=0,
    )
    if n == 0 or f"<!-- BEGIN: {name} -->" not in out:
        out = out.rstrip() + (
            f"\n\n## (Auto-added) {name}\n\n"
            f"<!-- BEGIN: {name} -->\n{new_body.strip()}\n<!-- END: {name} -->\n"
        )
    return out


def append_section(markdown: str, name: str, append_body: str) -> str:
    """Append (not replace) content inside a section, before END marker."""
    pattern = re.compile(
        r"(<!-- BEGIN: " + re.escape(name) + r" -->)(?P<body>.*?)(<!-- END: " + re.escape(name) + r" -->)",
        re.DOTALL,
    )

    def _repl(m: re.Match) -> str:
        existing = m.group("body").strip()
        combined = (existing + "\n\n" + append_body.strip()).strip() if existing else append_body.strip()
        return f"{m.group(1)}\n{combined}\n{m.group(3)}"

    new_md, n = pattern.subn(_repl, markdown, count=1)
    if n == 0:
        new_md = markdown.rstrip() + (
            f"\n\n## (Auto-added) {name}\n\n"
            f"<!-- BEGIN: {name} -->\n{append_body.strip()}\n<!-- END: {name} -->\n"
        )
    return new_md


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------


def slugify(s: str) -> str:
    s = unicodedata.normalize("NFKD", s)
    s = s.encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s or "untitled"


def shorten(s: str, n: int) -> str:
    s = (s or "").strip()
 