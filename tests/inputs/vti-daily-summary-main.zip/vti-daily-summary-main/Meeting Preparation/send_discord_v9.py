#!/usr/bin/env python3
"""send_discord_v9.py v9.4 — per-meeting bullets + Tracker link in footer."""
from __future__ import annotations
import argparse, json, sys, time, urllib.request, urllib.error
from pathlib import Path
from meeting_lib import DISCORD_WEBHOOK, DISCORD_USER_AGENT, log

ROOT = Path(__file__).resolve().parent
BRIEF_PATH = ROOT / "meeting_context" / "brief.json"
LINKS_PATH = ROOT / "links_v9.json"
MAX_POST_CHARS = 1900


def post(content, label):
    payload = json.dumps({"content": content, "username": "VTI Meeting Prep",
                          "allowed_mentions": {"parse": []}}).encode("utf-8")
    req = urllib.request.Request(DISCORD_WEBHOOK, data=payload, method="POST",
                                 headers={"Content-Type": "application/json",
                                          "User-Agent": DISCORD_USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            log(f"[{label}] HTTP {r.status} | {len(content)} chars")
            return r.status
    except urllib.error.HTTPError as e:
        log(f"[{label}] HTTP {e.code} ERROR: {e.read()[:200]}")
        return None


def _truncate(s, n):
    s = s.strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def _first_decision(decisions):
    if not decisions: return "—"
    return _truncate(decisions[0], 180)


def _summary_oneline(summary):
    if not summary: return "—"
    if len(summary) == 1:
        return _truncate(summary[0], 180)
    return _truncate(summary[0], 100) + " · " + _truncate(summary[1], 100)


def _persona_oneline(att):
    name = att.get("name", "")
    company = att.get("company", "")
    role = att.get("role", "")
    persona = att.get("persona_summary", "")
    if att.get("internal"):
        return f'{name} ({role})'
    base = f'{name} ({company}, {role})'
    if persona:
        return f'{base} — {_truncate(persona, 110)}'
    return base


def _split_evaluation(text):
    """v9.3.1: split chat_evaluation theo marker [likely]/Risk:/Michael nên → multi-line cho Discord."""
    import re
    if not text:
        return []
    patterns = [
        (r'\s+\[likely\]', '\n[likely]'),
        (r'\s+\[possible\]', '\n[possible]'),
        (r'\s+\[unlikely\]', '\n[unlikely]'),
        (r'\.\s+Risk:', '.\nRisk:'),
        (r'\.\s+Michael n[êe]n', lambda m: '.\n' + m.group(0).lstrip('. ').strip()),
    ]
    work = text
    for pat, repl in patterns:
        work = re.sub(pat, repl, work)
    return [s.strip() for s in work.split('\n') if s.strip()]


def _signal_lines(prefix, signals, top_n=2, max_each=260):
    """v9.3.1: render top N signals as indented bullets cho Discord."""
    out = []
    for s in signals[:top_n]:
        out.append(f'   • {prefix} {_truncate(s, max_each)}')
    return out




def build_recap_post(brief, recap_link):
    m = brief["meta"]
    today = brief.get("today_meetings") or []
    ci = brief.get("chat_intel") or {}
    lines = [f'📋 **Recap — {m["date_today_label"]}** ([Doc]({recap_link}))', '']

    # Day-wide chat radar (v9.1) — show ngay sau header, trước meeting list
    day_summary = ci.get("day_summary")
    trending = ci.get("trending_topics") or []
    urgency = ci.get("urgency_flags") or []
    if day_summary or trending or urgency:
        lines.append('💬 **Chat Radar hôm nay**')
        if day_summary:
            if isinstance(day_summary, list):
                for s in day_summary[:3]:
                    lines.append(f'   • {_truncate(s, 220)}')
            else:
                lines.append(f'   • {_truncate(str(day_summary), 320)}')
        if trending:
            top3 = [_truncate(t, 90) for t in trending[:3]]
            lines.append(f'   • Trending: {" · ".join(top3)}')
        if urgency:
            lines.append(f'   • ⚠️ Urgency: {_truncate(urgency[0], 220)}')
        lines.append('')

    if not today:
        lines.append('_Không có meeting hôm nay (cuối tuần / nghỉ lễ)._')
    else:
        for mtg in today:
            lines.append(f'• **{mtg.get("time","")} · {mtg.get("title","")}**')
            noidung = _summary_oneline(mtg.get("summary", []))
            chot = _first_decision(mtg.get("decisions", []))
            lines.append(f'   • Nội dung: {noidung}')
            lines.append(f'   • Chốt: {chot}')
            # Per-meeting mail + chat signals + đánh giá (v9.3.1 multi-line)
            for ln in _signal_lines('📧 Mail:', mtg.get("mail_signals") or [], top_n=2, max_each=240):
                lines.append(ln)
            for ln in _signal_lines('💬 Chat:', mtg.get("chat_signals") or [], top_n=2, max_each=240):
                lines.append(ln)
            eval_text = (mtg.get("chat_evaluation") or "").strip()
            if eval_text:
                lines.append('   • 🤔 Đánh giá:')
                for seg in _split_evaluation(eval_text):
                    lines.append(f'      ◦ {_truncate(seg, 320)}')
    return "\n".join(lines)


def build_prep_post(brief, prep_link, tracker_link, memory_link, include_footer=True):
    m = brief["meta"]
    tomorrow = brief.get("tomorrow_meetings") or []
    lines = [f'🎯 **Prep — {m["date_target_prep_label"]}** ([Doc]({prep_link}))', '']
    if not tomorrow:
        lines.append('_Không có meeting trong ngày prep target._')
    else:
        for mtg in tomorrow:
            risk = {'red':'🔴','amber':'🟡','green':'🟢'}.get(mtg.get('risk_level','green'),'')
            lines.append(f'• {risk} **{mtg.get("time","")} · {mtg.get("title","")}**')
            attendees = mtg.get("attendees", [])
            ext_picks = [a for a in attendees if not a.get("internal")][:3]
            if ext_picks:
                pic_strs = [_persona_oneline(a) for a in ext_picks]
                lines.append(f'   • PIC: {" / ".join(pic_strs)}')
            else:
                chair = next((a for a in attendees if "chair" in str(a.get("role_in_meeting","")).lower() or "organizer" in str(a.get("role","")).lower()), None)
                if chair:
                    lines.append(f'   • PIC: Internal ({len(attendees)} attendees, chair: {chair.get("name","")})')
                else:
                    lines.append(f'   • PIC: Internal ({len(attendees)} attendees)')
            story = mtg.get("story", [])
            if story:
                lines.append(f'   • Nội dung: {_summary_oneline(story)}')
            prep = mtg.get("prep_materials", [])
            if prep:
                lines.append(f'   • Chuẩn bị: {_truncate(prep[0], 180)}')
            # Per-meeting mail + chat signals + đánh giá (v9.3.1 multi-line)
            for ln in _signal_lines('📧 Mail:', mtg.get("mail_signals") or [], top_n=2, max_each=240):
                lines.append(ln)
            for ln in _signal_lines('💬 Chat:', mtg.get("chat_signals") or [], top_n=2, max_each=240):
                lines.append(ln)
            eval_text = (mtg.get("chat_evaluation") or "").strip()
            if eval_text:
                lines.append('   • 🤔 Đánh giá:')
                for seg in _split_evaluation(eval_text):
                    lines.append(f'      ◦ {_truncate(seg, 320)}')
    if include_footer:
        lines.append('')
        lines.append('━━━━━━━━━━━━━━━━')
        if tracker_link:
            lines.append(f'📊 **Action Tracker**: {tracker_link}')
        if memory_link:
            lines.append(f'🧠 **Memory**: {memory_link}')
    return "\n".join(lines)


def cmd_send(args):
    brief = json.load(open(BRIEF_PATH))
    links = json.load(open(args.links if args.links else LINKS_PATH))
    recap_link = links.get("recap_link", "")
    prep_link = links.get("prep_link", "")
    tracker_link = links.get("action_tracker_link", "")
    memory_link = links.get("memory_link", "")

    p1 = build_recap_post(brief, recap_link)
    p2 = build_prep_post(brief, prep_link, tracker_link, memory_link)

    if args.dry_run:
        print("=== POST 1 (Recap) ===")
        print(p1)
        print()
        print("=== POST 2 (Prep + footer) ===")
        print(p2)
        return 0

    # v9.3.1: if post exceeds MAX, smart-split by line preserving structure
    posts = []
    posts.append(("1 Recap", p1))
    if len(p2) <= MAX_POST_CHARS:
        posts.append(("2 Prep+Tracker+Memory", p2))
    else:
        # Split p2: keep header + first meeting bullet + footer in post 2a;
        # second meeting + footer in post 2b
        lines_p2 = p2.split("\n")
        # Find footer start (line with "━━━━")
        footer_start = next((i for i, l in enumerate(lines_p2) if "━━━" in l), None)
        body = lines_p2[:footer_start] if footer_start is not None else lines_p2
        footer = "\n".join(lines_p2[footer_start:]) if footer_start is not None else ""
        # Split body at meeting boundary "• 🔴/🟡/🟢"
        meeting_starts = [i for i, l in enumerate(body) if l.startswith("• ") and any(em in l for em in ("🔴","🟡","🟢"))]
        if len(meeting_starts) >= 2:
            mid = meeting_starts[1]
            header = "\n".join(body[:meeting_starts[0]])
            mtg1 = "\n".join(body[meeting_starts[0]:mid])
            mtg2 = "\n".join(body[mid:])
            posts.append(("2a Prep meeting 1", header + "\n" + mtg1))
            posts.append(("2b Prep meeting 2 + Tracker+Memory", header + "\n" + mtg2 + "\n" + footer))
        else:
            posts.append(("2 Prep (truncated)", p2[:MAX_POST_CHARS - 1] + "…"))

    ok = 0
    for label, content in posts:
        if len(content) > MAX_POST_CHARS:
            content = content[: MAX_POST_CHARS - 1] + "…"
        status = post(content, label)
        if status == 204:
            ok += 1
        time.sleep(0.8)
    total = len(posts)
    result = {"total": total, "ok": ok}
    print(json.dumps(result))
    return 0 if ok == total else 1


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--links", default=None)
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=cmd_send)
    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
