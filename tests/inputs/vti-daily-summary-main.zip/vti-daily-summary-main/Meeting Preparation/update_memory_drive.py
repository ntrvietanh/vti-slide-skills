#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""update_memory_drive.py — patch single Meeting_Memory.md on Drive (Google API).

Mục tiêu: thay vì tạo Memory Snapshot file mới mỗi ngày (pattern v7 cũ),
toàn bộ memory tích lũy nằm trong 1 file duy nhất `Meeting_Memory.md`
trên Drive (folder "Daily Meeting Prep"). Mỗi run:

  1. Resolve fileId (cache trong _state.json, fallback search, fallback create).
  2. download_text qua Drive API → markdown hiện tại.
  3. Apply memory_delta.json (Claude xuất ra: section nào replace, append, log change).
  4. upload_text với existing_id → SAME fileId, file persistent.
  5. Cache memory_file_id + memory_link vào _state.json.

memory_delta.json schema (Claude output):
  {
    "date": "2026-05-16",
    "replace_sections": {
      "clients": "<full markdown of section 1 — Per-Client Patterns>",
      "meeting_types": "<...>"
    },
    "append_sections": {
      "changelog": "- 16/05/2026 v23: added KGI ABC pattern (source: meeting today)",
      "provenance": "- 16/05/2026: persona-inference×3, chat-extractor×1, sanity×1"
    },
    "memory_link_hint": "optional — usually computed here"
  }

Subcommands:
  apply       — apply delta to Memory file on Drive
  show        — download current Memory file and print to stdout
  link        — print webViewLink (or computed URL) for current Memory file
  reset-seed  — overwrite Memory file with empty seed (rare; requires --confirm)
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from meeting_lib import (
    DRIVE_FOLDER_NAME,
    LOCAL_TZ,
    MEMORY_DELTA_PATH,
    MEMORY_FILE_NAME,
    _memory_seed,
    append_section,
    download_text,
    ensure_folder,
    get_drive,
    get_memory_file_id,
    load_credentials,
    load_json,
    load_state,
    log,
    replace_section,
    save_state,
    upload_text,
)


def _doc_view_link(file_id: str) -> str:
    # Markdown files on Drive — viewable as plain text. Drive auto-renders MD nicely.
    return f"https://drive.google.com/file/d/{file_id}/view"


def cmd_apply(args: argparse.Namespace) -> int:
    delta_path = Path(args.delta) if args.delta else MEMORY_DELTA_PATH
    delta = load_json(delta_path)
    if not delta:
        print(f"FAIL: memory_delta.json missing at {delta_path}", file=sys.stderr)
        return 2

    creds = load_credentials()
    drive = get_drive(creds)
    folder_id = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
    state = load_state()
    state["doc_folder_id"] = folder_id
    save_state(state)

    file_id, was_created = get_memory_file_id(drive, folder_id)

    if was_created:
        current = _memory_seed()
    else:
        current = download_text(drive, file_id) or _memory_seed()

    # Apply replace sections
    new_md = current
    for section, new_body in (delta.get("replace_sections") or {}).items():
        new_md = replace_section(new_md, section, new_body)

    # Apply append sections (timestamp prepended for changelog/provenance if missing)
    today_str = delta.get("date") or datetime.now(LOCAL_TZ).strftime("%Y-%m-%d")
    for section, append_body in (delta.get("append_sections") or {}).items():
        # If body doesn't start with a list marker / line, leave as-is.
        new_md = append_section(new_md, section, append_body)

    # Auto-stamp the file with a "Last updated" line at top, after the H1
    new_md = _stamp_last_updated(new_md, today_str)

    if args.dry_run:
        print(f"--- DRY RUN — would write {len(new_md)} chars to fileId={file_id} ---")
        print(new_md[:2000])
        print("---")
        return 0

    upload_text(drive, folder_id, MEMORY_FILE_NAME, new_md, existing_id=file_id, mimetype="text/markdown")
    link = _doc_view_link(file_id)
    state["memory_file_id"] = file_id
    state["memory_link"] = link
    state["memory_last_updated_at"] = datetime.now(LOCAL_TZ).isoformat()
    save_state(state)

    print(json.dumps(
        {"file_id": file_id, "link": link, "bytes": len(new_md), "was_created": was_created},
        ensure_ascii=False,
    ))
    log(f"Memory updated → {link} ({len(new_md)} bytes)")
    return 0


def _stamp_last_updated(markdown: str, date_str: str) -> str:
    """Add or replace a 'Last updated' line right under H1.

    Idempotent: if a 'Last updated' line already exists in the prelude,
    it's replaced. Otherwise inserted after the first H1.
    """
    import re

    lines = markdown.split("\n")
    out = []
    inserted = False
    found_existing = False
    for i, line in enumerate(lines):
        if line.lower().startswith("*last updated:"):
            out.append(f"*Last updated: {date_str}*")
            found_existing = True
        else:
            out.append(line)
        if not inserted and not found_existing and line.startswith("# ") and i + 1 < len(lines):
            # Insert after H1 + the next blank/italic line
            j = i + 1
            while j < len(lines) and (lines[j].strip() == "" or lines[j].lstrip().startswith("*")):
                # skip existing italic meta lines
                if not out[-1].startswith("# "):
                    pass
                # We will insert before the H2 heading
                break
    if not found_existing:
        # Simple insertion after first H1 line
        for i, line in enumerate(out):
            if line.startswith("# "):
                # find end of meta block
                j = i + 1
                while j < len(out) and (out[j].strip() == "" or out[j].lstrip().startswith("*")):
                    j += 1
                stamp = f"*Last updated: {date_str}*"
                out.insert(j, stamp)
                if j > 0 and out[j - 1].strip() != "":
                    out.insert(j, "")
                break
    return "\n".join(out)


def cmd_show(args: argparse.Namespace) -> int:
    creds = load_credentials()
    drive = get_drive(creds)
    folder_id = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
    file_id, was_created = get_memory_file_id(drive, folder_id)
    content = download_text(drive, file_id) or "(empty)"
    print(content)
    return 0


def cmd_link(args: argparse.Namespace) -> int:
    state = load_state()
    file_id = state.get("memory_file_id")
    if not file_id:
        # Resolve fresh
        creds = load_credentials()
        drive = get_drive(creds)
        folder_id = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
        file_id, _ = get_memory_file_id(drive, folder_id)
    print(_doc_view_link(file_id))
    return 0


def cmd_reset_seed(args: argparse.Namespace) -> int:
    if not args.confirm:
        print("Refusing to overwrite Memory file without --confirm", file=sys.stderr)
        return 2
    creds = load_credentials()
    drive = get_drive(creds)
    folder_id = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
    file_id, _ = get_memory_file_id(drive, folder_id)
    seed = _memory_seed()
    upload_text(drive, folder_id, MEMORY_FILE_NAME, seed, existing_id=file_id, mimetype="text/markdown")
    print(json.dumps({"file_id": file_id, "reset": True, "bytes": len(seed)}, ensure_ascii=False))
    log(f"Memory reset to seed → {file_id}")
    return 0


def main() -> int:
    p = argparse.ArgumentParser(description="Update single Meeting_Memory.md on Drive")
    sub = p.add_subparsers(dest="cmd", required=True)

    pa = sub.add_parser("apply", help="Apply memory_delta.json")
    pa.add_argument("--delta", help="Path to memory_delta.json")
    pa.add_argument("--dry-run", action="store_true")
    pa.set_defaults(func=cmd_apply)

    ps = sub.add_parser("show", help="Download + print current Memory file")
    ps.set_defaults(func=cmd_show)

    pl = sub.add_parser("link", help="Print webViewLink for current Memory file")
    pl.set_defaults(func=cmd_link)

    pr = sub.add_parser("reset-seed", help="Reset Memory file to empty seed")
    pr.add_argument("--confirm", action="store_true")
    pr.set_defaults(func=cmd_reset_seed)

    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
