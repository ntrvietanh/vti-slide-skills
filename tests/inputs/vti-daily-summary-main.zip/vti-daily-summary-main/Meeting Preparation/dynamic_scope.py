#!/usr/bin/env python3
"""dynamic_scope.py — v9.4 helper for daily-meeting-recap-and-prep.

Build meeting_context/dynamic_scope.json from calendar (today + target) + memory baseline.
The orchestrator + 4 sourcing sub-agents (F mail, G drive, H chat, I cross-day) consume
this file to template their prompts — NO hardcoded account/PIC/opp lists anywhere.

CLI:
  python3 dynamic_scope.py build \\
      --calendar-today meeting_context/calendar_today.json \\
      --calendar-target meeting_context/calendar_target.json \\
      --memory-baseline meeting_context/memory_baseline.md \\
      --out meeting_context/dynamic_scope.json

  python3 dynamic_scope.py --selftest      # parser smoke test, no API calls
  python3 dynamic_scope.py show <path>     # pretty-print a built dynamic_scope.json

Design rules:
  - ZERO hardcoded account/PIC/opp string literals. Everything derives from calendar + memory.
  - The only "always-on" list is internal_dm_top5 — and it is also derived from memory's
    INTERNAL persona section (by mention frequency), not from a constant.
  - Default time_windows are configuration, not data. Cap-related behavior lives in SKILL.md.
  - On empty input (no calendar, no memory baseline), emit a valid empty-shell JSON +
    a "gaps" array so downstream sourcing agents skip cleanly.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEFAULT_TIME_WINDOWS = {
    "mail_default": "30d",
    "mail_widen": ["60d", "180d", "no_bound"],
    "chat_summary": "30d",
    "chat_raw": "7d",
    "drive_modified": "60d",
    "cross_day_window": "30d",
}

# Domains considered "internal" to VTI — only used to classify is_internal,
# NOT to gate sourcing. Add via env or memory if your VTI footprint grows.
INTERNAL_DOMAIN_HINTS = ("vti.com.vn", "vti-apac.com", "vti.com.sg")

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


# ---------------------------------------------------------------------------
# Memory baseline parsing (markdown sections from Meeting_Memory.md)
# ---------------------------------------------------------------------------

def _slice_section(md: str, heading_prefix: str) -> str:
    """Return the body of the first H2/H3 section whose heading starts with prefix."""
    lines = md.splitlines()
    start = None
    for i, line in enumerate(lines):
        stripped = line.lstrip("#").strip()
        if line.startswith(("## ", "### ")) and stripped.lower().startswith(heading_prefix.lower()):
            start = i + 1
            break
    if start is None:
        return ""
    end = len(lines)
    base_level = lines[start - 1].count("#", 0, lines[start - 1].find(" "))
    for j in range(start, len(lines)):
        if lines[j].startswith("#"):
            level = lines[j].count("#", 0, lines[j].find(" "))
            if level <= base_level:
                end = j
                break
    return "\n".join(lines[start:end])


def _extract_account_blocks(clients_section: str) -> list[dict[str, Any]]:
    """Parse 'clients' section into list of account dicts."""
    accounts: list[dict[str, Any]] = []
    # Each account is its own H3 sub-heading "### N.K Name (Country) — Topic"
    block_starts = [m.start() for m in re.finditer(r"^### ", clients_section, re.MULTILINE)]
    block_starts.append(len(clients_section))
    for idx in range(len(block_starts) - 1):
        block = clients_section[block_starts[idx]:block_starts[idx + 1]]
        first_line = block.splitlines()[0] if block else ""
        # Strip leading "### N.K " prefix
        name = re.sub(r"^###\s+[\d.]+\s*", "", first_line).strip()
        if not name:
            continue
        # Domains: look for any @domain.tld inside the block, then unique
        emails = EMAIL_RE.findall(block)
        domains = sorted({e.split("@", 1)[1].lower() for e in emails
                          if not any(e.lower().endswith(d) for d in INTERNAL_DOMAIN_HINTS)})
        # Keywords: look for **Project** bold field bullets, **Topics frequently discussed**
        keywords: list[str] = []
        for label in ("Project", "Topics frequently discussed", "Sizing target"):
            mo = re.search(rf"\*\*{label}.*?\*\*[:：]?\s*(.+?)(?=\n\*\*|\n###|\Z)",
                           block, re.DOTALL)
            if mo:
                snippet = mo.group(1).strip()
                # Extract capitalized phrases and acronyms as keyword candidates
                for w in re.findall(r"\b[A-Z][A-Za-z0-9_-]{2,}\b", snippet):
                    if w not in keywords and len(w) < 30:
                        keywords.append(w)
        accounts.append({
            "name": name,
            "domains": domains,
            "keywords": keywords[:8],
            "source": "memory.clients",
        })
    return accounts


def _extract_pic_blocks(pics_section: str) -> list[dict[str, Any]]:
    """Parse 'pics' section (EXTERNAL + INTERNAL subsections) into list of PIC dicts."""
    pics: list[dict[str, Any]] = []
    # Walk by H4 "#### Name" entries
    block_starts = [m.start() for m in re.finditer(r"^#### ", pics_section, re.MULTILINE)]
    block_starts.append(len(pics_section))
    # Determine which subsection (EXTERNAL/INTERNAL) each H4 belongs to
    section_markers = list(re.finditer(r"^####?\s+(EXTERNAL|INTERNAL)", pics_section, re.MULTILINE))
    for idx in range(len(block_starts) - 1):
        pos = block_starts[idx]
        block = pics_section[pos:block_starts[idx + 1]]
        first_line = block.splitlines()[0]
        name_part = re.sub(r"^####\s+", "", first_line).strip()
        # name part may be "Mark Choon (Ufinity)" — split on " ("
        name = name_part.split(" (")[0].strip()
        if name.upper() in ("EXTERNAL", "INTERNAL"):
            continue
        # Determine is_internal by the nearest preceding subsection marker
        is_internal = False
        for m in section_markers:
            if m.start() <= pos:
                is_internal = "INTERNAL" in m.group(1).upper()
        # Email from block
        emails = EMAIL_RE.findall(block)
        email = emails[0] if emails else ""
        # Account hint: anything in parens after the name in the heading
        mo = re.search(r"\(([^)]+)\)", name_part)
        account_hint = mo.group(1).strip() if mo else ""
        pics.append({
            "name": name,
            "email": email,
            "account": account_hint,
            "is_internal": is_internal,
            "in_meeting_today": [],
            "in_meeting_target": [],
        })
    return pics


def _extract_opp_blocks(opps_section: str) -> list[dict[str, Any]]:
    """Parse 'opps' section into list of opp dicts."""
    opps: list[dict[str, Any]] = []
    block_starts = [m.start() for m in re.finditer(r"^### ", opps_section, re.MULTILINE)]
    block_starts.append(len(opps_section))
    for idx in range(len(block_starts) - 1):
        block = opps_section[block_starts[idx]:block_starts[idx + 1]]
        first_line = block.splitlines()[0]
        name = re.sub(r"^###\s+[\d.]+\s*", "", first_line).strip()
        if not name:
            continue
        # Stage line "**Stage**: proposal" etc
        stage = ""
        mo = re.search(r"\*\*Stage\*\*[:：]?\s*([^\n]+)", block)
        if mo:
            stage = mo.group(1).strip().split()[0].lower()
        # Account link
        account = ""
        mo = re.search(r"\*\*(?:Parent account|Account)\*\*[:：]?\s*([^\n]+)", block)
        if mo:
            account = mo.group(1).strip()
        opps.append({
            "name": name,
            "account": account,
            "stage": stage,
            "source": "memory.opps",
        })
    return opps


def _derive_internal_dm_top5(memory_md: str) -> list[str]:
    """Derive top-5 internal DM list by name frequency in memory baseline.

    No hardcoded list. If memory is empty, returns []. Downstream chat agent H
    treats empty list as 'scan all internal spaces in F4 instead of forcing F5'.
    """
    pics_section = _slice_section(memory_md, "per-pic personas") or _slice_section(memory_md, "pics")
    if not pics_section:
        return []
    internal_marker = re.search(r"####?\s+INTERNAL", pics_section, re.IGNORECASE)
    if not internal_marker:
        return []
    internal_body = pics_section[internal_marker.end():]
    names: list[str] = []
    for line in internal_body.splitlines():
        m = re.match(r"^####\s+([^()\n]+?)(?:\s*\(|$)", line)
        if m:
            names.append(m.group(1).strip())
    # Frequency across full memory body weights influence/activity
    freq = Counter()
    for n in names:
        freq[n] = memory_md.count(n)
    return [n for n, _ in freq.most_common(5)]


# ---------------------------------------------------------------------------
# Calendar parsing
# ---------------------------------------------------------------------------

def _parse_calendar(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    # Accept either {events: [...]} or [...] directly
    if isinstance(data, dict):
        events = data.get("events") or data.get("items") or []
    elif isinstance(data, list):
        events = data
    else:
        events = []
    return events


def _extract_attendee_emails(event: dict[str, Any]) -> list[str]:
    attendees = event.get("attendees") or []
    emails: list[str] = []
    for a in attendees:
        if isinstance(a, dict):
            email = a.get("email") or a.get("emailAddress") or ""
        else:
            email = str(a)
        if "@" in email:
            emails.append(email.lower())
    return emails


def _summarize_event(event: dict[str, Any]) -> str:
    title = event.get("summary") or event.get("title") or "(untitled)"
    start = event.get("start") or {}
    if isinstance(start, dict):
        dt = start.get("dateTime") or start.get("date") or ""
    else:
        dt = str(start)
    time_part = ""
    if "T" in dt:
        try:
            t = datetime.fromisoformat(dt.replace("Z", "+00:00"))
            time_part = t.strftime("%H:%M")
        except ValueError:
            time_part = ""
    return f"{time_part} {title}".strip()


# ---------------------------------------------------------------------------
# Build orchestration
# ---------------------------------------------------------------------------

def build_scope(calendar_today: Path | None,
                calendar_target: Path | None,
                memory_baseline: Path | None) -> dict[str, Any]:
    today_events = _parse_calendar(calendar_today)
    target_events = _parse_calendar(calendar_target)
    memory_md = memory_baseline.read_text(encoding="utf-8") if (memory_baseline and memory_baseline.exists()) else ""

    accounts_from_mem = _extract_account_blocks(
        _slice_section(memory_md, "per-client")
        or _slice_section(memory_md, "clients")
        or _slice_section(memory_md, "per-account")
        or _slice_section(memory_md, "1. per-account")
        or _slice_section(memory_md, "accounts")
    )
    pics_from_mem = _extract_pic_blocks(
        _slice_section(memory_md, "per-pic personas")
        or _slice_section(memory_md, "pics")
        or _slice_section(memory_md, "2. per-pic")
    )
    opps_from_mem = _extract_opp_blocks(
        _slice_section(memory_md, "opps")
        or _slice_section(memory_md, "opportunit")
        or _slice_section(memory_md, "per-opportunity")
        or _slice_section(memory_md, "3. per-opportunity")
    )

    # Walk events to (a) attach PICs to meetings, (b) discover unknown external attendees
    domain_to_account: dict[str, dict[str, Any]] = {}
    for acc in accounts_from_mem:
        for d in acc.get("domains", []):
            domain_to_account.setdefault(d.lower(), acc)

    email_to_pic: dict[str, dict[str, Any]] = {
        p["email"].lower(): p for p in pics_from_mem if p.get("email")
    }

    keywords_from_events: list[str] = []

    def attach(events: list[dict[str, Any]], slot: str) -> None:
        for ev in events:
            label = _summarize_event(ev)
            title = ev.get("summary") or ev.get("title") or ""
            for w in re.findall(r"\b[A-Z][A-Za-z0-9_-]{2,}\b", title):
                if w not in keywords_from_events and len(w) < 30:
                    keywords_from_events.append(w)
            for email in _extract_attendee_emails(ev):
                domain = email.split("@", 1)[1]
                if any(domain.endswith(d) for d in INTERNAL_DOMAIN_HINTS):
                    # internal attendee — register if not in memory
                    if email not in email_to_pic:
                        email_to_pic[email] = {
                            "name": email.split("@", 1)[0].replace(".", " ").title(),
                            "email": email,
                            "account": "VTI APAC",
                            "is_internal": True,
                            "in_meeting_today": [],
                            "in_meeting_target": [],
                        }
                    email_to_pic[email][slot].append(label)
                    continue
                # external — link to account by domain
                acc = domain_to_account.get(domain)
                if acc is None:
                    # Discover new account on the fly
                    acc = {
                        "name": domain.split(".")[0].title(),
                        "domains": [domain],
                        "keywords": [],
                        "source": "calendar.discovered",
                    }
                    accounts_from_mem.append(acc)
                    domain_to_account[domain] = acc
                if email not in email_to_pic:
                    email_to_pic[email] = {
                        "name": email.split("@", 1)[0].replace(".", " ").title(),
                        "email": email,
                        "account": acc["name"],
                        "is_internal": False,
                        "in_meeting_today": [],
                        "in_meeting_target": [],
                    }
                email_to_pic[email][slot].append(label)

    attach(today_events, "in_meeting_today")
    attach(target_events, "in_meeting_target")

    # Filter accounts/pics: include only those that have at least one signal
    # (in calendar today/target, or in memory active opp)
    active_account_names = set()
    for p in email_to_pic.values():
        if p["in_meeting_today"] or p["in_meeting_target"]:
            if p.get("account"):
                active_account_names.add(p["account"])
    for o in opps_from_mem:
        if o.get("stage") in ("discovery", "qualification", "proposal", "negotiation"):
            if o.get("account"):
                active_account_names.add(o["account"])

    accounts = [a for a in accounts_from_mem if a["name"] in active_account_names] or accounts_from_mem
    pics = list(email_to_pic.values())
    opps = [o for o in opps_from_mem if o.get("account") in active_account_names] or opps_from_mem

    # Global keyword pool = unique union of account.keywords + opp.keywords + event-derived
    keywords_global: list[str] = []
    for src in (keywords_from_events, *(a.get("keywords", []) for a in accounts), *(o.get("name", "").split() for o in opps)):
        for w in src:
            if w and w not in keywords_global:
                keywords_global.append(w)

    scope = {
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "accounts": accounts,
        "pics": pics,
        "opps": opps,
        "keywords_global": keywords_global[:30],
        "time_windows": DEFAULT_TIME_WINDOWS,
        "internal_dm_top5": _derive_internal_dm_top5(memory_md),
        "gaps": [],
    }

    if not pics and not accounts:
        scope["gaps"].append("Empty dynamic_scope: calendar+memory both empty")

    return scope


# ---------------------------------------------------------------------------
# Selftest
# ---------------------------------------------------------------------------

def selftest() -> int:
    """Smoke-test parser with synthetic markdown — verifies no hardcoded names leak in."""
    fake_memory = """## Clients

### 1.1 ExampleCo (SG) — AI delivery
**Project**: ABC platform with XYZ integration.
**Topics frequently discussed**: Scope, BRD, Roadmap.
Contact: alice@exampleco.com.

## Per-PIC Personas

#### EXTERNAL

#### Alice Q. Example (ExampleCo)
- *Role*: Director

#### INTERNAL

#### Bob Internal
- *Role*: Tech Lead
- Email: bob@vti.com.vn

## Opps

### 1.1 ExampleCo Platform Opp
**Parent account**: ExampleCo
**Stage**: proposal
"""
    fake_today = {"events": [{
        "summary": "ExampleCo BRD review",
        "start": {"dateTime": "2026-05-17T10:00:00+07:00"},
        "attendees": [{"email": "alice@exampleco.com"}, {"email": "bob@vti.com.vn"}],
    }]}
    tmp = Path("/tmp/dynamic_scope_selftest")
    tmp.mkdir(exist_ok=True)
    mem_path = tmp / "memory.md"
    cal_path = tmp / "today.json"
    mem_path.write_text(fake_memory, encoding="utf-8")
    cal_path.write_text(json.dumps(fake_today), encoding="utf-8")
    scope = build_scope(cal_path, None, mem_path)
    assert any(a["name"].lower().startswith("exampleco") for a in scope["accounts"]), \
        "ExampleCo should appear in accounts (from memory)"
    assert any(p["email"] == "alice@exampleco.com" for p in scope["pics"]), \
        "alice should be detected via calendar attendees"
    assert any(p["email"] == "bob@vti.com.vn" and p["is_internal"] for p in scope["pics"]), \
        "bob should be classified internal"
    assert scope["time_windows"]["mail_default"] == "30d"
    # Make sure NO hardcoded name like 'Ufinity', 'NxGen', 'AsiaPac' leaks
    serialized = json.dumps(scope)
    for forbidden in ("Ufinity", "NxGen", "AsiaPac", "Mark Choon"):
        assert forbidden not in serialized, f"Leaked hardcoded name: {forbidden}"
    print("OK: dynamic_scope.py CLI ready")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Build dynamic_scope.json for v9.4 sourcing agents.")
    sub = parser.add_subparsers(dest="cmd")

    pb = sub.add_parser("build", help="Build dynamic_scope.json from calendar + memory.")
    pb.add_argument("--calendar-today", type=Path, required=True)
    pb.add_argument("--calendar-target", type=Path, required=True)
    pb.add_argument("--memory-baseline", type=Path, required=True)
    pb.add_argument("--out", type=Path, default=Path("meeting_context/dynamic_scope.json"))

    ps = sub.add_parser("show", help="Pretty-print a dynamic_scope.json file.")
    ps.add_argument("path", type=Path)

    parser.add_argument("--selftest", action="store_true", help="Run parser selftest with synthetic data.")

    args = parser.parse_args()

    if args.selftest:
        return selftest()

    if args.cmd == "build":
        scope = build_scope(args.calendar_today, args.calendar_target, args.memory_baseline)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(scope, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Wrote {args.out} — accounts={len(scope['accounts'])} pics={len(scope['pics'])} "
              f"opps={len(scope['opps'])} keywords={len(scope['keywords_global'])}")
        if scope.get("gaps"):
            print("Gaps:", "; ".join(scope["gaps"]))
        return 0

    if args.cmd == "show":
        scope = json.loads(args.path.read_text(encoding="utf-8"))
        print(json.dumps(scope, indent=2, ensure_ascii=False))
        return 0

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
