/sessions/serene-great-hamilton/.local/lib/python3.10/site-packages/google/api_core/_python_version_support.py:273: FutureWarning: You are using a Python version (3.10.12) which Google will stop supporting in new releases of google.api_core once it reaches its end of life (2026-10-04). Please upgrade to the latest Python version, or at least Python 3.11, to continue receiving updates for google.api_core past that date.
  warnings.warn(message, FutureWarning)
# Meeting Memory — VTI APAC

*Single consolidated memory file. Updated daily by `update_memory_drive.py`.*
*Created: 16/05/2026*

*Last updated: 2026-05-17*
---

## 1. Per-Account profiles (Dimension 1)

<!-- BEGIN: clients -->
### KGI Securities / Ufinity

**Company snapshot**: KGI Securities = Singapore-based brokerage / retail futures trading. Ufinity = SI partner (Singapore-based). Project routed through Ufinity (Mark Choon commercial bridge).

**Account stage**: Active proposal — VTI BQ v2 submitted 14/05/2026 16:17 ICT. **Update 15-17/05**: BQ pivoted from v1.0 (ReactJS+AWS ap-southeast-1+Sumsub SGD 135K) to v2.0 (.NET MVC on-prem Windows/IIS/MSSQL SGD 199,500 = 52.25 MM), +39% — customer-driven infra rescope. Phase 0 demo target end-June 2026. Phase 1 launch 100 concurrent users ramp to 1,500 by Q4 2026. First contact via Ufinity ~Q1 2026.

**Decision-making**: Ufinity → KGI customer; Mark Choon owns commercial signoff; Yen Hock gates technical; final KGI finance review via Alex Chow involvement (Tue 12/05 first appearance). Procurement: direct (no public RFP). **Pattern observed**: Mark's 24h SLA on gap-list items is reliable — silence = signal.

**Budget cycle**: TBC — likely tied to KGI Securities fiscal year (Asia financial services typically Apr-Mar or Jan-Dec).

**Competitive landscape**: Unknown direct competitors yet — Ufinity holds the relationship. Risk: Ufinity may have alternative VTI-substitute SIs.

**Strategic priorities (customer)**: Centralized trading platform replace fragmented current state; MAS compliance posture; on-prem hosting preference (CONFIRMED 15/05 v2.0 BQ); multi-currency (SGD/USD/HKD) + multi-market (HK/TW future).

**Existing engagements (VTI)**: KGI Trading Platform (in proposal v2.0), CA Web sub-project (Ufinity portal — separate scope, BRD sent 14/05 night).

**Trigger events**: BRD CA Web v2 sent 14/05 night; **Mark hint 15/05 10:14 — Internet-facing Client Portal additional scope** (week 15/05). Customer fund verification policy = manual (no direct bank integration).

**Risk factors**: VTI no internal financial-domain SME → estimate risk; CA Web Q&A v2.0 still has 11 open questions to Ufinity since 14/05; estimate currently 38-42MM range with explicit assumption list; NinjaTrader SDK chart embed = Phase 1.5 split (not Phase 0 blocker). **New 15/05**: CA Web Portal scope creep without commercial gate.

**Account team org chart**: KGI side opaque (Yen Hock interfaces tech). Ufinity = Mark (commercial) + Yen Hock (tech) + Alex Chow (commercial finance). VTI = Tyson (Sales Mgr owner) + Hung Nguyen Duc / David (Lead Architect) + Son (FP) + Long Vu Thanh (SDK) + Hieu (chart) + Kevin (account) + Michael (sign-off).

**Recent activity (7d 11-17/05)**: 11/05 D9 internal CA Web BQ review → 12/05 UF×VTI CAWeb #1 10am + post-mortem 15:30 + CAWeb #2 with Alex Chow 16:00 + KGI Trading internal 17:00 → 13/05 2 internal reviews (16:00 + 21:00) → 14/05 UF/VTI KGI Trading joint 10am + post-mortem 21:00 + BQ v2 submitted 16:17 → 15/05 BRD sent + Mark Portal scope hint 10:14 + Yen Hock 18/05 morning window opened → 16-17/05 quiet weekend, awaiting Ufinity response. Mon 18/05 VAP Op meeting to align BQ v3 sequencing (due 20/05).

---

### NxGen Communications Pte Ltd

**Company snapshot**: Singapore SI, regional partner. Derrick Chong = MD; Ian Choy = Solution/Tech Lead.

**Account stage**: Active tender response. Capability assessment 14/05 → HDB AI Tender RFI received Fri 15/05 07:42 ICT (15 use cases, AWS deployment, AI Agentic Agent). Pipeline status: 'active tender response within 1 week' (target 22/05). First substantive contact 14/05.

**Decision-making**: Ian = technical recommendation authority; commercial via NxGen sales (TBC introduction post-proposal). **Pattern observed**: Ian delivers on time — 07:42 ICT Fri delivery of tender is reliable signal.

**Budget cycle**: TBC. Tender-driven (HDB).

**Competitive landscape**: HDB tender = multi-vendor (typical SG GovTech RFP). Specific competitors unknown — Ian to share post-RFI data.

**Strategic priorities (customer)**: HDB AI tender = 5-year contract, ~2,400 users / 1,000 concurrent, AWS+Azure GCC hybrid, ~30TB data 90% unstructured, Core+Specialized chatbots, 3 Agentic pilots, PQM upgrade from Mistral 7b to >90%, 4-tier man-day pricing.

**Existing engagements (VTI)**: HDB AI Tender BQ in production (4 deliverables required: Target Arch, Costing, Resource Plan, Prof Services Costing).

**Trigger events**: 14/05 13:30 NxGen×VTI Agentic AI exploration call (Fireflies notetaker active) → 15/05 RFI delivered → 22/05 BQ due.

**Risk factors**: 2 unresolved dependencies open since 14/05 — (1) MCP cloud-hosting clarification; (2) Aura Japanese case external sharing approval. Derrick Chong CV feedback stale 22-23/04 (~25d window) may indicate de-prioritization.

**Account team org chart**: NxGen = Ian Choy (Tech Lead, primary) + Derrick Chong (MD, secondary). VTI = Tyson (Sales owner) + Kevin (account) + D3 (Thang/Anh Tung — AI case study).

**Recent activity (7d)**: 11/05 cooling on Derrick CV feedback chase → 14/05 13:30 exploration call + Kevin's Agentic AI deck v2.0 sent 14/05 → 15/05 07:42 RFI delivered, xlsx attached → 16/05 Daniel/Tuan demo materials due → Mon 18/05 D3 sync 13:00 to consolidate case studies for BQ → 22/05 BQ deadline.

---

### AsiaPac (Keppel group) — IHL Portal / Ecommerce / Odoo migration

**Company snapshot**: Keppel-group SI. PIC Kit Yi sentiment shift past 14d: silent CC → active strategic driver.

**Account stage**: IHL Portal CR Part 1+2 (active discovery). **NEW strategic 15/05 — IHL Odoo Migration** (16 ecommerce sites; AWS infra estimate USD 5,202/yr; Tyson manager, Michael approver). Sentiment trend positive.

**Decision-making**: Kit Yi (primary driver post-15/05); James Wai (new SME); recurring Fri cadence PROPOSED 15/05 not yet booked.

**Budget cycle**: TBC.

**Competitive landscape**: Odoo SI competition — no incumbent moat (carry: cross-day).

**Strategic priorities (customer)**: IHL Portal accuracy + delivery status integration + Odoo migration strategic. SAP Ariba integration check — Keppel procurement-driven requirement; VTI capability NOT yet confirmed (AMBER).

**Existing engagements (VTI)**: IHL Portal CR Part 1 (data accuracy) + CR Part 2 (delivery status integration) + Odoo Migration NEW. Keppel Microsites (separate, scope clarified 08/04: VTI = app only, AsiaPac = infra). Keppel Bodyshop 2 HCs (delivery RISK — Rosie 14/05).

**Trigger events**: 15/05 IHL Portal CR call 14:00 + 14:52 (Fireflies recap) → Tyson invited Vuong follow-up → IHL CR3 spun up 15/05 → Odoo Migration NEW 15/05 → Kit Yi 5 deliverables owed by 22/05.

**Risk factors**: Ariba capability gap; Bodyshop delivery issue raised 14/05 (under-utilisation + customer-attribution); AR overdue (04/05 flag) blocking PSAM Y1-Q4 payment until VTI APAC bank re-opens (June 2026 ETA).

**Account team org chart**: AsiaPac = Kit Yi (driver) + James Wai (SME, new). VTI = Tyson (manager Odoo + IHL) + Michael (approver) + Kevin (relationship) + Vuong (PM follow-up).

**Recent activity (7d)**: 14/05 Rosie raised Bodyshop issue → 15/05 IHL CR call + Odoo NEW + Kit Yi 5 deliverables → 16-17/05 quiet weekend → Mon 18/05 internal scope alignment; Tue 19/05 1pm IHL estimation scheduled.

---

### Recruit Express

**Company snapshot**: Singapore EP/recruitment platform. PIC Karin.

**Account stage**: **Closure 15/05 08:30** — IT Professional Service Agreement Docusign-completed. First commercial-close milestone of week 11-15/05.

**Decision-making**: Karin (PIC); Charlotte (VTI commercial admin).

**Existing engagements (VTI)**: IT Professional Service Agreement (signed 15/05).

**Recent activity (7d)**: Charlotte sent Karin final draft Fri 15/05 AM → Docusign closed 15/05 08:30 → next: first delivery milestone planning.

---

### Sembcorp

**Company snapshot**: Singapore utilities; VTI relationship via IT Support Specialist + AMS support project.

**Account stage**: **Active rejection 15/05** — 2 VTI candidates rejected on English fluency (Việt + 1 other). Charlotte 2-option re-pitch needed by 21/05: (1) Fulltime native-EN search (Rec lead time ~4wk); (2) Partime VTI fallback with comtor.

**Decision-making**: Sembcorp = English-fluent gate; Cuong (VTI decision Op meeting 18/05) — Michael lean Option-1.

**Recent activity (7d)**: 20/04 sync-up about project info → 14/04 IT Support Specialist intro → 15/05 2 rejections → 21/05 re-pitch due.

---

### Mitsubishi Corporation (HCMC + SG branches)

**Company snapshot**: Japanese trading conglomerate; VTI engagement HCMC (Toàn placement) + SG (Kondo-san NEW 13/05).

**Account stage**: HCMC = Toàn placement confirmed; Charlotte HD template by 20/05. SG = Kondo-san WhatsApp 13/05 NEW; Kevin+Charlotte 2-option deck 16/05 verify; customer no anh Toàn, need Rec external + make-up CVs; window through Aug-Sep.

**Decision-making**: Charlotte (commercial); Kondo-san (SG PIC); MC HCMC PIC TBC; customer rejection power confirmed (Toàn rejection).

**Existing engagements (VTI)**: MC GenAI x NBD POC (warranty 06/03 → 05/06/2026 — wraps in 19d, continuation pitch state UNKNOWN). MC HCMC service trial 6 months OK confirmed 11/05.

**Risk factors**: MC SG candidate fit; HCMC contract template timing 20/05; AI training case D3 owns (decided 15/05, replaces D8 default).

---

### OBS / Orange Business Services

**Recent activity**: Capability deck (with case studies) sent 30/03 follow-up after SG mtg Mar 2026. AI capability follow-up template reference for HDB AI Tender effort.

---

### PSA Marine / PSAM Warehouse

**Account stage**: PSA Marine LFMS POC won 11/05 — kick-off Thu 21/05 10am SGT. First VTI APAC POC win in this segment. Internal review Tue 19/05. Delivery lead TBC.

**PSAM Warehouse**: BQ submitted 08/05 (R13 image AI scope). PMA/P360/Kafka maintenance Y1-Q4 payment blocked on VTI APAC bank re-opening (June 2026 ETA).

---

### Technovation (Malaysia / Penang) — Anthony intro

**Recent activity**: Explore collaboration 11/05; Kevin owes corp+AI deck 15/05 (verify Mon 18/05).

---

### Terrabit Networks — Anthony intro

**Recent activity**: NDA fully signed 13/05; ready for engagement.

---

### Resort World Sentosa (RWS) — Eslin (Anthony's personal connection)

**Recent activity**: RWS BA JD intro 14/05; demo request inbound vague 10→20 dev scale (chat: DM_Cuong/16-05). D3 supports if proceeds.

---

### Light pipeline (cross-day updates)

SWAT Mobility, Starhub, Wikilab (AIOps demo prep 21/04), Lucid Impact, B2B Commerce, Infinite Lab, GovTech rehearsal SG Hoàng Việt 07/05, Infor (Anthony intro 14/05), Concentrix (link 21/04), Dialogg AI (GITEX follow-up 08/05). See Anthony Fri sync recurring.
<!-- END: clients -->

## 2. Per-PIC personas (Dimension 2)

<!-- BEGIN: pics -->
### Per-PIC Personas

#### EXTERNAL (customer-side)

**Mark Choon (Ufinity, Account Director)**
- Role/scope: KGI Trading + CA Web commercial bridge
- Personality: Driver, decisive, pushes deadlines hard
- Detail-level: high (gap-list rigor)
- Communication: EN formal mail; 24h SLA expected
- Decision authority: Commercial signoff KGI/Ufinity engagements
- Sensitivity: Scope-creep without commercial gate (CA Web Portal 15/05)
- Best practice: Confirm scope-hint with formal email before estimation effort
- Pending owes: Ack BQ v2 (14/05) + response to CA Web Q&A 11 open
- Sample phrase: "In addition to the BRD for CAWeb, there is a Internet facing Client Portal that needs to be built. We will need a meeting between..."

**Yen Hock (Ufinity, Tech Lead)**
- Role/scope: KGI Trading + CA Web technical gate
- Personality: Engineering-focused, methodical
- Detail-level: high
- Communication: EN; technical specifics
- Decision authority: Tech approve gates BQ
- Sensitivity: Architecture quality (NinjaTrader chart embed, on-prem rescope rationale)
- Best practice: Use 18/05 morning window for architecture/sequence walkthrough
- Pending owes: Architecture sign-off post-BQ v2

**Alex Chow (Ufinity, Commercial finance)**
- Role: KGI commercial finance reviewer (first appearance 12/05)
- Detail-level: high
- Best practice: Expect re-appearance post-BQ v3
- Pending owes: Commercial finance review

**Ian Choy (NxGen, Solution/Tech Lead)**
- Role: NxGen HDB AI Tender primary PIC
- Personality: Reliable, on-time delivery (07:42 ICT Fri RFI proof)
- Detail-level: high
- Communication: EN technical; xlsx + reference docs
- Decision authority: Technical recommendation, commercial via NxGen sales
- Best practice: Push for MCP cloud-hosting + Aura case approval (open since 14/05)
- Pending owes: Data points by Mon 18/05
- Sample phrase: "Hi Team, Attached are the details of the HDB AI tender we plan to participate in. In summary, this is an AI Agentic Agent project with..."

**Derrick Chong (NxGen, MD)**
- Role: NxGen MD
- Personality: Reliability decaying — 25d stale on CV feedback (22-23/04 window)
- Detail-level: medium
- Communication: EN
- Sensitivity: Stale-owe pattern signals cooling
- Best practice: Kevin chase Mon 18/05 for Cloud Engineer + SDM + NICE + PM CV feedback
- Pending owes: 4 CV-set feedback (stale 25d)

**Kit Yi (AsiaPac, IHL driver — recently elevated)**
- Role: IHL Portal CR + Odoo Migration driver
- Personality: Sentiment trend 14d: silent CC → active strategic driver
- Detail-level: high (5 deliverables by 22/05)
- Communication: EN
- Decision authority: AsiaPac IHL scope-driver
- Best practice: Lock recurring Fri cadence (proposed 15/05); validate Ariba capability gap
- Pending owes: 5 IHL deliverables 22/05

**James Wai (AsiaPac, SME — new)**
- Role: New SME on Odoo Migration discovery
- Communication: TBC
- Pending owes: Discovery participation

**Karin (Recruit Express)**
- Role: EP service agreement PIC
- Status: CLOSED — Docusign 15/05 08:30
- Best practice: First delivery milestone planning

**Rosie (PM, AsiaPac Keppel Bodyshop)**
- Role: Keppel Bodyshop PM
- Personality: Direct issue-raiser (14/05 under-utilisation + customer-attribution concern)
- Communication: VI; project mgmt mail
- Sample phrase: "Hi Kevin, Gần đây chị nhận được một số feedback từ các member đang tham gia dự án Keppel Bodyshop (2 HCs) liên quan đến cách quản lý ta..."

**Kondo-san (Mitsubishi SG, NEW WhatsApp 13/05)**
- Role: MC SG IT PIC NEW
- Communication: WhatsApp (informal) — culturally Japanese formality expected
- Pending owes: Receive Kevin+Charlotte 2-option deck (16/05 verify); customer make-up CVs

#### INTERNAL (VTI)

**Tyson (VTI Sales Manager)**
- Role: APAC pipeline owner — KGI Trading + CA Web + NxGen HDB AI + AsiaPac IHL Odoo (4 active opps)
- Personality: Direct, fast-pace, async-first; absorbs workload but quality risk at concentration
- Detail-level: high
- Communication: VI/EN mixed; chat-short, mail-formal; submits BQs/proposals himself
- Decision authority: Pipeline tactical; escalates commercial to Michael
- Sensitivity: Workload concentration AMBER going into week 18-22/05
- Best practice: Surface sequencing question at Op meeting; load-balance with Kevin/Charlotte; back-up assignments
- Pending owes: KGI BQ v3 20/05 + NxGen BQ 22/05 + IHL Odoo discovery 22/05
- Sample phrase: (chat) "Review file anh Sơn KGI Trading — est tổng 40mm, ko handle transaction giao dịch nên ko issue lớn"

**Kevin Nguyen (VTI Account Lead)**
- Role: NxGen + OBS + RWS + Anthony intros + AI capability collateral
- Personality: Methodical relationship-builder; thread continuations
- Detail-level: medium
- Communication: EN-first; status-cards
- Decision authority: Account coordination; commercial via Michael
- Sensitivity: Stale-owes pattern (Derrick 25d) signals risk
- Best practice: Chase Derrick CVs Mon; verify demo materials Sat 16/05; ship Technovation deck 15/05 promise

**Hung Nguyen Duc / David (Lead Architect)**
- Role: Bidding + technical sign-off + KGI Trading 40MM est
- Personality: Engineering-precision; design-first
- Detail-level: high
- Communication: VI; long-form architecture comments
- Decision authority: Tech approve; bid go/no-go input
- Best practice: Discuss KGI on-prem rescope v2 vs v1 rationale; frame for v3

**Cuong Nguyenduc2 (VTI APAC Ops)**
- Role: Operations + delivery oversight; HD signing
- Communication: VI primary; DM_Cuong is high-traffic
- Decision authority: Sembcorp 2-option, Bodyshop mitigation
- Best practice: Surface Bodyshop issue + Sembcorp re-pitch Mon Op

**Charlotte (VTI commercial admin)**
- Role: Contract/SA logistics, MC HCMC HD template, Sembcorp re-pitch, Recruit Express closure
- Detail-level: high
- Pending owes: Sembcorp re-pitch 21/05; MC HCMC HD 20/05; Terrabit NDA logistics; Aura case approval chase

**Thang Nguyenduc1 (D3)**
- Role: D3 owner AI training case (decided 15/05); case study production for NxGen HDB
- Personality: Engineering-focused, case-study curator
- Communication: VI primary; deck-driven
- Decision authority: D3 technical scope
- Pending owes: 3-5 D3 cases mapped to HDB 15 use cases by 20/05; MCP cloud POV by 21/05

**Anh Nguyensytung (D3)**
- Role: AI/agentic capability presales co-pilot to Thang
- Communication: VI primary
- Pending owes: Capability mapping HDB use cases

**Tung Nguyenba (VAP Op organizer)**
- Role: VAP Weekly Op organizer; agenda owner
- Communication: VI; not in chat crawl (gap)

**Anthony Tee (VTI APAC Senior Advisor)**
- Role: Senior advisor; Anthony intros = Technovation, Terrabit, RWS Eslin, Infor
- Pattern: Friday sync recurring updates
- Best practice: Continue intro pipeline; Kevin/Charlotte close intro-action loops within 1 week
<!-- END: pics -->

## 3. Per-Opportunity tracking (Dimension 3)

<!-- BEGIN: opps -->
### KGI Trading Platform — via Ufinity (PRIMARY ACTIVE OPP)
- Stage: Active proposal v2.0 (BQ submitted 14/05 16:17 ICT)
- BQ history: v1.0 13/05 = ReactJS+AWS ap-southeast-1+Sumsub SGD 135K → v2.0 15/05 = .NET MVC on-prem Windows/IIS/MSSQL SGD 199,500 = 52.25 MM (+39%, infra pivot customer-driven)
- Next milestone: BQ v3 + cost docs + gap-list by 20/05
- Phase 0 demo deadline: 30 Jun 2026 (6 weeks)
- Open risks: Trading chart embed (NinjaTrader SDK) = Phase 1.5 split; CA Web Q&A 11 open questions to Ufinity since 14/05
- VTI owner: Tyson + Hung/David (architect)

### CA Web sub-project — via Ufinity (KGI parallel)
- Stage: BRD sent 14/05 night; **Mark hinted Internet-facing Client Portal as ADDITIONAL scope 15/05 10:14** — not yet sized or formally scoped
- Open risks: Scope-creep without commercial gate; Customer fund verification policy = manual (no direct bank integration); Kane D9 candidate English fluency concern
- VTI owner: Tyson + Kane (D9)
- Michael decision pending: Gate on formal scope-confirm email from Mark before estimation effort

### NxGen HDB AI Tender (PRIMARY ACTIVE OPP — ESCALATION)
- Stage: Active tender response (RFI received 15/05 07:42 ICT)
- Scope: 15 use cases AWS deployment; 5-year contract, ~2,400 users / 1,000 concurrent, AWS+Azure GCC hybrid, ~30TB data 90% unstructured, Core+Specialized chatbots, 3 Agentic pilots, PQM Mistral 7b→>90%, 4-tier man-day pricing
- Next milestone: VTI proposal v1 + BQ by Fri 22/05 (4 deliverables: Target Arch, Costing, Resource Plan, Prof Services Costing)
- Open dependencies: (1) MCP cloud-hosting clarification; (2) Aura Japanese case external sharing approval
- VTI owner: Tyson (BQ) + Kevin (account) + D3 Thang/Anh Tung (case studies)
- Trigger Mon 18/05 D3 sync: case study mapping + MCP POV

### IHL CR Part 1 (data accuracy) — AsiaPac
- Stage: Discovery
- VTI owner: Tyson; estimation Tue 19/05 1pm

### IHL CR Part 2 (delivery status integration) — AsiaPac
- Stage: Discovery
- VTI owner: Tyson; covered same estimation Tue 19/05

### IHL Odoo Migration (STRATEGIC NEW OPP — Fri 15/05)
- Stage: Discovery NEW
- Trigger: Kit Yi 15/05 — UPGRADE from silent CC to active strategic driver
- Scope: 16 ecommerce sites; AWS infra estimate USD 5,202/yr
- VTI owner: Tyson (manager); Michael (approver)
- Open: Recurring Fri cadence proposed 15/05 not yet booked; Ariba capability check; SI competition no incumbent moat

### Sembcorp 2-option re-pitch (NEW commercial decision)
- Stage: Re-pitch needed by 21/05
- Trigger: 2 VTI candidates rejected 15/05 on English fluency
- Decision Mon 18/05 Op: Option-1 (Rec full-time native-EN, 4wk lead) vs Option-2 (Partime VTI fallback)
- Michael lean: Option-1
- VTI owner: Charlotte + Cuong decision

### MC HCMC contract (Toàn placement)
- Stage: Confirmed; Charlotte HD template by 20/05

### MC Sing make-up CVs (Kondo-san NEW 13/05)
- Stage: Window through Aug-Sep; Rec hire external; Kevin+Charlotte 2-option deck 16/05 verify

### PSA Marine LFMS POC (WON 11/05)
- Stage: Kick-off Thu 21/05 10am SGT
- VTI owner: Hung/David assign delivery lead by 20/05; internal review Tue 19/05

### PSAM Warehouse R13 image AI (BQ 08/05)
- Stage: BQ submitted
- WMS onsite $8,010 for 3 trips

### PMA/P360/Kafka Maintenance Y1-Q4 (PSAM)
- Stage: Payment BLOCKED on VTI APAC bank re-opening (June 2026 ETA)
<!-- END: opps -->

## 4. Per-Meeting-Type Patterns

<!-- BEGIN: meeting_types -->
### Type: VAP Weekly Operation Meeting (Mon 10:00-12:00)
- Cadence: weekly Mon
- Attendees: Tung (organizer), Kevin, Cuong, Michael, Quyen, Khanh
- Agenda: opp/lead status (Kevin/Tyson) → bidding (David) → ops → other
- Michael's role: surface sequencing + commercial decisions (CA Web gate, Sembcorp option, Odoo discovery lead)
- Typical decisions: load-balance, opp prioritization, scope-gate
- Watch: Tyson workload concentration

### Type: VAP & D3 AI Case Study Sync (ad-hoc trigger-based)
- Cadence: ad-hoc when tender or case study consolidation needed
- Attendees: Kevin (organizer), Thang (D3), Anh Tung (D3), Michael (optional)
- Trigger pattern: external AI capability/tender deadline → consolidate D3 case studies
- Michael's role: frame target output (e.g., 3-5 cases mapped); decide self-pitch (Claude tool); approve external sharing
<!-- END: meeting_types -->

## 5. General Insights

<!-- BEGIN: general -->
1. **Speed-of-response signaling**: Stable across week. Ian Choy 1-week proposal turnaround locked. Karin signs 1 day ahead deadline. Mark 24h SLA gap list.

2. **Domain expertise gap = estimate risk**: Confirmed CA Web (no financial SME). Rule: range estimate + assumption list = baseline for any deal without internal SME.

3. **Mark Choon scope pattern (REFINED week)**: Tue = scope-add Alex Chow same-day; Thu = BRD revision push; Fri (Mark hint potential Internet-facing Client Portal next week). Default +10% buffer cho follow-on.

4. **NinjaTrader SDK chart embed**: Phase 1.5 split chốt. Long+Hieu joint own. Iframe fallback ready.

5. **NxGen RFI cadence**: 1 week proposal turnaround locked. Demo materials parallel track. Michael owns AI architecture sign-off.

6. **Anthony's network = core pipeline**: Mon 3 of 5 meetings. Stable. Fri sync expanded scope (Khôi Thailand playbook, Q2 trip dates, hire budget).

7. **Tyson workload concentration RED FLAG (Fri)**: Tuần 11-15/05 Tyson chair 8+ meetings. Tuần tới Tyson concurrent: KGI v3 (20/05) + RSA quote (20/05) + IHL CR split (22/05) + Odoo Q&A (22/05) + RWS chatbot (22/05). Michael CẦN re-prioritize Mon Operation — escalate IHL stream sang Hung hoặc Cuong.

8. **Mitsubishi expansion**: HCMC + SG 2 separate frameworks. Kondo-san decisive, country-specific scope thinking.

9. **Conflict management**: Tue Michael chose EP over UF — validated approach (Kevin+Tyson handled UF; Alex Chow one-off).

10. **KGI Trading proposal lifecycle**: VTI internal → joint customer → SAME-DAY post-mortem → revise → next session. Week 11-15/05 fits perfectly.

11. **Mark Choon 24h SLA gap list**: When Mark asks gap list, treat as 24h SLA.

12. **Kit Yi Chow persona FLIP (MAJOR Fri 15/05)**: Initial 'silent CC-only' hypothesis WRONG. Kit Yi = STRATEGIC SCOPE-DRIVER. Treat as peer-level decision-maker AsiaPac roadmap. Memory upgrade required.

13. **Scope expansion 30-50% pattern (NEW Fri)**: Customer brings additional scope beyond invite topic. Pattern observed Mark Choon (multiple weeks) + Kit Yi (Fri). Two-customer evidence = stable pattern. VTI BA must drive Q&A summary + estimation pipeline post-meeting.

14. **NxGen demo materials = cross-deal asset**: Aura + multi-agent + AIOps reusable cho Sembcorp + GovTech. Daniel+Tuan production 15/05 deadline = high leverage.

15. **MC HCMC trial contract = Legal template precedent**: Reusable cho MC SG + future Japanese accounts. Charlotte+Tri Legal velocity = key constraint.

16. **AI architecture sync Michael-Kevin (NEW Thu)**: Cloud provider + model hosting must align Michael+Kevin before any AI proposal submit. Pattern: Michael owns architecture sign-off cho AI deals.

17. **First-week patterns hardening (Day 5 summary)**: All major personas (Mark, Yen Hock, Ian, Karin, Kondo, Saoko, chị Huyền, Kit Yi, Alex Chow, James Wai, Anthony, SW Tang, Simon) now actionable. Prediction muscle building — Thu Prep accuracy high (Anthony sync, NxGen probe questions). Friday Prep accuracy good (Kit Yi flip caught as 'pending validation' — flipped exactly as flagged).

18. **Khôi Thailand-Malaysia playbook (NEW Fri 15/05)**: Position VTI = platform-implementation partner (Power Platform/Odoo/SAP) + retail/manufacturing focus. NOT custom-dev SI. Japanese SI partnerships go through country-level subsidiaries (Fujitsu Vietnam → Toyota Thailand pattern).

19. **Pipeline scaling pressure (NEW Fri)**: Anthony explicit 'Kevin alone can't handle'. Multiple SG accounts simultaneously. Michael cần (a) consolidate SG admin+sales hire budget, (b) plan resource scaling Q3.

20. **Memory week-end snapshot**: 13 client entries, 9 meeting-type patterns, 20 general insights. Memory ~16KB. Quality bar = v2-baseline depth from prior feedback.
<!-- END: general -->

## 6. Change Log

<!-- BEGIN: changelog -->
- **2026-05-11 Day 1 (Mon, week replay v1)**: Memory bootstrapped from baseline. 5 today meetings (Technovation intro, VAP Operation, Terrabit intro, CA Web BQ review, AIOps collect). Tomorrow Tue 12/05 = 6 meetings (UF×VTI CAWeb 2 slots, MC HCMC interview, internal CA Web review, EP Agreement, KGI BQ review). Persona seeds: Mark Choon, Yen Hock, Ian Choy, Derrick Chong, Kit Yi (initial silent hypothesis), Pravin (TBC), Karin Chan, Saoko Miyamoto + Kondo + Tam-san + Dung-san, chị Huyền, SW Tang (NEW), Simon Terrabit (NEW).

- **2026-05-12 Day 2 (Tue, week replay v1)**: 6 today meetings (UF×VTI CAWeb #1, MC HCMC interview Toàn, NEW internal CA Web BQ Review 15:30, EP Agreement, UF×VTI CAWeb #2 with Alex Chow NEW, KGI BQ internal). 3 tomorrow Wed meetings (MC WhatsApp Kondo NEW, 2nd KGI internal review, 21:00 KGI proposal syncup). 10 actions opened (1 red: Charlotte EP redline). Personas added: Alex Chow (Ufinity Commercial — first appearance confirmed Mon prediction). Memory pattern: Mark Choon scope-expansion + same-day attendee additions. Internal CA Web BQ Review 15:30 was NOT on Mon Prep (delta caught). MC HCMC Toàn interview went green per Mon Prep prediction. NEW accounts surfaced: GITS Magento (Gary), ALPSoft Azure L2.

- **2026-05-13 Day 3 (Wed, week replay v1)**: 3 today meetings (MC×WhatsApp Kondo NEW scope, 2nd KGI internal review with Long SDK report, 21:00 KGI proposal final align with full team). 4 tomorrow Thu meetings (UF×VTI joint customer call 10am, NxGen Agentic AI capability 13:30, EP Agreement Karin status, 21:00 post-mortem). 6 new actions opened (1 red: Hung architecture sign-off). Memory enrichment: Long Vu Thanh's SDK deep-dive confirmed chart embed = Phase 1.5; Kondo-san wants DIFFERENT MC SG framework (not HCMC template); Mark pattern confirmed (24h SLA gap list). Personas: Long Vu Thanh added as KGI NinjaTrader SDK SME.

- **2026-05-14 Day 4 (Thu, week replay v1)**: 4 today meetings (UF×VTI KGI Trading 10am — rich Fireflies 37min; NxGen Agentic AI 13:30 — rich Fireflies 59min; EP Agreement continued 15:00; KGI internal debrief 21:00 11min). 4 tomorrow Fri meetings (Anthony Sync 09:00, IHL Portal CR 14:00 — first AsiaPac customer-facing this week, VAP Weekly 16:00, sync up w Hieu 1:1 17:00). 13 actions opened (3 red: Hung data flow KGI, Kevin NxGen proposal, Michael NxGen architecture sync). Memory enrichment: Mark BRD-push pattern refined; NxGen 1-week cadence locked; Kit Yi persona STILL PENDING (Fri IHL CR moment of truth); cross-deal asset (NxGen demo materials reusable).

- **2026-05-15 Day 5 (Fri, week replay v1)**: 5 today meetings (Anthony Sync 09:00 — rich Fireflies 55min strategic; IHL Portal CR 14:00 — rich Fireflies 49min MAJOR Kit Yi persona FLIP + James Wai NEW; IHL CR wrap 14:52 12min; VAP Weekly 16:00 declined; sync up Hieu 17:00 1:1). 2 tomorrow Mon meetings (weekend skip): VAP Weekly Operation 10:00, VAP&D3 AI Case Study 13:00. 8 actions opened (1 red: Tyson IHL CR split + Odoo Q&A). MAJOR Memory updates: Kit Yi STRATEGIC SCOPE-DRIVER upgrade; James Wai persona NEW; AsiaPac massive scope expansion (Odoo migration 13 portals + SAP Ariba); Anthony strategic playbook (Khôi platform-implementation positioning); Q2 trip locked; hire budget Anthony push; weekly wrap-up NEW RULE.

- **2026-05-16 Day 6 (Sat, week replay v1)**: Weekend pause — 0 today meetings. Tomorrow Mon 18/05 prep (2 meetings: VAP Operation + VAP&D3 AI Case Study). 0 new actions opened. Memory at full week-end state: 13 client entries, 9 meeting-type patterns, 20 general insights, ~21KB. Action Tracker 43 open + 18 overdue. Full pipeline replay complete: Mon→Tue→Wed→Thu→Fri all artifacts published in date folders 2026-05-11/ through 2026-05-15/, plus Sat 2026-05-16/. Memory + Action Tracker accumulated sequentially demonstrating prediction muscle build-up: Mon initial seeds → Tue Alex Chow validated → Wed Long SDK confirmed → Thu Mark BRD push validated → Fri Kit Yi flip caught (predicted as 'pending validation' Thu, flipped exactly Fri).

- **2026-05-16 (Memory dimensional expansion)**: Restructured Memory schema from 5 sections → 7 sections. Added 'pics' (standalone Per-PIC personas Dimension 2 with 14 aspects) + 'opps' (Per-Opportunity tracking Dimension 3 with 15 aspects). Re-enriched 'clients' (Per-Account profiles Dimension 1 with 10 aspects per company). Backfilled all accounts from week 11-15/05 data: KGI/Ufinity, NxGen, AsiaPac IHL (+Odoo +Ariba new opps), Recruit Express, Sembcorp, MC HCMC + MC SG, OBS, Technovation, Terabit, RWS, GITS, ALPSoft. PICs documented: 23 personas (13 customer-side + 10 internal/network). Opps tracked: 14 active opps with full 15-aspect coverage.
- **2026-05-16 (Memory dimensional expansion)**: Restructured Memory schema from 5 sections → 7 sections. Added 'pics' (standalone Per-PIC personas Dimension 2 with 14 aspects) + 'opps' (Per-Opportunity tracking Dimension 3 with 15 aspects). Re-enriched 'clients' (Per-Account profiles Dimension 1 with 10 aspects per company). Backfilled all accounts from week 11-15/05 data: KGI/Ufinity, NxGen, AsiaPac IHL (+Odoo +Ariba new opps), Recruit Express, Sembcorp, MC HCMC + MC SG, OBS, Technovation, Terabit, RWS, GITS, ALPSoft. PICs documented: 23 personas (13 customer-side + 10 internal/network). Opps tracked: 14 active opps with full 15-aspect coverage.

- 2026-05-16 (Daily v8 Day 7 — weekend): 0 today + 0 tomorrow Sun meetings. Tomorrow_meetings target = Mon 18/05 per v9 rule (2 internal VTI: VAP Weekly Operation 10:00 + VAP&D3 AI Case Study 13:00). NEW signal RWS (Resorts World Sentosa) demo AI/chatbot — emerging deal from David DM 16/05 (46 msgs, scope 10→20 dev, BA hospitality gap). Michael AI tooling project (Claude-based) now visible to team. ALPSoft fresher training fee 25% still pending. Action Tracker holds 43 open + 18 overdue (no new actions today).

- 2026-05-16 (Daily v9.3 Day 7 — DEEP scan): 0 today + 0 Sun, target Mon 18/05 (2 internal VTI). Gmail DEEP 47 thread (RWS/NxGen/KGI/IHL/ALPSoft/Anthony intros/MC GenAI/Sembcorp). Chat 4 space (VAP+David DM+Nga DM+Anthony Sync) 718 msgs. **RWS upgrade** chat-only → JD-driven (Anthony FW Eminet 13/05); **NxGen 2-deal** track (staff aug Derrick 22/04 + HDB AI tender Ian Choy 15/05 mới); **Anthony intro funnel 2 tuần** (Infor declined, Dialogg push, Terrabit NDA, Technovation Penang, InfiniteX KL); **AsiaPac multi-engagement căng** (IHL CR 15/05 + Keppel issue chị Tu 14/05 + Sembcorp pivot fulltime/partime); MC HCMC swap deadlock 1 tuần (07-15/05); MC GenAI warranty deadline 06/06 surface. 4 internal personas refresh (Tung, David, Kevin, Thang D3).

- 2026-05-17 (Daily v9.4): Weekend digest — KGI BQ pivot v1→v2 captured; CA Web Portal scope creep flagged; NxGen HDB AI tender RFI delivered 15/05 + 22/05 deadline; AsiaPac Kit Yi sentiment shift silent→strategic + Odoo Migration NEW; Sembcorp 2-case rejection + 21/05 re-pitch; D3 AI training case owner confirmed; PSA Marine LFMS POC won; Recruit Express SA closed; 6-deadline cluster week 18-22/05.

- 2026-05-17 (Daily v9.4): Weekend digest — KGI BQ pivot v1→v2 captured; CA Web Portal scope creep flagged; NxGen HDB AI tender RFI delivered 15/05 + 22/05 deadline; AsiaPac Kit Yi sentiment shift silent→strategic + Odoo Migration NEW; Sembcorp 2-case rejection + 21/05 re-pitch; D3 AI training case owner confirmed; PSA Marine LFMS POC won; Recruit Express SA closed; 6-deadline cluster week 18-22/05.
<!-- END: changelog -->

## 7. AI Analysis Provenance

<!-- BEGIN: provenance -->
- **2026-05-11**: Pipeline v9.2 replay Day 1. Memory bootstrap (clients/meeting_types/general). Sources: Calendar events Mon-Tue, VTI.VAP chat _summary.json 11/05 (105 msgs, D9 CA Web + MC HCMC + Sembcorp topics). Sub-agents: 0 (Day 1 baseline).

- **2026-05-12**: Pipeline v9.2 replay Day 2. Memory enriched (Mark pattern, Alex Chow added, MC SG context, GITS, ALPSoft). Sources: Calendar Tue+Wed, VTI.VAP chat _summary.json 12/05 (50 msgs, GITS Magento + MC HCMC swap + ALPSoft + Sembcorp commercial). Sub-agents: 0 (manual delta-vs-prep).

- **2026-05-13**: Pipeline v9.2 replay Day 3. Memory general section enriched (12 insights). Sources: Calendar Wed+Thu, Fireflies transcript 'VTI Internal - Syncup KGI Trading Platform proposal' (67min 21:00 — rich detail on NinjaTrader integration + cash flow + estimation). Sub-agents: 0.

- **2026-05-14**: Pipeline v9.2 replay Day 4. Memory general (15 insights). Sources: Calendar Thu+Fri, Fireflies transcripts UF/VTI KGI (37m), NxGen Agentic AI (60m), VTI INTERNAL KGI 21:00 (11m). Rich action-items from Fireflies extraction. Sub-agents: 0.

- **2026-05-15**: Pipeline v9.2 replay Day 5. Memory full enrichment (clients/meeting_types/general 20 insights). Sources: Calendar Fri+Mon, Fireflies transcripts Anthony Sync (55m), IHL Portal CR (49m + 12m wrap), sync up Hieu (20m). MAJOR Kit Yi persona flip validated. Sub-agents: 0 (manual delta-vs-prep + persona inference inline).

- **2026-05-16**: Pipeline v9.2 replay Day 6 (final). Weekend run + memory full state. No new touchpoints. Memory ~21KB peak. All 6 daily folders populated. Total deliverables across week: 12 docs (6 Recap + 6 Prep), 1 Action Tracker (43 actions), 1 Memory (21KB).

- **2026-05-16 (Memory expansion)**: Pipeline v9.3 — Memory schema 5→7 sections. 'clients' enriched per-account 10 aspects. NEW 'pics' section 14 aspects/PIC. NEW 'opps' section 15 aspects/opp. Sources: full week replay 11-15/05 (Fireflies transcripts + chat _summary.json + Gmail threads + Calendar). Manual sub-agent inference; no automated sub-agents this pass.
- **2026-05-16 (Memory expansion)**: Pipeline v9.3 — Memory schema 5→7 sections. 'clients' enriched per-account 10 aspects. NEW 'pics' section 14 aspects/PIC. NEW 'opps' section 15 aspects/opp. Sources: full week replay 11-15/05 (Fireflies transcripts + chat _summary.json + Gmail threads + Calendar). Manual sub-agent inference; no automated sub-agents this pass.

- 2026-05-16 (Daily v8): Pipeline v8 first weekend run. Sources: Calendar Sat/Sun (0 events both days), Calendar Mon 18/05 (2 VTI internal active), Drive Google Chat Crawl _stage.json (5/41 spaces done, 36 deferred), DM David _summary.json (rich 16/05 data — RWS + AI tool), Memory baseline read OK. Sub-agents: persona×0 (no external PIC) · action-qc×1 (0 new) · cross-carry×1 (RWS + ALPSoft → Mon) · chat-extractor×1 (David DM) · sanity×1 (publish OK).

- 2026-05-16 (Daily v9.3): Pipeline v9.3 first DEEP run. Sources: Calendar Sat/Sun/Mon, Fireflies recap notifications (KGI 13-14/05, IHL CR 15/05 2x, NxGen Agentic AI 14/05), Gmail 47 thread (5-query/topic: RWS+NxGen+KGI+IHL/AsiaPac+ALPSoft+Anthony Tee), Drive Google Chat Crawl _stage.json (5/41 done, 36 deferred), DM David _summary 14d, Space VTI.VAP _summary 14d (718 msgs aggregate). Sub-agents: persona×4 internal (Tung/David/Kevin/Thang) · action-qc×1 (0 new actions) · cross-carry×1 (RWS+NxGen tender+ALPSoft+AsiaPac→Mon) · mail-and-chat-deep-extractor×1 · sanity×1. Effort metric: 47 mail thread + 718 chat msg + 5-pass reasoning.

- 2026-05-17: persona×11 (8 ext + 3 int) · mail-F×2 meeting (160 threads scanned, 11 fetched, 0 attachment binary extracted) · drive-G×4 scope (18 files fetched, 12 extracted) · chat-H×2 meeting (22 spaces scanned, 32 msgs, 3 links resolved) · cross-day-I×4 (23 carries, 4 trends, 7 escalations) · 5-pass reasoning · model=claude-opus-4-7 · pipeline=v9.4

- 2026-05-17: persona×11 (8 ext + 3 int) · mail-F×2 meeting (160 threads scanned, 11 fetched, 0 attachment binary extracted) · drive-G×4 scope (18 files fetched, 12 extracted) · chat-H×2 meeting (22 spaces scanned, 32 msgs, 3 links resolved) · cross-day-I×4 (23 carries, 4 trends, 7 escalations) · 5-pass reasoning · model=claude-opus-4-7 · pipeline=v9.4
<!-- END: provenance -->

