import base64, json, sys
b64 = sys.stdin.read()
data = json.loads(base64.b64decode(b64))
print(json.dumps(data, ensure_ascii=False, indent=2))
