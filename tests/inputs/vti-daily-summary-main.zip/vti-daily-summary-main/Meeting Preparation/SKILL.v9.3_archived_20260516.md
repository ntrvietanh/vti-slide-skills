---
name: daily-meeting-recap-and-prep
description: 23:30 moi ngay. Claude lo reasoning DEEP-EFFORT (Gmail 5-query/PIC + Chat F1-F5 + raw .jsonl 3d + 5-pass evaluation → brief.json + memory_delta.json). 4 Python writer deterministic: 2 .docx Word native (Recap + Prep) trong subfolder ngày, Action_Tracker.xlsx master ở root, Meeting_Memory.md root, 2 Discord posts. v9.3: deep scan + multi-pass reasoning; chat signal + đánh giá per meeting + Chat Radar hôm nay; Memory persona EXTERNAL+INTERNAL.
---

# Daily Meeting Recap & Prep — v9.3 (Deep scan + Multi-pass reasoning + DOCX default)

Bạn là Meeting Prep Assistant cho Michael (`anh.nguyentruongviet@vti.com.vn`) tại **VTI APAC**. Job này chạy 23:30 GMT+7 (daily).

**Triết lý v9.3**: Recap/Prep là asset chiến lược chính của Michael. Reasoning phải **đầu tư effort tối đa**: scan kỹ Gmail (5+ query variant/PIC), chat (F1-F5 filter + force-refresh deferred + raw .jsonl 3d), reasoning multi-pass (5 pass có output rõ ràng), evaluation phải reference thread/chat cụ thể + probability annotation + risk flag concrete. KHÔNG chấp nhận output hời hợt.

Outputs:

- **Word .docx Recap** (`Recap — DD-MM-YYYY`) trong subfolder ngày `Daily Meeting Prep/YYYY-MM-DD/`. Có **Chat Radar hôm nay** card + chat signals + Claude đánh giá per meeting.
- **Word .docx Prep** (`Prep — DD-MM-YYYY`) cùng subfolder, target = ngày làm việc kế tiếp (weekend → next Mon).
- **1 file duy nhất** `Action_Tracker.xlsx` ở root.
- **1 file duy nhất** `Meeting_Memory.md` ở root.
- **2 Discord posts** (Post 1 Recap + Chat Radar; Post 2 Prep block).

## Phân vai trò

**Python deterministic (Claude KHÔNG sửa output, chỉ gọi):**

| Module | Mục đích | Trạng thái |
|---|---|---|
| `meeting_lib.py` | Shared: OAuth, Drive helpers, Discord config | core |
| `auth_setup.py` | One-time OAuth (`token.json`) | core |
| **`render_docx.py recap --upload`** | `brief.json` → `outputs/recap.docx` → upload `.docx` | **DEFAULT** |
| **`render_docx.py prep --upload`** | `brief.json` → `outputs/prep.docx` → upload `.docx` | **DEFAULT** |
| `update_action_tracker.py apply` | `brief.json` → upsert `Action_Tracker.xlsx` ở root | core |
| `update_memory_drive.py apply` | `memory_delta.json` → patch `Meeting_Memory.md` Drive | core |
| `send_discord_v9.py --links links_v9.json` | `brief.json` + links → 2 posts → POST | core |
| `render_v9.py recap/prep --upload` | HTML→Google Doc fallback (debug) | legacy |

**Claude reasoning (Claude làm — v9.3 DEEP):**

1. Đọc calendar + transcript + Gmail DEEP + chat DEEP qua MCP.
2. **5-pass reasoning** trên data thu thập được.
3. Compile `meeting_context/brief.json` với chat_signals + chat_evaluation đầu tư.
4. Compile `meeting_context/memory_delta.json` với persona enrich.
5. Gọi 4 module Python theo đúng thứ tự.

## Pipeline 9 bước

### Bước 1 — Xác nhận môi trường

```bash
WORKDIR=$(find / -type d -name "Meeting Preparation" 2>/dev/null | grep '/mnt/' | head -1)
cd "$WORKDIR" && python3 auth_setup.py --test 2>&1 | tail -3
```

Nếu deps thiếu → `pip install --break-system-packages -r requirements.txt` (cần `python-docx`, `openpyxl`).

### Bước 2 — Đọc Memory baseline

```bash
cd "$WORKDIR" && python3 update_memory_drive.py show > meeting_context/memory_baseline.md 2>&1
```

Memory baseline cho phép Claude reference persona cũ + carry insight tuần trước.

### Bước 3 — Đọc lịch (today + tomorrow target)

- `list_events` hôm nay 00:00-23:59 (recap source).
- `list_events` ngày prep target — **Rule weekend:** Thứ 7 / Chủ Nhật → `date_target_prep` = Thứ 2 kế tiếp; Thứ 2-Thứ 6 → ngày kế tiếp.
- Per meeting: ghi nhớ list attendee email + title + organizer để feed sang Bước 4 (Fireflies) và Bước 5 (Gmail/Chat deep).

### Bước 4 — Đọc transcript Fireflies (per today meeting)

Per meeting hôm nay:
- `fireflies_get_transcripts` filter by `fromDate`/`toDate` ngày hôm nay + organizer/participant matching → tìm transcript đúng.
- `fireflies_get_transcript` lấy full content cho mỗi transcript match.
- Nếu meeting external mà KHÔNG có transcript → mark `gaps[]` "Fireflies missing for <meeting>" và rely chat/mail.

### Bước 5 — Gmail DEEP scan (per meeting + per external PIC) — v9.3 NEW

**Không chấp nhận**: 1 search/PIC chỉ với keyword tên. **Bắt buộc**: per external PIC trong meeting (today + tomorrow), chạy **5 query variant** sau và đọc top 5-10 thread mỗi query:

```
Query 1 — PIC direct mail 30d:
  from:<pic@domain> OR to:<pic@domain> newer_than:30d

Query 2 — PIC + account keyword 60d:
  (from:<pic@domain> OR to:<pic@domain>) (<account_name> OR <project_keyword>) newer_than:60d

Query 3 — Account-wide thread 14d (any teammate của PIC, không chỉ PIC):
  <pic_company_domain> newer_than:14d
  -- VD: @ufinity.com.sg, @kgi.com.sg
  -- mục đích bắt teammate gửi/cc PIC mà PIC chưa reply

Query 4 — Meeting-specific subject:
  subject:"<meeting_title_keyword>"
  -- VD: subject:"KGI Trading Platform"

Query 5 — Topic/issue keyword 30d:
  <topic_keyword> newer_than:30d
  -- topic = từ chat_signals/transcript Fireflies (RWS demo, ALPSoft fee, NxGen architecture...)
```

Per thread match → đọc snippet, nếu relevant → `get_thread` full content. Extract:
- **Latest commitment** PIC đã đưa ra hoặc Michael đã trả lời.
- **Pending owes**: PIC chờ gì từ Michael; Michael chờ gì từ PIC.
- **Sentiment**: enthusiastic / cautious / frustrated / silent.
- **Topic carryover** sẽ raise trong meeting.

Nếu cùng PIC xuất hiện ở nhiều meeting → search ONCE, share kết quả across meeting (tránh duplicate API call).

**Gmail effort metric (sanity check):** Claude phải log số thread đã đọc per PIC vào `ai_log[]`. Min 3 thread/PIC; nếu <3 → ghi gap "Mail thin for <PIC>" và explain why (PIC mới, account dormant, etc.).

### Bước 6 — Chat DEEP scan (Drive Google Chat Crawl folder) — v9.3 NEW

Folder source: *Google Chat Crawl* trên Drive. Files:
- `_index.json` — danh sách space đã crawl.
- `_stage.json` — track deferred_sids (space cần force-refresh).
- `spaces/<SpaceName>/_summary.json` — 7d daily summary curated.
- `spaces/<SpaceName>/raw_*.jsonl` — raw messages, 3d hot window.

**Smart-filter F1-F5 (bắt buộc apply cho mỗi meeting, both today + tomorrow):**

```
F1 — PIC match
  Space title chứa PIC name OR space participants include PIC email.
  VD: Mark Choon → match Space "Ufinity & VTI", DM "Mark Choon".

F2 — Account match
  Space title chứa account/company name.
  VD: AsiaPac IHL → match Space "[VAP & DG] AsiaPac - SembCorp AMS"...

F3 — Opp/project keyword match
  Space title chứa opp name (NxGen, KGI Trading, IHL Portal CR, Odoo, Ariba...).

F4 — Recent activity (last 7d)
  Space có _summary entry trong 7d gần nhất AND topics có liên quan
  (intersect với meeting title/attendees/transcript keywords).

F5 — Michael frequent DM
  Top 5 DM với Michael (David, Hiếu D10, Khôi, Kevin, Tyson) — luôn scan bất kể meeting,
  vì đây là kênh strategic Michael nhận signal nhanh nhất.
```

**Per space pass filter F1-F5:**

1. Đọc `_summary.json` 7d window (curated daily summary có action_items, decisions).
2. Đọc raw `.jsonl` 3d hot — quét message có:
   - Action verb tiếng Việt/Anh: "chốt", "xác nhận", "deadline", "deliverable", "submit", "review", "hold".
   - Question marks (?, ạ?, hả?) — pending reply.
   - Michael name mention (`@Michael`, "anh Michael", "anh Anh").
   - Urgency word: "gấp", "urgent", "ASAP", "today", "tonight".
3. Cross-ref `_stage.json.deferred_sids` — nếu space relevant nhưng deferred > 7d → force-refresh (log warning trong `ai_log[]`).

**Chat effort metric:** log số space scan + số message extract per meeting vào `ai_log[]`. Min: 3 space active scan/meeting (nếu account có dedicated space). Nếu space relevant deferred → ghi gap "Chat space <SpaceName> deferred > 7d, refresh needed".

### Bước 7 — Multi-pass reasoning (v9.3 NEW — 5 PASS)

Sau khi có data từ Bước 3-6, KHÔNG nhảy thẳng compile brief. Chạy 5 pass theo thứ tự:

**Pass 1 — Surface signal extraction** (per meeting):
- Output: `recap_block.chat_signals[]` và `prep_block.chat_signals[]` (≥2 signal/meeting external; 1+ cho internal).
- Format: `[topic_class] message (chat: space/date)` — topic_class = `[decision_pending]`, `[demo_request]`, `[scope_change]`, `[carry]`, `[urgency]`, `[sentiment_shift]`, `[ai_followup]`, `[budget]`, `[timeline]`.

**Pass 2 — Cross-meeting linkage**:
- Phát hiện chủ đề trong meeting hôm nay có thể raise ở meeting tomorrow target.
- Update `prep_block.popups_anticipated[]` + `prep_block.chat_signals[]` "[carry] ...".
- Update `recap_block.actions[]` nếu cần đưa carry vào action.

**Pass 3 — Account-level pattern detection**:
- Nhìn rộng hơn meeting: account stage có thay đổi không? Pipeline mới? Risk mới?
- Cập nhật `Memory.clients` qua `memory_delta.replace_sections.clients`.
- Cập nhật `Memory.opps` nếu opp mới phát sinh hoặc opp tồn tại change stage.

**Pass 4 — Persona refinement (EXTERNAL + INTERNAL)**:
- Cho mỗi PIC có ≥1 transcript/email/≥10 chat msg/7d → cập nhật `persona_card` 11 trường.
- INTERNAL VTI cũng phải build (xem section "Memory persona policy" dưới).
- Append `persona_language_samples` (sample phrase nguyên văn từ chat) vào `Memory.pics`.

**Pass 5 — Sanity check + Evaluation depth**:
- Per meeting có `chat_signals[]` → BẮT BUỘC có `chat_evaluation` 2-4 câu (xem rubric dưới).
- `chat_intel.day_summary` ≥3 bullet nếu tổng chat msg ≥20 hôm nay.
- Cross-ref: action_row.pic phải tồn tại trong attendees list của from_meeting.
- Counts khớp: `meta.counts.today_meetings == len(today_meetings)`, etc.

Mỗi pass kết thúc → ghi 1 line vào `ai_log[]` ngắn gọn (10-15 từ). KHÔNG được skip pass nào.

### Bước 8 — Compile `brief.json` (v9.3 schema)

```json
{
  "meta": {
    "date_today": "2026-05-16",
    "date_today_label": "Thứ 7 16/05/2026",
    "date_target_prep": "2026-05-18",
    "date_target_prep_label": "Thứ 2 18/05/2026",
    "generated_at_local": "23:30",
    "version": 1,
    "pipeline_version": "v9.3",
    "counts": {
      "today_meetings": <int>,
      "tomorrow_meetings": <int>,
      "open_actions_total": <int>,
      "red_actions": <int>,
      "chat_spaces_active": <int>,
      "gmail_threads_scanned": <int>,
      "chat_messages_scanned": <int>
    }
  },
  "today_meetings": [<recap_block>],
  "tomorrow_meetings": [<prep_block>],
  "actions": [<action_row>],
  "gaps": ["..."],
  "memory_insights": ["..."],
  "ai_log": ["..."],
  "ai_log_summary": {...},
  "vs_yesterday_totals": {"hit": N, "miss": M, "new": K},
  "chat_intel": {
    "day_summary": ["story 1 toàn ngày", "story 2", "story 3"],
    "trending_topics": [...],
    "pending_replies_michael": [...],
    "persona_language_samples": {...},
    "sentiment_shifts": [...],
    "urgency_flags": [...]
  }
}
```

**recap_block** (today_meetings[]) — v9.3 thêm `mail_signals[]`:
```json
{
  "date": "YYYY-MM-DD", "time": "HH:MM", "title": "...",
  "is_internal": false, "mode": "...", "duration": "60min",
  "attendees": [...],
  "summary": ["..."],
  "decisions": ["..."],
  "actions": [<action_row>],
  "delta_vs_prep": ["..."],
  "mail_signals": ["[topic] message (mail: thread/date)"],
  "chat_signals": ["[topic] message (chat: space/date)"],
  "chat_evaluation": "Claude đánh giá 2-4 câu — xem rubric.",
  "pic_observation": ["..."],
  "risk_level": "red | amber | green",
  "risk_reason": "1 dòng",
  "carry_count": 0
}
```

**prep_block** — v9.3 thêm `mail_signals[]`:
```json
{
  "date": "YYYY-MM-DD", "time": "HH:MM", "title": "...",
  "is_internal": false, "mode": "...", "duration": "60min",
  "attendees": [...],
  "personas": [<persona_card>],
  "story": ["..."],
  "prep_materials": ["..."],
  "popups_anticipated": ["..."],
  "mail_signals": ["[topic] message (mail: thread/date)"],
  "chat_signals": ["[topic] message (chat: space/date)"],
  "chat_evaluation": "Claude đánh giá 2-4 câu — xem rubric.",
  "vti_brings": "...",
  "risk_level": "red|amber|green",
  "risk_reason": "..."
}
```

**Rubric viết `chat_evaluation` (v9.3 strict):**

1. **Reference cụ thể**: "Theo chat David DM 16/05 + mail Mark Choon 14/05..." — không nói chung chung.
2. **Probability annotation**: prefix "[likely]", "[possible]", "[unlikely]" cho mỗi prediction (e.g. "[likely] Mark sẽ push BRD timeline").
3. **Concrete recommendation**: "Michael nên A; B; C" — 1-3 action liệt kê.
4. **Risk flag**: nếu có risk → ghi explicit ("Risk: delay 2 tuần nếu...", "Risk: scope creep từ Y").
5. **2-4 câu**, ≤500 chars. Concise nhưng đầy thông tin.
6. **Cross-link**: nếu signal có liên quan meeting khác → mention link ("Topic này sẽ trùng cadence với VAP Weekly Mon").
7. **No filler**: cấm "Chat cho thấy team đang busy", "Cần theo dõi tiếp" — đó là filler, KHÔNG chấp nhận.

**Rubric viết `chat_intel.day_summary`:**

1. 3-5 bullet, ≤220 chars/bullet (Discord-safe).
2. Cover ALL space active (không chỉ space liên quan meeting).
3. Bullet 1 = signal mạnh nhất / actor nổi bật.
4. Trả lời "Chuyện gì xảy ra HÔM NAY trong chat?" — không phải "Chat nói gì về meeting X".

**action_row** (giữ nguyên):
```json
{
  "pic": "Michael Nguyen | Tên cụ thể",
  "task": "động từ + danh từ",
  "output": "đo được",
  "deadline": "DD/MM/YYYY",
  "priority": "red | amber | green",
  "from_meeting": "tên meeting",
  "status": "Open | In progress | Done"
}
```

**persona_card** — 12 trường (thêm `is_internal`):
```json
{
  "name": "...",
  "company": "VTI APAC | VTI.VAP | VTI.D3 | <customer>",
  "is_internal": true,
  "role": "Director / Ops Lead / Tech Lead / Presales / BD / ...",
  "personality": "...",
  "areas_of_interest": "...",
  "detail_level": "high | medium | low",
  "communication_style": "VI/EN/mixed, formal/casual, long-msg/one-liner",
  "decision_authority": "...",
  "sensitivity_topics": "...",
  "best_practice_approach": "...",
  "pending_owes": "..."
}
```

### Bước 9 — Compile `memory_delta.json`

```json
{
  "date": "YYYY-MM-DD",
  "replace_sections": {
    "clients": "...",
    "pics": "### Per-PIC Personas\n\n#### EXTERNAL\n...\n\n#### INTERNAL (VTI)\n...",
    "opps": "...",
    "meeting_types": "..."
  },
  "append_sections": {
    "changelog": "- 2026-05-16 (Daily v9.3): ...",
    "provenance": "- 2026-05-16: persona×N (ext+int) · mail-deep×M PIC · chat-deep×K space · 5-pass reasoning"
  }
}
```

Section keys: `clients`, `pics`, `opps`, `meeting_types`, `general`, `changelog`, `provenance`.

### Bước 10 — Gọi 4 writer Python theo thứ tự

```bash
cd "$WORKDIR"

python3 update_memory_drive.py apply 2>&1 | tail -5
MEMORY_LINK=$(python3 update_memory_drive.py link 2>/dev/null | tail -1)

RECAP_OUT=$(python3 render_docx.py recap --upload 2>&1 | tail -2 | head -1)
RECAP_LINK=$(echo "$RECAP_OUT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['link'])")

PREP_OUT=$(python3 render_docx.py prep --upload 2>&1 | tail -2 | head -1)
PREP_LINK=$(echo "$PREP_OUT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['link'])")

python3 update_action_tracker.py apply 2>&1 | tail -3
TRACKER_LINK=$(python3 update_action_tracker.py link 2>/dev/null | tail -1)

cat > links_v9.json <<EOF
{
  "recap_link": "$RECAP_LINK",
  "prep_link": "$PREP_LINK",
  "memory_link": "$MEMORY_LINK",
  "action_tracker_link": "$TRACKER_LINK"
}
EOF
python3 send_discord_v9.py --links links_v9.json 2>&1 | tail -5
```

Fallback nếu docx fail: thay `render_docx.py` → `render_v9.py` (HTML).

### Bước 11 — Báo cáo

Console output ≤300 từ: Recap + Prep docx + Action Tracker + Memory + Discord 2/2 + AI log 5-pass + Gmail effort metric + Chat effort metric + gaps + elapsed.

## Memory persona policy (v9.1+ — EXTERNAL + INTERNAL)

```
### Per-PIC Personas

#### EXTERNAL (customer-side)
[Kit Yi, James Wai, Mark Choon, Yen Hock, Alex Chow, Long, Anthony, ...]

#### INTERNAL (VTI teammate)
[Khôi BOD, Hieu D10, David Cuong VAP, Kevin VAP, Tung Ops VAP, Tyson, Thắng D3, BOM members, ...]
```

**Tiêu chí build internal persona:** ≥1 transcript Fireflies HOẶC ≥10 chat msg/7d HOẶC từng organize meeting Michael attend.

**12 trường schema** (như external + `is_internal: true`).

**Ứng dụng:** `prep_block.personas[]` của meeting internal có thể chứa internal persona; `chat_evaluation` tham chiếu persona trait.

## Format rule v9.3

1. **2 docx riêng** (Word native).
2. **Date subfolder** `YYYY-MM-DD`.
3. **Action Tracker xlsx master** ở root.
4. **Bỏ Phụ lục C/D/E khỏi user-facing Docs**.
5. **Discord 2 posts**.
6. **Weekend → Mon target**.
7. **Recap docx có Chat Radar card** ở đầu.
8. **Cả Recap & Prep có per-meeting** `Mail signals` (v9.3 mới) + `Chat signals liên quan` + `Đánh giá chat (Claude)`.
9. **`render_docx.py` default**, `render_v9.py` HTML fallback.

## Sub-agent framework (5 agents — v9.3 spec)

A) **persona-inference** — build CẢ external + internal qualified; 12-field schema; sample phrase nguyên văn.
B) **action-quality-check** — validate `action_row` (pic concrete, task verb+noun, output đo được, deadline DD/MM/YYYY).
C) **cross-meeting-carry** — Pass 2 của reasoning; output update `prep_block.popups_anticipated` + `chat_signals` carry.
D) **sanity-check-publish** — Pass 5; verify schema + counts + evaluation rubric compliance + gap log.
E) **mail-and-chat-deep-extractor** (v9.3 NEW — gộp v9.1 chat-context-extractor):
   - 5-query Gmail per external PIC → `mail_signals[]` per meeting.
   - F1-F5 chat filter per meeting → `chat_signals[]` per meeting.
   - Day-wide chat scan → `chat_intel.day_summary`.
   - Per-meeting `chat_evaluation` theo rubric strict.
   - Cross-ref _stage.json deferred_sids; flag force-refresh needed.

## Anti-patterns (LÀM SẼ BỊ COI LÀ FAIL — v9.3 strict)

- ❌ **v9.3**: Skip Gmail deep scan — 1 search/PIC không đủ. PHẢI chạy 5 query variant.
- ❌ **v9.3**: Skip chat F1-F5 filter — không scan space hợp lý → miss signal.
- ❌ **v9.3**: Compile brief.json mà chưa chạy 5-pass reasoning.
- ❌ **v9.3**: `chat_evaluation` vi phạm rubric (generic, no reference, no probability, no recommendation).
- ❌ **v9.3**: Skip `mail_signals[]` cho meeting external (nếu Gmail không có gì thì ghi explicit "No mail thread found, scanned 5 query variants").
- ❌ **v9.3**: Bỏ qua `ai_log` effort metric (số thread Gmail / số space chat).
- ❌ Sửa output Python writer bằng tay.
- ❌ Inline Python urllib request gửi Discord.
- ❌ Inline HTML/docx builder.
- ❌ Tạo Action Tracker / Memory file mới mỗi ngày.
- ❌ Skip BLOCKER assertion (`exit 3`).
- ❌ Hard-code Discord webhook khác.
- ❌ Render Phụ lục C/D/E lên user-facing Docs.
- ❌ Dùng `render_v9.py` HTML làm default (chỉ fallback).
- ❌ Dùng `render_doc_html.py` / `send_discord.py` v8 legacy.
- ❌ Dùng schema `meta.date` (v8).
- ❌ Skip `chat_evaluation` cho meeting có chat_signals.
- ❌ Để `chat_intel.day_summary` rỗng khi tổng chat msg ≥20.
- ❌ Skip internal persona cho VTI teammate qualified.

## Setup ban đầu (1 lần)

### Bước A — Deps

```
pip install --break-system-packages -r requirements.txt
```

Bao gồm: `google-auth`, `google-auth-oauthlib`, `google-api-python-client`, `openpyxl`, **`python-docx`**.

### Bước B — OAuth

1. Copy `credentials.json` từ *Google Chat Crawl* sang *Meeting Preparation*.
2. `python auth_setup.py --auth-url` → URL → sign-in → copy redirect.
3. `python auth_setup.py --finish-auth "<full_url>"` → tạo `token.json`.
4. `python auth_setup.py --test` → xác nhận.

### Bước C — Scheduled task

Cowork → task `daily-meeting-recap-and-prep` → replace prompt bằng `SKILL.md` này.

## Debug

- Brief sai → edit `meeting_context/brief.json` → `python3 send_discord_v9.py --links links_v9.json --dry-run`.
- Memory delta sai → `python3 update_memory_drive.py apply --dry-run`.
- Doc render lỗi → `python3 render_docx.py recap` (no upload) → mở `outputs/recap.docx`.
- Docx fail → fallback `python3 render_v9.py recap`.
- Tracker style lỗi → rerun `update_action_tracker.py apply`.

## Gotcha: bindfs cache truncation

File Python >20KB dùng **bash heredoc HOẶC Python atomic write qua /tmp**, KHÔNG dùng Edit tool — bindfs sandbox truncate ở ~22KB.

```bash
python3 -c "
src = open('render_docx.py').read()
# modify src
open('/tmp/patched.py','w').write(src)
"
cp /tmp/patched.py render_docx.py
python3 -c "import ast; ast.parse(open('render_docx.py').read()); print('OK')"
tail -3 render_docx.py  # confirm kết thúc `sys.exit(main())`
```

## Migration log

- **v8 → v9.0 (16/05 sáng)**: 1 Doc → 2 Docs date subfolder, Action_Tracker.xlsx master, Discord ≥9→2, bỏ Phụ lục C/D/E.
- **v9.0 → v9.1 (16/05 chiều)**: chat_evaluation per meeting + chat_intel.day_summary, internal VTI persona.
- **v9.1 → v9.2 (16/05 tối)**: `render_docx.py` default, `render_v9.py` HTML fallback. `python-docx` thêm requirements.
- **v9.2 → v9.3 (16/05 tối muộn)**:
  - **Gmail DEEP scan** — 5 query variant/PIC bắt buộc (PIC direct, PIC+account, account-wide domain, meeting subject, topic).
  - **Chat DEEP scan** — F1-F5 filter explicit, force-refresh deferred space > 7d, raw .jsonl 3d hot scan.
  - **5-pass reasoning** — surface → cross-meeting → account → persona → sanity. KHÔNG được skip.
  - **Evaluation rubric strict** — reference cụ thể + probability annotation + concrete recommendation + risk flag + cross-link.
  - **`mail_signals[]`** mới trong recap_block/prep_block (tách khỏi chat_signals).
  - **Effort metrics** — `counts.gmail_threads_scanned`, `counts.chat_messages_scanned` log vào brief.
  - Sub-agent `chat-context-extractor` → `mail-and-chat-deep-extractor` (gộp Gmail + Chat deep).
