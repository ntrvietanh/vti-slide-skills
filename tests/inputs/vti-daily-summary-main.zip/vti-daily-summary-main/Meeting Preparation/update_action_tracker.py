#!/usr/bin/env python3
"""update_action_tracker.py v9.4 — VTI-brand styled Action Tracker xlsx on Drive.

Single Action_Tracker.xlsx at folder root.
Schema: id | date_opened | pic | task | output | deadline | priority | source_meeting | status | last_updated | notes
Sheets: All (master) + Open + Done + Overdue (derived).
Features:
- Navy header row, freeze top row + auto-filter
- Alternating row striping
- Color-coded priority pills + status pills
- Overdue deadlines = red bold
- Notes column preserved on upsert (user edits never overwritten)
- Title strip + summary counts on All sheet
"""
from __future__ import annotations
import argparse, hashlib, io, json, sys
from datetime import datetime, date
from pathlib import Path
from meeting_lib import (
    DRIVE_FOLDER_NAME, ensure_folder, get_drive, load_credentials, log,
    save_state, load_state,
)

ROOT = Path(__file__).resolve().parent
BRIEF_PATH = ROOT / "meeting_context" / "brief.json"
TRACKER_NAME = "Action_Tracker.xlsx"
COLS = ["id", "date_opened", "pic", "task", "output", "deadline", "priority",
        "source_meeting", "status", "last_updated", "notes"]
COL_WIDTHS = {"id": 11, "date_opened": 13, "pic": 22, "task": 55, "output": 40,
              "deadline": 13, "priority": 11, "source_meeting": 35, "status": 14,
              "last_updated": 13, "notes": 45}
HEADER_LABELS = {"id": "ID", "date_opened": "Date Opened", "pic": "PIC",
                 "task": "Task", "output": "Output / Deliverable",
                 "deadline": "Deadline", "priority": "Priority",
                 "source_meeting": "Source Meeting", "status": "Status",
                 "last_updated": "Last Updated", "notes": "Notes (your space)"}


def make_id(pic, task, source):
    h = hashlib.sha1(f"{pic}|{task}|{source}".encode("utf-8")).hexdigest()
    return h[:8]


def parse_dl(s):
    if not s: return None
    if isinstance(s, date) and not isinstance(s, datetime):
        return s
    if isinstance(s, datetime):
        return s.date()
    s = str(s).strip()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try: return datetime.strptime(s, fmt).date()
        except ValueError: pass
    return None


def find_or_create_xlsx(drive, parent_folder_id):
    q = f"'{parent_folder_id}' in parents and name = '{TRACKER_NAME}' and trashed = false"
    r = drive.files().list(q=q, fields="files(id,name)").execute()
    files = r.get("files", [])
    if files: return files[0]["id"], False
    from openpyxl import Workbook
    wb = Workbook()
    wb.active.title = "All"
    wb["All"].append(COLS)
    for sn in ("Open", "Done", "Overdue"):
        wb.create_sheet(sn).append(COLS)
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    from googleapiclient.http import MediaIoBaseUpload
    media = MediaIoBaseUpload(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", resumable=False)
    body = {"name": TRACKER_NAME, "parents": [parent_folder_id],
            "mimeType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
    f = drive.files().create(body=body, media_body=media, fields="id,name").execute()
    return f["id"], True


def download_xlsx(drive, file_id):
    from openpyxl import load_workbook
    req = drive.files().get_media(fileId=file_id)
    from googleapiclient.http import MediaIoBaseDownload
    buf = io.BytesIO()
    dl = MediaIoBaseDownload(buf, req)
    done = False
    while not done:
        _, done = dl.next_chunk()
    buf.seek(0)
    return load_workbook(buf)


def upload_xlsx(drive, file_id, wb):
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    from googleapiclient.http import MediaIoBaseUpload
    media = MediaIoBaseUpload(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", resumable=False)
    drive.files().update(fileId=file_id, media_body=media).execute()


def _apply_sheet_styling(ws, row_count, today_d, title_text=None):
    """Apply VTI-brand styling: title strip, header row, freeze panes, auto-filter,
    column widths, alternating rows, priority/status color pills, overdue red."""
    from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                                  NamedStyle)
    from openpyxl.utils import get_column_letter

    NAVY = "FF051934"; WHITE = "FFFFFFFF"; LIGHT = "FFDAE9F6"
    BG_ALT = "FFF0F5FB"; BORDER = "FFC8DCF0"
    RED_BG = "FFFFE5E5"; RED_FG = "FFB02020"
    AMBER_BG = "FFFFF4D6"; AMBER_FG = "FF6B3D00"
    GREEN_BG = "FFE6F4ED"; GREEN_FG = "FF1A7A4A"
    BLUE_BG = "FFE0EBFA"; BLUE_FG = "FF004AAD"
    GREY_FG = "FF6B7A8D"

    thin = Side(border_style="thin", color=BORDER)
    border_all = Border(left=thin, right=thin, top=thin, bottom=thin)
    nav_fill = PatternFill("solid", fgColor=NAVY)
    alt_fill = PatternFill("solid", fgColor=BG_ALT)
    white_fill = PatternFill("solid", fgColor="FFFFFFFF")
    title_fill = PatternFill("solid", fgColor=NAVY)

    # Column widths
    for i, col in enumerate(COLS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = COL_WIDTHS.get(col, 15)

    # Row 1: Title strip
    if title_text:
        ws.insert_rows(1)
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(COLS))
        c = ws.cell(row=1, column=1, value=title_text)
        c.font = Font(name="Arial", size=12, bold=True, color="FFFFFFFF")
        c.fill = title_fill
        c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[1].height = 28
        header_row = 2
        data_start = 3
    else:
        header_row = 1
        data_start = 2

    # Header row styling — rewrite cells to use friendly labels
    for col_idx, col_name in enumerate(COLS, start=1):
        cell = ws.cell(row=header_row, column=col_idx, value=HEADER_LABELS.get(col_name, col_name))
        cell.font = Font(name="Arial", size=10, bold=True, color="FFFFFFFF")
        cell.fill = nav_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border_all
    ws.row_dimensions[header_row].height = 32

    # Data rows
    for r_idx in range(data_start, data_start + row_count):
        is_alt = ((r_idx - data_start) % 2 == 1)
        for c_idx, col_name in enumerate(COLS, start=1):
            cell = ws.cell(row=r_idx, column=c_idx)
            cell.font = Font(name="Arial", size=10)
            cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True, indent=1)
            cell.border = border_all
            if is_alt:
                cell.fill = alt_fill
            else:
                cell.fill = white_fill
            # Override per-column styles
            val = cell.value
            if col_name == "pic":
                cell.font = Font(name="Arial", size=10, bold=True)
            elif col_name == "deadline":
                dl = parse_dl(val)
                if dl and dl < today_d:
                    # Check status
                    status_cell = ws.cell(row=r_idx, column=COLS.index("status") + 1)
                    if (status_cell.value or "").strip() not in ("Done", "Cancelled"):
                        cell.font = Font(name="Arial", size=10, bold=True, color=RED_FG)
                    else:
                        cell.font = Font(name="Arial", size=10, bold=True, color=GREY_FG)
                else:
                    cell.font = Font(name="Arial", size=10, bold=True, color="FF051934")
                cell.alignment = Alignment(horizontal="center", vertical="top")
            elif col_name == "priority":
                prio = (val or "").lower()
                if prio == "red":
                    cell.fill = PatternFill("solid", fgColor=RED_BG)
                    cell.font = Font(name="Arial", size=10, bold=True, color=RED_FG)
                elif prio == "amber":
                    cell.fill = PatternFill("solid", fgColor=AMBER_BG)
                    cell.font = Font(name="Arial", size=10, bold=True, color=AMBER_FG)
                elif prio == "green":
                    cell.fill = PatternFill("solid", fgColor=GREEN_BG)
                    cell.font = Font(name="Arial", size=10, bold=True, color=GREEN_FG)
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.value = (val or "").upper()
            elif col_name == "status":
                st = (val or "").strip()
                if st == "Open":
                    cell.fill = PatternFill("solid", fgColor=BLUE_BG)
                    cell.font = Font(name="Arial", size=10, bold=True, color=BLUE_FG)
                elif st == "In progress":
                    cell.fill = PatternFill("solid", fgColor=AMBER_BG)
                    cell.font = Font(name="Arial", size=10, bold=True, color=AMBER_FG)
                elif st == "Done":
                    cell.fill = PatternFill("solid", fgColor=GREEN_BG)
                    cell.font = Font(name="Arial", size=10, bold=True, color=GREEN_FG)
                elif st == "Cancelled":
                    cell.fill = PatternFill("solid", fgColor="FFEEEEEE")
                    cell.font = Font(name="Arial", size=10, italic=True, color=GREY_FG)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif col_name == "id":
                cell.font = Font(name="Arial", size=9, color=GREY_FG)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif col_name in ("date_opened", "last_updated"):
                cell.font = Font(name="Arial", size=9, color=GREY_FG)
                cell.alignment = Alignment(horizontal="center", vertical="top")
            elif col_name == "notes":
                # User space — light yellow tint background to distinguish
                cell.fill = PatternFill("solid", fgColor="FFFFFEF0")
                cell.font = Font(name="Arial", size=10, italic=True, color="FF6B7A8D")

    # Freeze top row(s)
    ws.freeze_panes = ws.cell(row=data_start, column=1)
    # Auto-filter
    if row_count > 0:
        last_col = get_column_letter(len(COLS))
        ws.auto_filter.ref = f"A{header_row}:{last_col}{data_start + row_count - 1}"


def _stamp_sheet(ws, today_d, title):
    """Apply styling + count rows."""
    # Count data rows (excluding header)
    rows = sum(1 for r in ws.iter_rows(min_row=2, values_only=True) if r and r[0])
    _apply_sheet_styling(ws, rows, today_d, title_text=title)


def cmd_apply(args):
    brief = json.load(open(BRIEF_PATH))
    actions_in = brief.get("actions") or []
    today = brief["meta"]["date_today"]
    today_d = date.fromisoformat(today)
    creds = load_credentials(); drive = get_drive(creds)
    root = ensure_folder(drive, DRIVE_FOLDER_NAME, parent_id="root")
    file_id, was_created = find_or_create_xlsx(drive, root)
    wb = download_xlsx(drive, file_id)
    if "All" not in wb.sheetnames:
        wb.create_sheet("All", 0).append(COLS)
    ws = wb["All"]

    # Strip prior styling/title to get to raw header + data
    # If first row is merged title row, delete it; then header should be row 1
    if ws.max_row > 0:
        first_cell = ws.cell(row=1, column=1).value
        if first_cell and "Action Tracker" in str(first_cell):
            ws.delete_rows(1)
        # Re-write header row with COLS keys (not friendly labels)
        for ci, key in enumerate(COLS, start=1):
            ws.cell(row=1, column=ci, value=key)

    # Build index of existing rows by id; preserve notes
    existing = {}
    if ws.max_row > 1:
        for row in ws.iter_rows(min_row=2, values_only=False):
            rid = row[0].value
            if rid: existing[rid] = row
    added, updated, unchanged, notes_preserved = 0, 0, 0, 0
    for a in actions_in:
        aid = make_id(a.get("pic", ""), a.get("task", ""), a.get("from_meeting", ""))
        new_row = [aid, today, a.get("pic", ""), a.get("task", ""), a.get("output", ""),
                   a.get("deadline", ""), a.get("priority", ""), a.get("from_meeting", ""),
                   a.get("status", "Open"), today, ""]
        if aid in existing:
            row = existing[aid]
            cur_status = row[8].value
            cur_dl = row[5].value
            cur_task = row[3].value
            cur_notes = row[10].value if len(row) > 10 else ""
            if cur_status != new_row[8] or cur_dl != new_row[5] or cur_task != new_row[3]:
                row[8].value = new_row[8]
                row[5].value = new_row[5]
                row[3].value = new_row[3]
                row[9].value = today
                updated += 1
            else:
                unchanged += 1
            # Notes: KEEP whatever user typed
            if cur_notes:
                notes_preserved += 1
        else:
            ws.append(new_row); added += 1

    # Re-derive Open/Done/Overdue
    for sn in ("Open", "Done", "Overdue"):
        if sn in wb.sheetnames: del wb[sn]
        wb.create_sheet(sn).append(COLS)
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row[0]: continue
        st = (row[8] or "").strip()
        dl = parse_dl(row[5])
        if st in ("Open", "In progress"):
            wb["Open"].append(list(row))
            if dl and dl < today_d:
                wb["Overdue"].append(list(row))
        elif st == "Done":
            wb["Done"].append(list(row))

    # Apply styling
    total = ws.max_row - 1
    open_n = wb["Open"].max_row - 1
    done_n = wb["Done"].max_row - 1
    overdue_n = wb["Overdue"].max_row - 1
    today_label = today_d.strftime("%d/%m/%Y")
    _stamp_sheet(ws, today_d, f"VTI APAC · Action Tracker · Updated {today_label}  ·  {total} actions  ·  {open_n} Open · {done_n} Done · {overdue_n} Overdue")
    _stamp_sheet(wb["Open"], today_d, f"OPEN actions ({open_n})  ·  Updated {today_label}")
    _stamp_sheet(wb["Done"], today_d, f"DONE actions ({done_n})  ·  Updated {today_label}")
    _stamp_sheet(wb["Overdue"], today_d, f"OVERDUE actions ({overdue_n})  ·  Updated {today_label}  ·  Action required")

    upload_xlsx(drive, file_id, wb)
    link = f"https://docs.google.com/spreadsheets/d/{file_id}/edit"
    state = load_state(); state["action_tracker_id"] = file_id; state["action_tracker_link"] = link; save_state(state)
    print(json.dumps({"file_id": file_id, "link": link, "was_created": was_created,
                      "added": added, "updated": updated, "unchanged": unchanged,
                      "notes_preserved": notes_preserved,
                      "total_rows": total, "open": open_n, "done": done_n, "overdue": overdue_n},
                     ensure_ascii=False))
    log(f"Action Tracker styled+updated → {link} ({added} added, {updated} updated, {notes_preserved} notes preserved)")
    return 0


def cmd_link(args):
    state = load_state()
    print(state.get("action_tracker_link", "(not yet created)"))
    return 0


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    pa = sub.add_parser("apply"); pa.set_defaults(func=cmd_apply)
    pl = sub.add_parser("link"); pl.set_defaults(func=cmd_link)
    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
