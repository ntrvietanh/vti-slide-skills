#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""send_discord.py - brief.json -> >=9 posts content-only -> POST Discord webhook.

Tach hoan toan Discord build/post khoi reasoning cua Claude.
Cung brief.json + cung links -> cung payload (deterministic).

Subcommands:
  build              build posts JSON (no POST)
  send               POST pre-built posts JSON
  build-and-send     both
  dry-run            build + print, NO POST
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

from meeting_lib import (
    BRIEF_PATH,
    DISCORD_POST_MAX_CHARS,
    DISCORD_POSTS_PATH,
    DISCORD_USER_AGENT,
    DISCORD_WEBHOOK,
    LOCAL_TZ,
    load_json,
    log,
    save_json,
    shorten,
)

RISK_EMOJI = {"red": "🔴", "amber": "🟡", "green": "🟢"}
WEEKDAYS_VI = ["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ Nhật"]


def _risk(level):
    return RISK_EMOJI.get((level or "green").lower(), "🟢")


def _fmt_date(iso, fmt="%d/%m"):
    return datetime.fromisoformat(iso).strftime(fmt)


def _weekday_vi(iso):
    return WEEKDAYS_VI[datetime.fromisoformat(iso).weekday()]


def _iso_plus_days(iso, days):
    dt = datetime.fromisoformat(iso)
    return datetime.fromordinal(dt.toordinal() + days).strftime("%Y-%m-%d")


def _short_time(iso):
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.astimezone(LOCAL_TZ).strftime("%d-%m %H:%M")
    except Exception:
        return iso[:16]


def build_overview(brief, doc_link):
    meta = brief["meta"]
    today_iso = meta["date"]
    today_str = _fmt_date(today_iso)
    today_wd = _weekday_vi(today_iso)
    version = meta.get("version", 1)
    counts = meta.get("counts", {})
    tomorrow_str = "?"
    if brief.get("tomorrow_meetings"):
        tmw_iso = brief["tomorrow_meetings"][0].get("date") or ""
        if tmw_iso:
            tomorrow_str = _fmt_date(tmw_iso)
    today_meetings = brief.get("today_meetings") or []
    tomorrow_meetings = brief.get("tomorrow_meetings") or []
    today_actions = brief.get("actions") or []
    red_actions = [a for a in today_actions if (a.get("priority") or "").lower() == "red"]
    external_tmw = sum(
        1 for m in tomorrow_meetings if any(not a.get("internal") for a in m.get("attendees", []))
    )
    internal_tmw = len(tomorrow_meetings) - external_tmw
    vs = brief.get("vs_yesterday_totals") or {}
    chat = brief.get("chat_intel") or None
    parts = []
    parts.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    parts.append(f"📋 **DAILY RECAP & PREP — {today_wd}, {today_str}/{today_iso.split('-')[0]}** `(v{version})`")
    parts.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    if doc_link:
        parts.append(f"👉 **Full prep doc:** <{doc_link}>")
    parts.append("")
    parts.append("🗓️ **TỔNG QUAN — HÔM NAY vs NGÀY MAI**")
    parts.append("")
    parts.append(
        f"📅 **Hôm nay ({today_str}):** {len(today_meetings)} meetings · "
        f"{len(today_actions)} action Michael ({len(red_actions)} RED urgent)"
    )
    parts.append(
        f"🎯 **Ngày mai ({tomorrow_str}):** {len(tomorrow_meetings)} meetings · "
        f"external: {external_tmw}, internal: {internal_tmw}"
    )
    if vs:
        parts.append(
            f"📚 **So với prep hôm qua:** Hit {vs.get('hit',0)} · "
            f"Miss {vs.get('miss',0)} · New {vs.get('new',0)}"
        )
    if chat:
        spaces_active = counts.get("chat_spaces_active", "?")
        pending = len(chat.get("pending_replies_michael") or [])
        urgency = len(chat.get("urgency_flags") or [])
        parts.append(
            f"💬 **Chat 24h:** {spaces_active} spaces active · "
            f"{pending} pending replies · {urgency} urgency flags"
        )
    parts.append("")
    if red_actions:
        parts.append("🔴 **TOP RED ACTIONS MICHAEL (tuần tới):**")
        for a in red_actions[:5]:
            parts.append(f"• {a.get('task','?')} → **{a.get('deadline','—')}**")
        parts.append("")
    gaps = brief.get("gaps") or []
    if gaps:
        parts.append("⚠️ **CẦN CHÚ Ý:**")
        for g in gaps[:5]:
            parts.append(f"• {g}")
    return "\n".join(parts)


def build_chat_radar(chat_intel):
    if not chat_intel:
        return "⚠️ Chat data unavailable hôm nay (pipeline lỗi)"
    parts = ["💬 **CHAT RADAR — 24h qua + 7d trending**", ""]
    trending = chat_intel.get("trending_topics") or []
    if trending:
        parts.append("🔥 **Trending topics (top 5, 7d):**")
        for t in trending[:5]:
            if isinstance(t, dict):
                topic = t.get("topic", "?")
                count = t.get("count", "?")
                cite = t.get("sample_cite", "")
                parts.append(f"• {topic} — {count} msg / {len(t.get('spaces') or [])} spaces {cite}")
            else:
                parts.append(f"• {t}")
        parts.append("")
    pending = chat_intel.get("pending_replies_michael") or []
    if pending:
        parts.append("📨 **Michael cần reply (pending > 24h):**")
        for p in pending[:4]:
            if isinstance(p, dict):
                emoji = _risk(p.get("priority", "amber"))
                snippet = shorten(p.get("snippet", ""), 60)
                parts.append(
                    f"• {emoji} {p.get('pic_name','?')} @ {p.get('space_short','?')} · "
                    f'"{snippet}" ({_short_time(p.get("created_at",""))})'
                )
            else:
                parts.append(f"• {p}")
        parts.append("")
    shifts = chat_intel.get("sentiment_shifts") or []
    if shifts:
        parts.append("🎭 **Sentiment shift:**")
        for s in shifts[:2]:
            if isinstance(s, dict):
                parts.append(
                    f"• {s.get('pic_name','?')} — {s.get('observation','?')} "
                    f"{s.get('evidence_cite','')}"
                )
            else:
                parts.append(f"• {s}")
        parts.append("")
    urgency = chat_intel.get("urgency_flags") or []
    if urgency:
        parts.append("⚡ **Urgency flags (24-48h):**")
        for u in urgency[:3]:
            if isinstance(u, dict):
                parts.append(f"• {u.get('issue','?')} {u.get('cite','')}")
            else:
                parts.append(f"• {u}")
    return "\n".join(parts).rstrip()


def build_today_post(m, is_first, today_iso):
    parts = []
    if is_first:
        parts.append(f"🟨 **PHẦN 1 · HÔM NAY CHỐT GÌ ({_fmt_date(today_iso)})**")
        parts.append("")
    risk = _risk(m.get("risk_level"))
    title = m.get("title", "?")
    time_str = m.get("time", "—")
    mode = m.get("mode", "—")
    duration = m.get("duration", "—")
    risk_word = (m.get("risk_level") or "GREEN").upper()
    is_internal = m.get("is_internal", False)
    parts.append(f"{risk} **{time_str} · {title}**")
    parts.append(
        f"_{'Internal' if is_internal else 'External'} · {mode} · {duration} · {risk} {risk_word} risk_"
    )
    parts.append("")
    ext = [a for a in m.get("attendees", []) if not a.get("internal")]
    intl = [a for a in m.get("attendees", []) if a.get("internal")]
    if ext:
        ext_str = ", ".join(
            f"{a.get('name','?')} ({a.get('role','—')}@{a.get('company','—')})" for a in ext
        )
        parts.append(f"👥 **External:** {ext_str}")
    if intl:
        intl_str = ", ".join(a.get("name", "?") for a in intl)
        parts.append(f"👥 **Internal:** {intl_str}")
    parts.append("")
    decisions = m.get("decisions") or []
    parts.append("📌 **CHỐT:**")
    if decisions:
        for d in decisions[:3]:
            parts.append(f"• {d}")
    else:
        parts.append("• Chưa có decision cuối — vẫn discussion (xem Doc).")
    parts.append("")
    actions_meeting = m.get("actions") or []
    n = len(actions_meeting)
    n_red = sum(1 for a in actions_meeting if (a.get("priority") or "").lower() == "red")
    n_amber = sum(1 for a in actions_meeting if (a.get("priority") or "").lower() == "amber")
    n_green = sum(1 for a in actions_meeting if (a.get("priority") or "").lower() == "green")
    parts.append(f"✅ **Actions team:** {n} ({n_red} RED, {n_amber} AMBER, {n_green} GREEN)")
    michael_red = next(
        (
            a for a in actions_meeting
            if (a.get("priority") or "").lower() == "red" and "michael" in (a.get("pic", "")).lower()
        ),
        None,
    )
    if michael_red:
        parts.append(
            f"• 🔴 **Michael:** {michael_red.get('task','?')} → **{michael_red.get('deadline','—')}**"
        )
    parts.append(f"📌 **Carry:** {m.get('carry_count', 0)} action chưa close từ prep hôm qua")
    parts.append("")
    obs = m.get("pic_observation") or []
    if obs:
        parts.append(f"🔍 **PIC obs:** {obs[0]}")
    return "\n".join(parts).rstrip()


def build_tomorrow_post(m, is_first, tomorrow_iso):
    parts = []
    if is_first:
        parts.append(f"🟩 **PHẦN 2 · NGÀY MAI BRIEF ({_fmt_date(tomorrow_iso)})**")
        parts.append("")
    risk = _risk(m.get("risk_level"))
    title = m.get("title", "?")
    time_str = m.get("time", "—")
    mode = m.get("mode", "—")
    risk_word = (m.get("risk_level") or "GREEN").upper()
    is_internal = m.get("is_internal", False)
    parts.append(f"{risk} **{time_str} · {title}**")
    parts.append(f"_{'Internal' if is_internal else 'External'} · {mode} · {risk} {risk_word} risk_")
    parts.append("")
    parts.append(f"⚠️ **Risk:** {m.get('risk_reason','—')}")
    parts.append("")
    ext = [a for a in m.get("attendees", []) if not a.get("internal")]
    intl = [a for a in m.get("attendees", []) if a.get("internal")]
    if ext:
        parts.append("👥 **External:**")
        for a in ext:
            note = f' — {a.get("note","")}' if a.get("note") else ""
            parts.append(f"• {a.get('name','?')} ({a.get('role','—')}@{a.get('company','—')}){note}")
    if intl:
        parts.append("👥 **Internal:** " + ", ".join(a.get("name", "?") for a in intl))
    parts.append("")
    objectives = m.get("objectives") or []
    if objectives:
        parts.append(f"📌 **Về:** {objectives[0]}")
        parts.append("")
    popups = m.get("popups") or []
    if popups:
        parts.append("⚠️ **Chú ý:**")
        for p in popups[:4]:
            parts.append(f"• {p}")
        parts.append("")
    chat_sig = m.get("chat_signals") or []
    chat_hint = shorten(chat_sig[0], 140) if chat_sig else "—"
    parts.append(f"💬 **Chat hint:** {chat_hint}")
    vti_brings = m.get("vti_brings")
    if vti_brings:
        parts.append("")
        parts.append(f"📎 **VTI mang:** {vti_brings}")
    return "\n".join(parts).rstrip()


def build_ai_wrap(brief, doc_link, memory_link):
    ai = brief.get("ai_log_summary") or {}
    meta = brief["meta"]
    now_str = datetime.now(LOCAL_TZ).strftime("%H:%M ICT %d/%m/%Y")
    version = meta.get("version", 1)
    parts = []
    parts.append(f"🤖 **PHỤ LỤC D · AI ANALYSIS LOG** _(v{version} run · {now_str})_")
    parts.append("")
    parts.append(f"• **Persona inference:** {ai.get('persona', '—')}")
    parts.append(f"• **Action quality-check:** {ai.get('action_qc', '—')}")
    parts.append(f"• **Cross-meeting carry:** {ai.get('cross_carry', '—')}")
    parts.append(f"• **Chat context extractor:** {ai.get('chat_extractor', '—')}")
    parts.append(f"• **Sanity-check publish:** {ai.get('sanity', '—')}")
    parts.append("")
    parts.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    parts.append(f"✅ **Recap+Prep done.** Daily v{version} + Memory updated.")
    if doc_link:
        parts.append(f"📄 Doc: <{doc_link}>")
    if memory_link:
        parts.append(f"🧠 Memory: <{memory_link}>")
    parts.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    return "\n".join(parts)


def build_posts(brief, doc_link, memory_link):
    meta = brief["meta"]
    today_iso = meta["date"]
    tomorrow_iso = (
        (brief.get("tomorrow_meetings") or [{}])[0].get("date")
        or _iso_plus_days(today_iso, 1)
    )
    chat_intel = brief.get("chat_intel") or None
    posts = []
    posts.append({"label": "1/N Tổng quan", "content": build_overview(brief, doc_link)})
    if chat_intel:
        posts.append({"label": "2/N Chat Radar", "content": build_chat_radar(chat_intel)})
    for i, m in enumerate(brief.get("today_meetings") or []):
        label = f"{len(posts)+1}/N Hôm nay · {shorten(m.get('title','?'), 40)}"
        posts.append({"label": label, "content": build_today_post(m, i == 0, today_iso)})
    for i, m in enumerate(brief.get("tomorrow_meetings") or []):
        label = f"{len(posts)+1}/N Ngày mai · {shorten(m.get('title','?'), 40)}"
        posts.append({"label": label, "content": build_tomorrow_post(m, i == 0, tomorrow_iso)})
    posts.append({"label": f"{len(posts)+1}/N AI+Wrap", "content": build_ai_wrap(brief, doc_link, memory_link)})
    return posts


def validate(posts, brief):
    issues = []
    chat_intel = brief.get("chat_intel") or None
    today_meetings = brief.get("today_meetings") or []
    tomorrow_meetings = brief.get("tomorrow_meetings") or []
    expected_min = 1 + (1 if chat_intel else 0) + len(today_meetings) + len(tomorrow_meetings) + 1
    if len(posts) < expected_min:
        issues.append(f"posts={len(posts)} < expected_min={expected_min}")
    for p in posts:
        if len(p["content"]) > DISCORD_POST_MAX_CHARS:
            issues.append(f'post "{p["label"]}" = {len(p["content"])} chars > {DISCORD_POST_MAX_CHARS}')
    if chat_intel and len(posts) >= 2:
        if "CHAT RADAR" not in posts[1]["content"] and "Chat Radar" not in posts[1]["label"]:
            issues.append("Chat Radar không phải post #2")
    for p in posts:
        c = p["content"]
        if "📌 **CHỐT:**" in c or "Chưa có decision cuối" in c:
            if not any(d in c for d in ("🔴", "🟡", "🟢")):
                issues.append(f'today post "{p["label"]}" thiếu Risk dot')
            if "📌 **Carry:**" not in c:
                issues.append(f'today post "{p["label"]}" thiếu Carry')
    for p in posts:
        c = p["content"]
        if "📌 **Về:**" in c:
            if "💬 **Chat hint:**" not in c:
                issues.append(f'tomorrow post "{p["label"]}" thiếu 💬 Chat hint')
            if not any(d in c for d in ("🔴", "🟡", "🟢")):
                issues.append(f'tomorrow post "{p["label"]}" thiếu Risk dot')
    for p in posts[:-1]:
        if "🧠 Memory:" in p["content"]:
            issues.append(f'Memory link chỉ ở wrap-up cuối, không ở "{p["label"]}"')
    return issues


def post_one(content, label):
    assert len(content) <= DISCORD_POST_MAX_CHARS, (
        f"[{label}] content {len(content)} > {DISCORD_POST_MAX_CHARS}"
    )
    data = json.dumps({"content": content}, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json", "User-Agent": DISCORD_USER_AGENT}
    req = urllib.request.Request(DISCORD_WEBHOOK, data=data, headers=headers)
    try:
        resp = urllib.request.urlopen(req)
        log(f"[{label}] HTTP {resp.status} | {len(content)} chars")
        return resp.status
    except urllib.error.HTTPError as ex:
        body = ex.read().decode("utf-8", errors="replace") if hasattr(ex, "read") else ""
        log(f"[{label}] HTTP ERROR {ex.code}: {body[:300]}")
        time.sleep(5)
        try:
            resp = urllib.request.urlopen(
                urllib.request.Request(DISCORD_WEBHOOK, data=data, headers=headers)
            )
            log(f"[{label}] retry HTTP {resp.status}")
            return resp.status
        except Exception as ex2:
            log(f"[{label}] retry failed: {ex2}")
            return None


def cmd_build(args):
    brief = load_json(Path(args.brief) if args.brief else BRIEF_PATH)
    if not brief:
        print("FAIL: brief.json missing", file=sys.stderr)
        return 2
    links = load_json(Path(args.links)) if args.links else {}
    doc_link = links.get("doc_link")
    memory_link = links.get("memory_link")
    posts = build_posts(brief, doc_link, memory_link)
    issues = validate(posts, brief)
    if issues:
        print("VALIDATION FAILED:", file=sys.stderr)
        for i in issues:
            print(f"  - {i}", file=sys.stderr)
        if not args.force:
            return 3
    out = Path(args.out) if args.out else DISCORD_POSTS_PATH
    save_json(out, posts)
    print(f"Built {len(posts)} posts -> {out}")
    return 0


def cmd_send(args):
    posts_path = Path(args.posts) if getattr(args, "posts", None) else DISCORD_POSTS_PATH
    posts = load_json(posts_path)
    if not posts:
        print(f"FAIL: posts file missing/empty at {posts_path}", file=sys.stderr)
        return 2
    sent_ok = 0
    for p in posts:
        status = post_one(p["content"], p["label"])
        if status is not None:
            sent_ok += 1
        time.sleep(1)
    print(json.dumps({"total": len(posts), "ok": sent_ok}, ensure_ascii=False))
    return 0 if sent_ok == len(posts) else 1


def cmd_build_and_send(args):
    rc = cmd_build(args)
    if rc != 0:
        return rc
    return cmd_send(args)


def cmd_dry_run(args):
    brief = load_json(Path(args.brief) if args.brief else BRIEF_PATH)
    if not brief:
        print("FAIL: brief.json missing", file=sys.stderr)
        return 2
    links = load_json(Path(args.links)) if args.links else {}
    posts = build_posts(brief, links.get("doc_link"), links.get("memory_link"))
    issues = validate(posts, brief)
    print(f"Built {len(posts)} posts.")
    if issues:
        print(f"{len(issues)} validation issues:")
        for i in issues:
            print(f"   - {i}")
    else:
        print("All validation passed.")
    print()
    for p in posts:
        print(f"--- {p['label']} ({len(p['content'])} chars) ---")
        print(p["content"])
        print()
    return 0 if not issues else 3


def main():
    parser = argparse.ArgumentParser(description="Build & send Discord posts from brief.json")
    sub = parser.add_subparsers(dest="cmd", required=True)
    pb = sub.add_parser("build")
    pb.add_argument("--brief")
    pb.add_argument("--links")
    pb.add_argument("--out")
    pb.add_argument("--force", action="store_true")
    pb.set_defaults(func=cmd_build)
    ps = sub.add_parser("send")
    ps.add_argument("--posts")
    ps.set_defaults(func=cmd_send)
    pa = sub.add_parser("build-and-send")
    pa.add_argument("--brief")
    pa.add_argument("--links")
    pa.add_argument("--out")
    pa.add_argument("--force", action="store_true")
    pa.set_defaults(func=cmd_build_and_send)
    pd = sub.add_parser("dry-run")
    pd.add_argument("--brief")
    pd.add_argument("--links")
    pd.set_defaults(func=cmd_dry_run)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
