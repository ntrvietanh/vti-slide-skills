#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
send_discord.py -- Gui crawl summary vao Discord webhook (plain text, no embed).

Doc _summaries_ready.json + _summary_queue.json de tong hop:
  - Tong so chats duoc update va so messages
  - Keynotes cua tung space

Exit codes: 0 success | 1 fatal
"""
import json
import sys
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path


SCRIPT_DIR       = Path(__file__).parent.resolve()
DISCORD_CFG_FILE = SCRIPT_DIR / "discord_config.json"
SUMMARIES_FILE   = SCRIPT_DIR / "_summaries_ready.json"
QUEUE_FILE       = SCRIPT_DIR / "_summary_queue.json"

MAX_MSG_LEN = 1900   # safe margin duoi 2000-char Discord limit


def log(msg):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def load_json(path):
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        log(f"  ! load_json({path.name}): {e}")
        return {}


def send_webhook(webhook_url, payload, username="", avatar_url=""):
    if username:
        payload["username"] = username
    if avatar_url:
        payload["avatar_url"] = avatar_url
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req  = urllib.request.Request(
        webhook_url, data=data,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": "DiscordBot (https://github.com, 1.0)",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            if resp.status in (200, 204):
                return True
            log(f"  ! Unexpected status {resp.status}")
            return False
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        log(f"  ! HTTPError {e.code}: {body[:300]}")
        return False
    except Exception as e:
        log(f"  ! Request failed: {e}")
        return False


def build_messages(summaries_data, queue_data):
    """Tra ve list cac plain-text content string, moi cai <= MAX_MSG_LEN ky tu."""
    now_str         = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    summaries       = summaries_data.get("summaries", [])
    queue_spaces    = queue_data.get("spaces", [])

    total_active    = queue_data.get("spaces_active", 0)
    total_done      = queue_data.get("spaces_done", 0)
    full_pass       = queue_data.get("full_pass", False)
    total_msgs_new  = sum(s.get("msg_count_new", 0) for s in queue_spaces)
    spaces_with_new = len([s for s in queue_spaces if s.get("msg_count_new", 0) > 0])

    fp_icon = "OK" if full_pass else "partial"

    # Header message
    header = (
        "**[GChat Crawl] " + now_str + "**\n"
        + str(spaces_with_new) + " chat co tin nhan moi | "
        + str(total_msgs_new) + " messages | "
        + str(total_done) + "/" + str(total_active)
        + " spaces crawled (" + fp_icon + ")"
    )

    if not summaries:
        if total_msgs_new == 0:
            note = "Khong co chat moi hom nay."
        else:
            note = "Co messages nhung chua du nguong tom tat."
        return [header + "\n" + note]

    messages = [header]

    # Sap xep theo tong msg_count giam dan
    sorted_sum = sorted(
        summaries,
        key=lambda s: sum(d.get("msg_count", 0) for d in s.get("daily_summaries", {}).values()),
        reverse=True,
    )

    for space in sorted_sum:
        name  = space.get("display_name", space.get("space_id", "?"))
        stype = space.get("space_type", "")
        daily = space.get("daily_summaries", {})
        space_msgs = sum(d.get("msg_count", 0) for d in daily.values())

        if stype == "DIRECT_MESSAGE":
            icon = "DM"
        elif stype == "GROUP_CHAT":
            icon = "GC"
        else:
            icon = "SP"

        lines = ["**[" + icon + "] " + name + "** (" + str(space_msgs) + " msgs)"]
        for date_str in sorted(daily.keys()):
            day     = daily[date_str]
            summary = day.get("summary", "")
            first   = summary.split(".")[0].strip()
            if first:
                lines.append("  " + date_str + ": " + first + ".")
            for d in day.get("decisions", [])[:2]:
                lines.append("    > " + d)
            for ai in day.get("action_items", [])[:1]:
                who  = ai.get("who", "?")
                what = ai.get("what", "?")
                lines.append("    ! " + who + ": " + what)

        block = "\n".join(lines)
        if len(block) > MAX_MSG_LEN:
            block = block[:MAX_MSG_LEN - 3] + "..."

        # Gop vao message truoc neu con cho, neu khong tao message moi
        if messages and len(messages[-1]) + 2 + len(block) <= MAX_MSG_LEN:
            messages[-1] = messages[-1] + "\n\n" + block
        else:
            messages.append(block)

    return messages


def main():
    log("=" * 60)
    log("send_discord.py started")

    cfg = load_json(DISCORD_CFG_FILE)
    webhook_url = cfg.get("webhook_url", "").strip()
    if not webhook_url or not webhook_url.startswith("https://discord.com/api/webhooks/"):
        log("FATAL: discord_config.json thieu hoac webhook_url khong hop le")
        return 1

    username   = cfg.get("username", "GChat Crawler")
    avatar_url = cfg.get("avatar_url", "")

    summaries_data = load_json(SUMMARIES_FILE)
    queue_data     = load_json(QUEUE_FILE)

    messages = build_messages(summaries_data, queue_data)
    log("  Sending " + str(len(messages)) + " plain-text message(s) ...")

    errors = 0
    for i, content in enumerate(messages, 1):
        payload = {"content": content}
        ok = send_webhook(webhook_url, payload, username=username, avatar_url=avatar_url)
        if ok:
            log("  Message " + str(i) + "/" + str(len(messages))
                + " sent OK (" + str(len(content)) + " chars).")
        else:
            log("  ! Message " + str(i) + "/" + str(len(messages)) + " FAILED.")
            errors += 1

    if errors == 0:
        log("  Discord notification sent OK.")
        return 0
    else:
        log("FATAL: " + str(errors) + "/" + str(len(messages)) + " messages failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
