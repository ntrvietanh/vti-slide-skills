#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
crawl_gchat.py v2 — Google Chat crawler
User: anh.nguyentruongviet@vti.com.vn

Drive structure:
  Google Chat Crawl/
  ├── _stage.json          ← global crawl state (resume point)
  ├── _index.json          ← space catalog: name→id→Drive folder ID
  └── spaces/
      └── <space_id>/
          ├── _summary.json    ← DETERMINISTIC navigation summary (last 7d stats)
          ├── _narrative.json  ← AI narrative summary written by scheduled task
          ├── 2026-05-13.jsonl ← messages normalized, one JSON per line
          └── 2026-05-15.jsonl

Two-tier design:
  Tier 1 (navigation, lightweight, deterministic):  _index.json + per-space _summary.json
  Tier 2 (raw data, on-demand):                     per-space YYYY-MM-DD.jsonl
  Optional AI layer:                                per-space _narrative.json

Message JSONL format (flat, agent-friendly):
  {"msg_id","space_id","space_name","space_type","thread_id","is_thread_reply",
   "create_time","sender_name","sender_email","text",
   "has_attachment","attachment_names","reactions","crawled_at"}

Auto full-history: if _stage.json not found on Drive → first run → crawl ALL history.

Usage:
  python crawl_gchat.py                      normal incremental run
  python crawl_gchat.py --full-history       force recrawl from beginning
  python crawl_gchat.py --dry-run            crawl but save locally, no Drive upload
  python crawl_gchat.py --auth-url           start OAuth flow
  python crawl_gchat.py --finish-auth "..."  complete OAuth
"""

import argparse
import json
import os
import sys
import threading
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urlparse

os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaInMemoryUpload

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SCRIPT_DIR         = Path(__file__).parent.resolve()
CREDENTIALS_FILE   = SCRIPT_DIR / "credentials.json"
TOKEN_FILE         = SCRIPT_DIR / "token.json"
STATE_FILE         = SCRIPT_DIR / "state.json"
LOG_FILE           = SCRIPT_DIR / "crawl.log"
PKCE_VERIFIER_FILE = SCRIPT_DIR / ".pkce_verifier"
MEMBERS_CACHE_FILE = SCRIPT_DIR / "_members_cache.json"

# Local TZ for "is today Sunday?" check on members-cache refresh schedule
LOCAL_TZ           = timezone(timedelta(hours=7))   # GMT+7 (Asia/Ho_Chi_Minh)

# Refresh members cache weekly on Sunday OR if older than this (safety net)
MEMBERS_CACHE_MAX_AGE_DAYS = 8

DRIVE_ROOT_NAME    = "Google Chat Crawl"
DRIVE_SPACES_NAME  = "spaces"
STAGE_FILENAME     = "_stage.json"
INDEX_FILENAME     = "_index.json"
SUMMARY_FILENAME   = "_summary.json"     # AI-generated daily summary (written by Claude session)

# AI summary window for queue (how much context to give Claude)
SUMMARY_DAYS                = 14
SELF_EMAIL                  = "anh.nguyentruongviet@vti.com.vn"

# Cache self user_name (users/<id>) — detected lazily from sender.email matching SELF_EMAIL
_SELF_USER_NAME: list = [None]   # mutable container so functions can update

# Cache resolved displayName per user resource (users/<id> → "Nguyen Van A" | None)
# Populated lazily qua People API. Hydrated from _members_cache.json at run start.
_USER_NAME_CACHE: dict = {}
_PEOPLE_CLIENT: list = [None]    # singleton, set in run_crawl

# Cache resolved display name per space (sid → {"display_name": str, "resolved_at": iso}).
# Hydrated from _members_cache.json at run start. resolve_display_name() consults
# this first and skips expensive members.list + people.get when hit.
_SPACE_DISPLAY_CACHE: dict = {}

# Mutable flag toggled by run_crawl() — when True, resolve_display_name() bypasses
# the cache and forces a fresh members.list + People API resolution. Set on Sunday
# (GMT+7), on first run, or when cache age > MEMBERS_CACHE_MAX_AGE_DAYS.
_FORCE_MEMBER_REFRESH: list = [False]

# Time-budget defaults — bash tool max is 45s, leave headroom
DEFAULT_MAX_SECONDS         = 35

SCOPES = [
    "https://www.googleapis.com/auth/chat.spaces.readonly",
    "https://www.googleapis.com/auth/chat.messages.readonly",
    "https://www.googleapis.com/auth/chat.memberships.readonly",
    "https://www.googleapis.com/auth/drive.file",
    # People API — resolve users/<id> → displayName (Chat API không trả về)
    "https://www.googleapis.com/auth/directory.readonly",
    "https://www.googleapis.com/auth/contacts.readonly",
]

OOB_REDIRECT_URI = "http://localhost"
SCHEMA_VERSION   = 2
WORKERS          = 4      # concurrent space-fetch threads (lowered from 15 — OpenSSL thread-safety crashes with People-API under load)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def log(msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass

# ---------------------------------------------------------------------------
# OAuth (unchanged from v1)
# ---------------------------------------------------------------------------

def build_flow() -> Flow:
    if not CREDENTIALS_FILE.exists():
        raise FileNotFoundError(f"Missing {CREDENTIALS_FILE}.")
    return Flow.from_client_secrets_file(
        str(CREDENTIALS_FILE), scopes=SCOPES, redirect_uri=OOB_REDIRECT_URI)

def print_auth_url() -> None:
    flow = build_flow()
    auth_url, _ = flow.authorization_url(
        access_type="offline", include_granted_scopes="true", prompt="consent")
    verifier = getattr(flow, "code_verifier", None)
    if verifier:
        PKCE_VERIFIER_FILE.write_text(verifier, encoding="utf-8")
    print("\n" + "=" * 72)
    print("OPEN IN BROWSER (VTI Workspace account):")
    print(auth_url)
    print("=" * 72)
    print('\nAfter approving, run:\n  python crawl_gchat.py --finish-auth "<full redirect URL>"\n')

def finish_auth(redirect_url: str) -> None:
    parsed = urlparse(redirect_url)
    code = parse_qs(parsed.query).get("code", [None])[0]
    if not code:
        raise ValueError("No ?code= in URL.")
    flow = build_flow()
    if PKCE_VERIFIER_FILE.exists():
        flow.code_verifier = PKCE_VERIFIER_FILE.read_text(encoding="utf-8").strip()
    flow.fetch_token(code=code)
    TOKEN_FILE.write_text(flow.credentials.to_json(), encoding="utf-8")
    log(f"Token saved → {TOKEN_FILE}")

def load_credentials() -> Credentials:
    if not TOKEN_FILE.exists():
        raise FileNotFoundError("Missing token.json — run --auth-url first.")
    creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)
    if not creds.valid:
        if creds.expired and creds.refresh_token:
            log("Refreshing OAuth token...")
            creds.refresh(Request())
            TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
        else:
            raise RuntimeError("Credentials not refreshable — re-run --auth-url.")
    # Init People API client (lazy, used by resolve_user_name_via_people)
    if _PEOPLE_CLIENT[0] is None:
        try:
            _PEOPLE_CLIENT[0] = build(
                "people", "v1", credentials=creds, cache_discovery=False)
            detect_self_via_people()
        except Exception as e:
            log(f"  ! Không init được People API client: {e}")
    return creds

# ---------------------------------------------------------------------------
# Members cache — persisted display-name + user-name resolutions
# ---------------------------------------------------------------------------
#
# Schema of _members_cache.json:
#   {
#     "schema_version": 1,
#     "refreshed_at": ISO timestamp of last FULL refresh (Sunday or first run),
#     "refresh_timezone": "Asia/Ho_Chi_Minh",
#     "user_names": { "users/<gaia_id>": "Display Name" | null, ... },
#     "spaces":     { "<sid>": {"display_name": "...", "resolved_at": ISO}, ... }
#   }
#
# Two layers:
#   - user_names: avoids People API people.get() for every member each run
#   - spaces:     avoids members.list + assembly logic for spaces seen before
#
# Refresh policy (decided once per run):
#   - cache file missing                → force refresh (full crawl, all spaces)
#   - today is Sunday in LOCAL_TZ
#       AND no refresh has happened yet today    → force refresh
#   - refreshed_at age > MAX_AGE_DAYS    → force refresh (safety net)
#   - otherwise                          → use cache; resolve new spaces ad-hoc

MEMBERS_CACHE_SCHEMA_VERSION = 1


def load_members_cache() -> dict:
    """Read _members_cache.json from disk. Returns empty skeleton if missing/corrupt."""
    if not MEMBERS_CACHE_FILE.exists():
        return {
            "schema_version":   MEMBERS_CACHE_SCHEMA_VERSION,
            "refreshed_at":     None,
            "refresh_timezone": "Asia/Ho_Chi_Minh",
            "user_names":       {},
            "spaces":           {},
        }
    try:
        data = json.loads(MEMBERS_CACHE_FILE.read_text(encoding="utf-8"))
        # Defensive: ensure required keys
        data.setdefault("user_names", {})
        data.setdefault("spaces", {})
        return data
    except (json.JSONDecodeError, OSError) as e:
        log(f"  ! load_members_cache failed ({e}) — starting empty")
        return {
            "schema_version":   MEMBERS_CACHE_SCHEMA_VERSION,
            "refreshed_at":     None,
            "refresh_timezone": "Asia/Ho_Chi_Minh",
            "user_names":       {},
            "spaces":           {},
        }


def should_refresh_members(cache: dict, now_utc: datetime) -> tuple:
    """Decide whether this run should force-rebuild the members cache.

    Returns (should_refresh: bool, reason: str).
    """
    refreshed_at = cache.get("refreshed_at")
    if not refreshed_at or not cache.get("user_names"):
        return True, "cache empty / first run"

    try:
        refreshed_dt = datetime.fromisoformat(refreshed_at.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return True, "refreshed_at unparseable"

    age_days = (now_utc - refreshed_dt).total_seconds() / 86400.0
    if age_days > MEMBERS_CACHE_MAX_AGE_DAYS:
        return True, f"cache age {age_days:.1f}d > {MEMBERS_CACHE_MAX_AGE_DAYS}d"

    # Sunday weekly refresh — only if we haven't already refreshed today (LOCAL_TZ)
    now_local       = now_utc.astimezone(LOCAL_TZ)
    refreshed_local = refreshed_dt.astimezone(LOCAL_TZ)
    if now_local.weekday() == 6:  # 0=Mon ... 6=Sun
        if refreshed_local.date() != now_local.date():
            return True, "Sunday weekly refresh (GMT+7)"

    return False, f"fresh cache (age {age_days:.1f}d, last {refreshed_local.date()})"


def hydrate_caches_from_disk(cache: dict) -> None:
    """Populate module-level _USER_NAME_CACHE and _SPACE_DISPLAY_CACHE from disk cache.

    Call BEFORE the thread pool starts so workers see consistent cache state.
    """
    _USER_NAME_CACHE.clear()
    _SPACE_DISPLAY_CACHE.clear()
    for user_resource, name in (cache.get("user_names") or {}).items():
        # Allow None — means previously resolved as "not found", skip People API again
        _USER_NAME_CACHE[user_resource] = name
    for sid, entry in (cache.get("spaces") or {}).items():
        if isinstance(entry, dict) and entry.get("display_name"):
            _SPACE_DISPLAY_CACHE[sid] = entry


def serialize_caches_to_disk(force_refresh_happened: bool,
                              now_utc: datetime) -> None:
    """Dump module-level caches → _members_cache.json.

    If `force_refresh_happened` is True, advance `refreshed_at` to now (this run
    rebuilt the cache from scratch). Otherwise preserve previous refreshed_at.
    """
    existing = load_members_cache()
    if force_refresh_happened:
        refreshed_at = now_utc.isoformat()
    else:
        refreshed_at = existing.get("refreshed_at") or now_utc.isoformat()

    payload = {
        "schema_version":   MEMBERS_CACHE_SCHEMA_VERSION,
        "refreshed_at":     refreshed_at,
        "refresh_timezone": "Asia/Ho_Chi_Minh",
        "user_names":       dict(_USER_NAME_CACHE),
        "spaces":           dict(_SPACE_DISPLAY_CACHE),
    }
    try:
        MEMBERS_CACHE_FILE.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8")
        log(f"  Saved members cache: {len(_USER_NAME_CACHE)} users, "
            f"{len(_SPACE_DISPLAY_CACHE)} spaces "
            f"(force_refresh={force_refresh_happened})")
    except OSError as e:
        log(f"  ! save members cache failed: {e}")


# ---------------------------------------------------------------------------
# Summary queue — written after crawl, read by Claude in scheduled task
# ---------------------------------------------------------------------------

SUMMARY_QUEUE_FILE = SCRIPT_DIR / "_summary_queue.json"
SUMMARY_QUEUE_MAX_SPACES = 12   # top N most active spaces per run
SUMMARY_QUEUE_MAX_MSGS   = 300  # max messages per space in queue

def write_summary_queue(spaces_data: list, now_utc: datetime) -> None:
    """Save recent messages for active spaces so Claude can reason + summarize them."""
    # Sort by message count desc, take top N
    sorted_spaces = sorted(spaces_data, key=lambda x: x["msg_count"], reverse=True)
    top = sorted_spaces[:SUMMARY_QUEUE_MAX_SPACES]
    queue = {
        "generated_at": now_utc.isoformat(),
        "schema_version": SCHEMA_VERSION,
        "spaces": [
            {
                "space_id":       s["space_id"],
                "display_name":   s["display_name"],
                "space_type":     s["space_type"],
                "drive_folder_id": s["drive_folder_id"],
                "available_dates": sorted(s.get("available_dates", [])),
                "msg_count_new":  s["msg_count"],
                "recent_messages": s["recent_messages"][-SUMMARY_QUEUE_MAX_MSGS:],
            }
            for s in top
        ],
    }
    SUMMARY_QUEUE_FILE.write_text(
        json.dumps(queue, indent=2, ensure_ascii=False), encoding="utf-8")
    log(f"Saved _summary_queue.json — {len(top)} spaces, "
        f"{sum(len(s['recent_messages'][-SUMMARY_QUEUE_MAX_MSGS:]) for s in top)} messages")

# ---------------------------------------------------------------------------
# Tier 1 — Deterministic navigation summary (no LLM)
# ---------------------------------------------------------------------------

def compute_nav_summary(entry: dict, msgs_last_window: list,
                        now_utc: datetime) -> dict:
    """Compute lightweight per-space navigation summary from raw messages.

    Output shape matches the 2-tier design: counts + top senders +
    top threads with previews. Agent reads this first before deciding
    which day's JSONL to pull.
    """
    cutoff_dt = now_utc - timedelta(days=SUMMARY_DAYS)

    # Filter to the rolling window (defensive — caller usually already filters)
    window_msgs = []
    for m in msgs_last_window:
        ct = m.get("create_time") or ""
        try:
            ct_dt = datetime.fromisoformat(ct.replace("Z", "+00:00"))
        except ValueError:
            continue
        if ct_dt >= cutoff_dt:
            window_msgs.append(m)

    # Active senders
    sender_counts: Counter = Counter()
    for m in window_msgs:
        name = m.get("sender_name") or m.get("sender_email") or "unknown"
        sender_counts[name] += 1
    active_senders = [
        f"{name} ({cnt})" for name, cnt in sender_counts.most_common(NAV_TOP_SENDERS)
    ]

    # Group by thread (standalone msg = its own thread)
    by_thread: dict = defaultdict(list)
    for m in window_msgs:
        tid = m.get("thread_id") or m.get("msg_id") or ""
        if tid:
            by_thread[tid].append(m)

    threads_list = []
    for tid, tmsgs in by_thread.items():
        tmsgs.sort(key=lambda m: m.get("create_time", ""))
        first_text = (tmsgs[0].get("text") or "").strip()
        preview = first_text[:NAV_PREVIEW_CHARS]
        if len(first_text) > NAV_PREVIEW_CHARS:
            preview += "…"
        threads_list.append({
            "thread_id":     tid,
            "msg_count":     len(tmsgs),
            "preview":       preview,
            "last_activity": tmsgs[-1].get("create_time", ""),
        })
    threads_list.sort(
        key=lambda t: (t["msg_count"], t["last_activity"]), reverse=True)
    top_threads = threads_list[:NAV_TOP_THREADS]

    return {
        "schema_version":  SCHEMA_VERSION,
        "space_id":        entry.get("space_id"),
        "space_name":      entry.get("display_name", ""),
        "space_type":      entry.get("space_type", "UNKNOWN"),
        "available_dates": sorted(set(entry.get("available_dates", []))),
        "generated_at":    now_utc.isoformat(),
        "generated_by":    "crawl_gchat.py",
        "last_7_days": {
            "from":           cutoff_dt.date().isoformat(),
            "to":             now_utc.date().isoformat(),
            "total_messages": len(window_msgs),
            "active_senders": active_senders,
            "active_threads": top_threads,
        },
    }

# ---------------------------------------------------------------------------
# Message normalization
# ---------------------------------------------------------------------------

def normalize_message(msg: dict, space_id: str, space_name: str,
                       space_type: str, crawled_at: str) -> dict:
    """Flatten raw Google Chat API message → compact agent-friendly dict."""
    sender    = msg.get("sender") or {}
    thread_nm = (msg.get("thread") or {}).get("name", "")
    thread_id = thread_nm.split("/")[-1] if thread_nm else ""
    msg_full  = msg.get("name", "")
    msg_id    = msg_full.split("/")[-1] if msg_full else ""

    # thread_id == msg_id means this message IS the thread root
    is_reply = bool(thread_id) and (thread_id != msg_id)

    attachments = msg.get("attachments") or []
    att_names   = [a.get("displayName", "") for a in attachments if a.get("displayName")]

    reactions_raw = msg.get("reactions") or []
    reactions = [
        {"emoji": (r.get("emoji") or {}).get("unicode", "?"),
         "count": r.get("reactionCount", 0)}
        for r in reactions_raw
    ]

    text = (msg.get("text") or msg.get("formattedText") or "").strip()

    return {
        "msg_id":           msg_id,
        "space_id":         space_id,
        "space_name":       space_name,
        "space_type":       space_type,
        "thread_id":        thread_id,
        "is_thread_reply":  is_reply,
        "create_time":      msg.get("createTime", ""),
        "sender_name":      sender.get("displayName", ""),
        "sender_email":     sender.get("email", ""),
        "text":             text,
        "has_attachment":   len(attachments) > 0,
        "attachment_names": att_names,
        "reactions":        reactions,
        "crawled_at":       crawled_at,
    }

def group_by_date(messages: list) -> dict:
    """Group normalized messages by their create_time date (YYYY-MM-DD)."""
    by_date = defaultdict(list)
    for m in messages:
        date = (m.get("create_time") or "")[:10]
        if date:
            by_date[date].append(m)
    return dict(by_date)

# ---------------------------------------------------------------------------
# Drive helpers
# ---------------------------------------------------------------------------

def _q(name: str) -> str:
    return name.replace("'", "\\'")

def find_folder(drive, name: str, parent_id: Optional[str] = None) -> Optional[str]:
    q = (f"name='{_q(name)}' and mimeType='application/vnd.google-apps.folder'"
         f" and trashed=false")
    if parent_id:
        q += f" and '{parent_id}' in parents"
    res = drive.files().list(q=q, fields="files(id)", pageSize=5,
                              spaces="drive").execute()
    files = res.get("files", [])
    return files[0]["id"] if files else None

def ensure_folder(drive, name: str, parent_id: Optional[str] = None) -> str:
    fid = find_folder(drive, name, parent_id)
    if fid:
        return fid
    body = {"name": name, "mimeType": "application/vnd.google-apps.folder"}
    if parent_id:
        body["parents"] = [parent_id]
    f = drive.files().create(body=body, fields="id").execute()
    log(f"  Created Drive folder '{name}' → {f['id']}")
    return f["id"]

def find_file(drive, name: str, parent_id: str) -> Optional[str]:
    q = f"name='{_q(name)}' and '{parent_id}' in parents and trashed=false"
    res = drive.files().list(q=q, fields="files(id)", pageSize=5,
                              spaces="drive").execute()
    files = res.get("files", [])
    return files[0]["id"] if files else None

def download_json(drive, file_id: str) -> Optional[dict]:
    try:
        raw = drive.files().get_media(fileId=file_id).execute()
        return json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
    except Exception as e:
        log(f"  ! download_json({file_id}): {e}")
        return None

def download_text(drive, file_id: str) -> Optional[str]:
    try:
        raw = drive.files().get_media(fileId=file_id).execute()
        return raw.decode("utf-8") if isinstance(raw, bytes) else raw
    except Exception as e:
        log(f"  ! download_text({file_id}): {e}")
        return None

def upload_text(drive, parent_id: str, filename: str, content: str,
                existing_id: Optional[str] = None) -> str:
    data  = content.encode("utf-8")
    media = MediaInMemoryUpload(data, mimetype="application/json", resumable=False)
    if existing_id:
        f = drive.files().update(
            fileId=existing_id, media_body=media, fields="id").execute()
    else:
        body = {"name": filename, "parents": [parent_id]}
        f = drive.files().create(
            body=body, media_body=media, fields="id").execute()
    return f["id"]

def upload_json_file(drive, parent_id: str, filename: str, payload: dict,
                     existing_id: Optional[str] = None) -> str:
    return upload_text(drive, parent_id, filename,
                       json.dumps(payload, indent=2, ensure_ascii=False), existing_id)

def list_folder_files(drive, folder_id: str) -> dict:
    """Return {filename: file_id} for all non-trashed files in a Drive folder."""
    result, page_token = {}, None
    while True:
        kwargs = {
            "q":      f"'{folder_id}' in parents and trashed=false",
            "fields": "nextPageToken,files(id,name)",
            "pageSize": 1000,
        }
        if page_token:
            kwargs["pageToken"] = page_token
        res = drive.files().list(**kwargs).execute()
        for f in res.get("files", []):
            result[f["name"]] = f["id"]
        page_token = res.get("nextPageToken")
        if not page_token:
            break
    return result

# ---------------------------------------------------------------------------
# _stage.json  and  _index.json
# ---------------------------------------------------------------------------

def load_stage(drive, root_id: str):
    fid = find_file(drive, STAGE_FILENAME, root_id)
    if not fid:
        return None, None
    return download_json(drive, fid), fid

def save_stage(drive, root_id: str, stage: dict,
               existing_id: Optional[str]) -> str:
    return upload_json_file(drive, root_id, STAGE_FILENAME, stage, existing_id)

def load_index(drive, root_id: str):
    fid = find_file(drive, INDEX_FILENAME, root_id)
    if fid:
        data = download_json(drive, fid)
        if data:
            return data, fid
    empty = {
        "schema_version":   SCHEMA_VERSION,
        "user":             "anh.nguyentruongviet@vti.com.vn",
        "updated_at":       datetime.now(timezone.utc).isoformat(),
        "spaces_folder_id": None,
        "spaces":           {},
    }
    return empty, fid

def save_index(drive, root_id: str, index: dict,
               existing_id: Optional[str]) -> str:
    index["updated_at"] = datetime.now(timezone.utc).isoformat()
    return upload_json_file(drive, root_id, INDEX_FILENAME, index, existing_id)

# ---------------------------------------------------------------------------
# Chat API helpers
# ---------------------------------------------------------------------------

def list_spaces(chat) -> list:
    spaces, page_token = [], None
    while True:
        kwargs = {"pageSize": 100}
        if page_token:
            kwargs["pageToken"] = page_token
        resp = chat.spaces().list(**kwargs).execute()
        spaces.extend(resp.get("spaces", []))
        page_token = resp.get("nextPageToken")
        if not page_token:
            break
    return spaces

def _try_cache_self_user_name(chat, space_name: str) -> None:
    """Try to detect self user_name (users/<id>) from sender.email of recent messages."""
    if _SELF_USER_NAME[0]:
        return
    try:
        resp = chat.spaces().messages().list(
            parent=space_name, pageSize=20).execute()
        for msg in resp.get("messages", []):
            sender = msg.get("sender") or {}
            email  = (sender.get("email") or "").lower()
            if email == SELF_EMAIL.lower():
                _SELF_USER_NAME[0] = sender.get("name")
                log(f"  Detected self user_name = {_SELF_USER_NAME[0]}")
                return
    except Exception:
        pass

def _is_self_member(u: dict) -> bool:
    """Identify self in a Membership.member dict (Chat API may omit email)."""
    if not u:
        return False
    email = (u.get("email") or "").lower()
    if email and email == SELF_EMAIL.lower():
        return True
    if _SELF_USER_NAME[0] and u.get("name") == _SELF_USER_NAME[0]:
        return True
    return False

def resolve_user_name_via_people(user_resource: str) -> Optional[str]:
    """Resolve 'users/<gaia_id>' → displayName qua People API (default source).

    Chat API chỉ trả về user ID, không có displayName/email. People API với
    scope directory.readonly + contacts.readonly trả về thông tin domain
    profile + workspace contacts.

    Cache trong _USER_NAME_CACHE để không gọi API trùng.
    """
    if user_resource in _USER_NAME_CACHE:
        return _USER_NAME_CACHE[user_resource]

    people = _PEOPLE_CLIENT[0]
    if people is None:
        _USER_NAME_CACHE[user_resource] = None
        return None

    uid = user_resource.split("/")[-1]
    try:
        person = people.people().get(
            resourceName=f"people/{uid}",
            personFields="names,emailAddresses").execute()
        names  = person.get("names") or []
        emails = person.get("emailAddresses") or []
        dn = ""
        if names:
            dn = (names[0].get("displayName") or "").strip()
        if not dn and emails:
            em = emails[0].get("value", "")
            dn = em.split("@")[0] if em else ""
        _USER_NAME_CACHE[user_resource] = dn or None
        return dn or None
    except HttpError as e:
        status = getattr(e.resp, "status", None)
        if status in (403, 404):
            _USER_NAME_CACHE[user_resource] = None
            return None
        log(f"  ! People API({uid}): {e}")
    except Exception as e:
        log(f"  ! People API({uid}): {e}")

    _USER_NAME_CACHE[user_resource] = None
    return None

def detect_self_via_people() -> None:
    """Lookup users/me qua People API để cache self user_name + email."""
    if _SELF_USER_NAME[0]:
        return
    people = _PEOPLE_CLIENT[0]
    if not people:
        return
    try:
        me = people.people().get(
            resourceName="people/me",
            personFields="names,emailAddresses,metadata").execute()
        # Lấy gaia ID từ metadata.sources
        for src in (me.get("metadata", {}).get("sources") or []):
            if src.get("type") == "DOMAIN_PROFILE" and src.get("id"):
                _SELF_USER_NAME[0] = f"users/{src['id']}"
                # Cache chính tên mình luôn
                names = me.get("names") or []
                if names:
                    _USER_NAME_CACHE[_SELF_USER_NAME[0]] = names[0].get("displayName")
                log(f"  Self resolved: {_SELF_USER_NAME[0]} = "
                    f"{_USER_NAME_CACHE.get(_SELF_USER_NAME[0])}")
                return
    except Exception as e:
        log(f"  ! detect_self_via_people: {e}")

def _extract_bot_name_from_messages(chat, space_name: str) -> Optional[str]:
    """Bot DM không có profile → extract tên bot từ message đầu tiên.

    Pattern thường gặp:
      "Welcome to the X app! ..."
      "Hello, I'm X"
      "X here. ..."
    """
    import re
    try:
        resp = chat.spaces().messages().list(
            parent=space_name, pageSize=5).execute()
        for msg in resp.get("messages", []):
            sender = msg.get("sender") or {}
            if sender.get("type") != "BOT":
                continue
            text = (msg.get("text") or msg.get("argumentText") or "")[:300]
            # "Welcome to the X app" / "Welcome to X"
            m = re.search(r'Welcome to (?:the )?([A-Z][\w\s]{1,40}?)(?:\s+app|\s+bot|!|,|\.)', text)
            if m:
                return m.group(1).strip()
            # "Hi, I'm X" / "Hello, I'm X" / "I am X"
            m = re.search(r"(?:I'm|I am|Hi,? I'm)\s+([A-Z][\w\s]{1,40}?)(?:\s+bot|!|,|\.)", text)
            if m:
                return m.group(1).strip()
            # "X here," / "X bot:"
            m = re.search(r'^([A-Z][\w\s]{1,40}?)\s+(?:here|bot)[,!:]', text)
            if m:
                return m.group(1).strip()
    except Exception:
        pass
    return None

def _try_dm_name_from_messages(chat, space_name: str) -> Optional[str]:
    """Fallback: lấy display_name từ sender khác mình trong messages của DM.

    Cả displayName từ Chat API (rỗng) → People API resolve.
    """
    try:
        resp = chat.spaces().messages().list(
            parent=space_name, pageSize=50).execute()
        seen = {}  # user_resource → displayName
        for msg in resp.get("messages", []):
            sender = msg.get("sender") or {}
            name   = sender.get("name", "")
            if not name:
                continue
            if _is_self_member(sender):
                continue
            dn = (sender.get("displayName") or "").strip()
            if not dn:
                email = sender.get("email") or ""
                dn    = email.split("@")[0] if email else ""
            if not dn:
                dn = resolve_user_name_via_people(name) or ""
            if dn and name not in seen:
                seen[name] = dn
        return " & ".join(list(seen.values())[:2]) if seen else None
    except Exception:
        return None

def _resolve_display_name_uncached(chat, space: dict, space_type: str, sid: str) -> str:
    """Heavy path: members.list + people.get + messages.list fallbacks.

    Caller `resolve_display_name()` decides when to invoke this (cache miss or
    forced Sunday refresh).
    """
    if space_type in ("DIRECT_MESSAGE", "GROUP_CHAT"):
        # Cache self user_name từ message trước (1 lần thôi)
        if not _SELF_USER_NAME[0]:
            _try_cache_self_user_name(chat, space["name"])

        # Bước 1+2+3: thử members.list
        humans, bots = [], []
        try:
            members, page_token = [], None
            while True:
                kwargs = {"parent": space["name"], "pageSize": 100}
                if page_token:
                    kwargs["pageToken"] = page_token
                resp = chat.spaces().members().list(**kwargs).execute()
                members.extend(resp.get("memberships", []))
                page_token = resp.get("nextPageToken")
                if not page_token:
                    break

            for m in members:
                if m.get("state", "JOINED") != "JOINED":
                    continue
                u = m.get("member") or {}
                if _is_self_member(u):
                    continue
                dn = (u.get("displayName") or "").strip()
                if not dn:
                    email = u.get("email") or ""
                    dn    = email.split("@")[0] if email else ""
                # Cuối cùng: gọi People API resolve qua user resource name
                if not dn and u.get("name"):
                    dn = resolve_user_name_via_people(u["name"]) or ""
                if not dn:
                    continue
                if u.get("type") == "BOT":
                    bots.append(dn)
                else:
                    humans.append(dn)
            humans = list(dict.fromkeys(humans))
            bots   = list(dict.fromkeys(bots))
        except Exception as e:
            log(f"  ! members.list({space.get('name')}): {e}")

        # Bước 4: nếu chưa có human/bot, thử lấy từ messages
        if not humans and not bots:
            from_msgs = _try_dm_name_from_messages(chat, space["name"])
            if from_msgs:
                return from_msgs

        if space_type == "DIRECT_MESSAGE":
            if len(humans) == 1: return humans[0]
            if len(humans) >= 2: return " & ".join(humans[:2])
            # Bot DM: thử extract tên bot từ message đầu tiên
            bot_name_from_msg = _extract_bot_name_from_messages(chat, space["name"])
            if bot_name_from_msg:
                return f"[Bot] {bot_name_from_msg}"
            if bots:
                return f"[Bot] {bots[0]}"
            return f"(private DM {sid[:8]})"
        else:  # GROUP_CHAT
            names = humans + [f"[Bot] {b}" for b in bots]
            if not names:
                return f"(unnamed group {sid[:8]})"
            if len(names) <= 4:
                return ", ".join(names)
            return f"{', '.join(names[:4])} +{len(names)-4}"

    return f"({space_type.lower()} {sid[:8]})"


def resolve_display_name(chat, space: dict) -> str:
    """Robust display name for any space type — cached on disk.

    Order tra cứu:
      1. space.displayName nếu có
      2. _SPACE_DISPLAY_CACHE (skipped if _FORCE_MEMBER_REFRESH[0] is True)
      3. members.list → People API → messages.list (heavy path)

    Cache update strategy:
      - Cache miss (new space) → resolve heavy + write back. Even on non-refresh
        runs, new spaces get resolved ad-hoc so summaries include their names.
      - Forced refresh (Sunday GMT+7 / first run / stale > 8d) → bypass cache,
        resolve heavy, overwrite cache entry.
    """
    space_type = space.get("spaceType") or space.get("type") or "UNKNOWN"
    display    = (space.get("displayName") or "").strip()
    sid        = space["name"].split("/")[-1]

    if display:
        return display

    # Cache hit (skipped during forced refresh)
    if not _FORCE_MEMBER_REFRESH[0]:
        cached = _SPACE_DISPLAY_CACHE.get(sid)
        if cached and cached.get("display_name"):
            return cached["display_name"]

    # Cache miss OR forced refresh → heavy path
    name = _resolve_display_name_uncached(chat, space, space_type, sid)

    # Persist in module-level cache (will be dumped to disk at end of run)
    _SPACE_DISPLAY_CACHE[sid] = {
        "display_name": name,
        "resolved_at":  datetime.now(timezone.utc).isoformat(),
    }
    return name

# Backward-compat alias
def get_dm_display_name(chat, space: dict) -> str:
    return resolve_display_name(chat, space)
# ---------------------------------------------------------------------------
# Canonical Drive folder naming: [Type]_[DisplayName]_[ID]
# ---------------------------------------------------------------------------

# Navigation summary constants (used by compute_nav_summary)
NAV_TOP_SENDERS   = 5
NAV_TOP_THREADS   = 8
NAV_PREVIEW_CHARS = 120

# Per-run tunables
PAGE_SIZE                   = 100
MAX_RETRIES_429             = 5
RETRY_BACKOFF_BASE          = 5
DEFAULT_RATE_SLEEP          = 0.1
QUEUE_RECENT_MSGS_PER_SPACE = 1500
MIN_MSGS_FOR_SUMMARY        = 3
ACTIVE_FILTER_PADDING_HOURS = 24    # khi lọc theo lastActiveTime, nới lỏng chút

_FOLDER_TYPE_PREFIX = {
    "DIRECT_MESSAGE": "DM",
    "GROUP_CHAT":     "Group",
    "SPACE":          "Space",
}
_BAD_FOLDER_CHARS = ("/", "\\", ":", "*", "?", '"', "<", ">", "|", "\n", "\r", "\t")


def canonical_folder_name(space_type: str, display_name: str, sid: str) -> str:
    """Compute canonical Drive folder name for a space: <Prefix>_<Name>_<ID>."""
    prefix = _FOLDER_TYPE_PREFIX.get(space_type, "Chat")
    clean = (display_name or "").strip()
    for bad in _BAD_FOLDER_CHARS:
        clean = clean.replace(bad, "-")
    clean = " ".join(clean.split())
    if not clean or clean == sid:
        clean = "unnamed"
    if len(clean) > 80:
        clean = clean[:77] + "..."
    return f"{prefix}_{clean}_{sid}"


def ensure_space_folder_canonical(drive, sid: str, space_type: str,
                                  display_name: str, spaces_parent_id: str,
                                  existing_folder_id: Optional[str] = None) -> str:
    """Get-or-create Drive folder. Rename existing if display_name changed."""
    canonical = canonical_folder_name(space_type, display_name, sid)

    if existing_folder_id:
        try:
            info = drive.files().get(
                fileId=existing_folder_id,
                fields="id,name,trashed").execute()
            if info.get("trashed"):
                existing_folder_id = None
            else:
                if info.get("name") != canonical:
                    drive.files().update(
                        fileId=existing_folder_id,
                        body={"name": canonical},
                        fields="id").execute()
                    log(f"  Renamed folder: '{info.get('name')}' → '{canonical}'")
                return existing_folder_id
        except HttpError as e:
            if getattr(e.resp, "status", None) == 404:
                existing_folder_id = None
            else:
                raise

    body = {
        "name":     canonical,
        "mimeType": "application/vnd.google-apps.folder",
        "parents":  [spaces_parent_id],
    }
    f = drive.files().create(body=body, fields="id").execute()
    log(f"  Created Drive folder: '{canonical}' → {f['id']}")
    return f["id"]


def build_index_entry(chat, space: dict) -> dict:
    """Build fresh _index.json entry for a Chat space."""
    space_type = space.get("spaceType") or space.get("type") or "UNKNOWN"
    space_name = space.get("name") or ""
    space_id   = space_name.split("/")[-1]
    display    = resolve_display_name(chat, space)
    return {
        "space_id":               space_id,
        "space_resource_name":    space_name,
        "display_name":           display,
        "space_type":             space_type,
        "drive_folder_id":        None,
        "drive_folder_name":      None,
        "last_crawl_utc":         None,
        "last_active_time":       space.get("lastActiveTime"),
        "total_messages_crawled": 0,
        "available_dates":        [],
    }


# ---------------------------------------------------------------------------
# Chat API helpers
# ---------------------------------------------------------------------------

def _retry_call(fn, *args, **kwargs):
    """Wrap a Google API call with exponential backoff on 429 / 5xx."""
    for attempt in range(MAX_RETRIES_429):
        try:
            return fn(*args, **kwargs)
        except HttpError as e:
            status = getattr(e.resp, "status", None)
            if status == 429 or (status and 500 <= status < 600):
                wait = RETRY_BACKOFF_BASE * (2 ** attempt)
                log(f"  ! HTTP {status} — chờ {wait}s rồi retry "
                    f"({attempt+1}/{MAX_RETRIES_429})")
                time.sleep(wait)
                continue
            raise
    raise RuntimeError(f"Bỏ cuộc sau {MAX_RETRIES_429} lần retry")


def list_messages(chat, space_name: str, since: Optional[datetime],
                  rate_sleep: float = DEFAULT_RATE_SLEEP) -> list:
    """List all messages in `space_name` with createTime > `since`.

    Returns flat list of raw message dicts. Paginates internally.
    """
    msgs: list      = []
    page_token      = None
    filter_str: Optional[str] = None
    if since is not None:
        ts = since.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        filter_str = f'createTime > "{ts}"'

    while True:
        kwargs = {
            "parent":      space_name,
            "pageSize":    PAGE_SIZE,
            "showDeleted": True,
            "orderBy":     "createTime desc",
        }
        if page_token:
            kwargs["pageToken"] = page_token
        if filter_str:
            kwargs["filter"] = filter_str
        try:
            resp = _retry_call(chat.spaces().messages().list(**kwargs).execute)
        except HttpError as e:
            log(f"  ! list_messages({space_name}): {e}")
            return msgs

        msgs.extend(resp.get("messages", ()) or ())
        page_token = resp.get("nextPageToken")
        if not page_token:
            return msgs
        if rate_sleep > 0:
            time.sleep(rate_sleep)


def merge_and_upload_daily(drive, space_folder_id: str, date_str: str,
                           new_messages: list, existing_files: dict) -> Optional[str]:
    """Merge new messages into <date>.jsonl by msg_id, re-upload.

    Mutates `existing_files[filename]` to keep the cache fresh.
    """
    filename    = f"{date_str}.jsonl"
    existing_id = existing_files.get(filename)
    merged: dict = {}

    if existing_id:
        raw = download_text(drive, existing_id)
        if raw:
            for line in raw.strip().split("\n"):
                line = line.strip()
                if not line:
                    continue
                try:
                    m = json.loads(line)
                    if m.get("msg_id"):
                        merged[m["msg_id"]] = m
                except json.JSONDecodeError:
                    pass

    for m in new_messages:
        mid = m.get("msg_id")
        if mid:
            merged[mid] = m

    sorted_msgs = sorted(merged.values(),
                         key=lambda m: m.get("create_time", ""))
    content = "\n".join(
        json.dumps(m, ensure_ascii=False) for m in sorted_msgs)

    new_id = upload_text(drive, space_folder_id, filename, content, existing_id)
    existing_files[filename] = new_id
    return new_id


# ---------------------------------------------------------------------------
# Main crawl
# ---------------------------------------------------------------------------

def _load_recent_msgs_for_queue(drive, folder_id: str, existing_files: dict,
                                cutoff_utc: datetime, limit: int) -> list:
    """Reuse backfill_history's window-reader: gộp last-N-days JSONL → sort → tail."""
    msgs: list = []
    for fname, fid in sorted(existing_files.items()):
        if not fname.endswith(".jsonl"):
            continue
        try:
            fdate = datetime.strptime(fname[:-6], "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if fdate < cutoff_utc:
            continue
        raw = download_text(drive, fid)
        if not raw:
            continue
        for line in raw.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                msgs.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    msgs.sort(key=lambda m: m.get("create_time", ""))
    return msgs[-limit:] if limit > 0 else msgs


def run_crawl(dry_run: bool = False,
              full_history: bool = False,
              backfill_days: Optional[int] = None,
              max_seconds: int = DEFAULT_MAX_SECONDS,
              rate_sleep: float = DEFAULT_RATE_SLEEP) -> int:
    """Incremental crawl pass — designed for hourly scheduled execution.

    Flow:
      1. Load `_stage.json` from Drive → determine since_utc.
      2. Load `_index.json` (or initialize empty).
      3. List spaces, filter active ones (lastActiveTime > since).
      4. For each space (parallel): list_messages(since), normalize,
         group_by_date, merge_and_upload_daily.
      5. Update per-space + global stage. Write _summary_queue.json.

    Returns total new messages crawled.
    """
    creds = load_credentials()
    drive = build("drive", "v3", credentials=creds, cache_discovery=False)
    _tl   = threading.local()

    def get_chat():
        if not hasattr(_tl, "chat"):
            _tl.chat = build("chat", "v1", credentials=creds,
                             cache_discovery=False)
        return _tl.chat

    chat = get_chat()

    now_utc    = datetime.now(timezone.utc)
    crawled_at = now_utc.isoformat()
    t_start    = time.monotonic()
    deadline   = (t_start + max_seconds) if max_seconds and max_seconds > 0 else None

    def over_budget() -> bool:
        return deadline is not None and time.monotonic() >= deadline

    # ── Members cache (display names + People-API resolutions) ────────────
    # Decide ONCE whether this run should rebuild the cache from scratch:
    #   * first run / cache missing → True
    #   * today is Sunday in GMT+7 and no refresh today yet → True
    #   * cache age > MEMBERS_CACHE_MAX_AGE_DAYS → True
    #   * otherwise → False (reuse cache; new spaces still resolved ad-hoc)
    members_cache = load_members_cache()
    force_refresh, refresh_reason = should_refresh_members(members_cache, now_utc)
    _FORCE_MEMBER_REFRESH[0] = force_refresh
    log(f"Members cache: {'REFRESH' if force_refresh else 'reuse'} — {refresh_reason}")
    if force_refresh:
        # Forced refresh starts from a clean slate — old cached display names
        # would otherwise short-circuit the resolver.
        _USER_NAME_CACHE.clear()
        _SPACE_DISPLAY_CACHE.clear()
    else:
        hydrate_caches_from_disk(members_cache)
        log(f"  Hydrated: {len(_USER_NAME_CACHE)} user names, "
            f"{len(_SPACE_DISPLAY_CACHE)} space display names")

    # ── Drive root + spaces folder ────────────────────────────────────────
    log("Setting up Drive folders...")
    root_id    = ensure_folder(drive, DRIVE_ROOT_NAME)
    spaces_dir = ensure_folder(drive, DRIVE_SPACES_NAME, root_id)

    # ── Load resume state ─────────────────────────────────────────────────
    stage, stage_id = load_stage(drive, root_id)
    prev_stage = stage or {}

    if full_history:
        log("--full-history → fetch ALL messages (warning: có thể vượt budget).")
        global_since: Optional[datetime] = None
    elif backfill_days is not None:
        global_since = now_utc - timedelta(days=int(backfill_days))
        log(f"--backfill-days {backfill_days} → since {global_since.isoformat()}")
    elif stage and stage.get("last_crawl_utc"):
        try:
            global_since = datetime.fromisoformat(
                stage["last_crawl_utc"].replace("Z", "+00:00"))
            log(f"Incremental — last_crawl_utc = {global_since.isoformat()}")
        except ValueError:
            log("! last_crawl_utc parse failed — fallback to last 24h")
            global_since = now_utc - timedelta(hours=24)
    else:
        # No stage file → first run. Be conservative: pick up last 24h only.
        log("No _stage.json found — first run, defaulting to last 24h window.")
        global_since = now_utc - timedelta(hours=24)

    index, index_id = load_index(drive, root_id)
    index["spaces_folder_id"] = spaces_dir

    # ── List + filter active spaces ───────────────────────────────────────
    log("Listing spaces from Chat API...")
    try:
        all_spaces = list_spaces(chat)
    except HttpError as e:
        log(f"  ! list_spaces failed: {e}")
        return 0
    log(f"  Total {len(all_spaces)} spaces in account.")

    if global_since and not full_history:
        pad = timedelta(hours=ACTIVE_FILTER_PADDING_HOURS)
        cutoff = global_since - pad
        kept = []
        for s in all_spaces:
            lat = s.get("lastActiveTime")
            if not lat:
                kept.append(s)
                continue
            try:
                lat_dt = datetime.fromisoformat(lat.replace("Z", "+00:00"))
                if lat_dt > cutoff:
                    kept.append(s)
            except ValueError:
                kept.append(s)
        log(f"  Active since {cutoff.date()}: {len(kept)}/{len(all_spaces)} spaces.")
        target_spaces = kept
    else:
        target_spaces = all_spaces

    # ── Fetch messages per space (parallel) ───────────────────────────────
    lock        = threading.Lock()
    counter     = {"n": 0}
    total_new   = 0
    results: list = []

    def process_space(s: dict) -> dict:
        sid   = s["name"].split("/")[-1]
        sname = s["name"]
        c     = get_chat()

        with lock:
            if sid not in index["spaces"]:
                index["spaces"][sid] = build_index_entry(c, s)
        entry = index["spaces"][sid]

        # refresh metadata
        entry["last_active_time"] = (s.get("lastActiveTime")
                                     or entry.get("last_active_time"))
        entry["space_type"] = (s.get("spaceType") or s.get("type")
                               or entry.get("space_type", "UNKNOWN"))
        fresh_display = resolve_display_name(c, s)
        if fresh_display and fresh_display != entry.get("display_name"):
            entry["display_name"] = fresh_display

        # per-space since: trust entry's own last_crawl_utc if newer than global
        since_for_space = global_since
        if not full_history and entry.get("last_crawl_utc"):
            try:
                entry_dt = datetime.fromisoformat(
                    entry["last_crawl_utc"].replace("Z", "+00:00"))
                if since_for_space is None or entry_dt > since_for_space:
                    since_for_space = entry_dt
            except ValueError:
                pass

        raw_msgs = list_messages(c, sname, since_for_space, rate_sleep)
        with lock:
            counter["n"] += 1
            n = counter["n"]
            disp = entry.get("display_name", sid)
            if raw_msgs or n % 25 == 0:
                log(f"  [{n:>4}/{len(target_spaces)}] [{entry['space_type']:18s}] "
                    f"{disp[:55]} — {len(raw_msgs)} msgs")

        normalized = [
            normalize_message(m, sid, entry["display_name"],
                              entry["space_type"], crawled_at)
            for m in raw_msgs
        ]
        return {"space_id": sid, "messages": normalized, "entry": entry}

    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        futures = {pool.submit(process_space, s): s for s in target_spaces}
        for fut in as_completed(futures):
            try:
                r = fut.result()
                results.append(r)
                total_new += len(r["messages"])
            except Exception as e:
                log(f"  ! thread error: {e}")

    log(f"Fetched {total_new} new messages across {len(target_spaces)} spaces.")  # noqa

    if dry_run:
        out = SCRIPT_DIR / f"dryrun_{now_utc.strftime('%Y%m%d_%H%M%S')}.json"
        out.write_text(json.dumps(
            [{"space_id": r["space_id"], "count": len(r["messages"]),
              "messages": r["messages"]} for r in results],
            indent=2, ensure_ascii=False), encoding="utf-8")
        log(f"Dry-run saved → {out}")
        return total_new

    # ── Upload JSONL per space — budget-aware ─────────────────────────────
    log("Uploading per-space JSONL to Drive...")
    spaces_with_msgs = [r for r in results if r["messages"]]
    spaces_with_msgs.sort(key=lambda r: len(r["messages"]), reverse=True)

    uploaded = 0
    deferred = 0
    queue_data = []
    cutoff_for_queue = now_utc - timedelta(days=SUMMARY_DAYS)

    for r in spaces_with_msgs:
        if over_budget():
            deferred = len(spaces_with_msgs) - uploaded
            log(f"⏰ Budget exhausted ({max_seconds}s) sau {uploaded} spaces. "
                f"{deferred} deferred to next run.")
            break

        sid      = r["space_id"]
        messages = r["messages"]
        entry    = r["entry"]

        entry["drive_folder_id"] = ensure_space_folder_canonical(
            drive, sid, entry["space_type"], entry["display_name"],
            spaces_dir, entry.get("drive_folder_id"))
        entry["drive_folder_name"] = canonical_folder_name(
            entry["space_type"], entry["display_name"], sid)
        folder_id = entry["drive_folder_id"]

        existing_files = list_folder_files(drive, folder_id)
        by_date = group_by_date(messages)
        for date_str, day_msgs in sorted(by_date.items()):
            merge_and_upload_daily(drive, folder_id, date_str,
                                   day_msgs, existing_files)
            avail = entry.setdefault("available_dates", [])
            if date_str not in avail:
                avail.append(date_str)

        entry["last_crawl_utc"]         = crawled_at
        entry["total_messages_crawled"] = (
            entry.get("total_messages_crawled", 0) + len(messages))
        index["spaces"][sid] = entry
        uploaded += 1

        # checkpoint index every 5 spaces — survives mid-run kill
        if uploaded % 5 == 0:
            try:
                index_id = save_index(drive, root_id, index, index_id)
                log(f"  ↳ checkpoint: index saved ({uploaded}/{len(spaces_with_msgs)})")
            except Exception as e:
                log(f"  ! checkpoint save_index failed: {e}")

        # build queue entry while we still have existing_files cached
        if len(messages) >= MIN_MSGS_FOR_SUMMARY:
            try:
                recent = _load_recent_msgs_for_queue(
                    drive, folder_id, existing_files,
                    cutoff_for_queue, QUEUE_RECENT_MSGS_PER_SPACE)
                if recent:
                    queue_data.append({
                        "space_id":        sid,
                        "display_name":    entry["display_name"],
                        "space_type":      entry["space_type"],
                        "drive_folder_id": folder_id,
                        "available_dates": sorted(entry.get("available_dates", [])),
                        "msg_count":       len(messages),
                        "recent_messages": recent,
                    })
            except Exception as e:
                log(f"  ! queue prep failed for {sid}: {e}")

    full_pass = (uploaded == len(spaces_with_msgs))
    log(f"Uploaded {uploaded}/{len(spaces_with_msgs)} active spaces.")

    # ── Persist _index.json + _stage.json ─────────────────────────────────
    try:
        index_id = save_index(drive, root_id, index, index_id)
    except Exception as e:
        log(f"  ! save_index failed: {e}")

    # Chỉ advance last_crawl_utc nếu FULL pass — partial run giữ timestamp cũ
    # để run sau không miss spaces deferred
    if full_pass:
        next_last_crawl = crawled_at
    else:
        next_last_crawl = prev_stage.get("last_crawl_utc") or crawled_at
        log(f"  ↳ Partial run — keeping last_crawl_utc at {next_last_crawl}")

    new_stage = {
        "schema_version":    SCHEMA_VERSION,
        "last_crawl_utc":    next_last_crawl,
        "phase":             "steady" if full_pass else "partial",
        "crawl_count":       int(prev_stage.get("crawl_count", 0)) + 1,
        "user":              SELF_EMAIL,
        "bootstrap_done":    True,
        "full_history_done": (prev_stage.get("full_history_done", False)
                              or bool(full_history and full_pass)),
        "last_run_summary": {
            "completed_at":     crawled_at,
            "full_pass":        full_pass,
            "spaces_uploaded":  uploaded,
            "spaces_deferred":  deferred,
            "messages_fetched": total_new,
            "elapsed_seconds":  round(time.monotonic() - t_start, 1),
            "budget_seconds":   max_seconds,
        },
        "updated_at":        crawled_at,
    }
    try:
        stage_id = save_stage(drive, root_id, new_stage, stage_id)
    except Exception as e:
        log(f"  ! save_stage failed: {e}")

    try:
        STATE_FILE.write_text(
            json.dumps(new_stage, indent=2, ensure_ascii=False),
            encoding="utf-8")
    except OSError as e:
        log(f"  ! local state.json write failed: {e}")

    # ── Persist members cache ─────────────────────────────────────────────
    # Whether the run was a forced refresh OR a normal incremental run, we
    # always dump back: incremental runs may have added new spaces / users
    # ad-hoc and we want them captured for next time.
    try:
        serialize_caches_to_disk(force_refresh, now_utc)
    except Exception as e:
        log(f"  ! serialize_caches_to_disk failed: {e}")

    # ── _summary_queue.json ───────────────────────────────────────────────
    if queue_data and not full_history:
        write_summary_queue(queue_data, now_utc)
    elif not queue_data:
        log("No new messages → skipping _summary_queue.json write.")

    elapsed = time.monotonic() - t_start
    log(f"Done in {elapsed:.1f}s (budget {max_seconds}s). "
        f"Full pass: {full_pass}. Total new: {total_new}.")
    return total_new


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Google Chat → Drive incremental crawler v2")
    parser.add_argument("--auth-url",      action="store_true",
                        help="Print OAuth authorization URL and exit.")
    parser.add_argument("--finish-auth",   metavar="REDIRECT_URL",
                        help="Complete OAuth with the redirect URL.")
    parser.add_argument("--dry-run",       action="store_true",
                        help="Crawl but save locally — no Drive upload.")
    parser.add_argument("--full-history",  action="store_true",
                        help="Recrawl all history (likely > 45s).")
    parser.add_argument("--backfill-days", type=int, default=None,
                        help="Fetch messages from last N days. Idempotent.")
    parser.add_argument("--max-seconds",   type=int, default=DEFAULT_MAX_SECONDS,
                        help=f"Soft time budget. Default {DEFAULT_MAX_SECONDS}s, "
                             f"0 = unlimited.")
    parser.add_argument("--rate-sleep",    type=float, default=DEFAULT_RATE_SLEEP,
                        help="Sleep between API pages (rate-limit politeness).")
    args = parser.parse_args()

    log("=" * 60)
    log(f"crawl_gchat.py v2 started — {vars(args)}")

    try:
        if args.auth_url:
            print_auth_url()
            return 0
        if args.finish_auth:
            finish_auth(args.finish_auth)
            return 0
        n = run_crawl(
            dry_run=args.dry_run,
            full_history=args.full_history,
            backfill_days=args.backfill_days,
            max_seconds=args.max_seconds,
            rate_sleep=args.rate_sleep,
        )
        log(f"Done. Crawled {n} messages.")
        return 0
    except KeyboardInterrupt:
        log("⚠ Interrupted by user")
        return 130
    except Exception as e:
        log(f"FATAL: {type(e).__name__}: {e}")
        import traceback
        log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(main())
