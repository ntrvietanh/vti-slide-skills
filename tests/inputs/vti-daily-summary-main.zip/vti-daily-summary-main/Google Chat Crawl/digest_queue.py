#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
digest_queue.py — Compactify _summary_queue.json into a smaller digest
that AI session can consume efficiently.

Output: _queue_digest.json — strips msg_id, thread_id, attachments, reactions,
sender_email; groups msgs by date; truncates long bursts.

Run on Windows local:
    python digest_queue.py
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

SCRIPT_DIR  = Path(__file__).parent.resolve()
QUEUE_FILE  = SCRIPT_DIR / "_summary_queue.json"
DIGEST_FILE = SCRIPT_DIR / "_queue_digest.json"

MAX_MSGS_PER_DAY    = 200   # cap to avoid context blowup
MAX_TEXT_PER_MSG    = 800   # truncate huge messages
MIN_TEXT_LEN        = 1     # skip empty text (still keep emoji-only since text>=1)

def main() -> int:
    if not QUEUE_FILE.exists():
        print(f"! Không thấy {QUEUE_FILE}")
        return 1

    print(f"Reading {QUEUE_FILE} ({QUEUE_FILE.stat().st_size:,} bytes)...")
    with open(QUEUE_FILE, encoding="utf-8") as f:
        q = json.load(f)

    spaces = q.get("spaces", [])
    print(f"Spaces in queue: {len(spaces)}")

    out_spaces = []
    total_kept_msgs = 0

    for s in spaces:
        msgs = s.get("recent_messages", [])
        by_date = defaultdict(list)
        for m in msgs:
            ct   = m.get("create_time") or ""
            date = ct[:10]
            if not date:
                continue
            text = (m.get("text") or "").strip()
            if len(text) < MIN_TEXT_LEN:
                continue
            if len(text) > MAX_TEXT_PER_MSG:
                text = text[:MAX_TEXT_PER_MSG] + "…[truncated]"
            sender = m.get("sender_name") or m.get("sender_email") or "?"
            by_date[date].append({
                "t":  ct[11:19],   # HH:MM:SS UTC, đủ cho summary
                "s":  sender,
                "m":  text,
            })

        # Cap mỗi ngày
        msgs_by_date = {}
        for d in sorted(by_date.keys()):
            day = by_date[d]
            if len(day) > MAX_MSGS_PER_DAY:
                # Lấy đầu + cuối để giữ context
                half = MAX_MSGS_PER_DAY // 2
                day = day[:half] + [{"t":"…","s":"…","m":f"[{len(day)-MAX_MSGS_PER_DAY} msgs lược bớt]"}] + day[-half:]
            msgs_by_date[d] = day
            total_kept_msgs += len(day)

        out_spaces.append({
            "space_id":        s.get("space_id"),
            "display_name":    s.get("display_name"),
            "space_type":      s.get("space_type"),
            "drive_folder_id": s.get("drive_folder_id"),
            "msg_count_new":   s.get("msg_count_new", 0),
            "dates":           sorted(msgs_by_date.keys()),
            "msgs_by_date":    msgs_by_date,
        })

    payload = {
        "generated_at":  q.get("generated_at"),
        "source":        "digest_queue.py",
        "total_spaces":  len(out_spaces),
        "total_msgs":    total_kept_msgs,
        "spaces":        out_spaces,
    }
    DIGEST_FILE.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    in_size  = QUEUE_FILE.stat().st_size
    out_size = DIGEST_FILE.stat().st_size
    print(f"\nDigest saved → {DIGEST_FILE}")
    print(f"  {len(out_spaces)} space, {total_kept_msgs} msgs kept")
    print(f"  Size: {in_size:,} → {out_size:,} ({out_size/in_size*100:.0f}%)")
    return 0

if __name__ == "__main__":
    sys.exit(main())
