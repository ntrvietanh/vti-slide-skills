#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
phase1_discover.py — Phase 1 of the 3-phase pipeline.

Job: ONE Chat API call to list all spaces user belongs to, then filter
client-side by `lastActiveTime > global_since - padding`. Writes the result
to local `_active_spaces.json` so phase2 can iterate per-space.

Inputs (read):
  - _stage.json on Drive  → global_since = last_crawl_utc
  - _index.json on Drive  → existing per-space metadata (drive_folder_id, etc.)

Outputs (written locally):
  - _active_spaces.json   → list of active spaces with metadata for phase2

Wall-clock budget: ~10-15s (Chat API list_spaces is the only heavy call).
"""
import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

import crawl_lib as lib


SCRIPT_DIR         = Path(__file__).parent.resolve()
ACTIVE_SPACES_FILE = SCRIPT_DIR / "_active_spaces.json"


def main() -> int:
    lib.log("=" * 60)
    lib.log("phase1_discover.py started")

    creds = lib.load_credentials()
    drive = lib.get_drive(creds)
    chat  = lib.get_chat(creds)

    now_utc = datetime.now(timezone.utc)

    # ── Determine global_since from _stage.json ──────────────────────────
    root_id = lib.ensure_folder(drive, lib.DRIVE_ROOT_NAME)
    stage, _ = lib.load_stage(drive, root_id)

    if stage and stage.get("last_crawl_utc"):
        try:
            since = datetime.fromisoformat(
                stage["last_crawl_utc"].replace("Z", "+00:00"))
            lib.log(f"  global_since (from _stage.json): {since.isoformat()}")
        except ValueError:
            since = now_utc - timedelta(hours=24)
            lib.log(f"  ! _stage.json last_crawl_utc parse failed — "
                    f"fallback 24h: {since.isoformat()}")
    else:
        since = now_utc - timedelta(hours=24)
        lib.log(f"  No _stage.json — defaulting since to 24h ago: {since.isoformat()}")

    # ── Load index (per-space metadata: drive_folder_id, last_crawl_utc) ─
    index, _ = lib.load_index(drive, root_id)
    index_spaces = index.get("spaces", {})

    # ── Hydrate display-name cache so list_messages can resolve later ────
    members_cache = lib.load_members_cache()
    lib.hydrate_caches_from_disk(members_cache)
    lib.log(f"  Hydrated members cache: "
            f"{len(lib._USER_NAME_CACHE)} user names, "
            f"{len(lib._SPACE_DISPLAY_CACHE)} space display names")

    # ── List all spaces (1 API call, ~5s for 700+ spaces) ────────────────
    try:
        all_spaces = lib.list_spaces(chat)
    except Exception as e:
        lib.log(f"FATAL: list_spaces failed: {e}")
        return 1
    lib.log(f"  Total {len(all_spaces)} spaces in account")

    # ── Filter client-side by lastActiveTime ─────────────────────────────
    pad    = timedelta(hours=lib.ACTIVE_FILTER_PADDING_HOURS)
    cutoff = since - pad
    active = []

    for s in all_spaces:
        sid  = s["name"].split("/")[-1]
        sres = s["name"]
        lat  = s.get("lastActiveTime")

        keep = True
        if lat:
            try:
                lat_dt = datetime.fromisoformat(lat.replace("Z", "+00:00"))
                if lat_dt <= cutoff:
                    keep = False
            except ValueError:
                pass
        # No lastActiveTime → keep (safer to over-fetch than miss)

        if not keep:
            continue

        # Reuse existing index entry if any, else build fresh
        if sid in index_spaces:
            entry = index_spaces[sid]
        else:
            try:
                entry = lib.build_index_entry(chat, s)
            except Exception as e:
                lib.log(f"  ! build_index_entry({sid}) failed: {e} — using minimal")
                entry = {
                    "space_id": sid,
                    "space_resource_name": sres,
                    "display_name": sid,
                    "space_type": s.get("spaceType") or s.get("type") or "UNKNOWN",
                    "drive_folder_id": None,
                    "last_crawl_utc": None,
                }

        active.append({
            "space_id":            sid,
            "space_resource_name": sres,
            "display_name":        entry.get("display_name") or sid,
            "space_type":          entry.get("space_type") or
                                   s.get("spaceType") or "UNKNOWN",
            "drive_folder_id":     entry.get("drive_folder_id"),
            "last_active_time":    lat or entry.get("last_active_time"),
            "last_crawl_utc":      entry.get("last_crawl_utc"),
        })

    lib.log(f"  Active since {cutoff.date()}: "
            f"{len(active)}/{len(all_spaces)} spaces kept")

    # Sort: most-recently-active first (so skill processes hottest spaces early)
    active.sort(key=lambda e: e.get("last_active_time") or "", reverse=True)

    # ── Write _active_spaces.json ────────────────────────────────────────
    output = {
        "discovered_at":  now_utc.isoformat(),
        "global_since":   since.isoformat(),
        "filter_cutoff":  cutoff.isoformat(),
        "total_spaces":   len(all_spaces),
        "active_count":   len(active),
        "schema_version": lib.SCHEMA_VERSION,
        "active_spaces":  active,
    }
    ACTIVE_SPACES_FILE.write_text(
        json.dumps(output, indent=2, ensure_ascii=False),
        encoding="utf-8")
    lib.log(f"Wrote {ACTIVE_SPACES_FILE.name} — "
            f"{len(active)} spaces queued for phase2")
    return 0


if __name__ == "__main__":
    sys.exit(main())
