#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
upload_summaries.py — Upload AI-generated daily summaries (Claude session
sinh ra) lên Drive thành `_summary.json` mỗi space.

Input: _summaries_ready.json (local) với schema:
{
  "generated_at":   "...",
  "schema_version": 2,
  "summaries": [
    {
      "space_id":       "AAQA_US73Ec",
      "display_name":   "...",
      "space_type":     "GROUP_CHAT",
      "drive_folder_id":"...",
      "covers_period":  {"from": "2026-05-01", "to": "2026-05-15"},
      "daily_summaries":{
        "2026-05-15": {
          "msg_count":           23,
          "active_participants": ["A", "B"],
          "topics":              ["topic1", ...],
          "summary":             "prose summary 2-4 sentences",
          "decisions":           ["..."],
          "action_items":        [{"who":"...","what":"..."}]
        },
        ...
      }
    },
    ...
  ]
}

Hành vi:
  - Với mỗi entry: download _summary.json hiện có trên Drive (nếu có)
  - Merge `daily_summaries` theo date (entry mới override entry cũ cùng date)
  - Cập nhật `covers_period`, `generated_at`, `display_name`, `space_type`
  - Upload lại (override existing _summary.json)
  - Xoá _summaries_ready.json local khi xong (nếu không có fail)

Usage: python upload_summaries.py
"""
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaInMemoryUpload

SCRIPT_DIR        = Path(__file__).parent.resolve()
TOKEN_FILE        = SCRIPT_DIR / "token.json"
SUMMARIES_FILE    = SCRIPT_DIR / "_summaries_ready.json"
SUMMARY_FILENAME  = "_summary.json"
SCHEMA_VERSION    = 2

SCOPES = ["https://www.googleapis.com/auth/drive.file"]

def load_credentials() -> Credentials:
    creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)
    if not creds.valid and creds.expired and creds.refresh_token:
        creds.refresh(Request())
        TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
    return creds

def _q(name: str) -> str:
    return name.replace("'", "\\'")

def find_summary_file(drive, folder_id: str) -> str:
    q   = (f"name='{SUMMARY_FILENAME}' and '{folder_id}' in parents "
           f"and trashed=false")
    res = drive.files().list(q=q, fields="files(id)", pageSize=2,
                              spaces="drive").execute()
    files = res.get("files", [])
    return files[0]["id"] if files else None

def download_json(drive, file_id: str):
    try:
        raw = drive.files().get_media(fileId=file_id).execute()
        return json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
    except Exception as e:
        print(f"  ! download_json({file_id}): {e}")
        return None

def upload_or_update(drive, folder_id: str, filename: str, payload: dict,
                     existing_id: str = None) -> str:
    content = json.dumps(payload, indent=2, ensure_ascii=False).encode("utf-8")
    media   = MediaInMemoryUpload(content, mimetype="application/json",
                                   resumable=False)
    if existing_id:
        f = drive.files().update(fileId=existing_id, media_body=media,
                                  fields="id").execute()
    else:
        body = {"name": filename, "parents": [folder_id]}
        f = drive.files().create(body=body, media_body=media,
                                  fields="id").execute()
    return f["id"]

def merge_summary(existing: dict, new_entry: dict) -> dict:
    """Merge new daily_summaries vào existing summary by date.

    New entries thắng entries cũ cùng date. Giữ metadata mới nhất.
    """
    if not existing:
        merged_daily = dict(new_entry.get("daily_summaries", {}))
    else:
        merged_daily = dict(existing.get("daily_summaries", {}))
        for date, daily in (new_entry.get("daily_summaries") or {}).items():
            merged_daily[date] = daily

    dates = sorted(merged_daily.keys())
    covers = {
        "from": dates[0] if dates else new_entry.get("covers_period", {}).get("from"),
        "to":   dates[-1] if dates else new_entry.get("covers_period", {}).get("to"),
    }

    return {
        "schema_version":  SCHEMA_VERSION,
        "space_id":        new_entry.get("space_id"),
        "display_name":    new_entry.get("display_name")
                            or (existing or {}).get("display_name", ""),
        "space_type":      new_entry.get("space_type")
                            or (existing or {}).get("space_type", "UNKNOWN"),
        "generated_at":    datetime.now(timezone.utc).isoformat(),
        "generated_by":    "claude",
        "covers_period":   covers,
        "total_days":      len(dates),
        "daily_summaries": {d: merged_daily[d] for d in dates},
    }

def main() -> int:
    if not SUMMARIES_FILE.exists():
        print(f"! Không có {SUMMARIES_FILE}. Bỏ qua.")
        return 0
    try:
        data = json.loads(SUMMARIES_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"! {SUMMARIES_FILE} không phải JSON hợp lệ: {e}")
        return 1

    summaries = data.get("summaries", [])
    if not summaries:
        print("! _summaries_ready.json không có entry nào.")
        return 0

    creds = load_credentials()
    drive = build("drive", "v3", credentials=creds, cache_discovery=False)

    ok, fail, skipped = 0, 0, 0
    for s in summaries:
        folder_id = s.get("drive_folder_id")
        label     = s.get("display_name", s.get("space_id", "?"))
        if not folder_id:
            print(f"  SKIP (no drive_folder_id): {label}")
            skipped += 1
            continue
        try:
            existing_id   = find_summary_file(drive, folder_id)
            existing_data = download_json(drive, existing_id) if existing_id else None
            merged        = merge_summary(existing_data, s)
            new_id        = upload_or_update(
                drive, folder_id, SUMMARY_FILENAME, merged, existing_id)
            days = len(merged.get("daily_summaries", {}))
            print(f"  OK  [{days:3d} days] {label[:55]} → {new_id}")
            ok += 1
        except Exception as e:
            print(f"  FAIL: {label}: {type(e).__name__}: {e}")
            fail += 1

    print(f"\nTotal: ok={ok}  fail={fail}  skip={skipped}")
    if fail == 0:
        SUMMARIES_FILE.unlink(missing_ok=True)
        print(f"Đã xoá {SUMMARIES_FILE} (vì không có fail).")
    return 0 if fail == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
