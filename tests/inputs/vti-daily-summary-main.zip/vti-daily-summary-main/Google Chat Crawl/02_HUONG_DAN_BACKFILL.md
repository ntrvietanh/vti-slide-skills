# Hướng dẫn backfill

**File này đã bị thay thế. Xem [03_CLEAN_VA_BACKFILL_LAI.md](./03_CLEAN_VA_BACKFILL_LAI.md)** cho workflow mới (canonical folder naming, scope 14 ngày, AI-generated `_summary.json`).
