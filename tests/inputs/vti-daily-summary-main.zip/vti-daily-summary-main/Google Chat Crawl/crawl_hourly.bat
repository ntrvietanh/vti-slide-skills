@echo off
REM ---------------------------------------------------------------------------
REM Hourly Google Chat crawler — wrapper for Windows Task Scheduler
REM ---------------------------------------------------------------------------
setlocal

REM cd vào workspace tuyệt đối — Task Scheduler có thể chạy từ cwd khác
cd /d "C:\Users\Administrator\Documents\Claude\Projects\Google Chat Crawl"

REM Tạo folder logs nếu chưa có
if not exist "logs" mkdir "logs"

REM Tên log file = ngày hôm nay (yyyy-MM-dd)
for /f "tokens=2 delims==" %%i in ('"wmic os get localdatetime /value"') do set dt=%%i
set TODAY=%dt:~0,4%-%dt:~4,2%-%dt:~6,2%

REM Run crawler — stdout/stderr append vào daily log
echo. >> "logs\crawl_%TODAY%.log"
echo ==================== %date% %time% ==================== >> "logs\crawl_%TODAY%.log"
python crawl_gchat.py --max-seconds 60 --rate-sleep 0.1 >> "logs\crawl_%TODAY%.log" 2>&1
set EXITCODE=%ERRORLEVEL%

echo Exit code: %EXITCODE% >> "logs\crawl_%TODAY%.log"
exit /b %EXITCODE%
