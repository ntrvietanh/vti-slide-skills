# Uninstall_GChatCrawl_Task.ps1
# Xoa Windows Scheduled Task GChatCrawl_Daily
# Chay PowerShell voi quyen Administrator:
#   powershell -ExecutionPolicy Bypass -File .\Uninstall_GChatCrawl_Task.ps1

$TaskName = "GChatCrawl_Daily"

$existing = schtasks /Query /TN $TaskName 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Task '$TaskName' khong ton tai - khong can xoa." -ForegroundColor Yellow
    exit 0
}

schtasks /Delete /TN $TaskName /F
if ($LASTEXITCODE -eq 0) {
    Write-Host "Da xoa task '$TaskName' thanh cong." -ForegroundColor Green
} else {
    Write-Host "Xoa task that bai." -ForegroundColor Red
    exit 1
}
