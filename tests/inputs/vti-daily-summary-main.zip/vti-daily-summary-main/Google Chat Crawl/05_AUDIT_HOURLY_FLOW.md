# Daily Automated Flow — chỉ 1 task duy nhất

## Tổng quan

```
┌────────────────────────────────────────────────────────────┐
│ DAILY 8:02 AM (Cowork scheduled task — daily-gchat-summary)│
│                                                            │
│ 1. CRAWL — python crawl_gchat.py                           │
│    • Pull msg mới (createTime > _stage.last_crawl_utc)     │
│    • Refresh display_name qua People API                   │
│    • Auto-rename Drive folder canonical [Type]_[Name]_[ID] │
│    • Append JSONL daily lên Drive (merge by msg_id)        │
│    • Update _index.json + _stage.json                      │
│    • Ghi _summary_queue.json local                         │
│                                                            │
│ 2. SUMMARIZE — Claude sinh AI summaries                    │
│    • Đọc _summary_queue.json                               │
│    • Cho mỗi space active, sinh daily_summaries:           │
│      - msg_count, active_participants                      │
│      - topics, summary (tiếng Việt 2-4 câu)                │
│      - decisions, action_items                             │
│    • Ghi _summaries_ready.json local                       │
│                                                            │
│ 3. UPLOAD — python upload_summaries.py                     │
│    • Merge daily entries by date vào _summary.json         │
│      mỗi folder space trên Drive                           │
│    • Tự xoá _summaries_ready.json local khi xong           │
└────────────────────────────────────────────────────────────┘
```

**Tần suất**: 1 lần/ngày, 8:02 AM VN time.

## Setup checklist

### 1. Disable Windows Task Scheduler (KHÔNG cần nữa)

Trước đó có Windows scheduled task chạy `crawl_gchat.py` hourly. Giờ Cowork task daily đã làm hết việc đó → tắt Windows task để khỏi xung đột quota:

```powershell
Get-ScheduledTask | Where-Object {$_.TaskName -like "*Chat*"} | Disable-ScheduledTask
```

### 2. Run Cowork task 1 lần manual để pre-approve tool permissions

Vào Cowork sidebar → **"Scheduled"** → tìm `daily-gchat-summary` → click **"Run now"**.

Lần đầu sẽ hỏi approve các tool: Read, Write, Bash. Approve hết. Lần sau cron trigger sẽ chạy auto không hỏi nữa.

### 3. Verify

Sau lần manual run, check:
- Drive: `_stage.json` có `last_crawl_utc` mới
- Drive: spaces có msg mới có JSONL appended
- Drive: spaces folder có `_summary.json` updated (mở xem date entries)
- Local: `_summaries_ready.json` đã bị xoá (nếu upload OK)

## Khi nào task chạy

- **Cron**: `0 8 * * *` → 8 AM VN time
- **Thực tế**: 8:02 AM (Cowork delay ~2 phút để cân tải)
- **Yêu cầu**: Máy bật + Cowork running tại thời điểm đó

Nếu máy tắt lúc 8:02 → task miss. Lần app launch sau, nếu trễ thì sẽ chạy bù (1 lần thôi).

## Run thủ công khi cần

Bất cứ lúc nào muốn refresh ngay (vd: sau khi chat nhiều):

Sidebar → Scheduled → `daily-gchat-summary` → **Run now**

## Drive structure sau khi task chạy xong

```
Google Chat Crawl/
├── _stage.json                      ← last_crawl_utc daily
├── _index.json                      ← display_name + drive_folder_name daily
└── spaces/
    └── DM_HUY Nguyen Le Quang (VTI.D9)_wg3_w8AAAAE/
        ├── 2026-05-01.jsonl         ← messages from past 14d (or longer)
        ├── 2026-05-15.jsonl         ← latest day append
        ├── 2026-05-16.jsonl         ← today's new msgs
        └── _summary.json            ← AI daily_summaries merged by date
```

## Common issues

| Triệu chứng | Cause | Fix |
|---|---|---|
| `Stored credentials are not refreshable` | Token revoked | Re-run `crawl_gchat.py --auth-url` từ Windows |
| Folder không rename | display_name không đổi | OK, không phải bug |
| `_summary.json` không update | Queue rỗng (không có space active) | Bình thường |
| Cowork task fail bước upload | Python deps thiếu trong sandbox | Prompt đã có `pip install` — nếu vẫn fail, kiểm tra log |
| Mất nhiều thời gian | Lần đầu pip install deps | Lần sau cached, nhanh hơn |

## Architecture note

Tại sao chuyển từ "hourly Windows + on-demand summary" sang "daily Cowork all-in-one"?

| Trước | Sau |
|---|---|
| Windows Task Scheduler hourly | Cowork daily |
| 2 systems (Windows + Cowork) | 1 system (Cowork) |
| Hourly fresh nhưng summary manual | Daily fresh, summary tự động |
| 24 runs/day | 1 run/day |
| Quota API: ~24x | Quota API: 1x |
| Setup: 2 nơi | Setup: 1 nơi |

Trade-off: Data trên Drive trễ tối đa 24h thay vì 1h. Cho usage này (review chat history), trễ 1 ngày OK.

Nếu muốn fresh hơn, đổi cron `0 8 * * *` → `0 8,14,20 * * *` (3 lần/ngày 8h, 14h, 20h).
