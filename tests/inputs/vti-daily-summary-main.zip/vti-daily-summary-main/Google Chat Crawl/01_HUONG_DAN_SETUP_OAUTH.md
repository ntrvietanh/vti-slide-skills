# Hướng dẫn setup OAuth cho Google Chat Crawler (Workspace VTI)

Tài liệu này hướng dẫn bạn (Michael — `anh.nguyentruongviet@vti.com.vn`) thiết lập OAuth credentials cho Google Cloud trên **tài khoản Workspace VTI APAC**, để script Python có thể đọc Google Chat (đầy đủ Spaces + DM + Group DM) và ghi lên Google Drive thay bạn.

> **Thời gian dự kiến:** 15–20 phút (chỉ làm 1 lần duy nhất).
>
> **Mọi thứ chạy local trên máy bạn.** Không có credential nào được gửi đi đâu khác.
>
> **Ưu điểm khi dùng Workspace:**
> - Crawl được **DM 1-1, Group DM, và Spaces** đầy đủ.
> - OAuth có thể để chế độ **Internal** → refresh token KHÔNG bị hết hạn 7 ngày.
> - Không cần submit verification của Google.

---

## ⚠️ LƯU Ý TRƯỚC KHI BẮT ĐẦU

**Quyền Workspace admin:** Tuỳ chính sách VTI APAC, có thể IT/Workspace Admin đã giới hạn user tự tạo GCP project hoặc bật OAuth client. Nếu ở bước nào đó bị block (báo lỗi "Restricted by admin policy" hoặc "Access denied"), bạn cần liên hệ admin VTI để:

- Cho phép tạo GCP project trên tài khoản Workspace.
- Bật **Google Chat API** ở mức tổ chức.
- Cho phép **OAuth consent screen Internal** với scope `chat.messages.readonly`.

Nếu admin VTI cấm hoàn toàn việc tạo project cá nhân, ta sẽ phải dùng phương án **dùng GCP project cá nhân (External)** — nói tôi biết khi bạn gặp vấn đề, sẽ chuyển hướng.

---

## Bước 1 — Mở Google Cloud Console

1. Mở trình duyệt, vào: <https://console.cloud.google.com/>
2. **Đăng nhập bằng đúng tài khoản** `anh.nguyentruongviet@vti.com.vn`.
   - Nếu trình duyệt đang đăng nhập tài khoản khác, mở Incognito hoặc thêm tài khoản.
3. Lần đầu vào, chấp nhận Terms of Service.

---

## Bước 2 — Tạo Project mới

1. Trên thanh trên cùng, bấm vào dropdown chọn project (bên cạnh logo "Google Cloud").
2. Bấm **NEW PROJECT** (góc trên bên phải hộp thoại).
3. Đặt:
   - **Project name:** `gchat-crawler-vti`
   - **Organization:** chọn `vti.com.vn` (nếu được phép) — đây là điểm khác biệt so với Gmail cá nhân.
   - **Location:** để mặc định (`vti.com.vn` hoặc `No organization` nếu admin chặn).
4. Bấm **CREATE**. Chờ ~30 giây.
5. Đảm bảo project mới đang được chọn ở thanh trên cùng.

> **Nếu thấy thông báo "Restricted by admin policy":** quay lên mục cảnh báo ở đầu file — cần liên hệ admin VTI.

---

## Bước 3 — Bật 2 API cần thiết

### 3.1 Bật Google Chat API

1. Trong thanh tìm kiếm trên cùng, gõ: `Google Chat API`.
2. Bấm vào kết quả **Google Chat API**.
3. Bấm nút **ENABLE** (nút xanh lớn). Chờ vài giây.

### 3.2 Bật Google Drive API

1. Quay lại thanh tìm kiếm, gõ: `Google Drive API`.
2. Bấm vào kết quả **Google Drive API**.
3. Bấm **ENABLE**.

---

## Bước 4 — Cấu hình OAuth Consent Screen

1. Menu trái → **APIs & Services** → **OAuth consent screen**.
2. **User Type:** chọn **Internal** ← **đây là điểm khác biệt quan trọng so với Gmail cá nhân**.
   - "Internal" nghĩa là chỉ user trong domain `vti.com.vn` được dùng → KHÔNG cần Google verify → refresh token không hết hạn 7 ngày.
3. Bấm **CREATE**.
4. Điền form **App information**:
   - **App name:** `VTI GChat Personal Crawler`
   - **User support email:** `anh.nguyentruongviet@vti.com.vn`
   - **Developer contact information:** `anh.nguyentruongviet@vti.com.vn`
   - Mọi mục khác để trống.
5. Bấm **SAVE AND CONTINUE**.

### 4.1 Tab Scopes

1. Bấm **ADD OR REMOVE SCOPES**.
2. Trong ô tìm kiếm, dán từng cái sau và tick chọn:
   - `https://www.googleapis.com/auth/chat.spaces.readonly`
   - `https://www.googleapis.com/auth/chat.messages.readonly`
   - `https://www.googleapis.com/auth/chat.memberships.readonly`
   - `https://www.googleapis.com/auth/drive.file`
3. Bấm **UPDATE** → **SAVE AND CONTINUE**.

> Với **Internal user type**, scope "Restricted/Sensitive" cũng dùng được ngay mà không cần verification.

### 4.2 Summary

- Xem lại, bấm **BACK TO DASHBOARD**.
- Vì là Internal nên không có mục Test users — mọi user trong VTI Workspace tự động dùng được. (Trong thực tế chỉ bạn dùng vì là OAuth Desktop type.)

---

## Bước 5 — Tạo OAuth Client ID (Desktop App)

1. Menu trái → **APIs & Services** → **Credentials**.
2. Bấm **+ CREATE CREDENTIALS** (trên cùng) → chọn **OAuth client ID**.
3. **Application type:** chọn **Desktop app**.
4. **Name:** `gchat-crawler-vti-desktop`.
5. Bấm **CREATE**.
6. Hộp thoại hiện ra với `Client ID` + `Client Secret`. Bấm **DOWNLOAD JSON**.

---

## Bước 6 — Đặt file credentials đúng chỗ

1. File vừa tải có tên kiểu `client_secret_XXXX.apps.googleusercontent.com.json`.
2. **Đổi tên** thành: `credentials.json`.
3. **Copy** file đó vào folder dự án này:

   ```
   C:\Users\Administrator\Documents\Claude\Projects\Google Chat Crawl\credentials.json
   ```

> Đây là cùng folder bạn đang chọn trong Cowork. Đặt đúng path → script sẽ tìm thấy.

---

## Bước 7 — Báo lại tôi để viết script

Khi bạn xong bước 6, nhắn trong cuộc hội thoại này:

> "Xong rồi"

Tôi sẽ:

- Viết script `crawl_gchat.py` đầy đủ.
- Chạy 1 lần → script mở trình duyệt cho bạn login → sinh `token.json` (refresh token).
- Test crawl thử với 1 Space để xác nhận hoạt động.
- Tạo scheduled task chạy mỗi giờ, upload JSON lên Drive folder `Google Chat Archive/YYYY-MM-DD/`.

---

## FAQ nhanh

**Q: Workspace có giới hạn gì không?**
A: Hầu như không. Bạn crawl được:
- ✅ Tất cả **Spaces (rooms)** bạn là thành viên.
- ✅ Tất cả **Group DMs** bạn tham gia.
- ✅ Tất cả **DM 1-1** với bất kỳ ai (kể cả người ngoài VTI nếu họ chat với bạn qua Google Chat).
- ❌ KHÔNG đọc được tin nhắn ở Space mà bạn KHÔNG là thành viên (đương nhiên).

**Q: Refresh token có hết hạn không?**
A: Với **Internal** OAuth → KHÔNG hết hạn (trừ khi bạn revoke hoặc đổi password). Đây là lợi thế lớn so với Gmail cá nhân (7 ngày).

**Q: Admin VTI có thấy được data tôi crawl không?**
A: Workspace Admin của VTI có thể audit OAuth app bạn cấp quyền (qua Admin Console → Security → API Controls). Họ thấy được app `gchat-crawler-vti-desktop` đã được cấp quyền nhưng KHÔNG đọc được nội dung tin nhắn (data ở local máy bạn). Nếu chính sách VTI yêu cầu khai báo app, hãy thông báo với IT.

**Q: Có nguy cơ bảo mật gì?**
A: `credentials.json` + `token.json` cho phép đọc **toàn bộ chat** của bạn. KHÔNG:
- Share với ai.
- Commit lên Git/GitHub.
- Backup lên cloud public.
- Đưa vào máy người khác.
- Folder dự án này nên ở **My Documents** local, không nằm trong OneDrive/Google Drive sync.

**Q: Muốn dừng/xoá tất cả?**
A: Google Cloud Console → APIs & Services → Credentials → xoá OAuth client. Revoke thêm tại <https://myaccount.google.com/permissions> (đăng nhập tài khoản VTI). Xoá folder local.

---

*Cập nhật: 2026-05-15 (cho Workspace anh.nguyentruongviet@vti.com.vn)*
