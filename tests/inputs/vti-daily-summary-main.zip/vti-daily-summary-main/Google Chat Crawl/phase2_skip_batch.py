#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
phase2_skip_batch.py — Phase 2A: Batch-stamp all certain-SKIP spaces.

Problem it solves
-----------------
With 100-200 active spaces, most of them have no new messages (their
last_active_time <= effective_since).  Running phase2_crawl_one.py for
each of them costs 1 bash call × ~3s overhead × N spaces = minutes of
wasted time.

Solution
--------
Load _index.json ONCE from Drive, update last_crawl_utc for every
confirmed-SKIP space in memory, save ONCE.  Total cost: ~5-8s regardless
of how many SKIP spaces exist.

A space is "certain-SKIP" iff (from _active_spaces.json metadata):
  last_active_time <= effective_since
  where effective_since = last_crawl_utc (if set) OR global_since

These spaces are guaranteed to produce a SKIP in phase2_crawl_one.py
without any API call.  We can safely stamp them here instead.

Spaces that ARE active (last_active_time > effective_since) or that have
no index entry yet are left untouched — Claude runs phase2_crawl_one.py
for those individually (Phase 2B).

Inputs  (read):  _active_spaces.json (local), _index.json (Drive)
Outputs (write): _index.json (Drive) — last_crawl_utc updated for SKIPs
                 _skip_batch_result.json (local) — summary for Claude

Exit codes: 0 success | 1 fatal
"""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import crawl_lib as lib


SCRIPT_DIR         = Path(__file__).parent.resolve()
ACTIVE_SPACES_FILE = SCRIPT_DIR / "_active_spaces.json"
RESULT_FILE        = SCRIPT_DIR / "_skip_batch_result.json"


def _parse_iso(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def main() -> int:
    lib.log("=" * 60)
    lib.log("phase2_skip_batch.py started")

    if not ACTIVE_SPACES_FILE.exists():
        lib.log("FATAL: _active_spaces.json missing — run phase1 first")
        return 1

    cfg           = json.loads(ACTIVE_SPACES_FILE.read_text(encoding="utf-8"))
    active_spaces = cfg.get("active_spaces", [])
    gsince        = _parse_iso(cfg.get("global_since"))

    # ── Classify spaces ──────────────────────────────────────────────────
    skip_sids   = []   # certain SKIP — no API call needed
    active_sids = []   # have potential new messages — need phase2_crawl_one

    for s in active_spaces:
        sid              = s["space_id"]
        lat              = _parse_iso(s.get("last_active_time"))
        lcu              = _parse_iso(s.get("last_crawl_utc"))
        effective_since  = lcu or gsince

        if lat and effective_since and lat <= effective_since:
            skip_sids.append(sid)
        else:
            active_sids.append(sid)

    lib.log(f"  Total active spaces : {len(active_spaces)}")
    lib.log(f"  Certain-SKIP (2A)   : {len(skip_sids)}")
    lib.log(f"  Need crawl   (2B)   : {len(active_sids)}")

    # Always write result so Claude knows which sids to run in Phase 2B
    result = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "skip_count":   len(skip_sids),
        "active_sids":  active_sids,
        "active_count": len(active_sids),
    }

    if not skip_sids:
        lib.log("  No SKIP spaces to stamp.")
        RESULT_FILE.write_text(
            json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        lib.log(f"  Wrote {RESULT_FILE.name}")
        return 0

    # ── Load _index.json once ────────────────────────────────────────────
    lib.log("  Loading credentials + _index.json …")
    creds   = lib.load_credentials()
    drive   = lib.get_drive(creds)
    root_id = lib.ensure_folder(drive, lib.DRIVE_ROOT_NAME)

    index, index_id = lib.load_index(drive, root_id)
    index_spaces    = index.setdefault("spaces", {})

    # ── Stamp each SKIP space in memory ─────────────────────────────────
    now_utc  = datetime.now(timezone.utc).isoformat()
    stamped  = 0
    no_entry = []

    for sid in skip_sids:
        entry = index_spaces.get(sid)
        if entry:
            entry["last_crawl_utc"] = now_utc
            index_spaces[sid]       = entry
            stamped += 1
        else:
            # Space has no index entry yet — leave for Phase 2B to init+crawl
            # (phase2_crawl_one.py will build_index_entry and fetch from scratch)
            no_entry.append(sid)

    lib.log(f"  Stamped {stamped} spaces | {len(no_entry)} had no index entry "
            f"(moved to Phase 2B)")

    # Move no-entry SKIP spaces into active_sids so Claude runs phase2_crawl_one
    result["active_sids"]  = active_sids + no_entry
    result["active_count"] = len(result["active_sids"])
    if no_entry:
        lib.log(f"  No-entry spaces added to Phase 2B: {no_entry}")

    # ── Save _index.json once ────────────────────────────────────────────
    try:
        lib.save_index(drive, root_id, index, index_id)
        lib.log(f"  Saved _index.json ({stamped} spaces stamped in one write)")
    except Exception as e:
        lib.log(f"FATAL: save_index failed: {e}")
        return 1

    result["stamped"] = stamped
    RESULT_FILE.write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    lib.log(f"  Wrote {RESULT_FILE.name}")

    lib.log(f"Done. Phase 2B needs {result['active_count']} individual crawls.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
