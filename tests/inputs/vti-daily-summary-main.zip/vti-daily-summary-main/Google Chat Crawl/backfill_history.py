#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
backfill_history.py — Google Chat backfill (local, no time budget).

Scope MẶC ĐỊNH:
  - Spaces filter: chỉ DM/Group/Space có lastActiveTime trong 14 ngày.
  - Messages filter: chỉ message trong 14 ngày trở lại (createTime > now-14d).

Quy trình:
  1. List + filter spaces (active 14d).
  2. Build _index.json đầy đủ UPFRONT trên Drive:
       - display_name resolved (DM/Group cũng có tên người, không phải ID)
       - drive_folder_id + drive_folder_name (canonical [Type]_[Name]_[ID])
       - Rename folder cũ nếu display_name đã thay đổi
  3. Với mỗi space: paginate messages → flush batch JSONL trên Drive.
  4. Cuối session: write _summary_queue.json (toàn bộ space backfilled).
  5. AI session (Claude) đọc queue → sinh _summary.json daily per-space →
     upload qua upload_summaries.py.
     KHÔNG sinh _summary.json deterministic, KHÔNG có _narrative.json nữa.

Tách biệt với crawl_gchat.py (scheduled hourly):
  crawl_gchat.py      → owns _stage.json (last_crawl_utc, KHÔNG ĐỘNG)
  backfill_history.py → owns _backfill_state.json (resume local)

CLI:
  python backfill_history.py                       active 14d + last 14d msgs
  python backfill_history.py --space SID           chỉ 1 space (test)
  python backfill_history.py --since-days 30 --active-days 30
  python backfill_history.py --limit 5             dừng sau 5 space (resume được)
  python backfill_history.py --retry-failed        chạy lại space failed
  python backfill_history.py --reset               xoá state local
  python backfill_history.py --dry-run             không upload Drive
"""

import argparse
import json
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Reuse helpers từ scheduled task script
from crawl_gchat import (
    SCRIPT_DIR,
    DRIVE_ROOT_NAME,
    DRIVE_SPACES_NAME,
    SCHEMA_VERSION,
    load_credentials,
    ensure_folder,
    ensure_space_folder_canonical,
    canonical_folder_name,
    resolve_display_name,
    list_folder_files,
    list_spaces,
    build_index_entry,
    load_index,
    save_index,
    download_text,
    normalize_message,
    group_by_date,
    merge_and_upload_daily,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BACKFILL_STATE_FILE  = SCRIPT_DIR / "_backfill_state.json"
BACKFILL_LOG_FILE    = SCRIPT_DIR / "backfill.log"
SUMMARY_QUEUE_FILE   = SCRIPT_DIR / "_summary_queue.json"

DEFAULT_ACTIVE_DAYS  = 14
DEFAULT_SINCE_DAYS   = 14
DEFAULT_RATE_SLEEP   = 0.1

PAGE_SIZE                   = 100
BATCH_FLUSH_PAGES           = 20
MAX_RETRIES_429             = 5
RETRY_BACKOFF_BASE          = 5
QUEUE_RECENT_MSGS_PER_SPACE = 1500
MIN_MSGS_FOR_SUMMARY        = 3

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def blog(msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(BACKFILL_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

def load_state() -> dict:
    if BACKFILL_STATE_FILE.exists():
        try:
            return json.loads(BACKFILL_STATE_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            blog("! _backfill_state.json corrupt — starting fresh")
    return {
        "schema_version":   SCHEMA_VERSION,
        "started_at":       None,
        "updated_at":       None,
        "user":             "anh.nguyentruongviet@vti.com.vn",
        "active_days":      DEFAULT_ACTIVE_DAYS,
        "since_days":       DEFAULT_SINCE_DAYS,
        "total_spaces":     0,
        "spaces_done":      0,
        "spaces_failed":    0,
        "messages_total":   0,
        "spaces":           {},
    }

def save_state(state: dict) -> None:
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    BACKFILL_STATE_FILE.write_text(
        json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")

def init_space_state(sid: str, display: str, space_type: str) -> dict:
    return {
        "display_name":     display,
        "space_type":       space_type,
        "status":           "pending",
        "pages_fetched":    0,
        "messages_fetched": 0,
        "dates_written":    [],
        "first_msg_time":   None,
        "last_msg_time":    None,
        "started_at":       None,
        "completed_at":     None,
        "last_error":       None,
    }

# ---------------------------------------------------------------------------
# Chat API with retry
# ---------------------------------------------------------------------------

def _retry_call(fn, *args, **kwargs):
    for attempt in range(MAX_RETRIES_429):
        try:
            return fn(*args, **kwargs)
        except HttpError as e:
            status = getattr(e.resp, "status", None)
            if status == 429 or (status and 500 <= status < 600):
                wait = RETRY_BACKOFF_BASE * (2 ** attempt)
                blog(f"  ! HTTP {status} — chờ {wait}s rồi retry ({attempt+1}/{MAX_RETRIES_429})")
                time.sleep(wait)
                continue
            raise
    raise RuntimeError(f"Bỏ cuộc sau {MAX_RETRIES_429} lần retry")

def iter_messages_since(chat, space_name: str, since_iso: Optional[str],
                        rate_sleep: float):
    """Yield (page_idx, msgs) cho tất cả message createTime > since_iso."""
    page_token = None
    page_idx   = 0
    filter_str = f'createTime > "{since_iso}"' if since_iso else None

    while True:
        kwargs = {
            "parent":      space_name,
            "pageSize":    PAGE_SIZE,
            "showDeleted": True,
            "orderBy":     "createTime desc",
        }
        if page_token:
            kwargs["pageToken"] = page_token
        if filter_str:
            kwargs["filter"] = filter_str

        resp = _retry_call(chat.spaces().messages().list(**kwargs).execute)

        page_idx += 1
        yield page_idx, resp.get("messages", [])

        page_token = resp.get("nextPageToken")
        if not page_token:
            return
        if rate_sleep > 0:
            time.sleep(rate_sleep)

# ---------------------------------------------------------------------------
# Window messages reader
# ---------------------------------------------------------------------------

def load_recent_msgs_from_drive(drive, folder_id: str, existing_files: dict,
                                cutoff_utc: datetime, limit: int) -> list:
    """Đọc lại các JSONL date >= cutoff, gộp + sort, trả về limit msgs mới nhất."""
    msgs = []
    for fname, fid in sorted(existing_files.items()):
        if not fname.endswith(".jsonl"):
            continue
        try:
            fdate = datetime.strptime(fname[:-6], "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if fdate < cutoff_utc:
            continue
        raw = download_text(drive, fid)
        if not raw:
            continue
        for line in raw.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                msgs.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    msgs.sort(key=lambda m: m.get("create_time", ""))
    return msgs[-limit:] if limit > 0 else msgs

# ---------------------------------------------------------------------------
# Per-space backfill
# ---------------------------------------------------------------------------

def backfill_one_space(drive, chat, space_obj: dict, index: dict, index_id: str,
                       root_id: str, spaces_dir_id: str, state: dict,
                       since_iso: str, rate_sleep: float, dry_run: bool,
                       now_utc: datetime) -> dict:
    """Backfill 1 space. Trả về dict: {ok, messages, queue_entry}."""
    sid   = space_obj["name"].split("/")[-1]
    sname = space_obj["name"]

    if sid not in index["spaces"]:
        index["spaces"][sid] = build_index_entry(chat, space_obj)
    entry = index["spaces"][sid]
    fresh_display = resolve_display_name(chat, space_obj)
    if fresh_display and fresh_display != entry.get("display_name"):
        entry["display_name"] = fresh_display
    display    = entry.get("display_name", sid)
    space_type = entry.get("space_type", "UNKNOWN")

    if sid not in state["spaces"]:
        state["spaces"][sid] = init_space_state(sid, display, space_type)
    sp_state = state["spaces"][sid]
    sp_state["display_name"] = display
    sp_state["space_type"]   = space_type
    sp_state["status"]       = "in_progress"
    sp_state["started_at"]   = sp_state.get("started_at") or datetime.now(timezone.utc).isoformat()
    sp_state["last_error"]   = None
    save_state(state)

    if not dry_run:
        entry["drive_folder_id"] = ensure_space_folder_canonical(
            drive, sid, space_type, display, spaces_dir_id,
            entry.get("drive_folder_id"))
        entry["drive_folder_name"] = canonical_folder_name(space_type, display, sid)
    folder_id = entry.get("drive_folder_id") or ""

    existing_files = {} if dry_run else list_folder_files(drive, folder_id)

    blog(f"━━ [{space_type:18s}] {display[:60]}  (id={sid})")

    t_start    = time.monotonic()
    buffer     = []
    pages      = 0
    total_msgs = 0
    all_dates  = set(sp_state.get("dates_written", []))
    first_mt   = sp_state.get("first_msg_time")
    last_mt    = sp_state.get("last_msg_time")
    crawled_at = now_utc.isoformat()

    def flush_buffer():
        nonlocal buffer
        if not buffer:
            return 0
        by_date = group_by_date(buffer)
        for date_str, day_msgs in sorted(by_date.items()):
            if not dry_run:
                merge_and_upload_daily(drive, folder_id, date_str,
                                       day_msgs, existing_files)
            all_dates.add(date_str)
        n = len(buffer)
        buffer = []
        return n

    try:
        for page_idx, raw_msgs in iter_messages_since(chat, sname, since_iso, rate_sleep):
            pages = page_idx
            if not raw_msgs:
                continue
            for raw in raw_msgs:
                m = normalize_message(raw, sid, display, space_type, crawled_at)
                buffer.append(m)
                total_msgs += 1
                ct = m.get("create_time") or ""
                if ct:
                    if not first_mt or ct < first_mt:
                        first_mt = ct
                    if not last_mt or ct > last_mt:
                        last_mt = ct

            if pages % BATCH_FLUSH_PAGES == 0:
                flushed = flush_buffer()
                elapsed = time.monotonic() - t_start
                rate    = total_msgs / elapsed if elapsed > 0 else 0
                blog(f"    pages={pages:4d}  msgs={total_msgs:6d}  "
                     f"dates={len(all_dates):3d}  {rate:5.0f} msg/s  flushed={flushed}")
                sp_state.update({
                    "pages_fetched": pages, "messages_fetched": total_msgs,
                    "dates_written": sorted(all_dates),
                    "first_msg_time": first_mt, "last_msg_time": last_mt,
                })
                save_state(state)

        flush_buffer()

        entry["available_dates"]        = sorted(set(entry.get("available_dates", [])) | all_dates)
        entry["total_messages_crawled"] = (entry.get("total_messages_crawled", 0) + total_msgs)
        entry["backfill_complete"]      = True
        entry["backfill_completed_at"]  = datetime.now(timezone.utc).isoformat()
        entry["first_msg_time"]         = first_mt
        entry["last_msg_time"]          = last_mt
        index["spaces"][sid] = entry

        recent_msgs = []
        if not dry_run and total_msgs > 0:
            try:
                existing_files = list_folder_files(drive, folder_id)
                since_dt = datetime.fromisoformat(since_iso.replace("Z", "+00:00"))
                recent_msgs = load_recent_msgs_from_drive(
                    drive, folder_id, existing_files, since_dt,
                    limit=QUEUE_RECENT_MSGS_PER_SPACE)
            except Exception as e:
                blog(f"  ! queue prep failed: {e}")

        if not dry_run:
            try:
                save_index(drive, root_id, index, index_id)
            except Exception as e:
                blog(f"  ! save_index failed: {e}")

        sp_state.update({
            "status":           "done",
            "pages_fetched":    pages,
            "messages_fetched": total_msgs,
            "dates_written":    sorted(all_dates),
            "first_msg_time":   first_mt,
            "last_msg_time":    last_mt,
            "completed_at":     datetime.now(timezone.utc).isoformat(),
            "elapsed_seconds":  round(time.monotonic() - t_start, 1),
        })
        state["spaces_done"]    = sum(1 for s in state["spaces"].values() if s["status"] == "done")
        state["spaces_failed"]  = sum(1 for s in state["spaces"].values() if s["status"] == "failed")
        state["messages_total"] = sum(s.get("messages_fetched", 0) for s in state["spaces"].values())
        save_state(state)

        elapsed = time.monotonic() - t_start
        blog(f"    ✓ DONE — {total_msgs} msgs / {len(all_dates)} ngày / {elapsed:.1f}s")

        queue_entry = None
        if total_msgs >= MIN_MSGS_FOR_SUMMARY and recent_msgs:
            queue_entry = {
                "space_id":        sid,
                "display_name":    display,
                "space_type":      space_type,
                "drive_folder_id": folder_id,
                "available_dates": sorted(all_dates),
                "msg_count_new":   total_msgs,
                "first_msg_time":  first_mt,
                "last_msg_time":   last_mt,
                "recent_messages": recent_msgs,
            }

        return {"ok": True, "messages": total_msgs, "queue_entry": queue_entry}

    except KeyboardInterrupt:
        blog("    ⚠ Ctrl+C — flushing buffer...")
        try:
            flush_buffer()
        except Exception as e:
            blog(f"  ! flush khi interrupt failed: {e}")
        sp_state.update({
            "pages_fetched": pages, "messages_fetched": total_msgs,
            "dates_written": sorted(all_dates),
            "first_msg_time": first_mt, "last_msg_time": last_mt,
            "status": "in_progress", "last_error": "interrupted",
        })
        save_state(state)
        raise

    except Exception as e:
        blog(f"    ✗ FAILED: {type(e).__name__}: {e}")
        try:
            flush_buffer()
        except Exception:
            pass
        sp_state.update({
            "pages_fetched": pages, "messages_fetched": total_msgs,
            "dates_written": sorted(all_dates),
            "first_msg_time": first_mt, "last_msg_time": last_mt,
            "status": "failed",
            "last_error": f"{type(e).__name__}: {e}",
        })
        state["spaces_failed"] = sum(1 for s in state["spaces"].values() if s["status"] == "failed")
        save_state(state)
        return {"ok": False, "messages": total_msgs, "queue_entry": None,
                "error": str(e)}

# ---------------------------------------------------------------------------
# Index bootstrap (UPFRONT — trước khi crawl message)
# ---------------------------------------------------------------------------

def bootstrap_index(drive, chat, all_spaces: list, index: dict,
                    index_id: str, root_id: str, spaces_dir_id: str,
                    dry_run: bool) -> str:
    blog(f"Bootstrap _index.json cho {len(all_spaces)} active spaces...")
    new_entries = 0
    for s in all_spaces:
        sid = s["name"].split("/")[-1]
        if sid not in index["spaces"]:
            index["spaces"][sid] = build_index_entry(chat, s)
            new_entries += 1
        entry = index["spaces"][sid]
        entry["last_active_time"] = s.get("lastActiveTime") or entry.get("last_active_time")
        entry["space_type"]       = (s.get("spaceType") or s.get("type")
                                     or entry.get("space_type", "UNKNOWN"))
        fresh_display = resolve_display_name(chat, s)
        if fresh_display and fresh_display != entry.get("display_name"):
            entry["display_name"] = fresh_display
        if not dry_run:
            entry["drive_folder_id"] = ensure_space_folder_canonical(
                drive, sid, entry["space_type"], entry["display_name"],
                spaces_dir_id, entry.get("drive_folder_id"))
            entry["drive_folder_name"] = canonical_folder_name(
                entry["space_type"], entry["display_name"], sid)

    blog(f"  +{new_entries} entry mới, tổng {len(index['spaces'])} space trong index.")
    if not dry_run:
        new_id = save_index(drive, root_id, index, index_id)
        blog(f"  → _index.json đã save lên Drive (id={new_id})")
        return new_id
    return index_id

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_backfill(only_space: Optional[str], limit: Optional[int],
                 retry_failed: bool, reset: bool, rate_sleep: float,
                 dry_run: bool, since_days: int, active_days: int) -> int:

    if reset and BACKFILL_STATE_FILE.exists():
        BACKFILL_STATE_FILE.unlink()
        blog("Reset: đã xoá _backfill_state.json")

    creds = load_credentials()
    drive = build("drive", "v3", credentials=creds, cache_discovery=False)
    chat  = build("chat",  "v1", credentials=creds, cache_discovery=False)

    now_utc       = datetime.now(timezone.utc)
    since_dt      = now_utc - timedelta(days=since_days)
    since_iso     = since_dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    cutoff_active = now_utc - timedelta(days=active_days)

    blog("=" * 72)
    blog(f"BACKFILL bắt đầu")
    blog(f"  since_days   = {since_days}  (createTime > {since_dt.date()})")
    blog(f"  active_days  = {active_days}  (lastActiveTime > {cutoff_active.date()})")
    blog(f"  dry_run      = {dry_run}")
    blog(f"  rate_sleep   = {rate_sleep}s/page")
    if only_space:
        blog(f"  scope        = ONLY space {only_space}")
    if limit:
        blog(f"  session_limit= {limit} spaces")
    if retry_failed:
        blog(f"  mode         = retry-failed")

    root_id    = ensure_folder(drive, DRIVE_ROOT_NAME)
    spaces_dir = ensure_folder(drive, DRIVE_SPACES_NAME, root_id)
    index, index_id = load_index(drive, root_id)
    index["spaces_folder_id"] = spaces_dir

    state = load_state()
    state["since_days"]  = since_days
    state["active_days"] = active_days
    if not state.get("started_at"):
        state["started_at"] = now_utc.isoformat()

    blog("Listing spaces từ Chat API...")
    all_spaces = list_spaces(chat)
    blog(f"  Total {len(all_spaces)} spaces trong account.")

    if only_space:
        filtered = [s for s in all_spaces if s["name"].split("/")[-1] == only_space]
        if not filtered:
            blog(f"! Không tìm thấy space {only_space}")
            return 1
    else:
        filtered = []
        no_active_time = 0
        for s in all_spaces:
            lat = s.get("lastActiveTime")
            if not lat:
                no_active_time += 1
                filtered.append(s)
                continue
            try:
                lat_dt = datetime.fromisoformat(lat.replace("Z", "+00:00"))
                if lat_dt >= cutoff_active:
                    filtered.append(s)
            except ValueError:
                filtered.append(s)
        blog(f"  Active trong {active_days} ngày: {len(filtered)}/{len(all_spaces)} "
             f"(no lastActiveTime: {no_active_time})")

    state["total_spaces"] = len(filtered)

    if not filtered:
        blog("Không có space nào active. Done.")
        save_state(state)
        return 0

    index_id = bootstrap_index(drive, chat, filtered, index, index_id,
                                root_id, spaces_dir, dry_run)

    if only_space:
        targets = filtered
    else:
        def should_process(s):
            sid = s["name"].split("/")[-1]
            sp  = state["spaces"].get(sid, {})
            status = sp.get("status", "pending")
            if retry_failed:
                return status == "failed"
            return status != "done"

        targets = [s for s in filtered if should_process(s)]
        targets.sort(key=lambda s: s.get("lastActiveTime") or "", reverse=True)

    if limit:
        targets = targets[:limit]

    blog(f"Sẽ crawl message cho {len(targets)} spaces session này.")
    save_state(state)

    if not targets:
        blog("Không có space nào cần backfill message. ✓ All done.")
        _maybe_write_queue([], now_utc, dry_run)
        return 0

    t_session = time.monotonic()
    n_ok, n_fail = 0, 0
    queue_entries = []

    for i, s in enumerate(targets, 1):
        sid = s["name"].split("/")[-1]
        blog(f"\n[{i}/{len(targets)}] (ok={n_ok} fail={n_fail})")
        try:
            res = backfill_one_space(
                drive, chat, s, index, index_id, root_id, spaces_dir,
                state, since_iso, rate_sleep, dry_run, now_utc)
            if res.get("ok"):
                n_ok += 1
                if res.get("queue_entry"):
                    queue_entries.append(res["queue_entry"])
            else:
                n_fail += 1
        except KeyboardInterrupt:
            blog("\n⚠ Ctrl+C — state đã save, chạy lại lệnh để resume.")
            _maybe_write_queue(queue_entries, now_utc, dry_run)
            return 130
        except Exception as e:
            blog(f"  ! Unexpected: {e}")
            n_fail += 1

    if not dry_run:
        try:
            save_index(drive, root_id, index, index_id)
        except Exception as e:
            blog(f"  ! final save_index: {e}")

    _maybe_write_queue(queue_entries, now_utc, dry_run)

    elapsed = time.monotonic() - t_session
    blog("\n" + "=" * 72)
    blog(f"BACKFILL session xong — ok={n_ok} fail={n_fail} / "
         f"{len(targets)} spaces / {elapsed:.0f}s")
    blog(f"Cumulative: done={state.get('spaces_done',0)} "
         f"total_target={state.get('total_spaces',0)} "
         f"msgs={state.get('messages_total',0)}")

    remaining = state.get("total_spaces", 0) - state.get("spaces_done", 0)
    if remaining == 0:
        blog("🎉 TẤT CẢ ACTIVE SPACES ĐÃ BACKFILL XONG.")
        if queue_entries:
            blog(f"   _summary_queue.json đã sẵn sàng với {len(queue_entries)} space "
                 f"→ chat lại với tôi để xử lý summary.")
        blog("   → Bật lại scheduled task hourly cho incremental tiếp tục.")
    else:
        blog(f"Còn {remaining} spaces. Chạy lại lệnh để tiếp tục.")
    return 0 if n_fail == 0 else 2

def _maybe_write_queue(entries: list, now_utc: datetime, dry_run: bool) -> None:
    if dry_run:
        blog(f"(dry_run) Skipping _summary_queue.json. Would have {len(entries)} entries.")
        return
    if not entries:
        SUMMARY_QUEUE_FILE.write_text(
            json.dumps({
                "generated_at":   now_utc.isoformat(),
                "schema_version": SCHEMA_VERSION,
                "source":         "backfill_history.py",
                "spaces":         [],
            }, indent=2, ensure_ascii=False), encoding="utf-8")
        blog(f"_summary_queue.json ghi rỗng (không có space >= MIN_MSGS_FOR_SUMMARY).")
        return
    payload = {
        "generated_at":   now_utc.isoformat(),
        "schema_version": SCHEMA_VERSION,
        "source":         "backfill_history.py",
        "total_spaces":   len(entries),
        "spaces":         entries,
    }
    SUMMARY_QUEUE_FILE.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    msgs_in_queue = sum(len(e.get("recent_messages", [])) for e in entries)
    blog(f"_summary_queue.json: {len(entries)} space, {msgs_in_queue} msgs sẵn cho AI sinh _summary.json.")

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    p = argparse.ArgumentParser(
        description="Google Chat backfill (active spaces, recent history).")
    p.add_argument("--space",        metavar="SPACE_ID",
                   help="Chỉ backfill 1 space (qua filter active luôn)")
    p.add_argument("--limit",        type=int, default=None,
                   help="Stop sau N spaces session này (resume được)")
    p.add_argument("--retry-failed", action="store_true",
                   help="Chỉ chạy lại các space status=failed")
    p.add_argument("--reset",        action="store_true",
                   help="Xoá _backfill_state.json (KHÔNG xoá Drive)")
    p.add_argument("--rate-sleep",   type=float, default=DEFAULT_RATE_SLEEP,
                   help=f"Sleep giữa các page request (default {DEFAULT_RATE_SLEEP}s)")
    p.add_argument("--dry-run",      action="store_true",
                   help="Fetch + count nhưng KHÔNG upload Drive")
    p.add_argument("--since-days",   type=int, default=DEFAULT_SINCE_DAYS,
                   help=f"Lấy message trong N ngày trở lại (default {DEFAULT_SINCE_DAYS})")
    p.add_argument("--active-days",  type=int, default=DEFAULT_ACTIVE_DAYS,
                   help=f"Chỉ space active trong N ngày (default {DEFAULT_ACTIVE_DAYS})")
    args = p.parse_args()

    try:
        return run_backfill(
            only_space   = args.space,
            limit        = args.limit,
            retry_failed = args.retry_failed,
            reset        = args.reset,
            rate_sleep   = args.rate_sleep,
            dry_run      = args.dry_run,
            since_days   = args.since_days,
            active_days  = args.active_days,
        )
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        blog(f"FATAL: {type(e).__name__}: {e}")
        import traceback
        blog(traceback.format_exc())
        return 1

if __name__ == "__main__":
    sys.exit(main())
