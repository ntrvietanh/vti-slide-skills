# =============================================================================
# Setup_GChatCrawl_Task.ps1
# Đăng ký Windows Scheduled Task cho crawl_hourly.bat
#   - Daily 23:00 (11 PM)
#   - Boot trigger (chạy 2 phút sau khi máy boot)
#   - Run whether user is logged on or not (cần password)
#   - StartWhenAvailable = catch missed runs khi máy off
#
# CÁCH CHẠY:
#   1. Mở PowerShell với quyền Run as Administrator
#   2. cd "C:\Users\Administrator\Documents\Claude\Projects\Google Chat Crawl"
#   3. powershell -ExecutionPolicy Bypass -File .\Setup_GChatCrawl_Task.ps1
# =============================================================================

# Khong dat ErrorActionPreference=Stop vi schtasks ghi stderr binh thuong
# (vd khi /Query mot task chua ton tai) se bi PowerShell coi nhu terminating error
$ErrorActionPreference = "Continue"

$TaskName  = "GChatCrawl_Daily"
$XmlPath   = Join-Path $PSScriptRoot "GChatCrawl_Task.xml"
$BatPath   = Join-Path $PSScriptRoot "crawl_hourly.bat"
$UserName  = "$env:COMPUTERNAME\Administrator"

Write-Host ""
Write-Host "=== Setup Google Chat Crawl Scheduled Task ===" -ForegroundColor Cyan
Write-Host ""

# 1. Sanity checks
if (-not (Test-Path $XmlPath)) { Write-Error "Khong tim thay XML: $XmlPath"; exit 1 }
if (-not (Test-Path $BatPath)) { Write-Error "Khong tim thay BAT: $BatPath"; exit 1 }

$isAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Error "Phai chay PowerShell voi quyen Administrator (Run as administrator)."
    exit 1
}

Write-Host "[OK] Da chay voi quyen Administrator"
Write-Host "[OK] XML:  $XmlPath"
Write-Host "[OK] BAT:  $BatPath"
Write-Host ""

# 2. Hoi password Windows (de luu vao task)
Write-Host "Nhap password Windows cua user '$UserName' de task co the chay khi khong dang nhap." -ForegroundColor Yellow
Write-Host "(Password chi luu trong Credential Manager cua Windows, khong gui di dau.)" -ForegroundColor DarkGray
$SecurePass = Read-Host "Password" -AsSecureString
$BSTR       = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
$PlainPass  = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
[System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR) | Out-Null

if ([string]::IsNullOrEmpty($PlainPass)) {
    Write-Error "Password khong duoc rong."
    exit 1
}

# 3. Xoa task cu neu da co (suppress stderr de tranh PowerShell coi nhu error)
& cmd /c "schtasks /Query /TN `"$TaskName`" >NUL 2>&1"
if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "[INFO] Task '$TaskName' da ton tai - xoa de tao moi..." -ForegroundColor Yellow
    & cmd /c "schtasks /Delete /TN `"$TaskName`" /F >NUL 2>&1"
}

# 4. Tao task tu XML
Write-Host ""
Write-Host "Dang dang ky task..." -ForegroundColor Cyan
$createOutput = & cmd /c "schtasks /Create /TN `"$TaskName`" /XML `"$XmlPath`" /RU `"$UserName`" /RP `"$PlainPass`" 2>&1"
if ($LASTEXITCODE -ne 0) {
    Write-Host ($createOutput -join "`n") -ForegroundColor Red
    Write-Error "schtasks /Create FAILED (exit code $LASTEXITCODE)"
    exit 1
}
Write-Host ($createOutput -join "`n")

# Clear password tu memory
$PlainPass = $null
[System.GC]::Collect()

# 5. Verify
Write-Host ""
Write-Host "=== Task da tao thanh cong ===" -ForegroundColor Green
schtasks /Query /TN $TaskName /V /FO LIST | Select-String -Pattern "TaskName|Status|Last Run|Next Run|Run As User|Schedule"

Write-Host ""
Write-Host "=== Tiep theo ===" -ForegroundColor Cyan
Write-Host "  - Test chay ngay:        schtasks /Run /TN $TaskName"
Write-Host "  - Xem trang thai:        schtasks /Query /TN $TaskName /V /FO LIST"
Write-Host "  - Mo Task Scheduler GUI: taskschd.msc"
Write-Host "  - Log output:            logs\crawl_<YYYY-MM-DD>.log"
Write-Host ""
Write-Host "Hoan tat!" -ForegroundColor Green
