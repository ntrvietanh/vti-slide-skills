# Clean và backfill lại từ đầu theo rule mới

Sau khi thay đổi: folder canonical name, display name DM/Group đúng, scope 14 ngày, summary do AI sinh — cần clean Drive + state local rồi chạy lại.

## Bước 1 — TẮT scheduled task

```powershell
Get-ScheduledTask | Where-Object {$_.TaskName -like "*Chat*"} | Disable-ScheduledTask
```

## Bước 2 — XOÁ folder "Google Chat Crawl" trên Drive

Vào <https://drive.google.com> (đăng nhập `anh.nguyentruongviet@vti.com.vn`):

1. Tìm folder **"Google Chat Crawl"** ở My Drive
2. Click chuột phải → **Move to trash**
3. Vào **Trash** (thùng rác) → **Empty trash** (đổ rác) — bắt buộc, không thì script `drive.file` scope vẫn thấy folder cũ

## Bước 3 — XOÁ state local

```powershell
cd "C:\Users\Administrator\Documents\Claude\Projects\Google Chat Crawl"

# State files
del _backfill_state.json
del _summary_queue.json
del _summaries_ready.json
del state.json
del _folder_map.json

# Logs (optional, có thể giữ để xem)
del crawl.log
del backfill.log
del dryrun_*.json

# KHÔNG xoá: token.json, credentials.json, *.py, *.md, requirements.txt
```

## Bước 4 — Chạy backfill mới

```powershell
# Test trước 1 space để verify mọi thứ OK (folder name, display name, scope)
python backfill_history.py --space AAQA_US73Ec --dry-run

# Chạy thật 1 space
python backfill_history.py --space AAQA_US73Ec

# Vào Drive xem folder mới: "Group_<tên đúng>_AAQA_US73Ec/"
# Có JSONL daily files trong đó

# OK rồi thì full backfill
python backfill_history.py
```

## Bước 5 — Sinh `_summary.json` (AI)

Sau khi log in:
```
🎉 TẤT CẢ ACTIVE SPACES ĐÃ BACKFILL XONG.
   _summary_queue.json đã sẵn sàng với N space → chat lại với tôi để xử lý.
```

→ Mở chat mới với tôi (Claude), nói **"xử lý summary queue"**. Tôi sẽ:

1. Đọc `_summary_queue.json` local
2. Với mỗi space, sinh `daily_summaries` per-date theo schema:
   ```json
   {
     "2026-05-15": {
       "msg_count":           23,
       "active_participants": ["A", "B"],
       "topics":              ["Migration plan", "Sprint kickoff"],
       "summary":             "Tóm tắt 2-4 câu tiếng Việt...",
       "decisions":           ["Quyết định 1"],
       "action_items":        [{"who":"A","what":"..."}]
     }
   }
   ```
3. Ghi `_summaries_ready.json` local
4. Bạn chạy:
   ```powershell
   python upload_summaries.py
   ```
5. Mỗi space sẽ có `_summary.json` trên Drive trong folder `[Type]_[Name]_[ID]/`

## Bước 6 — Bật lại scheduled task

```powershell
Get-ScheduledTask | Where-Object {$_.TaskName -like "*Chat*"} | Enable-ScheduledTask
```

Từ giờ:
- Scheduled task chạy hourly, fetch message mới
- Ghi vào đúng folder `[Type]_[Name]_[ID]/` đã có (qua `drive_folder_id` trong `_index.json`)
- Tự refresh `display_name` nếu tên Chat đổi → rename folder Drive
- Append entry mới vào `_summary_queue.json` cho space có msgs mới
- Trong session Cowork tiếp theo (hoặc chạy tay), AI xử lý queue → merge vào `_summary.json` existing trên Drive (`upload_summaries.py` lo merge by date)

## Cấu trúc Drive sau khi xong

```
Google Chat Crawl/
├── _index.json              ← catalog tất cả space (folder_id, folder_name, display_name)
├── _stage.json              ← scheduled task quản (last_crawl_utc)
└── spaces/
    ├── DM_Nguyễn Văn A_AAQA_US73Ec/
    │   ├── 2026-05-02.jsonl
    │   ├── 2026-05-15.jsonl
    │   └── _summary.json      ← AI-generated daily summaries
    ├── Group_Team Sales_AAAATbep7gY/
    │   ├── 2026-05-08.jsonl
    │   └── _summary.json
    └── Space_Project Alpha_AAQAthuwL6Y/
        ├── ...
        └── _summary.json
```

`_summary.json` chi tiết:

```json
{
  "schema_version":  2,
  "space_id":        "AAQA_US73Ec",
  "display_name":    "Nguyễn Văn A",
  "space_type":      "DIRECT_MESSAGE",
  "generated_at":    "2026-05-15T10:30:00Z",
  "generated_by":    "claude",
  "covers_period":   {"from": "2026-05-02", "to": "2026-05-15"},
  "total_days":      9,
  "daily_summaries": {
    "2026-05-02": {
      "msg_count": 12,
      "active_participants": ["Nguyễn Văn A"],
      "topics": ["Lịch họp tuần", "Status MVP"],
      "summary": "Trao đổi về lịch họp thứ Năm và cập nhật tiến độ MVP. A xác nhận sẽ gửi demo cuối tuần.",
      "decisions": ["Họp Thứ Năm 10h"],
      "action_items": [{"who":"A","what":"Gửi demo trước thứ Sáu"}]
    },
    "2026-05-15": { ... }
  }
}
```

## Checklist

- [ ] Disable scheduled task
- [ ] Xoá Drive folder + empty trash
- [ ] Xoá state local
- [ ] Test 1 space dry-run
- [ ] Test 1 space thật
- [ ] Verify Drive folder name format `[Type]_[Name]_[ID]` ✓
- [ ] Verify DM/Group hiện đúng tên người ✓
- [ ] Full backfill
- [ ] Gọi tôi xử lý summary queue
- [ ] Chạy `upload_summaries.py`
- [ ] Verify `_summary.json` trên Drive
- [ ] Enable scheduled task lại
