#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
phase3_finalize.py — Phase 3 of the 3-phase pipeline.

Job:
  1. Aggregate per-space queue parts (_summary_queue_parts/*.json) into a
     single _summary_queue.json that the skill's Claude-reasoning step will
     consume.
  2. Decide whether this run was a "full pass" (every space listed in
     _active_spaces.json has its entry.last_crawl_utc >= discovered_at).
  3. If full pass: advance global _stage.json last_crawl_utc to
     discovered_at (NOT "now" — covers in-flight messages).
  4. If partial: keep previous global last_crawl_utc so phase1 next run
     re-discovers the deferred spaces.
  5. Persist members cache.
  6. On full pass: clean up queue parts.

Inputs (read):
  - _active_spaces.json  (local, from phase1)
  - _summary_queue_parts/*.json (local, from phase2 instances)
  - _index.json on Drive (per-space last_crawl_utc)

Outputs (written):
  - _summary_queue.json (local) — for the skill's Claude reasoning step
  - _stage.json on Drive (advanced last_crawl_utc IFF full pass)
  - state.json local (mirror of _stage.json for human inspection)

Wall-clock budget: ~5-10s.
"""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import crawl_lib as lib


SCRIPT_DIR              = Path(__file__).parent.resolve()
ACTIVE_SPACES_FILE      = SCRIPT_DIR / "_active_spaces.json"
QUEUE_PARTS_DIR         = SCRIPT_DIR / "_summary_queue_parts"
SUMMARY_QUEUE_FILE      = SCRIPT_DIR / "_summary_queue.json"
SUMMARY_QUEUE_MAX_SPACES = 12      # cap to keep skill prompt size sane
SUMMARY_QUEUE_MAX_MSGS   = 300     # per-space cap (trim oldest)


def _parse_iso(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def main() -> int:
    lib.log("=" * 60)
    lib.log("phase3_finalize.py started")

    if not ACTIVE_SPACES_FILE.exists():
        lib.log(f"FATAL: {ACTIVE_SPACES_FILE.name} missing — nothing to finalize")
        return 1

    cfg            = json.loads(ACTIVE_SPACES_FILE.read_text(encoding="utf-8"))
    expected_sids  = [e["space_id"] for e in cfg.get("active_spaces", [])]
    discovered_at  = cfg.get("discovered_at")
    discovered_dt  = _parse_iso(discovered_at)

    lib.log(f"  Active spaces from phase1: {len(expected_sids)}")
    lib.log(f"  discovered_at: {discovered_at}")

    creds   = lib.load_credentials()
    drive   = lib.get_drive(creds)
    root_id = lib.ensure_folder(drive, lib.DRIVE_ROOT_NAME)

    # ── Determine completion per space from _index.json ──────────────────
    index, _   = lib.load_index(drive, root_id)
    index_sp   = index.get("spaces", {})
    completed  = []
    deferred   = []

    for sid in expected_sids:
        entry = index_sp.get(sid)
        if not entry:
            deferred.append(sid)
            continue
        lcu = _parse_iso(entry.get("last_crawl_utc"))
        if lcu and discovered_dt and lcu >= discovered_dt:
            completed.append(sid)
        else:
            deferred.append(sid)

    full_pass = (len(deferred) == 0 and len(expected_sids) > 0)
    lib.log(f"  Completed: {len(completed)}/{len(expected_sids)}  "
            f"Deferred: {len(deferred)}  Full pass: {full_pass}")

    # ── Aggregate queue parts ────────────────────────────────────────────
    parts = []
    if QUEUE_PARTS_DIR.exists():
        for f in sorted(QUEUE_PARTS_DIR.glob("*.json")):
            try:
                p = json.loads(f.read_text(encoding="utf-8"))
                # Trim recent_messages tail to cap
                rm = p.get("recent_messages", [])
                if len(rm) > SUMMARY_QUEUE_MAX_MSGS:
                    p["recent_messages"] = rm[-SUMMARY_QUEUE_MAX_MSGS:]
                parts.append(p)
            except Exception as e:
                lib.log(f"  ! skip queue part {f.name}: {e}")

    parts.sort(key=lambda p: p.get("msg_count_new", 0), reverse=True)
    top = parts[:SUMMARY_QUEUE_MAX_SPACES]
    overflow = len(parts) - len(top)
    if overflow > 0:
        lib.log(f"  Dropped {overflow} queue parts (cap={SUMMARY_QUEUE_MAX_SPACES})")

    queue = {
        "generated_at":   datetime.now(timezone.utc).isoformat(),
        "schema_version": lib.SCHEMA_VERSION,
        "source":         "phase3_finalize.py",
        "full_pass":      full_pass,
        "spaces_active":  len(expected_sids),
        "spaces_done":    len(completed),
        "spaces":         top,
    }
    SUMMARY_QUEUE_FILE.write_text(
        json.dumps(queue, indent=2, ensure_ascii=False),
        encoding="utf-8")
    lib.log(f"  Wrote {SUMMARY_QUEUE_FILE.name} — {len(top)} spaces, "
            f"{sum(len(p.get('recent_messages', [])) for p in top)} msgs")

    # ── Save members cache (best effort) ─────────────────────────────────
    try:
        lib.serialize_caches_to_disk(
            force_refresh_happened=False, now_utc=datetime.now(timezone.utc))
    except Exception as e:
        lib.log(f"  ! serialize_caches_to_disk: {e}")

    # ── Update _stage.json ───────────────────────────────────────────────
    prev_stage, stage_id = lib.load_stage(drive, root_id)
    prev_stage = prev_stage or {}

    if full_pass:
        next_lcu = discovered_at
        phase    = "steady"
        lib.log(f"  Full pass → advance global last_crawl_utc → {next_lcu}")
    else:
        next_lcu = prev_stage.get("last_crawl_utc") or discovered_at
        phase    = "partial"
        lib.log(f"  Partial run → keep last_crawl_utc at {next_lcu}")

    new_stage = {
        "schema_version":    lib.SCHEMA_VERSION,
        "last_crawl_utc":    next_lcu,
        "phase":             phase,
        "crawl_count":       int(prev_stage.get("crawl_count", 0)) + 1,
        "user":              lib.SELF_EMAIL,
        "bootstrap_done":    True,
        "full_history_done": prev_stage.get("full_history_done", False),
        "last_run_summary": {
            "completed_at":    datetime.now(timezone.utc).isoformat(),
            "discovered_at":   discovered_at,
            "full_pass":       full_pass,
            "spaces_active":   len(expected_sids),
            "spaces_done":     len(completed),
            "spaces_deferred": len(deferred),
            "deferred_sids":   deferred[:20],
        },
        "updated_at":        datetime.now(timezone.utc).isoformat(),
    }

    try:
        lib.save_stage(drive, root_id, new_stage, stage_id)
        lib.log("  _stage.json saved on Drive")
    except Exception as e:
        lib.log(f"  ! save_stage failed: {e}")

    try:
        lib.STATE_FILE.write_text(
            json.dumps(new_stage, indent=2, ensure_ascii=False),
            encoding="utf-8")
    except OSError as e:
        lib.log(f"  ! local state.json write failed: {e}")

    # ── Clean up queue parts on full pass ────────────────────────────────
    if full_pass and QUEUE_PARTS_DIR.exists():
        cleaned = 0
        for f in QUEUE_PARTS_DIR.glob("*.json"):
            try:
                f.unlink()
                cleaned += 1
            except Exception:
                pass
        lib.log(f"  Cleaned {cleaned} queue parts (full pass)")

    lib.log(f"Done. full_pass={full_pass} done={len(completed)} "
            f"deferred={len(deferred)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
