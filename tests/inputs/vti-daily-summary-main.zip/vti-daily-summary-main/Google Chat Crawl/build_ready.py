#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_ready.py — Assemble _summaries_ready.json từ AI-curated summaries
+ deterministic fallback cho phần còn lại.

Schema mỗi entry:
{
  "space_id":     "...",
  "display_name": "...",
  "space_type":   "...",
  "drive_folder_id": "...",
  "covers_period": {"from": "...", "to": "..."},
  "daily_summaries": {
    "YYYY-MM-DD": {
      "msg_count":           N,
      "active_participants": [...],
      "topics":              [...],
      "summary":             "prose",
      "decisions":           [...],
      "action_items":        [{"who":"...","what":"..."}]
    }
  }
}

CURATED dict: ai-written summaries cho spaces quan trọng.
Phần còn lại auto-fill bằng deterministic logic.
"""
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR    = Path(__file__).parent.resolve()
BATCH_DIR     = SCRIPT_DIR / "_summary_batches"   # per-space compact files
READY_FILE    = SCRIPT_DIR / "_summaries_ready.json"

# ---------------------------------------------------------------------------
# AI-curated summaries (sẽ được tôi cập nhật manually qua các turn)
# Key: space_id, Value: {date: daily_summary_dict}
# Bất kỳ date nào không có trong CURATED sẽ fallback deterministic.
# ---------------------------------------------------------------------------

CURATED = {
    # VTI.VAP — main internal management space, full 12-day curated
    "AAAAukFeUNA": {
        "2026-05-02": {
            "topics": ["Banter nội bộ"],
            "summary": "Vài tin nhắn rời rạc, không có nội dung công việc cụ thể.",
            "decisions": [],
            "action_items": [],
        },
        "2026-05-04": {
            "topics": ["MC HCMC candidate swap", "Mitsubishi liên hệ", "Stats nhân lực gửi Concentrix"],
            "summary": "Họp online sáng. Thảo luận swap candidate anh Toàn đi MC HCMC sang MC Sing, nhưng đang tranh cãi do anh Thành muốn đổi qua candidate khác. Gửi loop email với Mitsubishi HCMC. Bàn về file thống kê resources HR gửi để gửi Concentrix — đang cần sửa hình thức + có thể make-up lại số liệu.",
            "decisions": ["Gửi candidate (anh Toàn) đi MC Sing theo plan ban đầu"],
            "action_items": [
                {"who": "Khanh Tran Duy", "what": "Update với anh Tuân về deadline & review mồng 7"},
                {"who": "Khanh Tran Duy", "what": "Mail Tam san + Dung san MC HCMC"},
                {"who": "Cuong Nguyen Duc", "what": "Check lại số liệu trên file resources trước khi gửi Concentrix"},
            ],
        },
        "2026-05-05": {
            "topics": ["ODC Tùng scale +2 headcount", "Ufinity request resources", "Internal banter Anthropic Claude"],
            "summary": "Tin vui: ODC Tùng (Ufinity) có khả năng scale lên thêm 2 headcount. Daniel (Ufinity) thông tin có 2 candidate competitor muốn quit và Ufinity muốn process qua VTI. Bàn về việc VTI có open cho cả 2 ng này không, ưu tiên hợp tác với Ufinity. Discussion cao trào: anh Thảo muốn giữ người, dùng candidate khù khoằm bên ngoài thay vì người sẵn có.",
            "decisions": ["Confirm sẵn sàng process 2 candidate Daniel giới thiệu nếu họ đồng ý"],
            "action_items": [
                {"who": "Cuong Nguyen Duc", "what": "Theo dõi Daniel feedback từ 2 candidate"},
            ],
        },
        "2026-05-06": {
            "topics": ["SO contract GITS vs APAC", "ODC Tùng scale", "GovTech visit"],
            "summary": "Sales Operations với GITS gặp vấn đề: anh Sáng chưa confirm next step. Đang tìm cách bypass TA bằng cách ký hợp đồng APAC với pháp nhân VN hoặc ký với cá nhân ông Đức. Push action với A Thảo về ODC Tùng tăng 2HC liên quan GovTech. Cẩn thận tránh xung đột với D1.",
            "decisions": ["Hỏi anh Trí về việc dùng APAC ký với pháp nhân VN"],
            "action_items": [
                {"who": "Tyson Nguyen", "what": "Chạy xuống hỏi anh Trí về phương án ký hợp đồng"},
                {"who": "Cuong Nguyen Duc", "what": "Inform anh Thảo về cơ hội ODC scale + GovTech"},
                {"who": "Michael Nguyen", "what": "Inform anh Hiếu + Hùng về opp GovTech để join meeting mai"},
            ],
        },
        "2026-05-07": {
            "topics": ["Cora Migration với Anthony", "MC HCMC swap deadlock", "GovTech rehearsal"],
            "summary": "Chiều 3pm họp với Anthony về phần chưa done Cora Migration — sẽ raise các câu chuyện vướng mắc. Xung đột về MC HCMC: anh Thành tự gửi CV swap candidate dù trước đó đã chốt không swap; team không nắm thông tin này. Chuẩn bị tài liệu rehearsal Sái Hoàng Việt (GovTech) cho mai — anh Thành đề xuất dùng ChatGPT generate câu hỏi.",
            "decisions": ["Anh Thành phụ trách nói chuyện lại về candidate swap MC HCMC"],
            "action_items": [
                {"who": "Tyson Nguyen", "what": "Tạo group chat tiếp GovTech"},
                {"who": "Michael + Kevin", "what": "Trả lời câu hỏi của GovTech về case studies + plan VN của bạn này"},
            ],
        },
        "2026-05-08": {
            "topics": ["PSAM BQ deadline", "GITS contract 3-day notice issue", "PSAM WMS pricing", "MC HCMC interview anh Toàn"],
            "summary": "Deadline BQ PSAM hôm nay — anh Tuân fix 2 mục non-compliant + fill BQ template. SLW Technology submit 6 CV Magento batch 1 cho onboard tháng 6 — có 1 mindle 3 năm lệch senior. Quan ngại: GITS ký contract chỉ ràng buộc resource notice 3 ngày, cần thương lượng lên 45 ngày. Chốt keep anh Toàn đi MC HCMC theo plan ban đầu. Tính giá onsite PSAM WMS: $8,010 cho 3 trips.",
            "decisions": [
                "PSAM WMS onsite quote $8,010",
                "Keep anh Toàn đi MC HCMC, chốt lịch pv online",
                "Yêu cầu GITS sửa contract notice từ 3 → 45 ngày",
            ],
            "action_items": [
                {"who": "Tyson Nguyen", "what": "Check song song BQ PSAM với VSL"},
                {"who": "Cuong Nguyen Duc", "what": "Gửi batch #2 CVs Magento cho Gary + hỏi timeline phản hồi"},
                {"who": "VAP team", "what": "Trao đổi với GITS về điều khoản resource trong contract"},
            ],
        },
        "2026-05-10": {
            "topics": ["Technovation Penang 1st meeting prep"],
            "summary": "Confirm join 1st meeting Technovation 9am thứ 2 — bên đầu tiên ở Penang. Bàn về việc review trước tài liệu (giống đợt InfiniteX, M3) để chắc chắn. Anh Sáng remind cháu accept Google Calendar.",
            "decisions": ["Tham gia online 9am thứ 2"],
            "action_items": [],
        },
        "2026-05-11": {
            "topics": ["D9 CA Web Ufinity pick", "MC HCMC trial 6 tháng", "Sembcorp partime IT"],
            "summary": "D9 đang pick candidate CA Web Ufinity — quan ngại candidate không nói được English. Email MC HCMC: confirm OK service trial 6 tháng, lưu ý sắp xếp nhân sự đủ năng lực. CA Web estimate không khả quan do thiếu Q&A từ khách + không ai hiểu financial domain. AIOps D3 review tài liệu.",
            "decisions": [
                "Email MC HCMC accept 6-month service trial",
                "Tiếp tục push Ufinity CA Web nhưng giảm kỳ vọng về estimate",
            ],
            "action_items": [
                {"who": "Khanh Tran Duy", "what": "Email MC HCMC về điều kiện trial 6 tháng + lưu ý nhân sự"},
                {"who": "Tyson Nguyen", "what": "Set deadline Justin cho tài liệu CA Web"},
            ],
        },
        "2026-05-12": {
            "topics": ["GITS Magento batch 2", "MC HCMC swap stop", "ALPSoft Azure L2 Cloud Engineer", "VAP - Sembcorp commercial"],
            "summary": "GITS submit thêm 4 CV Magento — 3 ông 5-10 năm OK, 1 ông Nguyễn Trung Hiệp skills khác 5-10 năm. Chốt gửi batch 2 cho Gary. Book phòng Bangkok cho anh Toàn pv. ALPSoft mở case mới Azure L2 Cloud Engineer concept tương tự. VAP-Sembcorp commercial keep nguyên giá hợp đồng cũ.",
            "decisions": [
                "Gửi GITS Magento batch 2 cho Gary",
                "Keep giá Sembcorp hợp đồng nguyên",
            ],
            "action_items": [
                {"who": "Cuong Nguyen Duc", "what": "Verify content + template CV Magento → xuất PDF gửi Gary"},
            ],
        },
        "2026-05-13": {
            "topics": ["KGI Trading QA", "MC Sing nhân sự strategy", "Tài liệu Hùng kiến trúc sư"],
            "summary": "Push Mark check QA KGI Trading. MC Sing: khách không prefer anh Toàn (chưa đủ kinh nghiệm), cần Rec tuyển thêm ngoài + make-up CVs. Có time đến tháng 8-9 chốt người. Bàn về việc tuyển sớm để onboard VTI trước hay submit rồi mới tuyển. Quan ngại về tài liệu retail/ecom của VTI: chưa có case tương tự bài toán khách.",
            "decisions": [
                "MC Sing: submit make-up CVs trước, chỉ tuyển vào VTI khi khách chốt người",
                "Có thể tuyển thêm bên ngoài cho MC Sing pool",
            ],
            "action_items": [
                {"who": "Recruitment", "what": "Tuyển thêm candidates external cho MC Sing pool"},
            ],
        },
        "2026-05-14": {
            "topics": ["KGI Trading est 40mm review", "MC HCMC interview với anh Toàn vé bay", "Sembcorp English requirement"],
            "summary": "Review file anh Sơn KGI Trading — est tổng 40mm, ko handle transaction giao dịch nên ko issue lớn. Critique: cần data flow + sequence diagram, đặc biệt giao dịch tiền phải qua Singpass. Chị Trang đặt vé chiều cho anh Toàn về cùng. Sembcorp confirm có IT group → cần English fluent, không phiên dịch. 2 ứng viên IT VTI ko đủ English → vấn đề.",
            "decisions": [
                "MC pitch: ngồi Agentic AI + Multi AI Agents only, thêm CS MC",
                "Sembcorp English fluent → ko dùng được 2 IT VTI",
            ],
            "action_items": [
                {"who": "Cuong Nguyen Duc", "what": "Chat riêng với chị Huyền Sembcorp về English requirement"},
            ],
        },
        "2026-05-15": {
            "topics": ["MC HCMC contract template", "Sembcorp reject 2 cases + option fulltime/partime", "Bỏ thầu IT SG"],
            "summary": "MC yêu cầu HĐ mẫu vụ IT — Charlotte log request lấy mẫu Legal. Sembcorp confirm cần English fluent → reject 2 cases VTI (Việt và 1 case khác). Đề xuất 2 option cho Sembcorp: 1) Fulltime tuyển ng đáp ứng English, 2) Partime dùng ng VTI bỏ Eng requirement. Vụ KH SG đòi quản lý sàn Shopee đang ghost. Quyết định để D3 nhận AI training case (không gom D8).",
            "decisions": [
                "Reject 2 cases Sembcorp",
                "AI training case → D3 own, D8 không gom",
            ],
            "action_items": [
                {"who": "Quyen Nguyen Thi Do", "what": "Log request bodyshop MC HCMC + gửi HĐ mẫu"},
                {"who": "VAP team", "what": "Propose 2 options fulltime/partime cho Sembcorp"},
            ],
        },
    },
}

# ---------------------------------------------------------------------------
# Deterministic fallback summary builder
# ---------------------------------------------------------------------------

URL_RE = re.compile(r'https?://\S+')
WORD_RE = re.compile(r'[\w\-]{4,}', re.UNICODE)

# Common Vietnamese stopwords for topic extraction
STOPWORDS = set("""
anh chị em chúng tôi mình bạn bro của trong với và là có không cho được đã đang sẽ thì thế này
nay mai hôm hqua hôm_nay vs cho ko đc cũng nhưng nên nếu hoặc nha nhe nhé nhỉ rồi xong vậy đâu
oke okay yes về tại để sau khi như chỉ vào ra lên xuống vào_ra một hai ba do bởi nào ai gì sao đấy
case team rep call meeting họp send done update check khách clinet xin a_a anh_em đội
help giúp bro bro_ơi chú nhỉ nhỉ_ấy
""".split())

def is_self_indicator(text: str) -> bool:
    return bool(re.search(r'@?Michael Nguyen', text, re.IGNORECASE))

def extract_participants(lines: list) -> list:
    """Lấy unique sender names từ format 'HH:MM sender: ...'."""
    senders = []
    for ln in lines:
        if ln.startswith("  +"):
            continue
        # Format: "HH:MM sender: text"
        m = re.match(r'^\d{2}:\d{2}\s+(.+?):\s', ln)
        if m:
            s = m.group(1).strip()
            if s and s != '?' and s not in senders:
                senders.append(s)
    return senders[:8]

def extract_topic_keywords(lines: list) -> list:
    """Heuristic: lấy 2-4 từ/cụm xuất hiện nhiều nhất, làm topic seeds."""
    text = " ".join(lines).lower()
    text = URL_RE.sub('', text)
    words = WORD_RE.findall(text)
    words = [w for w in words if w not in STOPWORDS and not w.isdigit()]
    counts = Counter(words)
    return [w for w, _ in counts.most_common(4)]

def auto_daily_summary(date: str, day_data: dict) -> dict:
    lines = day_data.get("lines", [])
    total = day_data.get("total_msgs", 0)
    participants = extract_participants(lines)
    topic_keywords = extract_topic_keywords(lines)

    # Auto-generated prose summary
    if total == 0:
        prose = "(không có message)"
    elif total <= 3:
        prose = f"{total} message ngắn từ {', '.join(participants[:2])}."
    else:
        kw = ', '.join(topic_keywords[:3]) if topic_keywords else 'nội dung không xác định'
        prose = (f"{total} messages từ {len(participants)} người (chủ yếu: "
                 f"{', '.join(participants[:3])}). Đề cập: {kw}.")
    return {
        "msg_count":           total,
        "active_participants": participants,
        "topics":              topic_keywords,
        "summary":             prose,
        "decisions":           [],
        "action_items":        [],
        "ai_curated":          False,
    }

def build_summary(space: dict) -> dict:
    """Space here is a per-space batch file (with compact_by_date)."""
    sid = space["space_id"]
    daily = {}
    curated = CURATED.get(sid, {})

    compact = space.get("compact_by_date", {})
    for date in sorted(compact.keys()):
        day_data = compact[date]   # {total_msgs, shown, lines}
        base = auto_daily_summary(date, day_data)
        if date in curated:
            base.update(curated[date])
            base["ai_curated"] = True
        daily[date] = base

    dates_sorted = sorted(daily.keys())
    return {
        "space_id":        sid,
        "display_name":    space.get("display_name"),
        "space_type":      space.get("space_type"),
        "drive_folder_id": space.get("drive_folder_id"),
        "covers_period":   {
            "from": dates_sorted[0] if dates_sorted else None,
            "to":   dates_sorted[-1] if dates_sorted else None,
        },
        "daily_summaries": daily,
    }

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    batch_files = sorted(BATCH_DIR.glob("*.json"))
    if not batch_files:
        print(f"! Không có file nào trong {BATCH_DIR}. Chạy lại digest_queue.py + script tạo batch.")
        return 1

    summaries = []
    for bf in batch_files:
        with open(bf, encoding="utf-8") as f:
            space = json.load(f)
        summaries.append(build_summary(space))

    curated_count = sum(
        1 for s in summaries
        for daily in s["daily_summaries"].values()
        if daily.get("ai_curated"))
    total_days = sum(len(s["daily_summaries"]) for s in summaries)

    payload = {
        "generated_at":   datetime.now(timezone.utc).isoformat(),
        "schema_version": 2,
        "generated_by":   "claude (build_ready.py)",
        "stats": {
            "total_spaces":    len(summaries),
            "total_days":      total_days,
            "curated_days":    curated_count,
            "auto_days":       total_days - curated_count,
        },
        "summaries": summaries,
    }

    READY_FILE.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {READY_FILE}")
    print(f"  {len(summaries)} spaces, {total_days} total days")
    print(f"  curated: {curated_count}, auto: {total_days - curated_count}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
