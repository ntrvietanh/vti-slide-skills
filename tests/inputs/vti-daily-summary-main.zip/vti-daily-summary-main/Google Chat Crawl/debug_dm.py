#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
debug_dm.py — In raw API responses cho 1 DM/Group để xem Chat API trả gì.

Usage:
    python debug_dm.py wg3_w8AAAAE         # full space_id từ folder name
"""
import json
import sys
from pathlib import Path

import os
os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

SCRIPT_DIR = Path(__file__).parent.resolve()
TOKEN_FILE = SCRIPT_DIR / "token.json"

SCOPES = [
    "https://www.googleapis.com/auth/chat.spaces.readonly",
    "https://www.googleapis.com/auth/chat.messages.readonly",
    "https://www.googleapis.com/auth/chat.memberships.readonly",
    "https://www.googleapis.com/auth/drive.file",
    "https://www.googleapis.com/auth/directory.readonly",
    "https://www.googleapis.com/auth/contacts.readonly",
]

def main():
    if len(sys.argv) < 2:
        print("Usage: python debug_dm.py <SPACE_ID>")
        sys.exit(1)
    sid = sys.argv[1]
    space_name = f"spaces/{sid}"

    creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)
    if not creds.valid and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    chat = build("chat", "v1", credentials=creds, cache_discovery=False)

    print(f"\n{'='*60}\n  GET space: {space_name}\n{'='*60}")
    try:
        space = chat.spaces().get(name=space_name).execute()
        print(json.dumps(space, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"ERROR: {e}")

    print(f"\n{'='*60}\n  LIST members: {space_name}\n{'='*60}")
    try:
        members = chat.spaces().members().list(
            parent=space_name, pageSize=50).execute()
        print(json.dumps(members, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"ERROR: {e}")

    print(f"\n{'='*60}\n  LIST messages (first 3): {space_name}\n{'='*60}")
    user_ids_seen = set()
    try:
        msgs = chat.spaces().messages().list(
            parent=space_name, pageSize=3).execute()
        for m in msgs.get("messages", []):
            sn = m.get("sender", {}).get("name")
            if sn:
                user_ids_seen.add(sn)
            if "text" in m and len(m.get("text","")) > 80:
                m["text"] = m["text"][:80] + "...[truncated]"
            if "formattedText" in m:
                m["formattedText"] = "(truncated)"
        print(json.dumps(msgs, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"ERROR: {e}")

    # Collect user IDs from members too
    try:
        members_resp = chat.spaces().members().list(
            parent=space_name, pageSize=50).execute()
        for mem in members_resp.get("memberships", []):
            un = mem.get("member", {}).get("name")
            if un:
                user_ids_seen.add(un)
    except Exception:
        pass

    print(f"\n{'='*60}\n  PEOPLE API resolve cho {len(user_ids_seen)} user(s)\n{'='*60}")
    people = build("people", "v1", credentials=creds, cache_discovery=False)
    for uid_full in sorted(user_ids_seen):
        uid = uid_full.split("/")[-1]
        print(f"\n  Resolving {uid_full}:")
        for source_label, source in [("DIRECTORY", "DIRECTORY_SOURCE_TYPE_DOMAIN_PROFILE"),
                                       ("CONTACTS",  "READ_SOURCE_TYPE_CONTACT"),
                                       ("DEFAULT",   None)]:
            try:
                kwargs = {
                    "resourceName": f"people/{uid}",
                    "personFields": "names,emailAddresses",
                }
                if source:
                    kwargs["sources"] = [source]
                person = people.people().get(**kwargs).execute()
                names = person.get("names", [])
                emails = person.get("emailAddresses", [])
                print(f"    [{source_label}] names={names}  emails={emails}")
            except Exception as e:
                print(f"    [{source_label}] ERROR: {e}")

if __name__ == "__main__":
    main()
