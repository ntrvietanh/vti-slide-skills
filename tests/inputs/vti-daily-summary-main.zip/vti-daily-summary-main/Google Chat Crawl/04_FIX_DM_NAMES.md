# Fix DM names — thêm People API scope

Chat API chỉ trả về user ID (`users/111683...`) không có `displayName`. Phải dùng People API để lookup. Cần thêm 2 OAuth scope mới.

## Bước 1 — Add scope ở GCP Console

1. Mở <https://console.cloud.google.com/apis/credentials/consent?project=vti-apac-manage>
2. Vào **OAuth consent screen** → **Scopes**
3. Click **Add or remove scopes**
4. Tìm + check 2 scope sau:
   - `https://www.googleapis.com/auth/directory.readonly`
   - `https://www.googleapis.com/auth/contacts.readonly`
5. Click **Update** → **Save**

## Bước 2 — Enable People API

1. Mở <https://console.cloud.google.com/apis/library/people.googleapis.com?project=vti-apac-manage>
2. Click **Enable**

## Bước 3 — Re-authorize OAuth (lấy token mới với scope mới)

```powershell
cd "C:\Users\Administrator\Documents\Claude\Projects\Google Chat Crawl"

# Xoá token cũ
del token.json

# Sinh URL OAuth mới
python crawl_gchat.py --auth-url
# → Mở URL trong browser (account anh.nguyentruongviet@vti.com.vn)
# → Approve TẤT CẢ scopes (Chat + Drive + Directory + Contacts)
# → Copy URL bị redirect (http://localhost/?code=...)

# Hoàn tất OAuth
python crawl_gchat.py --finish-auth "<paste URL đầy đủ>"
```

## Bước 4 — Test resolve qua People API

Chạy lại debug script trên 1 DM xem tên có ra không:

```powershell
python debug_dm.py wg3_w8AAAAE
```

Nếu vẫn không thấy displayName trong response → có thể user kia ngoài domain VTI hoặc đã deleted. Trường hợp đó tôi sẽ thêm fallback đẹp hơn (vd: dùng email từ contacts).

## Bước 5 — Re-bootstrap để rename folder

```powershell
python backfill_history.py
```

Bootstrap sẽ:
- Re-resolve display_name (giờ qua People API nếu Chat API thiếu info)
- Rename folder Drive về `[DM/Group]_<TênThật>_<ID>`

Sau đó verify Drive — DM/Group folders giờ phải có tên người thật.

## Note kỹ thuật

Code đã thêm:
- `resolve_user_name_via_people(user_resource)` — lookup `users/<id>` qua People API, cache để khỏi spam
- `_USER_NAME_CACHE` — in-memory cache trong session
- Integrate vào `resolve_display_name` (path members.list) + `_try_dm_name_from_messages` (path sender)

Trong scheduled task hourly, lần đầu sau khi re-authorize sẽ tốn vài giây hơn để People API lookup all unique users; sau đó cache hit là OK.
