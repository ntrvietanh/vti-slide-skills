#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bootstrap_stage.py — one-shot helper to seed _stage.json on Drive

Vì crawler dùng OAuth scope `drive.file` (per-file), nó KHÔNG thấy được file
_stage.json mà user upload thủ công qua Drive web UI. Script này dùng chính
credentials của crawler để CREATE _stage.json qua Drive API → file sẽ thuộc
về app và visible với các run kế tiếp.

Usage:
  python bootstrap_stage.py                            # default: 17:30 ICT hôm nay
  python bootstrap_stage.py --last-utc "2026-05-15T10:30:00+00:00"
  python bootstrap_stage.py --dry-run                  # in payload, không upload

Sau khi chạy:
  1. Vào Drive folder "Google Chat Crawl" — XOÁ file _stage.json upload thủ công cũ
     (file 404 bytes) để tránh duplicate.
  2. Chạy `python crawl_gchat.py` để confirm — log phải hiện
     "Incremental — last_crawl_utc = 2026-05-15T10:30:00+00:00"
     (KHÔNG còn "No _stage.json found").
"""

import argparse
import json
import sys
from datetime import datetime, timezone

from googleapiclient.discovery import build

from crawl_gchat import (
    DRIVE_ROOT_NAME,
    SCHEMA_VERSION,
    SELF_EMAIL,
    ensure_folder,
    load_credentials,
    load_stage,
    save_stage,
    log,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--last-utc",
        default="2026-05-15T10:30:00+00:00",
        help="Giá trị last_crawl_utc đặt vào stage. "
             "Default: 2026-05-15T10:30:00+00:00 (= 17:30 ICT hôm nay).",
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="In payload, không upload Drive.")
    parser.add_argument("--force", action="store_true",
                        help="Ghi đè nếu _stage.json (do app tạo) đã tồn tại.")
    args = parser.parse_args()

    # Validate timestamp
    try:
        last_dt = datetime.fromisoformat(args.last_utc.replace("Z", "+00:00"))
    except ValueError as e:
        print(f"! --last-utc invalid: {e}", file=sys.stderr)
        return 2

    now_iso = datetime.now(timezone.utc).isoformat()
    stage = {
        "schema_version":    SCHEMA_VERSION,
        "last_crawl_utc":    last_dt.isoformat(),
        "phase":             "steady",
        "crawl_count":       1,
        "user":              SELF_EMAIL,
        "bootstrap_done":    True,
        "full_history_done": False,
        "updated_at":        now_iso,
        "_note":             "Created by bootstrap_stage.py — synthetic baseline.",
    }

    print("Payload:")
    print(json.dumps(stage, indent=2, ensure_ascii=False))

    if args.dry_run:
        print("\n--dry-run → not uploading.")
        return 0

    log("Loading credentials...")
    creds = load_credentials()
    drive = build("drive", "v3", credentials=creds, cache_discovery=False)

    log(f"Resolving Drive folder '{DRIVE_ROOT_NAME}'...")
    root_id = ensure_folder(drive, DRIVE_ROOT_NAME)

    existing_stage, existing_id = load_stage(drive, root_id)
    if existing_stage is not None and not args.force:
        print(f"\n! _stage.json đã tồn tại trên Drive (id={existing_id}). "
              f"Dùng --force để ghi đè.")
        print("Current value:")
        print(json.dumps(existing_stage, indent=2, ensure_ascii=False))
        return 1

    new_id = save_stage(drive, root_id, stage, existing_id)
    print(f"\n✓ _stage.json uploaded — Drive file id = {new_id}")
    print("Bây giờ vào Drive web → xoá file _stage.json (404 bytes) "
          "bạn upload tay trước đó để tránh duplicate.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
