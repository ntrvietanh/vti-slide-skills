@echo off
REM Double-click file nay de cai dat Windows Scheduled Task
REM Tu dong xin quyen Administrator (UAC popup) va goi PowerShell script
setlocal
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Start-Process powershell -Verb RunAs -ArgumentList '-NoExit','-NoProfile','-ExecutionPolicy','Bypass','-File','%~dp0Setup_GChatCrawl_Task.ps1'"

exit /b 0
