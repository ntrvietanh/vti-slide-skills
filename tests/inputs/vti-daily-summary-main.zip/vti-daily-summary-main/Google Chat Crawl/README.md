# Google Chat Crawler

Tự động crawl tin nhắn Google Chat của `anh.nguyentruongviet@vti.com.vn` và lưu lên Google Drive theo từng ngày.

## File trong folder này

| File | Vai trò | Có nên backup/share? |
|---|---|---|
| `crawl_gchat.py` | Script chính | ✅ OK |
| `requirements.txt` | Dependencies Python | ✅ OK |
| `credentials.json` | OAuth client (secret) | ❌ KHÔNG share |
| `token.json` | Refresh token (rất nhạy cảm) | ❌ KHÔNG share |
| `state.json` | Theo dõi mốc crawl cuối cho mỗi space | ✅ OK |
| `crawl.log` | Log mỗi lần chạy | ✅ OK |

## Output trên Google Drive

```
Google Chat Crawl/
├── 2026-05-15/
│   ├── 10-00.json
│   ├── 11-00.json
│   └── ...
├── 2026-05-16/
│   └── ...
```

> **Lưu ý:** Vì dùng scope `drive.file`, app chỉ thấy được folder do chính nó tạo. **KHÔNG đổi tên hay di chuyển folder "Google Chat Crawl"** — không thì app sẽ tạo bản nhân đôi.

## Câu lệnh

```bash
# Lần đầu — sinh URL OAuth để mở trong browser
python crawl_gchat.py --auth-url

# Sau khi click Allow và copy URL bị redirect (sẽ là http://localhost/?code=...)
python crawl_gchat.py --finish-auth "<dán URL đầy đủ trong ngoặc kép>"

# Chạy bình thường (sẽ được scheduler gọi mỗi giờ)
python crawl_gchat.py

# Test không upload lên Drive — lưu JSON tại chỗ để inspect
python crawl_gchat.py --dry-run

# Crawl toàn bộ lịch sử (chạy thủ công, chỉ khi cần backfill)
python crawl_gchat.py --full-history
```

## Logic crawl

1. Load OAuth token từ `token.json` (refresh nếu hết hạn).
2. List tất cả Spaces (DM, Group DM, Space) mà user là thành viên.
3. Với mỗi space:
   - Lấy `last_crawl` từ `state.json` cho space đó.
   - Nếu chưa có (lần đầu) → since = NOW (chỉ tin mới từ giờ trở đi, đúng yêu cầu).
   - Gọi `messages.list` với `filter='createTime > "<since>"'`.
4. Gộp tất cả vào 1 JSON, upload lên `Google Chat Crawl/YYYY-MM-DD/HH-MM.json`.
5. Cập nhật `state.json`.

## Troubleshooting

**"Stored credentials are not refreshable"**
→ Token bị revoke. Chạy lại `--auth-url` rồi `--finish-auth`.

**"403 PERMISSION_DENIED" khi list spaces**
→ Scope chưa đủ. Vào OAuth consent screen của project `vti-apac-manage` add lại 4 scope, rồi re-auth.

**"Quota exceeded"**
→ Google Chat API có quota 600 read req/phút/user. Nhiều space + crawl `--full-history` có thể chạm quota. Script sẽ log lỗi và bỏ qua space đó.

**Không thấy file mới trên Drive**
→ Check `crawl.log`. Có thể app tạo folder mới do bạn đã đổi tên folder cũ.

## Bảo mật

- `credentials.json` + `token.json` cho phép đọc **toàn bộ chat** + ghi Drive. **KHÔNG**:
  - Commit lên Git/GitHub.
  - Lưu vào OneDrive/Google Drive sync folder.
  - Share qua chat/email.
- Muốn revoke: <https://myaccount.google.com/permissions> (đăng nhập tài khoản VTI).
- Muốn xoá hết: vào GCP Console → APIs & Services → Credentials → xoá OAuth client.
