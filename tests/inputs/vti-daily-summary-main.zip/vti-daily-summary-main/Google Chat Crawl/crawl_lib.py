#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
crawl_lib.py — Shared helpers for the 3-phase incremental crawler.

This module re-exports needed symbols from crawl_gchat.py and applies two
runtime patches to avoid known issues:

  1. People-API short-circuit (PARTIAL — see note below)
     `detect_self_via_people` is forced to return None because it targets
     `people/me`, which requires the `profile` scope the token does NOT
     have. `resolve_user_name_via_people` is left intact — it targets
     `people/<gaia_id>` and only needs `contacts.readonly` (which the
     token has). The per-user call is cached in-memory and 403/404s are
     swallowed in crawl_gchat.py.

  2. WORKERS reduced 15 -> 4
     Keeps OpenSSL thread pressure low enough to avoid an observed
     `free(): corrupted unsorted chunks` crash under heavy concurrent
     SSL load. Phase2 runs single-threaded anyway, so this is defensive.

Usage:
    import crawl_lib as lib
    creds = lib.load_credentials()
    drive = lib.get_drive(creds)
    chat  = lib.get_chat(creds)
    ...
"""
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent.resolve()
sys.path.insert(0, str(SCRIPT_DIR))

# Import the original crawler module (acts as our function library)
import crawl_gchat as _cg

from googleapiclient.discovery import build as _build

# --- Patches: People-API short-circuit + reduced concurrency ---------------
# NOTE (2026-05-16): re-enabled resolve_user_name_via_people. Direct test
# confirmed `people.people().get(resourceName="people/<gaia_id>")` works
# with current scopes (contacts.readonly). detect_self_via_people stays
# patched out because `people/me` needs the missing `profile` scope.
_cg.detect_self_via_people       = lambda: None
_cg.WORKERS                      = 4

# --- Re-exports ------------------------------------------------------------
log                            = _cg.log
load_credentials               = _cg.load_credentials
build_flow                     = _cg.build_flow
print_auth_url                 = _cg.print_auth_url
finish_auth                    = _cg.finish_auth

# Drive helpers
ensure_folder                  = _cg.ensure_folder
find_folder                    = _cg.find_folder
find_file                      = _cg.find_file
download_json                  = _cg.download_json
download_text                  = _cg.download_text
upload_text                    = _cg.upload_text
upload_json_file               = _cg.upload_json_file
list_folder_files              = _cg.list_folder_files

# State helpers
load_stage                     = _cg.load_stage
save_stage                     = _cg.save_stage
load_index                     = _cg.load_index
save_index                     = _cg.save_index

# Members cache
load_members_cache             = _cg.load_members_cache
should_refresh_members         = _cg.should_refresh_members
hydrate_caches_from_disk       = _cg.hydrate_caches_from_disk
serialize_caches_to_disk       = _cg.serialize_caches_to_disk

# Spaces & messages
list_spaces                    = _cg.list_spaces
list_messages                  = _cg.list_messages
normalize_message              = _cg.normalize_message
group_by_date                  = _cg.group_by_date
merge_and_upload_daily         = _cg.merge_and_upload_daily
_load_recent_msgs_for_queue    = _cg._load_recent_msgs_for_queue

# Display-name resolution (uses Chat API + People API + on-disk cache)
resolve_display_name           = _cg.resolve_display_name
get_dm_display_name            = _cg.get_dm_display_name
canonical_folder_name          = _cg.canonical_folder_name
ensure_space_folder_canonical  = _cg.ensure_space_folder_canonical
build_index_entry              = _cg.build_index_entry

# Constants
SCHEMA_VERSION                 = _cg.SCHEMA_VERSION
SELF_EMAIL                     = _cg.SELF_EMAIL
DRIVE_ROOT_NAME                = _cg.DRIVE_ROOT_NAME
DRIVE_SPACES_NAME              = _cg.DRIVE_SPACES_NAME
STAGE_FILENAME                 = _cg.STAGE_FILENAME
INDEX_FILENAME                 = _cg.INDEX_FILENAME
STATE_FILE                     = _cg.STATE_FILE
SUMMARY_DAYS                   = _cg.SUMMARY_DAYS
QUEUE_RECENT_MSGS_PER_SPACE    = _cg.QUEUE_RECENT_MSGS_PER_SPACE
MIN_MSGS_FOR_SUMMARY           = _cg.MIN_MSGS_FOR_SUMMARY
ACTIVE_FILTER_PADDING_HOURS    = _cg.ACTIVE_FILTER_PADDING_HOURS
LOCAL_TZ                       = _cg.LOCAL_TZ

# Mutable shared state (lists/dicts share references with _cg)
_USER_NAME_CACHE               = _cg._USER_NAME_CACHE
_SPACE_DISPLAY_CACHE           = _cg._SPACE_DISPLAY_CACHE
_SELF_USER_NAME                = _cg._SELF_USER_NAME
_PEOPLE_CLIENT                 = _cg._PEOPLE_CLIENT
_FORCE_MEMBER_REFRESH          = _cg._FORCE_MEMBER_REFRESH


# --- Client builders (used by phase1/2/3) ----------------------------------
def get_drive(creds):
    """Build a Drive v3 client. Cheap; OK to call once per phase script."""
    return _build("drive", "v3", credentials=creds, cache_discovery=False)


def _detect_self_via_directory_search():
    """Resolve self gaia ID via People API searchDirectoryPeople using the
    known SELF_EMAIL. Replaces detect_self_via_people (which needs the
    `profile` scope we don't have). Sets `_cg._SELF_USER_NAME[0]` so that
    `_is_self_member` can filter self out of DM/group display names."""
    if _cg._SELF_USER_NAME[0]:
        return
    people = _cg._PEOPLE_CLIENT[0]
    if not people:
        return
    try:
        # Search by the local-part of SELF_EMAIL; matches against name + email
        local = (_cg.SELF_EMAIL or "").split("@", 1)[0]
        if not local:
            return
        resp = people.people().searchDirectoryPeople(
            query=local,
            readMask="names,emailAddresses,metadata",
            sources=["DIRECTORY_SOURCE_TYPE_DOMAIN_PROFILE"],
            pageSize=10).execute()
        target = (_cg.SELF_EMAIL or "").lower()
        for person in resp.get("people", []):
            emails = [(e.get("value") or "").lower()
                      for e in (person.get("emailAddresses") or [])]
            if target not in emails:
                continue
            srcs = (person.get("metadata", {}).get("sources") or [])
            gaia = next((s.get("id") for s in srcs
                         if s.get("type") == "DOMAIN_PROFILE"), None)
            if gaia:
                _cg._SELF_USER_NAME[0] = "users/%s" % gaia
                names = person.get("names") or []
                if names:
                    _cg._USER_NAME_CACHE[_cg._SELF_USER_NAME[0]] = \
                        names[0].get("displayName")
                log("  Self resolved via directory search: %s = %s"
                    % (_cg._SELF_USER_NAME[0],
                       _cg._USER_NAME_CACHE.get(_cg._SELF_USER_NAME[0])))
                return
    except Exception as e:
        log("  ! _detect_self_via_directory_search: %s" % e)


def get_chat(creds):
    """Build a Chat v1 client + prime the People API singleton so the
    Chat-API->People-API fallback works the moment a DM display-name is
    missing. Also resolves self via directory search so DM names exclude
    the current user instead of showing `Self & Other`."""
    chat = _build("chat", "v1", credentials=creds, cache_discovery=False)
    if _cg._PEOPLE_CLIENT[0] is None:
        try:
            _cg._PEOPLE_CLIENT[0] = _build(
                "people", "v1", credentials=creds, cache_discovery=False)
        except Exception as e:
            log("  ! get_chat: failed to build People client: %s" % e)
    _detect_self_via_directory_search()
    return chat


def get_people(creds):
    """Build a People v1 client (also caches into the crawl_gchat singleton)."""
    if _cg._PEOPLE_CLIENT[0] is None:
        _cg._PEOPLE_CLIENT[0] = _build(
            "people", "v1", credentials=creds, cache_discovery=False)
    return _cg._PEOPLE_CLIENT[0]
