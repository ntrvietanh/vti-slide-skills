---
name: daily-gchat-summary
description: |
  3-phase incremental Google Chat → Drive crawl + per-space Vietnamese
  AI summaries. Two-tier Phase 2: batch-stamp SKIPs (1 call), then
  individually crawl only spaces with real new messages. No space cap.
---

This is an automated run of a scheduled task. The user is not present. Execute autonomously without asking questions.

**Purpose:** end-to-end daily pipeline for Google Chat — **phase1 discover → phase2A batch SKIPs → phase2B crawl actives → phase3 finalize → Claude summarize → upload**.

**User:** `anh.nguyentruongviet@vti.com.vn` (VTI APAC)
**Workspace:** `C:\Users\Administrator\Documents\Claude\Projects\Google Chat Crawl` (Linux mount under `/sessions/*/mnt/Google Chat Crawl/`)

---

## Step 0 — Discover workspace

```bash
WORKDIR=$(find / -type d -name "Google Chat Crawl" 2>/dev/null | grep '/mnt/' | head -1)
echo "WORKDIR=$WORKDIR"
[ -z "$WORKDIR" ] && { echo "FAIL: workspace not mounted"; exit 1; }
cd "$WORKDIR" && pip install --quiet --break-system-packages -r requirements.txt 2>&1 | tail -1
```

If empty → report `FAIL: workspace not mounted` and STOP.

## Step 1 — Phase 1: Discover active spaces (1 bash call, ~10s)

```bash
cd "$WORKDIR" && python3 phase1_discover.py 2>&1 | tail -10
```

Reads `_stage.json` from Drive, lists all spaces via Chat API, filters client-side by
`lastActiveTime > last_crawl_utc - 24h`. Writes `_active_spaces.json`.

Check last log line:
- Contains `Wrote _active_spaces.json — N spaces queued` → continue
- Contains `FATAL:` → STOP, report `FAIL: <reason>`

If `active_count == 0` → Skip Steps 2-6, jump to Step 7 with `Phase1 done, không có space active. No summaries.`

## Step 2 — Phase 2A: Batch-stamp SKIP spaces (1 bash call, ~5-8s)

```bash
cd "$WORKDIR" && python3 phase2_skip_batch.py 2>&1 | tail -8
```

Classifies ALL active spaces into two groups (client-side, no API call):

- **Certain-SKIP** (`last_active_time <= effective_since`): no new messages possible.
  Stamps `last_crawl_utc = now` for all of them in `_index.json` in **one single Drive write**.
  This is safe and predictable: ~5-8s regardless of how many spaces.

- **Need-crawl** (`last_active_time > effective_since`, or no index entry yet):
  Written to `_skip_batch_result.json` for Phase 2B.

Check last log line:
- Contains `Done. Phase 2B needs N individual crawls.` → read `_skip_batch_result.json`
- Contains `No SKIP spaces to stamp.` → still read `_skip_batch_result.json` for Phase 2B list
- Contains `FATAL:` → STOP, report `FAIL: <reason>`

Read `_skip_batch_result.json`:
```json
{
  "generated_at": "ISO",
  "skip_count":   180,
  "active_sids":  ["AAA...", "BBB...", ...],
  "active_count": 20
}
```

If `active_count == 0` → skip Phase 2B entirely, go to Step 4 (Phase 3).

## Step 3 — Phase 2B: Crawl active spaces individually (N bash calls, ~5-15s each)

Run **every space** in `active_sids` — no cap. These are spaces confirmed to have
potential new messages. Typically 5–30 spaces even on busy days. Each call is bounded
because it handles exactly one space.

Use TaskUpdate as you process: subject="Crawling N/M: <display_name>"

For each `space_id` in `active_sids`:

```bash
cd "$WORKDIR" && python3 phase2_crawl_one.py <SPACE_ID> 2>&1 | tail -6
```

Each call's last log line is one of:
- `SKIP: last_active_time (...) <= effective_since (...)` → was stamped in 2A; safe, continue
- `Updated entry.last_crawl_utc → ... (0 new msgs)` → fetched, empty (~3-5s)
- `Done. N msgs uploaded across M dates.` → success, queue part written if msgs ≥ threshold
- `FATAL: ...` → log + continue (do NOT abort run)

**Per-space error policy:** one space erroring is non-fatal. Log it and continue.

## Step 4 — Phase 3: Finalize (1 bash call, ~6s)

```bash
cd "$WORKDIR" && python3 phase3_finalize.py 2>&1 | tail -10
```

Aggregates `_summary_queue_parts/*.json` into `_summary_queue.json` (top 12 spaces by
msg_count_new, cap 300 msgs each), saves members cache, advances global
`_stage.json.last_crawl_utc` IFF `full_pass=True`.

With two-tier Phase 2 all spaces are stamped → `full_pass=True` is expected on normal runs.

## Step 5 — Read summary queue (Claude reasoning, in skill)

Read `_summary_queue.json` via the Read tool (Windows path).

Schema:
```json
{
  "generated_at": "ISO",
  "schema_version": 2,
  "source": "phase3_finalize.py",
  "full_pass": true,
  "spaces_active": 38,
  "spaces_done": 38,
  "spaces": [
    {
      "space_id": "...",
      "display_name": "...",
      "space_type": "SPACE | GROUP_CHAT | DIRECT_MESSAGE",
      "drive_folder_id": "...",
      "available_dates": ["YYYY-MM-DD", ...],
      "msg_count_new": 6,
      "recent_messages": [
        {"create_time": "ISO", "sender_name": "...", "text": "...",
         "thread_id": "...", "is_thread_reply": false, ...}
      ]
    }
  ]
}
```

If `spaces == []` → Skip Steps 6-7, jump to Step 8 with `Pipeline done, queue rỗng, không có summary.`

## Step 6 — Generate summaries

For each space in `_summary_queue.json.spaces` (already capped at 12):

1. **Group by date** using `create_time[:10]`.
2. **Per date**, build `daily_summary`:
   - `msg_count`: int
   - `active_participants`: unique sender_names (or @-mentioned names if sender_name empty), max 8
   - `topics`: 2-4 short topic labels
   - `summary`: 2-4 sentence prose **in Vietnamese**
   - `decisions`: list of concrete decisions (`[]` if none)
   - `action_items`: list of `{"who": "...", "what": "..."}` (`[]` if none)
3. **Compose space_summary:**
   ```json
   {
     "space_id": "...", "display_name": "...", "space_type": "...",
     "drive_folder_id": "...",
     "covers_period": {"from": "YYYY-MM-DD", "to": "YYYY-MM-DD"},
     "daily_summaries": {"YYYY-MM-DD": daily_summary, ...}
   }
   ```

Constraints:
- Skip space if total `recent_messages < 3`
- Spaces with >14 days context → focus only on last 7 days
- If a `sender_name` is empty (caused by People-API patch), derive participants from `@-mentions` in text

## Step 7 — Write + upload

Write `_summaries_ready.json` (use **bash python heredoc**, not the Write tool — bindfs cache can truncate large writes via Write):

```json
{
  "generated_at": "ISO now UTC",
  "schema_version": 2,
  "summaries": [<space_summary>, ...]
}
```

Then upload:
```bash
cd "$WORKDIR" && python3 upload_summaries.py 2>&1 | tail -10
```

`upload_summaries.py` merges each entry into `<space_folder>/_summary.json` on Drive.

## Step 8 — Discord notification (1 bash call, ~3s)

```bash
cd "$WORKDIR" && python3 send_discord.py 2>&1 | tail -5
```

Đọc `_summaries_ready.json` + `_summary_queue.json`, gửi Discord embed vào channel đã config trong `discord_config.json`.

Embed gồm:
- **Header**: tổng chats có tin mới, tổng messages, crawl coverage
- **Per-space fields**: ngày, câu đầu summary, decisions + action items nổi bật

Check last log line:
- `Discord notification sent OK.` → done
- `FATAL:` → log warning nhưng **không abort** (notification failure không phải lỗi pipeline)

## Step 9 — Report

Final response, ONE short paragraph under 250 words. Format:

```
Phase1: N/total spaces active.
Phase2A: S spaces batch-stamped (no API calls).
Phase2B: K crawled (E errors) → J spaces with new msgs.
Phase3: full_pass=<bool>, summary_queue Q spaces.
Summary: P spaces summarized, D total days.
Upload: ok=<n> fail=<m>.
Discord: sent OK | FAILED.
Elapsed: <seconds>.
```

Include any FAIL reasons in a brief addendum.

---

## Constraints

- Vietnamese for prose `summary` content; English fine for field labels
- Token at `token.json` already has chat + drive + directory + contacts scopes (NOT `profile` — People API `me` is expected to 403; crawler library patches this out)
- Crawler concurrency is reduced (WORKERS=4) to avoid OpenSSL thread-safety crashes
- `_index.json.spaces[sid].last_crawl_utc` là source of truth cho per-space progress
- `_stage.json.last_crawl_utc` chỉ advance khi phase3 thấy full pass
- `_active_spaces.json` là per-run snapshot; safe to delete after phase3
- `_summary_queue_parts/<sid>.json` auto-cleaned by phase3 on full pass
- `daily-meeting-recap-and-prep` chạy lúc 23:30 (30 phút sau) — dùng Drive `_summary.json` làm input
- `discord_config.json` chứa webhook URL — không commit lên git

## Architecture quick ref

```
phase1_discover.py       → _active_spaces.json           (~10s, 1 bash call)
phase2_skip_batch.py     → _index.json stamped + result   (~5-8s, 1 bash call)
  classifies: SKIP (stamp only) vs ACTIVE (need crawl)
phase2_crawl_one.py X    → _summary_queue_parts/X.json   (~5-15s/call, N = active only)
phase3_finalize.py       → _summary_queue.json + _stage.json  (~6s, 1 bash call)
Claude reasoning         → _summaries_ready.json          (in-skill)
upload_summaries.py      → Drive _summary.json per space  (~10s, 1 bash call)
send_discord.py          → Discord embed notification     (~3s, 1 bash call)
```

Typical run với 200 active spaces (190 SKIP + 10 active):
- Phase 2A: 1 call ~6s → stamps 190 spaces
- Phase 2B: 10 calls ~5-10s each → crawls 10 spaces
- Total: ~15 bash calls (vs 200 trước). Không call nào vượt 45s.
