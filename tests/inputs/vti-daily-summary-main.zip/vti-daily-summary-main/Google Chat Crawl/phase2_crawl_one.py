#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
phase2_crawl_one.py — Phase 2 of the 3-phase pipeline.

Job: crawl ONE specific space identified by its space_id. Uses per-space
last_crawl_utc from Drive _index.json to determine the incremental fetch
window. Does not touch global _stage.json (phase3 owns that).

Inputs (read):
  - _active_spaces.json  (local, written by phase1)
  - _index.json on Drive

Outputs (written):
  - Drive: new/updated daily JSONL + updated _index.json entry
  - Local: _summary_queue_parts/<space_id>.json (if window msgs >= MIN)

Budget: ~5-10s per space. Skip-early ~3s.

Exit codes:
  0 success | 1 fatal | 2 usage
"""
import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

import crawl_lib as lib


SCRIPT_DIR         = Path(__file__).parent.resolve()
ACTIVE_SPACES_FILE = SCRIPT_DIR / "_active_spaces.json"
QUEUE_PARTS_DIR    = SCRIPT_DIR / "_summary_queue_parts"


def _parse_iso(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _is_fallback_name(name: str) -> bool:
    """Return True for placeholder display names like '(private DM xxxx)'
    or '(unnamed group xxxx)'. These indicate the DM/Group never resolved
    a real participant name and the folder/index entry should be re-tried."""
    if not name:
        return True
    return (name.startswith("(private DM ")
            or name.startswith("(unnamed group ")
            or name.startswith("(direct_message ")
            or name.startswith("(group_chat "))


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: phase2_crawl_one.py <space_id>", file=sys.stderr)
        return 2

    sid = sys.argv[1].strip()
    if not sid:
        print("Usage: phase2_crawl_one.py <space_id>", file=sys.stderr)
        return 2

    if not ACTIVE_SPACES_FILE.exists():
        lib.log(f"FATAL: {ACTIVE_SPACES_FILE.name} missing - run phase1 first")
        return 1

    cfg     = json.loads(ACTIVE_SPACES_FILE.read_text(encoding="utf-8"))
    entries = {e["space_id"]: e for e in cfg.get("active_spaces", [])}
    if sid not in entries:
        lib.log(f"FATAL: space_id={sid} not in _active_spaces.json")
        return 1
    meta = entries[sid]

    lib.log("=" * 60)
    lib.log(f"phase2_crawl_one.py - sid={sid} - "
            f"{(meta.get('display_name') or sid)[:60]}")

    # Early skip: if last_active_time older than effective_since, nothing new.
    # effective_since = per-space last_crawl_utc (if any) OR global_since.
    lat = _parse_iso(meta.get("last_active_time"))
    lcu = _parse_iso(meta.get("last_crawl_utc"))
    gsince = _parse_iso(cfg.get("global_since"))
    effective_since = lcu or gsince
    if lat and effective_since and lat <= effective_since:
        lib.log(f"  SKIP: last_active_time ({lat.isoformat()}) "
                f"<= effective_since ({effective_since.isoformat()})")
        return 0

    # Build clients
    creds = lib.load_credentials()
    drive = lib.get_drive(creds)
    chat  = lib.get_chat(creds)

    root_id    = lib.ensure_folder(drive, lib.DRIVE_ROOT_NAME)
    spaces_dir = lib.ensure_folder(drive, lib.DRIVE_SPACES_NAME, root_id)

    # Hydrate display-name cache
    members_cache = lib.load_members_cache()
    lib.hydrate_caches_from_disk(members_cache)

    # Load index, find or init entry
    index, index_id = lib.load_index(drive, root_id)
    index_spaces    = index.setdefault("spaces", {})

    if sid not in index_spaces:
        space_resource = {
            "name":           meta["space_resource_name"],
            "spaceType":      meta.get("space_type", "UNKNOWN"),
            "lastActiveTime": meta.get("last_active_time"),
        }
        try:
            index_spaces[sid] = lib.build_index_entry(chat, space_resource)
        except Exception as e:
            lib.log(f"  ! build_index_entry failed: {e} - using minimal entry")
            index_spaces[sid] = {
                "space_id":               sid,
                "space_resource_name":    meta["space_resource_name"],
                "display_name":           meta.get("display_name") or sid,
                "space_type":             meta.get("space_type") or "UNKNOWN",
                "drive_folder_id":        None,
                "drive_folder_name":      None,
                "last_crawl_utc":         None,
                "last_active_time":       meta.get("last_active_time"),
                "total_messages_crawled": 0,
                "available_dates":        [],
            }

    entry = index_spaces[sid]
    entry["last_active_time"] = (meta.get("last_active_time")
                                  or entry.get("last_active_time"))
    entry["space_type"]       = (meta.get("space_type")
                                  or entry.get("space_type") or "UNKNOWN")
    if meta.get("display_name") and not entry.get("display_name"):
        entry["display_name"] = meta["display_name"]

    # Opportunistic re-resolution: if the cached display_name is a fallback
    # placeholder, try People-API again now that the patch is removed.
    if _is_fallback_name(entry.get("display_name", "")):
        try:
            space_resource = {
                "name":        meta["space_resource_name"],
                "spaceType":   entry["space_type"],
                "displayName": meta.get("display_name") or "",
            }
            fresh = lib.resolve_display_name(chat, space_resource)
            if fresh and not _is_fallback_name(fresh):
                lib.log(f"  Re-resolved display name: "
                        f"'{entry['display_name']}' -> '{fresh}'")
                entry["display_name"] = fresh
        except Exception as e:
            lib.log(f"  ! re-resolve display name failed: {e}")

    # Determine per-space since (use entry's lcu if any, else global_since)
    entry_since = _parse_iso(entry.get("last_crawl_utc"))
    since = entry_since or gsince
    if since is None:
        since = datetime.now(timezone.utc) - timedelta(hours=24)
    lib.log(f"  since: {since.isoformat()}")

    now_utc    = datetime.now(timezone.utc)
    crawled_at = now_utc.isoformat()

    # Fetch messages
    try:
        raw_msgs = lib.list_messages(
            chat, meta["space_resource_name"], since, rate_sleep=0.05)
    except Exception as e:
        lib.log(f"FATAL: list_messages failed: {e}")
        return 1
    lib.log(f"  Fetched {len(raw_msgs)} new messages")

    # No new messages -> still mark space as crawled this round
    if not raw_msgs:
        entry["last_crawl_utc"] = crawled_at
        index_spaces[sid] = entry
        try:
            lib.save_index(drive, root_id, index, index_id)
            lib.log(f"  Updated entry.last_crawl_utc -> {crawled_at} (0 new msgs)")
        except Exception as e:
            lib.log(f"  ! save_index failed: {e}")
        return 0

    # Normalize
    normalized = [
        lib.normalize_message(m, sid, entry["display_name"],
                              entry["space_type"], crawled_at)
        for m in raw_msgs
    ]

    # Ensure Drive folder + upload daily JSONL
    try:
        entry["drive_folder_id"] = lib.ensure_space_folder_canonical(
            drive, sid, entry["space_type"], entry["display_name"],
            spaces_dir, entry.get("drive_folder_id"))
    except Exception as e:
        lib.log(f"FATAL: ensure_space_folder_canonical failed: {e}")
        return 1

    entry["drive_folder_name"] = lib.canonical_folder_name(
        entry["space_type"], entry["display_name"], sid)
    folder_id = entry["drive_folder_id"]

    existing_files = lib.list_folder_files(drive, folder_id)
    by_date        = lib.group_by_date(normalized)
    dates_touched  = []
    for date_str, day_msgs in sorted(by_date.items()):
        try:
            lib.merge_and_upload_daily(
                drive, folder_id, date_str, day_msgs, existing_files)
            dates_touched.append(date_str)
        except Exception as e:
            lib.log(f"  ! merge_and_upload_daily({date_str}) failed: {e}")
            continue
        avail = entry.setdefault("available_dates", [])
        if date_str not in avail:
            avail.append(date_str)

    # Update entry + save index
    entry["last_crawl_utc"]         = crawled_at
    entry["total_messages_crawled"] = (
        entry.get("total_messages_crawled", 0) + len(normalized))
    index_spaces[sid] = entry
    try:
        lib.save_index(drive, root_id, index, index_id)
    except Exception as e:
        lib.log(f"  ! save_index failed: {e}")

    # Write per-space queue part for phase3.
    #
    # Gate policy (2026-05-16): require at least 1 new msg THIS run (so we
    # don't re-summarize idle spaces), but accumulate older msgs from the
    # past SUMMARY_DAYS days when checking MIN_MSGS_FOR_SUMMARY. A DM that
    # gets 1 msg/day still produces a summary once its rolling window
    # reaches the threshold, instead of being silently dropped.
    if len(normalized) >= 1:
        cutoff_for_queue = now_utc - timedelta(days=lib.SUMMARY_DAYS)
        # Refresh existing_files to include the file we just uploaded
        existing_files = lib.list_folder_files(drive, folder_id)
        try:
            recent = lib._load_recent_msgs_for_queue(
                drive, folder_id, existing_files,
                cutoff_for_queue, lib.QUEUE_RECENT_MSGS_PER_SPACE)
        except Exception as e:
            lib.log(f"  ! _load_recent_msgs_for_queue failed: {e}")
            recent = normalized

        if len(recent) >= lib.MIN_MSGS_FOR_SUMMARY:
            QUEUE_PARTS_DIR.mkdir(exist_ok=True)
            part = {
                "space_id":         sid,
                "display_name":     entry["display_name"],
                "space_type":       entry["space_type"],
                "drive_folder_id":  folder_id,
                "available_dates":  sorted(entry.get("available_dates", [])),
                "msg_count_new":    len(normalized),
                "msg_count_window": len(recent),
                "recent_messages":  recent,
            }
            part_file = QUEUE_PARTS_DIR / f"{sid}.json"
            part_file.write_text(
                json.dumps(part, indent=2, ensure_ascii=False),
                encoding="utf-8")
            prior = len(recent) - len(normalized)
            lib.log(f"  Wrote queue part {part_file.name} "
                    f"({len(normalized)} new + {prior} prior "
                    f"= {len(recent)} window msgs)")
        else:
            lib.log(f"  Below threshold: {len(recent)} window msgs "
                    f"< MIN_MSGS_FOR_SUMMARY={lib.MIN_MSGS_FOR_SUMMARY} "
                    f"-- will accumulate next run")

    # Optional incremental cache flush
    try:
        lib.serialize_caches_to_disk(force_refresh_happened=False, now_utc=now_utc)
    except Exception:
        pass

    lib.log(f"  Done. {len(normalized)} msgs uploaded across "
            f"{len(dates_touched)} dates.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
