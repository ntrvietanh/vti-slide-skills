# Google Chat Data — Folder Structure & Agent Query Guide

Tài liệu này dành cho **agent khác** (Claude session khác, automation script, hoặc human dev) cần tra cứu dữ liệu Google Chat đã crawl. Đọc trước khi query.

## Bối cảnh

User `anh.nguyentruongviet@vti.com.vn` (VTI APAC) có pipeline daily crawl Google Chat → Drive. Mỗi space (DM/Group/Space) được lưu thành 1 folder riêng trên Drive, với data messages dạng JSONL theo ngày + AI summary daily.

## Folder structure trên Drive

```
My Drive/
└── Google Chat Crawl/                              ← root, do app drive.file scope tạo
    ├── _stage.json                                 ← global state (last_crawl_utc)
    ├── _index.json                                 ← CATALOG — entry point cho agent
    └── spaces/
        ├── DM_HUY Nguyen Le Quang (VTI.D9)_wg3_w8AAAAE/
        │   ├── 2026-05-01.jsonl                    ← raw messages theo ngày
        │   ├── 2026-05-02.jsonl
        │   ├── 2026-05-15.jsonl
        │   └── _summary.json                       ← AI daily summaries
        ├── Group_KT-BOA-VAP Review Revenue VAP_AAQAB8gxEIo/
        │   ├── ...
        │   └── _summary.json
        ├── Space_VTI.VAP_AAAAukFeUNA/
        │   ├── ...
        │   └── _summary.json
        ├── DM_[Bot] Google Drive_urPHFcAAAAE/
        │   └── ...
        └── ... (1 folder/space)
```

## Naming convention

Folder name canonical: `<Type>_<DisplayName>_<SpaceID>`

| Prefix | Loại |
|---|---|
| `DM_` | DIRECT_MESSAGE (1-1) |
| `Group_` | GROUP_CHAT (multi-user không có title chính thức) |
| `Space_` | SPACE (có title) |
| `Chat_` | Unknown type |

Đặc biệt:
- DM với bot → `DM_[Bot] <BotName>_<ID>` (vd `DM_[Bot] Google Drive_urPHFcAAAAE`)
- DM với external user (ngoài VTI) → fallback `DM_(private DM <prefix>)_<ID>`
- Group không title → ghép tên member: `Group_TênA, TênB, TênC_<ID>`

**Source of truth là SpaceID (phần cuối folder name).** DisplayName có thể đổi (user rename chat) → folder cũng được auto-rename, nhưng SpaceID không bao giờ đổi.

## Files trong mỗi space folder

### 1. `YYYY-MM-DD.jsonl` — raw messages

1 file/ngày, format JSON Lines (mỗi dòng 1 message). Schema 1 msg:

```json
{
  "msg_id":           "RokDlpXdXCI.RokDlpXdXCI",
  "space_id":         "wg3_w8AAAAE",
  "space_name":       "<display name lúc crawl>",
  "space_type":       "DIRECT_MESSAGE",
  "thread_id":        "RokDlpXdXCI",
  "is_thread_reply":  false,
  "create_time":      "2026-05-15T03:51:10.838140Z",
  "sender_name":      "HUY Nguyen Le Quang (VTI.D9)",
  "sender_email":     "huy.nguyenlequang@vti.com.vn",
  "text":             "alo thầy ơi",
  "has_attachment":   false,
  "attachment_names": [],
  "reactions":        [{"emoji": "👍", "count": 2}],
  "crawled_at":       "2026-05-15T23:02:11Z"
}
```

**Note**:
- `sender_name` / `sender_email`: có thể rỗng nếu Chat API không trả về (đặc biệt msg cũ) — fallback dùng `users/<id>` qua People API resolution
- `text`: plain text (đã strip formatting)
- `is_thread_reply = false` nghĩa là msg root của thread; `true` nghĩa là reply trong thread (`thread_id` cùng giá trị nhưng `msg_id` khác)
- File được dedupe theo `msg_id` — chạy crawl nhiều lần không tạo dupe

### 2. `_summary.json` — AI daily summary

1 file/space, được generate daily bởi Cowork scheduled task.

```json
{
  "schema_version":  2,
  "space_id":        "wg3_w8AAAAE",
  "display_name":    "HUY Nguyen Le Quang (VTI.D9)",
  "space_type":      "DIRECT_MESSAGE",
  "generated_at":    "2026-05-15T23:05:12Z",
  "generated_by":    "claude",
  "covers_period":   {"from": "2026-05-01", "to": "2026-05-15"},
  "total_days":      9,
  "daily_summaries": {
    "2026-05-15": {
      "msg_count":           23,
      "active_participants": ["HUY Nguyen Le Quang (VTI.D9)", "Michael Nguyen (VTI.APAC)"],
      "topics":              ["Migration plan", "Sprint 5 deliverables"],
      "summary":             "Trao đổi về timeline migration, HUY đề xuất shift cutover sang thứ Sáu tuần sau do QA delay. Quyết định test staging trước.",
      "decisions":           ["Cutover dời sang thứ Sáu tuần sau"],
      "action_items":        [{"who": "HUY", "what": "Setup staging environment"}]
    },
    "2026-05-08": { ... }
  }
}
```

Note: `daily_summaries` chỉ có key cho NGÀY có message. Nếu space im 1 tuần, không có entry cho 7 ngày đó.

## Index file — `_index.json` (root level)

Entry point để agent navigate. Schema:

```json
{
  "schema_version":   2,
  "user":             "anh.nguyentruongviet@vti.com.vn",
  "updated_at":       "2026-05-15T23:02:11Z",
  "spaces_folder_id": "1xxxxxxxxxxxx",
  "spaces": {
    "wg3_w8AAAAE": {
      "space_id":               "wg3_w8AAAAE",
      "space_resource_name":    "spaces/wg3_w8AAAAE",
      "display_name":           "HUY Nguyen Le Quang (VTI.D9)",
      "space_type":             "DIRECT_MESSAGE",
      "drive_folder_id":        "1abc...",
      "drive_folder_name":      "DM_HUY Nguyen Le Quang (VTI.D9)_wg3_w8AAAAE",
      "last_crawl_utc":         "2026-05-15T23:00:00Z",
      "last_active_time":       "2026-05-15T11:02:55Z",
      "total_messages_crawled": 87,
      "available_dates":        ["2026-05-01", "2026-05-02", "2026-05-15"],
      "first_msg_time":         "2026-05-01T08:30:00Z",
      "last_msg_time":          "2026-05-15T11:02:55Z",
      "backfill_complete":      true
    },
    "AAAAukFeUNA": { ... },
    ...
  }
}
```

**Sử dụng `_index.json` để:**
- Liệt kê tất cả spaces có data
- Tìm space theo display_name (substring search)
- Map space_id → drive_folder_id để query JSONL/summary
- Biết available_dates trước khi download file

## Cách query data (cho agent)

### Pattern 1: "Cho tôi summary chat với X trong 1 tuần qua"

```
1. Đọc _index.json
2. Tìm space có display_name match "X" (substring)
3. Lấy drive_folder_id
4. Đọc _summary.json trong folder đó
5. Lọc daily_summaries trong 7 ngày gần nhất → trả về
```

### Pattern 2: "Tôi đã quyết định gì với team Y hôm 2026-05-10?"

```
1. Đọc _index.json
2. Tìm space "Y" → folder_id
3. Đọc _summary.json
4. daily_summaries["2026-05-10"].decisions → trả về
```

### Pattern 3: "Tìm thông tin chi tiết về meeting hôm qua trong space Z"

```
1. Đọc _index.json
2. Folder space "Z" → folder_id
3. Đọc <yesterday>.jsonl trong folder
4. Filter messages liên quan (theo keyword hoặc thread)
5. Sort theo create_time
6. Trả về context
```

### Pattern 4: "Liệt kê tất cả space tôi active 14 ngày qua"

```
1. Đọc _index.json
2. Filter spaces có last_active_time > now - 14 days
3. Sort theo last_active_time desc
4. Trả về list (display_name + last_msg_time + msg_count)
```

### Pattern 5: "Có action item nào tôi pending không?"

```
1. Đọc _index.json
2. Cho mỗi space, đọc _summary.json
3. Aggregate tất cả action_items[*] với who = "tôi" hoặc "Michael" trong covers_period gần
4. Trả về list pending items
```

## API access từ agent

### Đọc files trên Drive

Cần OAuth token với scope `drive.file` (đã có sẵn trong `token.json`). Vì scope này restricted (chỉ thấy file do chính app tạo), agent KHÔNG list được file thông thường — phải có:
- `drive_folder_id` từ `_index.json` để access folder
- File ID cụ thể từ folder listing

Helper functions có sẵn trong `crawl_gchat.py`:
- `load_credentials()` — load OAuth token
- `find_folder(drive, name, parent_id)` — tìm folder
- `find_file(drive, name, parent_id)` — tìm file
- `list_folder_files(drive, folder_id)` — list files trong folder
- `download_json(drive, file_id)` / `download_text(drive, file_id)` — download

Example query agent code:

```python
from crawl_gchat import (load_credentials, ensure_folder, find_file,
                          list_folder_files, download_json, download_text,
                          DRIVE_ROOT_NAME)
from googleapiclient.discovery import build

creds = load_credentials()
drive = build("drive", "v3", credentials=creds, cache_discovery=False)

# 1. Locate root + load index
root_id = ensure_folder(drive, DRIVE_ROOT_NAME)
index_id = find_file(drive, "_index.json", root_id)
index = download_json(drive, index_id)

# 2. Find space by display_name substring
matches = [
    (sid, entry) for sid, entry in index["spaces"].items()
    if "HUY" in entry["display_name"]
]
sid, entry = matches[0]
folder_id = entry["drive_folder_id"]

# 3. Read summary
files = list_folder_files(drive, folder_id)
summary = download_json(drive, files["_summary.json"])

# 4. Read raw msgs of a specific date
raw = download_text(drive, files["2026-05-15.jsonl"])
import json
msgs = [json.loads(line) for line in raw.strip().split("\n") if line]
```

### Đọc files local (nếu agent chạy trên cùng machine)

State files local:
- `_summary_queue.json` — recent activity queue, used by scheduled task
- `_backfill_state.json` — backfill progress (không cần với agent đọc data)
- `_summaries_ready.json` — temporary, có thể không tồn tại

Không nên dựa vào local state — Drive là source of truth.

## Search patterns

### Full-text search trong messages

Hiện tại KHÔNG có index search. Pattern bruteforce:

```python
# Search "migration" trong 14 ngày qua across tất cả spaces
results = []
for sid, entry in index["spaces"].items():
    folder_id = entry["drive_folder_id"]
    files = list_folder_files(drive, folder_id)
    for fname, fid in files.items():
        if not fname.endswith(".jsonl"): continue
        if fname[:-6] < "2026-05-01": continue   # 14d filter by date string
        raw = download_text(drive, fid)
        for line in raw.strip().split("\n"):
            msg = json.loads(line)
            if "migration" in msg.get("text", "").lower():
                results.append({
                    "space": entry["display_name"],
                    "date": fname[:-6],
                    "sender": msg.get("sender_name"),
                    "text": msg["text"],
                    "msg_id": msg["msg_id"],
                })
```

### Tìm chat về 1 chủ đề

Faster approach: search trong `_summary.json` (topics, summary) trước, rồi drill down:

```python
# Tìm spaces nói về "Sembcorp"
matched = []
for sid, entry in index["spaces"].items():
    files = list_folder_files(drive, entry["drive_folder_id"])
    if "_summary.json" not in files: continue
    summary = download_json(drive, files["_summary.json"])
    for date, daily in summary["daily_summaries"].items():
        topics = " ".join(daily.get("topics", []))
        prose  = daily.get("summary", "")
        if "Sembcorp" in topics or "Sembcorp" in prose:
            matched.append({
                "space": entry["display_name"],
                "date": date,
                "topics": daily["topics"],
                "summary": daily["summary"],
            })
```

## Limitations

1. **Scope crawl**: chỉ space có msg trong 14 ngày qua + lastActiveTime > 14d. Space im lâu hơn 14d không có data fresh.
2. **AI summary chỉ daily**: nếu cần summary cho intervals khác (vd: hourly, weekly aggregate), agent phải tự tính từ daily entries.
3. **Sender info có thể trống**: msg cũ đôi khi không có `sender_name`/`sender_email` (Chat API behavior). Dùng `space_id` + `space_name` để context.
4. **Attachments**: chỉ lưu metadata (`attachment_names`), KHÔNG download file binary.
5. **Reactions**: lưu metadata, không xác định người react.
6. **Deleted msgs**: được include với metadata only (text rỗng) nếu crawl với `showDeleted=true`.

## File cần biết (project local)

| File | Vai trò |
|---|---|
| `crawl_gchat.py` | Daily crawl script (helpers reusable cho agent) |
| `upload_summaries.py` | Push summary lên Drive |
| `backfill_history.py` | Backfill (chạy 1 lần khi setup) |
| `digest_queue.py` | Compact queue cho AI consume |
| `build_ready.py` | Assemble summaries (mix curated + auto) |
| `debug_dm.py` | Debug 1 space (xem API response) |
| `token.json` | OAuth token (đã có scope: chat + drive + people) |
| `credentials.json` | OAuth client secret |
| `_summary_queue.json` | Queue local (refreshed mỗi run crawl) |

## Reuse code

Agent có thể import từ `crawl_gchat.py`:

```python
from crawl_gchat import (
    # Drive helpers
    load_credentials, ensure_folder, find_folder, find_file,
    download_json, download_text, list_folder_files,
    load_index, load_stage,
    # Constants
    DRIVE_ROOT_NAME, DRIVE_SPACES_NAME, INDEX_FILENAME,
    STAGE_FILENAME, SUMMARY_FILENAME,
    # Naming
    canonical_folder_name, resolve_display_name,
    # User resolution
    resolve_user_name_via_people, detect_self_via_people,
)
```

Tất cả idempotent, safe to call.

## Summary cho agent

Khi nhận task liên quan đến chat history:

1. **Đọc `_index.json` từ Drive** trước (entry point)
2. **Filter spaces** theo display_name / type / active period
3. **Đọc `_summary.json`** cho overview (fast)
4. **Drill xuống `.jsonl`** chỉ khi cần raw content
5. **Cite source** rõ ràng: space_id + date + msg_id để user verify

Đừng:
- ❌ List ALL files trên Drive (drive.file scope không cho)
- ❌ Modify file (read-only đối với agent query)
- ❌ Crawl trực tiếp từ Chat API (đã có pipeline rồi, đừng duplicate)
- ❌ Trust display_name absolutely (có thể đổi) — dùng space_id làm khoá
