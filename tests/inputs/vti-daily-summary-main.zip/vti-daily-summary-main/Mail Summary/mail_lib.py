#!/usr/bin/env python3
"""mail_lib.py — shared utilities cho hourly-mail-summary.

Tất cả deterministic logic: state I/O + migration, thread parsing,
auto-sender detection, Discord formatter + sender. KHÔNG chứa LLM
reasoning — reasoning là việc của Claude (đọc markdown context files
do mail_prelude.py sinh ra, viết decisions vào decisions.json).

Files khác:
    mail_prelude.py  — scan inbox, dump markdown context cho Claude reason
    mail_finale.py   — đọc decisions.json, update state, build & send Discord
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PROJECT_DIR = Path(__file__).resolve().parent
STATE_PATH = PROJECT_DIR / "state.json"
THREAD_CACHE_DIR = PROJECT_DIR / "thread_cache"
INBOX_PATH = PROJECT_DIR / "inbox.json"
THREADS_TO_FETCH_PATH = PROJECT_DIR / "threads_to_fetch.json"

# Prompts (markdown templates Claude reads)
PROMPTS_DIR = PROJECT_DIR / "prompts"

# Config (regex lists, etc — editable by humans)
CONFIG_DIR = PROJECT_DIR / "config"
AUTO_SENDERS_PATH = CONFIG_DIR / "auto_senders.txt"
AUTO_SENDERS_SUGGESTED_PATH = CONFIG_DIR / "auto_senders_suggested.txt"

# Context for Claude reasoning (markdown files Claude generates → reads → answers)
CONTEXT_DIR = PROJECT_DIR / "mail_context"
STATE_SNAPSHOT_PATH = CONTEXT_DIR / "state_snapshot.json"
TRIAGE_MD_PATH = CONTEXT_DIR / "threads_to_triage.md"
DONE_CHECK_MD_PATH = CONTEXT_DIR / "pending_done_checks.md"
UNSNOOZE_MD_PATH = CONTEXT_DIR / "unsnooze_checks.md"
RUN_INDEX_PATH = CONTEXT_DIR / "_run_index.json"
DECISIONS_PATH = CONTEXT_DIR / "decisions.json"

DISCORD_OUTPUT_PATH = PROJECT_DIR / "discord_output.txt"
RUN_LOG_PATH = PROJECT_DIR / "run.log"
LAST_OUTPUT_PATH = PROJECT_DIR / "last_output.txt"

DISCORD_WEBHOOK = (
    "https://discord.com/api/webhooks/1503692385824149544/"
    "m4HNatodLO5vekEJOXXdhg_h5SBHruc-ThRHN__LAtXbYQZ_caq02cR582UkQKZ0MlXW"
)

VTI_DOMAIN = "@vti.com.vn"
MICHAEL_EMAILS = {"anh.nguyentruongviet@vti.com.vn", "michael.nguyen@vti.com.vn"}
SKIP_LABEL = "Claude/Skip"
GMAIL_LINK = "https://mail.google.com/mail/mu/mp/751/#cv/Inbox/{thread_id}"
LOCAL_TZ = timezone(timedelta(hours=7))

PROCESSED_LIMIT = 500
PENDING_LIMIT = 50
DISCORD_CHUNK_BYTES = 1900

# ---------------------------------------------------------------------------
# Tier-1 auto-sender classifier (deterministic, no reasoning)
# ---------------------------------------------------------------------------
# Patterns load runtime from config/auto_senders.txt — to add a pattern,
# edit that file (no code change). See also config/auto_senders_suggested.txt
# for Claude-flagged candidates awaiting human review.


def _read_pattern_file(path: Path) -> list[str]:
    """Read regex patterns from a config file. Skip blank lines and # comments."""
    patterns: list[str] = []
    if not path.exists():
        return patterns
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            patterns.append(stripped)
    except OSError as e:
        # log not yet available at import time — fall back to stderr
        print(f"[mail_lib] could not read {path}: {e}", file=sys.stderr)
    return patterns


def _compile_auto_sender_re() -> re.Pattern:
    patterns = _read_pattern_file(AUTO_SENDERS_PATH)
    # NOTE: suggested patterns are NOT compiled here — they require human review first.
    if not patterns:
        # Defensive fallback: empty file = match nothing (better than match everything).
        return re.compile(r"(?!)", re.IGNORECASE)
    return re.compile("|".join(patterns), re.IGNORECASE)


AUTO_SENDER_RE = _compile_auto_sender_re()


def is_auto_sender(email: str) -> bool:
    return bool(email and AUTO_SENDER_RE.search(email.strip()))


def reload_auto_senders() -> int:
    """Re-read config/auto_senders.txt — useful after appending suggestions.
    Returns number of patterns loaded."""
    global AUTO_SENDER_RE
    AUTO_SENDER_RE = _compile_auto_sender_re()
    return len(_read_pattern_file(AUTO_SENDERS_PATH))


def get_known_auto_sender_patterns() -> set[str]:
    """Patterns already known (auto_senders.txt + auto_senders_suggested.txt) —
    used by finale to dedupe new Claude suggestions."""
    known: set[str] = set()
    known.update(_read_pattern_file(AUTO_SENDERS_PATH))
    known.update(_read_pattern_file(AUTO_SENDERS_SUGGESTED_PATH))
    return known


def append_auto_sender_suggestion(pattern: str, reason: str, thread_id: str, subject: str) -> bool:
    """Append a Claude-suggested pattern to config/auto_senders_suggested.txt.
    Dedupe — returns False if pattern already exists in known set."""
    pattern = pattern.strip()
    if not pattern:
        return False
    if pattern in get_known_auto_sender_patterns():
        return False
    AUTO_SENDERS_SUGGESTED_PATH.parent.mkdir(parents=True, exist_ok=True)
    block = (
        f"\n# {now_iso()} — thread {thread_id} ({subject[:80]})\n"
        f"# reason: {reason.strip()}\n"
        f"{pattern}\n"
    )
    with AUTO_SENDERS_SUGGESTED_PATH.open("a", encoding="utf-8") as f:
        f.write(block)
    return True


# ---------------------------------------------------------------------------
# State migration & I/O
# ---------------------------------------------------------------------------


def _empty_state() -> dict:
    return {
        "processed_threads": {},
        "pending_actions": [],
        "skipped_threads": {},
        "last_run_at": None,
    }


def migrate_state(state: dict) -> dict:
    s = dict(state)
    if "processed_ids" in s and "processed_threads" not in s:
        s["processed_threads"] = {tid: None for tid in s.pop("processed_ids")}
    s.setdefault("processed_threads", {})
    s.setdefault("skipped_threads", {})
    migrated_pending = []
    for action in s.get("pending_actions", []) or []:
        a = dict(action)
        if "pushed_member_email" in a:
            a.setdefault("expected_sender_hint", a.pop("pushed_member_email"))
        if "expected_sender" in a:
            a.setdefault("expected_sender_hint", a.pop("expected_sender"))
        if "latest_message_id" in a:
            a.setdefault("trigger_message_id", a.pop("latest_message_id"))
        a.pop("last_processed_message", None)
        a.setdefault("action_id", short_id())
        a.setdefault("reminder_count", 0)
        a.setdefault("flagged_at", now_iso())
        a.setdefault("unsnooze_reason", None)
        a.setdefault("content_summary", "")
        a.setdefault("subject", "")
        a.setdefault("sender", "")
        a.setdefault("action_type", "reply")
        a.setdefault("action_desc", "")
        a.setdefault("expected_sender_hint", None)
        a.setdefault("priority", "yellow")
        migrated_pending.append(a)
    s["pending_actions"] = migrated_pending
    s.setdefault("last_run_at", None)
    return s


def load_state() -> dict:
    if not STATE_PATH.exists():
        return _empty_state()
    with STATE_PATH.open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return migrate_state(raw)


def save_state(state: dict) -> None:
    processed = state.get("processed_threads", {})
    if len(processed) > PROCESSED_LIMIT:
        items = sorted(processed.items(), key=lambda kv: (kv[1] or kv[0]), reverse=True)[:PROCESSED_LIMIT]
        state["processed_threads"] = dict(items)
    pending = state.get("pending_actions", [])
    if len(pending) > PENDING_LIMIT:
        pending = sorted(pending, key=lambda a: a.get("flagged_at", ""), reverse=True)[:PENDING_LIMIT]
        state["pending_actions"] = pending
    tmp = STATE_PATH.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2, sort_keys=True)
    tmp.replace(STATE_PATH)


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


def now_dt() -> datetime:
    return datetime.now(LOCAL_TZ)


def now_iso() -> str:
    return now_dt().strftime("%Y-%m-%dT%H:%M:%S")


def short_id() -> str:
    return uuid.uuid4().hex[:12]


def log(msg: str) -> None:
    line = f"[{now_iso()}] {msg}"
    print(line, file=sys.stderr)
    try:
        with RUN_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def dump_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
    tmp.replace(path)


# ---------------------------------------------------------------------------
# Thread parsing
# ---------------------------------------------------------------------------


def parse_address(raw: str | None) -> tuple[str, str]:
    if not raw:
        return "", ""
    raw = raw.strip()
    m = re.match(r"^(.*?)<([^>]+)>\s*$", raw)
    if m:
        name = m.group(1).strip().strip('"').strip("'").strip()
        email = m.group(2).strip().lower()
        return name, email
    return "", raw.lower()


def parse_thread(thread_data: dict) -> dict:
    tid = thread_data.get("id") or thread_data.get("threadId") or ""
    messages_raw = thread_data.get("messages") or []
    parsed_msgs = []
    has_unread = False
    has_skip = False
    subject = ""
    for msg in messages_raw:
        mid = msg.get("id") or ""
        from_raw = msg.get("from") or msg.get("From") or msg.get("sender") or ""
        from_name, from_email = parse_address(from_raw)
        to_field = msg.get("to") or msg.get("To") or msg.get("toRecipients") or []
        if isinstance(to_field, str):
            to_field = [to_field]
        to_emails = [parse_address(t)[1] for t in to_field if t]
        cc_field = msg.get("cc") or msg.get("Cc") or msg.get("ccRecipients") or []
        if isinstance(cc_field, str):
            cc_field = [cc_field]
        cc_emails = [parse_address(c)[1] for c in cc_field if c]
        ts = msg.get("internalDate") or msg.get("date") or msg.get("ts") or ""
        body = msg.get("body") or msg.get("text") or msg.get("plainBody") or ""
        snippet = msg.get("snippet") or ""
        if not subject:
            subject = msg.get("subject") or ""
        labels = msg.get("labelIds") or msg.get("labels") or []
        if any(str(lb).upper() == "UNREAD" for lb in labels):
            has_unread = True
        if any(str(lb) == SKIP_LABEL or str(lb).lower().endswith("/skip") for lb in labels):
            has_skip = True
        parsed_msgs.append(
            {
                "id": mid,
                "ts": str(ts),
                "from_name": from_name,
                "from_email": from_email,
                "to_emails": to_emails,
                "cc_emails": cc_emails,
                "body": body,
                "snippet": snippet,
            }
        )
    thread_labels = thread_data.get("labelIds") or thread_data.get("labels") or []
    if any(str(lb) == SKIP_LABEL or str(lb).lower().endswith("/skip") for lb in thread_labels):
        has_skip = True
    if not subject:
        subject = thread_data.get("subject") or ""
    return {
        "id": tid,
        "subject": subject,
        "messages": parsed_msgs,
        "latest_message_id": parsed_msgs[-1]["id"] if parsed_msgs else "",
        "has_unread": has_unread,
        "has_skip_label": has_skip,
    }


def load_thread_objs() -> dict[str, dict]:
    objs: dict[str, dict] = {}
    if not THREAD_CACHE_DIR.exists():
        return objs
    for f in sorted(THREAD_CACHE_DIR.glob("*.json")):
        try:
            with f.open("r", encoding="utf-8") as fp:
                raw = json.load(fp)
            t = parse_thread(raw)
            if t["id"]:
                objs[t["id"]] = t
        except Exception as e:
            log(f"skip thread cache {f}: {e}")
    return objs


def msg_index(messages: list[dict], msg_id: str) -> int:
    for i, m in enumerate(messages):
        if m["id"] == msg_id:
            return i
    return -1


# ---------------------------------------------------------------------------
# Body cleaning — strip HTML and quoted reply chain
# ---------------------------------------------------------------------------

_HTML_TAG_RE = re.compile(r"<[^>]+>")
_HTML_ENTITY_RE = re.compile(r"&(?:nbsp|amp|lt|gt|quot|#\d+|#x[0-9a-fA-F]+);")

_QUOTE_PATTERNS = [
    re.compile(r"^On .{0,200}\bwrote:\s*$", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^Vào .{0,200}\bđã viết:\s*$", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^From: .{0,200}$", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^-+\s*Original Message\s*-+", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^-+\s*Forwarded message\s*-+", re.IGNORECASE | re.MULTILINE),
]


def _strip_html(text: str) -> str:
    if "<" not in text:
        return text
    text = _HTML_TAG_RE.sub(" ", text)
    text = _HTML_ENTITY_RE.sub(lambda m: {
        "&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"',
    }.get(m.group(0), " "), text)
    return text


def clean_body(body: str, snippet: str = "", limit_chars: int = 1800) -> str:
    """Strip HTML + quoted reply chain. Return clean plain text."""
    src = body or snippet or ""
    if not src:
        return ""
    src = _strip_html(src)
    # Cut at first quote marker
    earliest = len(src)
    for pat in _QUOTE_PATTERNS:
        m = pat.search(src)
        if m and m.start() < earliest:
            earliest = m.start()
    src = src[:earliest]
    # Normalize whitespace
    src = re.sub(r"[ \t]+", " ", src)
    src = re.sub(r"\n{3,}", "\n\n", src)
    src = src.strip()
    if len(src) > limit_chars:
        src = src[:limit_chars].rstrip() + " […truncated…]"
    return src


# ---------------------------------------------------------------------------
# Classification helpers (deterministic)
# ---------------------------------------------------------------------------


def is_internal(thread: dict) -> bool:
    for m in thread["messages"]:
        for addr in [m["from_email"], *m["to_emails"], *m["cc_emails"]]:
            if addr and not addr.endswith(VTI_DOMAIN):
                return False
    return True


def company_name_from_thread(thread: dict | None) -> str:
    if thread:
        for m in thread["messages"]:
            for addr in [m["from_email"], *m["to_emails"], *m["cc_emails"]]:
                if addr and not addr.endswith(VTI_DOMAIN):
                    return addr.split("@", 1)[-1].upper()
    return "KHÁC"


def similar_desc(a: str, b: str) -> bool:
    na = re.sub(r"\W+", " ", a.lower()).strip()
    nb = re.sub(r"\W+", " ", b.lower()).strip()
    if not na or not nb:
        return False
    if na == nb:
        return True
    short, long_ = sorted([na, nb], key=len)
    return short in long_ and len(short) >= 8


# ---------------------------------------------------------------------------
# Discord formatting
# ---------------------------------------------------------------------------

PRIORITY_RANK = {"red": 0, "yellow": 1, "green": 2}
PRIORITY_EMOJI = {"red": "🔴", "yellow": "🟡", "green": "🟢"}


def fmt_ts(ts_str: str) -> str:
    if not ts_str:
        return ""
    try:
        n = int(ts_str)
        dt = datetime.fromtimestamp(n / 1000, tz=LOCAL_TZ)
        return dt.strftime("%H:%M")
    except (ValueError, TypeError):
        pass
    try:
        dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).astimezone(LOCAL_TZ)
        return dt.strftime("%H:%M")
    except ValueError:
        return ts_str[:5] if len(ts_str) >= 5 else ts_str


def fmt_date_short(iso_ts: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_ts)
        return dt.strftime("%d/%m %H:%M")
    except (ValueError, AttributeError):
        return iso_ts


def fmt_ts_human(ts_str: str) -> str:
    """Format timestamp as DD/MM HH:MM — for markdown context."""
    if not ts_str:
        return ""
    try:
        n = int(ts_str)
        dt = datetime.fromtimestamp(n / 1000, tz=LOCAL_TZ)
        return dt.strftime("%d/%m %H:%M")
    except (ValueError, TypeError):
        pass
    try:
        dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).astimezone(LOCAL_TZ)
        return dt.strftime("%d/%m %H:%M")
    except ValueError:
        return ts_str


def action_is_customer(action: dict, thread: dict | None) -> bool:
    se = (action.get("sender_email") or "").lower()
    if se and not se.endswith(VTI_DOMAIN):
        return True
    if thread:
        return not is_internal(thread)
    hint = (action.get("expected_sender_hint") or "").lower()
    return hint == "non-vti"


def company_name_from_action(action: dict, thread: dict | None) -> str:
    name = company_name_from_thread(thread)
    if name != "KHÁC":
        return name
    se = (action.get("sender_email") or "").lower()
    if se and "@" in se:
        return se.split("@", 1)[-1].upper()
    return "KHÁC"


def _parse_ts_for_sort(ts: str) -> int:
    try:
        return int(ts)
    except (ValueError, TypeError):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            return int(dt.timestamp() * 1000)
        except (ValueError, AttributeError):
            return 0


def sort_actions(actions: list[dict]) -> list[dict]:
    return sorted(
        actions,
        key=lambda a: (
            PRIORITY_RANK.get(a.get("priority", "yellow"), 1),
            -a.get("reminder_count", 0),
            -_parse_ts_for_sort(a.get("ts", "")),
            a.get("action_id", ""),
        ),
    )


def action_label(action: dict) -> str:
    atype = action.get("action_type", "")
    hint = action.get("expected_sender_hint") or ""
    if atype == "push_member" and hint and hint != "non-vti":
        return f"push_member → {hint}"
    if atype == "push_member" and hint == "non-vti":
        return "push_member → non-vti (chờ khách phản hồi)"
    return atype


def format_action_line(action: dict, run_started_at: str) -> str:
    pe = PRIORITY_EMOJI.get(action.get("priority", "yellow"), "🟡")
    link = GMAIL_LINK.format(thread_id=action["thread_id"])
    subject = action.get("subject", "(no subject)")
    ts = fmt_ts(action.get("ts", ""))
    sender = action.get("sender", "")
    reminder_count = action.get("reminder_count", 0)
    is_pending_reminder = reminder_count > 0 and action.get("flagged_at") != run_started_at
    suffix = ""
    if is_pending_reminder:
        suffix = f"  *(nhắc lần {reminder_count} — flagged {fmt_date_short(action.get('flagged_at', ''))})*"
    elif action.get("unsnooze_reason"):
        suffix = "  *(un-snooze)*"
    head = f"{pe} [{subject}]({link}){suffix}\n{sender} · {ts}"
    summary = action.get("content_summary", "").strip()
    label = action_label(action)
    desc = action.get("action_desc", "")
    body_lines = [
        f"**Nội dung:** {summary}" if summary else "**Nội dung:** (chưa có tóm tắt)",
        f"**Action [{label}]:** {desc}",
    ]
    if action.get("unsnooze_reason"):
        body_lines.insert(0, f"**Lý do un-snooze:** {action['unsnooze_reason']}")
    return head + "\n" + "\n".join(body_lines)


def build_discord_output(
    tier1_auto: list[dict],
    new_actions: list[dict],
    survived_pending: list[dict],
    unsnoozed: dict,
    run_started_at: str,
    thread_objs: dict[str, dict] | None = None,
    info_auto_compact: list[dict] | None = None,
) -> str:
    all_actions = survived_pending + new_actions
    if thread_objs is None:
        thread_objs = load_thread_objs()
    if info_auto_compact is None:
        info_auto_compact = []

    customer_actions: list[dict] = []
    internal_actions: list[dict] = []
    for a in all_actions:
        t = thread_objs.get(a["thread_id"])
        if action_is_customer(a, t):
            customer_actions.append(a)
        else:
            internal_actions.append(a)

    customer_count = len(customer_actions)
    internal_count = len(internal_actions)
    auto_count = len(tier1_auto) + len(info_auto_compact)
    unsnooze_count = len(unsnoozed)

    try:
        dt = datetime.fromisoformat(run_started_at)
    except (ValueError, TypeError):
        dt = now_dt()

    header_line2 = f"Khách hàng: {customer_count}  |  Nội bộ: {internal_count}  |  Auto: {auto_count}"
    if unsnooze_count > 0:
        header_line2 += f"  |  Un-snooze: {unsnooze_count}"

    lines: list[str] = []
    lines.append(f"# MAIL SUMMARY — {dt.strftime('%H:%M %d/%m/%Y')}")
    lines.append(header_line2)
    lines.append("")

    if unsnoozed:
        lines.append("## 🔄 UN-SNOOZE — THREAD ĐÃ SKIP NAY CÓ DIỄN BIẾN MỚI")
        lines.append("")
        lines.append(
            "> ⚠️ Các thread dưới đây trước đó đã được apply label `Claude/Skip`. "
            "Hệ thống phát hiện message mới ĐỦ QUAN TRỌNG nên bật lại theo dõi.\n"
            "> Nếu vẫn không muốn theo dõi, apply lại label `Claude/Skip` lên thread."
        )
        lines.append("")
        for a in sort_actions([a for a in new_actions if a.get("unsnooze_reason")]):
            lines.append(format_action_line(a, run_started_at))
            lines.append("")

    if customer_actions:
        lines.append("## 🏢 KHÁCH HÀNG")
        lines.append("")
        by_company: dict[str, list[dict]] = {}
        for a in customer_actions:
            key = company_name_from_action(a, thread_objs.get(a["thread_id"]))
            by_company.setdefault(key, []).append(a)
        sorted_companies = sorted(
            by_company.items(),
            key=lambda kv: (
                min(PRIORITY_RANK.get(a.get("priority", "yellow"), 1) for a in kv[1]),
                kv[0],
            ),
        )
        for company, actions in sorted_companies:
            lines.append(f"**{company}**")
            for a in sort_actions(actions):
                lines.append(format_action_line(a, run_started_at))
                lines.append("")
        lines.append("")

    if internal_actions:
        lines.append("## 👥 NỘI BỘ")
        lines.append("")
        for a in sort_actions(internal_actions):
            lines.append(format_action_line(a, run_started_at))
            lines.append("")

    if tier1_auto or info_auto_compact:
        lines.append("## 🤖 HỆ THỐNG / AUTO")
        for t in sorted(tier1_auto, key=lambda x: -_parse_ts_for_sort(x.get("ts", ""))):
            sender = t["sender_name"] or t["sender_email"]
            ts = fmt_ts(t["ts"])
            snip = (t.get("snippet") or "")[:120].replace("\n", " ")
            lines.append(f"{sender} — {snip} · {ts}")
        # info actions that matched auto_senders — shown compact, no detail needed
        for a in info_auto_compact:
            subject = (a.get("subject") or "")[:80]
            sender_raw = a.get("sender", "")
            # Extract just the name/email part before the timestamp
            sender_parts = sender_raw.split("·")
            sender_disp = sender_parts[0].strip() if sender_parts else sender_raw
            lines.append(f"· {sender_disp} — {subject}")
        lines.append("")

    if not (all_actions or tier1_auto or info_auto_compact or unsnoozed):
        lines.append("_Không có gì mới._")

    return "\n".join(lines).rstrip() + "\n"


# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Discord sender
# ---------------------------------------------------------------------------


def split_for_discord(text: str) -> list[str]:
    lines = text.split("\n")
    chunks: list[str] = []
    cur = ""
    for line in lines:
        if len(cur) + len(line) + 1 > DISCORD_CHUNK_BYTES:
            if cur.strip():
                chunks.append(cur)
            cur = ""
        cur += line + "\n"
    if cur.strip():
        chunks.append(cur)
    return chunks


def send_discord_chunk(content: str) -> int:
    payload = json.dumps({"content": content})
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
        f.write(payload)
        tmp_path = f.name
    try:
        result = subprocess.run(
            [
                "curl", "-s", "-o", os.devnull, "-w", "%{http_code}",
                "-X", "POST", DISCORD_WEBHOOK,
                "-H", "Content-Type: application/json",
                "--data-binary", f"@{tmp_path}",
            ],
            capture_output=True, text=True, timeout=30,
        )
        try:
            return int(result.stdout.strip() or "0")
        except ValueError:
            return -1
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def send_discord_file(path: Path) -> int:
    """Send discord_output.txt. Returns number of chunks sent, or -1 on error."""
    if not path.exists():
        log(f"send_discord_file: {path} missing")
        return -1
    text = path.read_text(encoding="utf-8")
    chunks = split_for_discord(text)
    for chunk in chunks:
        status = send_discord_chunk(chunk)
        if status not in (200, 204):
            log(f"discord POST failed status={status} chunk_len={len(chunk)}")
            return -1
    try:
        shutil.copy(path, LAST_OUTPUT_PATH)
    except OSError:
        pass
    log(f"sent {len(chunks)} chunks")
    return len(chunks)
