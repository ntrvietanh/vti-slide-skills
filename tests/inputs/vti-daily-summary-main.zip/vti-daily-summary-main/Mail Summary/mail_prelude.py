#!/usr/bin/env python3
"""mail_prelude.py — Python phần ĐẦU pipeline: scan + dump markdown context.

Subcommands:
  scan <inbox.json>   → ghi threads_to_fetch.json (thread cần get_thread)
  prepare              → ghi mail_context/*.md cho Claude reason
  init                 → tạo state.json rỗng + folder cache
  clear                → xoá thread_cache/, mail_context/, manifest cũ

Flow tổng:
  1. Claude paginate Gmail inbox → inbox.json
  2. python mail_prelude.py scan inbox.json
  3. Claude get_thread cho mỗi id → thread_cache/<id>.json
  4. python mail_prelude.py prepare
  5. Claude đọc mail_context/*.md, reason, ghi mail_context/decisions.json
  6. python mail_finale.py apply
  7. python mail_finale.py send
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from mail_lib import (
    CONTEXT_DIR,
    DONE_CHECK_MD_PATH,
    INBOX_PATH,
    MICHAEL_EMAILS,
    PROMPTS_DIR,
    RUN_INDEX_PATH,
    STATE_SNAPSHOT_PATH,
    SKIP_LABEL,
    THREAD_CACHE_DIR,
    THREADS_TO_FETCH_PATH,
    TRIAGE_MD_PATH,
    UNSNOOZE_MD_PATH,
    VTI_DOMAIN,
    clean_body,
    dump_json,
    fmt_ts_human,
    is_auto_sender,
    load_json,
    load_state,
    load_thread_objs,
    log,
    msg_index,
    now_iso,
    save_state,
)


# ---------------------------------------------------------------------------
# Prompt loading (from prompts/*.md)
# ---------------------------------------------------------------------------


def _load_prompt(name: str) -> str:
    """Load a prompt template from prompts/<name>.md.

    Templates use <<MARKER>> placeholders (not Python .format() braces, to
    avoid clashing with `{}` in markdown code blocks). Substitution is done
    by simple string replace in _render_prompt.
    """
    path = PROMPTS_DIR / f"{name}.md"
    if not path.exists():
        raise FileNotFoundError(
            f"prompt template missing: {path}\n"
            f"Run from project dir, or check that prompts/ folder exists."
        )
    return path.read_text(encoding="utf-8")


def _render_prompt(template: str, threads_block: str, run_started_at: str, count: int) -> str:
    """Substitute <<RUN_STARTED_AT>>, <<THREADS>>, <<COUNT>> markers."""
    return (
        template
        .replace("<<RUN_STARTED_AT>>", run_started_at)
        .replace("<<THREADS>>", threads_block)
        .replace("<<COUNT>>", str(count))
    )


# ---------------------------------------------------------------------------
# scan — inbox diff
# ---------------------------------------------------------------------------


def cmd_scan(args: list[str]) -> int:
    inbox_path = Path(args[0]) if args else INBOX_PATH
    if not inbox_path.exists():
        print(f"inbox file {inbox_path} not found", file=sys.stderr)
        return 2
    with inbox_path.open("r", encoding="utf-8") as f:
        inbox = json.load(f)

    state = load_state()
    processed = state.get("processed_threads", {})
    pending_thread_ids = {a["thread_id"] for a in state.get("pending_actions", [])}
    skipped_thread_ids = set(state.get("skipped_threads", {}).keys())

    to_fetch: list[str] = []
    seen: set[str] = set()
    for item in inbox:
        tid = item.get("threadId") or item.get("id")
        latest = item.get("latestMessageId") or item.get("historyId") or ""
        if not tid:
            continue
        seen.add(tid)
        if tid in skipped_thread_ids or tid not in processed or processed[tid] != latest:
            to_fetch.append(tid)
    # Always include pending/skipped threads even if not in current inbox page
    for tid in pending_thread_ids | skipped_thread_ids:
        if tid not in seen and tid not in to_fetch:
            to_fetch.append(tid)

    # Dedupe preserving order
    deduped: list[str] = []
    seen2: set[str] = set()
    for tid in to_fetch:
        if tid not in seen2:
            seen2.add(tid)
            deduped.append(tid)

    dump_json(THREADS_TO_FETCH_PATH, {"thread_ids": deduped, "total_inbox": len(inbox)})
    log(f"scan: {len(inbox)} in inbox, {len(deduped)} need fetch")
    print(json.dumps({"thread_ids": deduped, "total_inbox": len(inbox)}, ensure_ascii=False))
    return 0


# ---------------------------------------------------------------------------
# prepare — write markdown context
# ---------------------------------------------------------------------------


# Triage rule preamble — written once at top of triage markdown.
# Keep this STABLE — Claude reads it every run, so consistency matters.


def _format_message_for_md(m: dict, marker: str = "") -> str:
    """Render one message as markdown section.

    marker examples: "← NEW (unprocessed)", "← TRIGGER", "← skip point"
    """
    sender = m["from_name"] or m["from_email"]
    ts = fmt_ts_human(m["ts"])
    head = f"#### [{m['id']}] {sender} · `{m['from_email']}` · {ts}"
    if marker:
        head += f" {marker}"
    body = clean_body(m["body"], m["snippet"], limit_chars=1800)
    if not body:
        body = "_(empty body)_"
    return f"{head}\n\n{body}"


def _format_thread_section_for_triage(
    thread: dict,
    last_processed_msg_id: str | None,
    existing_actions: list[dict],
) -> str:
    """One thread section in triage markdown."""
    parts: list[str] = []
    parts.append(f"### Thread: {thread['subject'] or '(no subject)'}")
    parts.append("")
    parts.append(f"- `thread_id`: `{thread['id']}`")

    # Participants
    all_emails: list[str] = []
    seen_emails: set[str] = set()
    for m in thread["messages"]:
        for addr in [m["from_email"], *m["to_emails"], *m["cc_emails"]]:
            if addr and addr not in seen_emails:
                seen_emails.add(addr)
                all_emails.append(addr)
    parts.append(f"- participants: {', '.join(all_emails) if all_emails else '(none)'}")
    parts.append(f"- total_messages: {len(thread['messages'])}")
    parts.append(f"- last_processed_message_id: `{last_processed_msg_id or 'null (first time seeing this thread)'}`")
    parts.append("")

    # Existing actions on this thread
    parts.append("**Existing actions on this thread (don't duplicate):**")
    if existing_actions:
        for a in existing_actions:
            hint = a.get("expected_sender_hint") or "null"
            parts.append(f"- `[{a['action_type']}]` {a.get('action_desc', '')} (hint: `{hint}`)")
    else:
        parts.append("- _(none)_")
    parts.append("")

    # Determine new-message boundary
    if last_processed_msg_id:
        new_idx = msg_index(thread["messages"], last_processed_msg_id)
    else:
        new_idx = -1  # all messages are new

    parts.append("**Messages (chronological):**")
    parts.append("")
    for i, m in enumerate(thread["messages"]):
        marker = ""
        if i > new_idx:
            marker = "← NEW (unprocessed)"
        if i == len(thread["messages"]) - 1:
            marker = (marker + " ← LATEST").strip()
        parts.append(_format_message_for_md(m, marker))
        parts.append("")

    return "\n".join(parts)


def _format_thread_section_for_done(
    action: dict,
    thread: dict,
    new_msgs: list[dict],
) -> str:
    parts: list[str] = []
    parts.append(f"### Action: {action.get('action_desc', '(no desc)')}")
    parts.append("")
    parts.append(f"- `action_id`: `{action['action_id']}`")
    parts.append(f"- `action_type`: `{action.get('action_type', '')}`")
    parts.append(f"- `expected_sender_hint`: `{action.get('expected_sender_hint') or 'null'}`")
    parts.append(f"- thread: **{thread['subject'] or '(no subject)'}**")
    parts.append(f"- thread_id: `{thread['id']}`")
    parts.append(f"- flagged_at: {action.get('flagged_at', '')} (reminded {action.get('reminder_count', 0)}x)")
    parts.append("")
    parts.append(f"**Previous content summary:** {action.get('content_summary', '(none)')}")
    parts.append("")

    # Trigger message
    trigger_id = action.get("trigger_message_id", "")
    trigger_idx = msg_index(thread["messages"], trigger_id)
    if trigger_idx >= 0:
        parts.append("**Trigger message (action was created from this):**")
        parts.append("")
        parts.append(_format_message_for_md(thread["messages"][trigger_idx], "← TRIGGER"))
        parts.append("")

    parts.append(f"**New messages arrived after trigger ({len(new_msgs)}):**")
    parts.append("")
    for i, m in enumerate(new_msgs):
        marker = "← LATEST" if i == len(new_msgs) - 1 else ""
        parts.append(_format_message_for_md(m, marker))
        parts.append("")

    return "\n".join(parts)


def _format_thread_section_for_unsnooze(
    thread: dict,
    skipped_at_msg_id: str,
    new_msgs: list[dict],
) -> str:
    parts: list[str] = []
    parts.append(f"### Thread: {thread['subject'] or '(no subject)'}")
    parts.append("")
    parts.append(f"- `thread_id`: `{thread['id']}`")
    parts.append(f"- skipped at message: `{skipped_at_msg_id}`")
    parts.append("")

    # Prior context — last 3 messages up to skip point
    skip_idx = msg_index(thread["messages"], skipped_at_msg_id)
    if skip_idx < 0:
        skip_idx = len(thread["messages"]) - len(new_msgs) - 1
    prior = thread["messages"][: skip_idx + 1]
    prior_tail = prior[-3:] if len(prior) > 3 else prior
    parts.append(f"**Last {len(prior_tail)} message(s) BEFORE skip (for context):**")
    parts.append("")
    for m in prior_tail:
        parts.append(_format_message_for_md(m, "← (before skip)"))
        parts.append("")

    parts.append(f"**New message(s) AFTER skip ({len(new_msgs)}):**")
    parts.append("")
    for i, m in enumerate(new_msgs):
        marker = "← NEW" + (" ← LATEST" if i == len(new_msgs) - 1 else "")
        parts.append(_format_message_for_md(m, marker))
        parts.append("")

    return "\n".join(parts)


def cmd_prepare(args: list[str]) -> int:
    CONTEXT_DIR.mkdir(parents=True, exist_ok=True)
    # Wipe any old markdown context — start fresh.
    # JSON files are overwritten via dump_json (atomic rename), so no need to unlink them.
    # Tolerate unlink failures (some mounts disallow unlink but allow overwrite).
    for f in CONTEXT_DIR.glob("*.md"):
        try:
            f.unlink()
        except OSError:
            # Fallback: truncate
            try:
                f.write_text("", encoding="utf-8")
            except OSError as e:
                log(f"could not clear {f}: {e}")

    state = load_state()
    run_started_at = now_iso()
    pending = state["pending_actions"]
    skipped = state["skipped_threads"]
    processed = state["processed_threads"]
    thread_objs = load_thread_objs()

    # -----------------------------------------------------------------------
    # Skip label changes (deterministic)
    # -----------------------------------------------------------------------

    skip_changes: dict[str, list[dict]] = {
        "newly_skipped": [],
        "remove_from_skipped": [],
        "stay_skipped": [],
    }
    unsnooze_queue: list[dict] = []

    threads_to_inspect = set(skipped.keys()) | {a["thread_id"] for a in pending} | set(thread_objs.keys())
    for tid in sorted(threads_to_inspect):
        t = thread_objs.get(tid)
        if not t:
            continue
        has_label = t["has_skip_label"]
        was_skipped = tid in skipped
        if has_label and not was_skipped:
            skip_changes["newly_skipped"].append(
                {
                    "thread_id": tid,
                    "skipped_at": run_started_at,
                    "skipped_at_message_id": t["latest_message_id"],
                    "subject": t["subject"],
                }
            )
        elif has_label and was_skipped:
            anchor = skipped[tid].get("skipped_at_message_id") or ""
            idx = msg_index(t["messages"], anchor) if anchor else -1
            new_msgs = t["messages"][idx + 1 :] if idx >= 0 else []
            if not new_msgs:
                skip_changes["stay_skipped"].append({"thread_id": tid})
            else:
                unsnooze_queue.append(
                    {
                        "thread_id": tid,
                        "subject": t["subject"],
                        "skipped_at_message_id": anchor,
                        "new_messages_latest_id": new_msgs[-1]["id"],
                    }
                )
        elif (not has_label) and was_skipped:
            skip_changes["remove_from_skipped"].append({"thread_id": tid})

    newly_skipped_ids = {x["thread_id"] for x in skip_changes["newly_skipped"]}
    removed_skip_ids = {x["thread_id"] for x in skip_changes["remove_from_skipped"]}

    # -----------------------------------------------------------------------
    # Done-check queue
    # -----------------------------------------------------------------------

    done_queue: list[dict] = []
    no_new_msg_decisions: list[dict] = []
    threads_with_new_msgs_via_pending: set[str] = set()

    for action in pending:
        tid = action["thread_id"]
        if tid in newly_skipped_ids:
            continue
        if tid in skipped and tid not in removed_skip_ids:
            continue
        t = thread_objs.get(tid)
        if not t:
            no_new_msg_decisions.append(
                {"action_id": action["action_id"], "decision": "keep_no_new_msgs"}
            )
            continue
        trigger_idx = msg_index(t["messages"], action.get("trigger_message_id", ""))
        new_msgs = t["messages"][trigger_idx + 1 :] if trigger_idx >= 0 else []
        if not new_msgs:
            if action["action_type"] in ("info", "external_action") and not t["has_unread"]:
                no_new_msg_decisions.append(
                    {"action_id": action["action_id"], "decision": "done_unread_cleared"}
                )
            else:
                no_new_msg_decisions.append(
                    {"action_id": action["action_id"], "decision": "keep_no_new_msgs"}
                )
            continue
        # Has new messages — for info/external_action, reading the thread is enough to close.
        # If Michael has already read all messages (no unread), auto-done without Claude check.
        if action["action_type"] in ("info", "external_action") and not t["has_unread"]:
            no_new_msg_decisions.append(
                {"action_id": action["action_id"], "decision": "done_unread_cleared"}
            )
            continue
        done_queue.append(
            {
                "action_id": action["action_id"],
                "thread_id": tid,
                "new_messages_latest_id": new_msgs[-1]["id"],
            }
        )
        threads_with_new_msgs_via_pending.add(tid)

    # -----------------------------------------------------------------------
    # Triage queue (new threads or threads with new messages, excluding tier1 auto)
    # -----------------------------------------------------------------------

    triage_queue: list[dict] = []
    tier1_auto: list[dict] = []

    for tid, t in thread_objs.items():
        if tid in newly_skipped_ids:
            continue
        if tid in skipped and tid not in removed_skip_ids:
            continue
        is_new = tid not in processed or processed[tid] != t["latest_message_id"]
        if not (is_new or tid in threads_with_new_msgs_via_pending):
            continue
        if not t["messages"]:
            continue
        first_msg = t["messages"][0]
        # Tier-1 auto: single-message thread from system sender
        if len(t["messages"]) == 1 and is_auto_sender(first_msg["from_email"]):
            tier1_auto.append(
                {
                    "thread_id": tid,
                    "subject": t["subject"],
                    "sender_name": first_msg["from_name"] or first_msg["from_email"],
                    "sender_email": first_msg["from_email"],
                    "ts": first_msg["ts"],
                    "snippet": (first_msg["snippet"] or first_msg["body"][:200]).strip(),
                    "latest_message_id": t["latest_message_id"],
                }
            )
            continue
        triage_queue.append(
            {
                "thread_id": tid,
                "latest_message_id": t["latest_message_id"],
                "last_processed_message_id": processed.get(tid),
            }
        )

    # -----------------------------------------------------------------------
    # Write markdown context files
    # -----------------------------------------------------------------------

    # Triage
    if triage_queue:
        parts: list[str] = []
        for i, item in enumerate(triage_queue, 1):
            tid = item["thread_id"]
            t = thread_objs[tid]
            existing = [a for a in pending if a["thread_id"] == tid]
            parts.append(f"<!-- Thread {i} of {len(triage_queue)} -->")
            parts.append("")
            parts.append(_format_thread_section_for_triage(
                t, item["last_processed_message_id"], existing
            ))
            parts.append("")
        threads_block = "\n".join(parts)
        rendered = _render_prompt(
            _load_prompt("triage"),
            threads_block=threads_block,
            run_started_at=run_started_at,
            count=len(triage_queue),
        )
        TRIAGE_MD_PATH.write_text(rendered, encoding="utf-8")

    # Done-check
    if done_queue:
        parts = []
        for i, item in enumerate(done_queue, 1):
            tid = item["thread_id"]
            t = thread_objs[tid]
            action = next(a for a in pending if a["action_id"] == item["action_id"])
            trigger_idx = msg_index(t["messages"], action.get("trigger_message_id", ""))
            new_msgs = t["messages"][trigger_idx + 1 :] if trigger_idx >= 0 else []
            parts.append(f"<!-- Action {i} of {len(done_queue)} -->")
            parts.append("")
            parts.append(_format_thread_section_for_done(action, t, new_msgs))
            parts.append("")
        threads_block = "\n".join(parts)
        rendered = _render_prompt(
            _load_prompt("done_check"),
            threads_block=threads_block,
            run_started_at=run_started_at,
            count=len(done_queue),
        )
        DONE_CHECK_MD_PATH.write_text(rendered, encoding="utf-8")

    # Un-snooze
    if unsnooze_queue:
        parts = []
        for i, item in enumerate(unsnooze_queue, 1):
            tid = item["thread_id"]
            t = thread_objs[tid]
            skip_idx = msg_index(t["messages"], item["skipped_at_message_id"])
            new_msgs = t["messages"][skip_idx + 1 :] if skip_idx >= 0 else t["messages"]
            parts.append(f"<!-- Thread {i} of {len(unsnooze_queue)} -->")
            parts.append("")
            parts.append(_format_thread_section_for_unsnooze(
                t, item["skipped_at_message_id"], new_msgs
            ))
            parts.append("")
        threads_block = "\n".join(parts)
        rendered = _render_prompt(
            _load_prompt("unsnooze"),
            threads_block=threads_block,
            run_started_at=run_started_at,
            count=len(unsnooze_queue),
        )
        UNSNOOZE_MD_PATH.write_text(rendered, encoding="utf-8")

    # State snapshot (read-only reference for Claude)
    dump_json(STATE_SNAPSHOT_PATH, {
        "pending_count": len(pending),
        "skipped_count": len(skipped),
        "processed_count": len(processed),
        "last_run_at": state.get("last_run_at"),
    })

    # Run index — finale.py reads this for deterministic decisions
    run_index = {
        "run_started_at": run_started_at,
        "skip_changes": skip_changes,
        "no_new_msg_decisions": no_new_msg_decisions,
        "tier1_auto": tier1_auto,
        "done_queue_action_ids": [d["action_id"] for d in done_queue],
        "unsnooze_queue_thread_ids": [u["thread_id"] for u in unsnooze_queue],
        "triage_queue_thread_ids": [t["thread_id"] for t in triage_queue],
        "unsnooze_latest_msg_ids": {u["thread_id"]: u["new_messages_latest_id"] for u in unsnooze_queue},
    }
    dump_json(RUN_INDEX_PATH, run_index)

    # Initialize empty decisions.json so Claude has a template to fill
    decisions_init = {
        "triage_decisions": [],
        "done_decisions": [],
        "unsnooze_decisions": [],
    }
    dump_json(CONTEXT_DIR / "decisions.json", decisions_init)

    stats = {
        "newly_skipped": len(skip_changes["newly_skipped"]),
        "removed_skip": len(skip_changes["remove_from_skipped"]),
        "unsnooze_to_check": len(unsnooze_queue),
        "done_to_check": len(done_queue),
        "triage_to_do": len(triage_queue),
        "tier1_auto": len(tier1_auto),
        "no_new_msg_decisions": len(no_new_msg_decisions),
    }
    log("prepare: " + ", ".join(f"{k}={v}" for k, v in stats.items()))
    print(json.dumps({
        "stats": stats,
        "context_dir": str(CONTEXT_DIR),
        "files": {
            "triage_md": str(TRIAGE_MD_PATH) if triage_queue else None,
            "done_check_md": str(DONE_CHECK_MD_PATH) if done_queue else None,
            "unsnooze_md": str(UNSNOOZE_MD_PATH) if unsnooze_queue else None,
            "decisions": str(CONTEXT_DIR / "decisions.json"),
            "run_index": str(RUN_INDEX_PATH),
        },
    }, ensure_ascii=False))
    return 0


# ---------------------------------------------------------------------------
# init / clear
# ---------------------------------------------------------------------------


def cmd_init(args: list[str]) -> int:
    from mail_lib import STATE_PATH
    THREAD_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    CONTEXT_DIR.mkdir(parents=True, exist_ok=True)
    state = load_state()
    save_state(state)
    print(
        json.dumps(
            {
                "state_path": str(STATE_PATH),
                "pending_count": len(state["pending_actions"]),
                "processed_count": len(state["processed_threads"]),
                "skipped_count": len(state["skipped_threads"]),
                "last_run_at": state.get("last_run_at"),
            },
            ensure_ascii=False,
        )
    )
    return 0


def cmd_clear(args: list[str]) -> int:
    n = 0
    if THREAD_CACHE_DIR.exists():
        for f in THREAD_CACHE_DIR.glob("*.json"):
            try:
                f.unlink()
                n += 1
            except OSError:
                pass
    if CONTEXT_DIR.exists():
        for f in CONTEXT_DIR.iterdir():
            if f.is_file():
                try:
                    f.unlink()
                    n += 1
                except OSError:
                    pass
    print(f"cleared {n} files (thread_cache + mail_context)")
    return 0


# ---------------------------------------------------------------------------
# entrypoint
# ---------------------------------------------------------------------------

COMMANDS = {
    "scan": cmd_scan,
    "prepare": cmd_prepare,
    "init": cmd_init,
    "clear": cmd_clear,
}


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print(f"usage: mail_prelude.py {{{'|'.join(COMMANDS)}}}", file=sys.stderr)
        return 2
    return COMMANDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    sys.exit(main())
