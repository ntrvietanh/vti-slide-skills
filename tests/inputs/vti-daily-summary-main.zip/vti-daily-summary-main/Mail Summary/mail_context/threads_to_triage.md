# Triage queue — 2026-05-19T07:14:20

You are helping **Michael** (VTI APAC) classify email threads in his inbox.

## Identity

- Michael's emails: `anh.nguyentruongviet@vti.com.vn`, `michael.nguyen@vti.com.vn`
- Internal VTI domain: `@vti.com.vn`
- "Việt Anh", "Michael", "@Anh", "@VietAnh", "nhờ Việt Anh", "nhờ Michael" — all refer to Michael (the user himself).

## Hard rules — apply BEFORE reading thread content

**RULE 1 — Michael is NEVER a `push_member` target.**
Michael is the user. If anyone is waiting on Michael to reply/decide/act:
- `action_type` = `reply`
- `expected_sender_hint` = `michael`

If a thread contains "Việt Anh ơi", "@Michael", "@Anh", "nhờ Việt Anh", or any callout to Michael → action_type = `reply` (not push_member).

**RULE 2 — HR / system mail → always `info`.**
If sender matches any of: `vbs@*`, `vms@*`, `hr@vti.*`, `vti.hr@*`, `vti-hr@*`, `hr.vti@*`, `@hr.vti.*` → action_type = `info`.
This includes policy announcements, decisions, regulations, HR notices, training, salary, KPI forms, leave, party, birthday, etc. Even "BAN HÀNH QUY ĐỊNH", "QUYẾT ĐỊNH", "CÔNG VĂN" — still `info`. You MAY raise priority to `red` if it requires Michael's compliance, but never change action_type.

## VTI member nicknames (so you can match callouts)

| Nickname | Email |
|---|---|
| Cuong | cuong.nguyenduc2@vti.com.vn |
| Kevin | kevin.nguyen@vti.com.vn |
| Khoi | khoi.* (any @vti.com.vn) |
| Quyen | quyen.nguyenthido@vti.com.vn |
| Dung | dung.nguyenthi@vti.com.vn |
| Tung | tung.nguyenba@vti.com.vn |
| Khanh | khanh.tranduy@vti.com.vn |
| Tu | tu.phan@vti.com.vn |
| Việt Anh / Michael | (the user — see RULE 1) |

## Procedure for each thread

1. **Apply hard rules.** If a rule matches → use rule output, skip to step 4.
2. **Examine message[-1]** (the LATEST message in the thread, listed last). This is the current state.
   - Sender of `message[-1]`: Michael / VTI member / external?
   - TO/CC of `message[-1]`: who is the audience?
   - Content of `message[-1]`: question / commitment / acknowledgement / FYI / attachment?
   - **If Michael sent `message[-1]` → Michael already replied → do NOT create a `reply` action.** You may create `push_member` with hint=`non-vti` if Michael is now waiting on the customer.
3. **List ALL waiting pairs in the thread.** A single thread can have multiple parallel actions. For each pair:

   | Situation | `action_type` | `expected_sender_hint` |
   |---|---|---|
   | Customer/partner waiting on Michael | `reply` | `michael` |
   | Customer/partner waiting on specific VTI member | `push_member` | email of that member |
   | VTI sent outbound (BQ/NDA/proposal/attachment), customer hasn't replied | `push_member` | `non-vti` |
   | Internal VTI member assigned a task | `push_member` | email of assignee |
   | No one is waiting — just FYI/broadcast | `info` | `null` |
   | Auto-mail requiring portal/click action | `external_action` | `null` |

4. **Re-check RULE 1.** If any `push_member` ended up with hint = Michael's email → change to `reply` with hint = `michael`.

## Other guidance

- Michael in CC does NOT auto-mean `info`. Read the conversation loop.
- "Sẽ gửi", "will send", "I'll", "we'll" = a commitment. May spawn an additional `push_member` with hint = committer's email (waiting for the commitment to be fulfilled).
- Auto-reply "out of office" doesn't count as a reply.
- Polite "đã nhận, sẽ xem" doesn't complete an action that requires concrete output (e.g. quote, document, decision).
- **Don't duplicate**: if an action already exists in "Existing actions" with the same `action_type` and similar `action_desc`, skip it.

## Priority

- `red` — urgent (deadline ≤24h, customer pressing, blocker)
- `yellow` — within day/week
- `green` — no rush / FYI

## Auto-sender suggestion (optional)

If you classify a thread as `info` and the sender is **clearly automated** (newsletter / marketing / system notification / no-reply pattern) but the sender's email does NOT match a typical auto-sender pattern already known to the system, you MAY suggest adding the sender to the auto-sender list.

Signs of automation: unsubscribe footer, `noreply`/`no-reply`/`donotreply`/`newsletter`/`updates`/`marketing` in local part, sender is a marketing domain, body is mass-broadcast HTML template.

If suggesting, fill `auto_sender_suggestion` per-thread with:
- `email_pattern`: a regex that matches the sender (e.g. `^updates@.*\.example\.com$` or `^marketing@vendor\.com$`)
- `reason`: one short sentence why this looks automated

The system will append your suggestion to `config/auto_senders_suggested.txt` for Michael to review and promote manually. **Suggestions are NEVER auto-applied** — they go to a separate file.

Do NOT suggest for senders already obviously covered (e.g. `no-reply@*`, `@github.com`, well-known SaaS).

---

## Threads to triage

<!-- Thread 1 of 3 -->

### Thread: Internal - BQ_ Uf... - Breakdown of role & headcount for rol...

- `thread_id`: `19e1c282a6051106`
- participants: comments-noreply@docs.google.com, anh.nguyentruongviet@vti.com.vn
- total_messages: 2
- last_processed_message_id: `19e1c282a6051106`

**Existing actions on this thread (don't duplicate):**
- _(none)_

**Messages (chronological):**

#### [19e1c282a6051106] comments-noreply@docs.google.com · `comments-noreply@docs.google.com` · 12/05 19:27

TUAN Mai Van (VTI.D9) assigned you an action item in Internal - BQ_ Ufinity

#### [19e3a7d3441eda38] comments-noreply@docs.google.com · `comments-noreply@docs.google.com` · 18/05 16:49 ← NEW (unprocessed) ← LATEST

Tyson Nguyen marked an action item as done


<!-- Thread 2 of 3 -->

### Thread: AI Tender Budgetary Quote

- `thread_id`: `19e2a962169c25d8`
- participants: ian.choy@nxgen.asia, anh.nguyentruongviet@vti.com.vn, kevin.nguyen@vti.com.vn, tung.nguyenba@vti.com.vn, khanh.tranduy@vti.com.vn, anthony.tee@vti.com.vn, bdg@vti.com.vn
- total_messages: 3
- last_processed_message_id: `19e3a029a59212d8`

**Existing actions on this thread (don't duplicate):**
- `[push_member]` Tyson chuẩn bị Budgetary Quote cho HDB AI Tender (AI Agentic Agent, 15 use cases, AWS) theo yêu cầu Ian Choy (NxGen). (hint: `tung.nguyenba@vti.com.vn`)
- `[push_member]` Kevin cần schedule sync-up với Ian Choy (NxGen) vào ngày 22 May theo đề nghị của Ian. (hint: `kevin.nguyen@vti.com.vn`)

**Messages (chronological):**

#### [19e2a962169c25d8] ian.choy@nxgen.asia · `ian.choy@nxgen.asia` · 15/05 14:42

Hi Team, Attached are the details of the HDB AI tender we plan to participate in. AI Agentic Agent project with 15 defined use cases. Proposed in AWS.

#### [19e39f70e34717f2] kevin.nguyen@vti.com.vn · `kevin.nguyen@vti.com.vn` · 18/05 14:22

Hi Ian, As discussed, we had an internal sync-up today, and would like to update our understanding of the deliverables. We target to follow up with the 1st draft on 22 May.

#### [19e3a029a59212d8] ian.choy@nxgen.asia · `ian.choy@nxgen.asia` · 18/05 14:35 ← LATEST

Hi Kevin, Thanks, please feel free to schedule a sync-up on 22 May. Regards, Ian Choy


<!-- Thread 3 of 3 -->

### Thread: [VTI.PQM] METRIC REPORT Tháng 4 - 2026

- `thread_id`: `19e3b160820805f2`
- participants: thuy.hoangthithanh@vti.com.vn, vti.bom@vti.com.vn, hoa.lekim@vti.com.vn, vti.pqm@vti.com.vn
- total_messages: 1
- last_processed_message_id: `null (first time seeing this thread)`

**Existing actions on this thread (don't duplicate):**
- _(none)_

**Messages (chronological):**

#### [19e3b160820805f2] thuy.hoangthithanh@vti.com.vn · `thuy.hoangthithanh@vti.com.vn` · 18/05 19:35 ← NEW (unprocessed) ← LATEST

Dear các anh/chị Manager, Phòng Quản lý Chất lượng Dự án (Project Quality Management) - VTI.PQM xin gửi anh/chị dữ liệu tổng hợp metric lũy kế đến Tháng 4 - 2026 Note: Từ Tháng 5 sẽ tổng hợp metric của



---

## How to write your decisions

Append all triage decisions to the `triage_decisions` array in `mail_context/decisions.json`:

```json
{
  "triage_decisions": [
    {
      "thread_id": "<thread_id>",
      "actions": [
        {
          "action_type": "reply | push_member | external_action | info",
          "priority": "red | yellow | green",
          "expected_sender_hint": "michael | <email> | non-vti | null",
          "action_desc": "<one sentence describing the action>",
          "content_summary": "<2-3 sentences summarizing the thread state>",
          "trigger_message_id": "<id of the message that triggered this action>"
        }
      ],
      "auto_sender_suggestion": null
    }
  ]
}
```

Or with a suggestion:

```json
{
  "thread_id": "<thread_id>",
  "actions": [...],
  "auto_sender_suggestion": {
    "email_pattern": "^updates@example\\.com$",
    "reason": "Mass-broadcast newsletter with unsubscribe footer, no human sender"
  }
}
```

If a thread has NO action needed (e.g. blocked by RULE 2 → info but already handled), still include the thread with an empty `actions: []`. This tells the system you considered it.

Threads to triage: **3**
