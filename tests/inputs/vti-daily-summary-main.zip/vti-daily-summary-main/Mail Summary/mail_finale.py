#!/usr/bin/env python3
"""mail_finale.py — Python phần CUỐI pipeline: apply decisions + send Discord.

Subcommands:
  apply    → đọc mail_context/decisions.json (do Claude reason xong) +
             mail_context/_run_index.json (deterministic decisions từ prelude),
             áp dụng vào state.json, build discord_output.txt
  send     → POST discord_output.txt lên webhook bằng curl
  run      → apply + send (chạy 1 phát)
  diff     → so sánh discord_output.txt hiện tại với last_output.txt
"""

from __future__ import annotations

import difflib
import json
import re
import sys
from pathlib import Path

from mail_lib import (
    DECISIONS_PATH,
    DISCORD_OUTPUT_PATH,
    LAST_OUTPUT_PATH,
    RUN_INDEX_PATH,
    append_auto_sender_suggestion,
    build_discord_output,
    load_json,
    load_state,
    load_thread_objs,
    log,
    msg_index,
    save_state,
    send_discord_file,
    short_id,
    similar_desc,
)


VALID_ACTION_TYPES = {"reply", "push_member", "external_action", "info"}
VALID_PRIORITIES = {"red", "yellow", "green"}

# VTI HR policy/decision keywords — if subject contains any of these,
# vti.hr info actions are shown (once) even though sender matches auto_senders.txt
VTI_HR_POLICY_KEYWORDS = ["quyết định", "quy định", "bổ nhiệm", "bãi nhiệm", "sáp nhập", "thành lập"]


def _load_auto_patterns() -> list[re.Pattern]:
    """Load compiled regex patterns from config/auto_senders.txt."""
    config_path = Path(__file__).parent / "config" / "auto_senders.txt"
    patterns: list[re.Pattern] = []
    try:
        for line in config_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                try:
                    patterns.append(re.compile(line, re.IGNORECASE))
                except re.error:
                    pass
    except FileNotFoundError:
        pass
    return patterns


def _email_matches_auto(sender: str, patterns: list[re.Pattern]) -> bool:
    """Return True if any email in the sender string matches an auto-sender pattern."""
    for part in sender.split("·"):
        part = part.strip().lower()
        if "@" in part:
            for pat in patterns:
                if pat.search(part):
                    return True
    return False


def _is_vti_hr_policy(action: dict) -> bool:
    """Return True if a vti.hr action is about policy/decision → keep visible."""
    subject = (action.get("subject") or "").lower()
    return any(kw in subject for kw in VTI_HR_POLICY_KEYWORDS)


def _should_show_info(action: dict, auto_patterns: list[re.Pattern]) -> bool:
    """Decide if an info action should appear in Discord this run.

    Rules:
    - Sender matches auto_senders.txt → suppress, UNLESS it's a vti.hr policy/decision
    - Everything else → show (but will not be persisted to next run)
    """
    sender = action.get("sender", "")
    if _email_matches_auto(sender, auto_patterns):
        # Special exception: vti.hr policy/decision emails still surface once
        if _is_vti_hr_policy(action):
            return True
        return False
    return True


def _validate_decisions(d: dict) -> list[str]:
    errs: list[str] = []
    for key in ("triage_decisions", "done_decisions", "unsnooze_decisions"):
        if key not in d:
            errs.append(f"missing key: {key}")
        elif not isinstance(d[key], list):
            errs.append(f"{key} is not a list")
    for i, td in enumerate(d.get("triage_decisions", [])):
        if not isinstance(td, dict):
            errs.append(f"triage_decisions[{i}] not a dict")
            continue
        if "thread_id" not in td:
            errs.append(f"triage_decisions[{i}] missing thread_id")
        for j, a in enumerate(td.get("actions", [])):
            atype = a.get("action_type")
            if atype not in VALID_ACTION_TYPES:
                errs.append(f"triage_decisions[{i}].actions[{j}] invalid action_type={atype}")
            prio = a.get("priority")
            if prio not in VALID_PRIORITIES:
                errs.append(f"triage_decisions[{i}].actions[{j}] invalid priority={prio}")
    for i, dd in enumerate(d.get("done_decisions", [])):
        if "action_id" not in dd:
            errs.append(f"done_decisions[{i}] missing action_id")
        if "done" not in dd or not isinstance(dd["done"], bool):
            errs.append(f"done_decisions[{i}] missing/invalid 'done' bool")
    for i, ud in enumerate(d.get("unsnooze_decisions", [])):
        if "thread_id" not in ud:
            errs.append(f"unsnooze_decisions[{i}] missing thread_id")
        if "should_unsnooze" not in ud or not isinstance(ud["should_unsnooze"], bool):
            errs.append(f"unsnooze_decisions[{i}] missing/invalid 'should_unsnooze' bool")
    return errs


def cmd_apply(args: list[str]) -> int:
    decisions = load_json(DECISIONS_PATH, None)
    if not decisions:
        print(f"decisions file {DECISIONS_PATH} missing or empty", file=sys.stderr)
        return 2
    run_index = load_json(RUN_INDEX_PATH, None)
    if not run_index:
        print(f"run index {RUN_INDEX_PATH} missing — run prelude prepare first", file=sys.stderr)
        return 2

    auto_patterns = _load_auto_patterns()

    errs = _validate_decisions(decisions)
    if errs:
        print("decisions.json validation errors:", file=sys.stderr)
        for e in errs:
            print(f"  · {e}", file=sys.stderr)
        return 2

    state = load_state()
    run_started_at = run_index["run_started_at"]
    pending = state["pending_actions"]
    skipped = state["skipped_threads"]
    processed = state["processed_threads"]
    thread_objs = load_thread_objs()

    # ---------------------------------------------------------------
    # 1. Apply skip-label changes (from prelude — deterministic)
    # ---------------------------------------------------------------
    newly_skipped_ids = {x["thread_id"] for x in run_index["skip_changes"]["newly_skipped"]}
    for x in run_index["skip_changes"]["newly_skipped"]:
        skipped[x["thread_id"]] = {
            "skipped_at": x["skipped_at"],
            "skipped_at_message_id": x["skipped_at_message_id"],
        }
    for x in run_index["skip_changes"]["remove_from_skipped"]:
        skipped.pop(x["thread_id"], None)
    pending = [a for a in pending if a["thread_id"] not in newly_skipped_ids]

    # ---------------------------------------------------------------
    # 2. Apply un-snooze decisions (from Claude)
    # ---------------------------------------------------------------
    unsnoozed_this_run: dict[str, dict] = {}
    unsnooze_by_tid = {ud["thread_id"]: ud for ud in decisions["unsnooze_decisions"]}
    unsnooze_latest_msg_ids = run_index.get("unsnooze_latest_msg_ids", {})

    for tid in run_index["unsnooze_queue_thread_ids"]:
        ud = unsnooze_by_tid.get(tid)
        latest_msg_id = unsnooze_latest_msg_ids.get(tid)
        if not ud:
            # Claude didn't answer — keep skipped, advance anchor to avoid re-asking
            if tid in skipped and latest_msg_id:
                skipped[tid]["skipped_at_message_id"] = latest_msg_id
            log(f"unsnooze: no decision for thread {tid} — keep skipped")
            continue
        if ud["should_unsnooze"]:
            skipped.pop(tid, None)
            unsnoozed_this_run[tid] = {
                "trigger_summary": ud.get("trigger_summary", "") or "",
                "reasoning": ud.get("reasoning", "") or "",
            }
        else:
            if tid in skipped and latest_msg_id:
                skipped[tid]["skipped_at_message_id"] = latest_msg_id

    # ---------------------------------------------------------------
    # 3. Apply done-check decisions
    # ---------------------------------------------------------------
    done_action_ids: set[str] = set()
    updated_summaries: dict[str, str] = {}

    # Deterministic decisions from prelude (no_new_msg cases)
    for d in run_index["no_new_msg_decisions"]:
        if d["decision"] == "done_unread_cleared":
            done_action_ids.add(d["action_id"])

    # Claude's decisions
    done_by_aid = {dd["action_id"]: dd for dd in decisions["done_decisions"]}
    for aid in run_index["done_queue_action_ids"]:
        dd = done_by_aid.get(aid)
        if not dd:
            log(f"done-check: no decision for action {aid} — keep pending")
            continue
        if dd["done"]:
            done_action_ids.add(aid)
        else:
            new_sum = dd.get("updated_content_summary", "") or ""
            if new_sum:
                updated_summaries[aid] = new_sum

    survived_pending: list[dict] = []
    for a in pending:
        if a["action_id"] in done_action_ids:
            continue
        a = dict(a)
        a["reminder_count"] = a.get("reminder_count", 0) + 1
        if a["action_id"] in updated_summaries:
            a["content_summary"] = updated_summaries[a["action_id"]]
        survived_pending.append(a)

    # ---------------------------------------------------------------
    # 4. Apply triage decisions
    # ---------------------------------------------------------------
    new_actions: list[dict] = []
    triage_by_tid = {td["thread_id"]: td for td in decisions["triage_decisions"]}

    for tid in run_index["triage_queue_thread_ids"]:
        td = triage_by_tid.get(tid)
        if not td:
            log(f"triage: no decision for thread {tid} — skipping (will retry next run)")
            continue
        t = thread_objs.get(tid)
        if not t:
            continue
        for raw_action in td.get("actions", []) or []:
            atype = raw_action.get("action_type")
            if atype not in VALID_ACTION_TYPES:
                continue
            desc = raw_action.get("action_desc", "")
            # Dedupe against existing pending
            similar = any(
                pa["thread_id"] == tid
                and pa["action_type"] == atype
                and similar_desc(pa.get("action_desc", ""), desc)
                for pa in survived_pending
            )
            if similar:
                continue
            # info action with no real content → drop (avoid noise)
            if atype == "info" and not desc.strip():
                continue
            trigger_id = raw_action.get("trigger_message_id") or t["latest_message_id"]
            sender_msg = None
            for m in t["messages"]:
                if m["id"] == trigger_id:
                    sender_msg = m
                    break
            if not sender_msg:
                sender_msg = t["messages"][-1]
            sender_email = sender_msg["from_email"]
            sender_name = sender_msg["from_name"]
            sender_disp = (
                f"{sender_name} · {sender_email}"
                if sender_name and sender_name != sender_email
                else sender_email
            )
            unsnooze_info = unsnoozed_this_run.get(tid)
            unsnooze_reason = None
            if unsnooze_info:
                unsnooze_reason = (
                    f"{unsnooze_info['trigger_summary']} · {unsnooze_info['reasoning']}".strip(" ·")
                )
            new_actions.append(
                {
                    "action_id": short_id(),
                    "thread_id": tid,
                    "subject": t["subject"],
                    "sender": sender_disp,
                    "sender_email": sender_email,
                    "sender_name": sender_name,
                    "ts": sender_msg["ts"],
                    "action_type": atype,
                    "priority": raw_action.get("priority", "yellow"),
                    "expected_sender_hint": raw_action.get("expected_sender_hint"),
                    "action_desc": desc,
                    "content_summary": raw_action.get("content_summary", ""),
                    "trigger_message_id": trigger_id,
                    "flagged_at": run_started_at,
                    "reminder_count": 0,
                    "unsnooze_reason": unsnooze_reason,
                }
            )

    # ---------------------------------------------------------------
    # 5. Harvest auto-sender suggestions from triage decisions
    # ---------------------------------------------------------------
    suggestions_added = 0
    for td in decisions["triage_decisions"]:
        sug = td.get("auto_sender_suggestion")
        if not sug or not isinstance(sug, dict):
            continue
        pattern = (sug.get("email_pattern") or "").strip()
        reason = (sug.get("reason") or "").strip()
        if not pattern:
            continue
        tid = td.get("thread_id", "")
        t = thread_objs.get(tid)
        subject = t["subject"] if t else ""
        if append_auto_sender_suggestion(pattern, reason, tid, subject):
            suggestions_added += 1
            log(f"auto-sender suggestion appended: {pattern} (thread {tid})")
        else:
            log(f"auto-sender suggestion duplicate, skipped: {pattern}")

    # ---------------------------------------------------------------
    # 6. Update processed_threads (mark all fetched threads as processed)
    # ---------------------------------------------------------------
    for tid, t in thread_objs.items():
        if t["latest_message_id"]:
            processed[tid] = t["latest_message_id"]

    # ---------------------------------------------------------------
    # 7. Save state — info actions are NEVER persisted across runs.
    #    They are show-once: displayed in this run's Discord output,
    #    then automatically dismissed (not saved to pending_actions).
    # ---------------------------------------------------------------
    def _is_info(a: dict) -> bool:
        return a.get("action_type") == "info"

    # Split survived_pending: info actions shown this run → dismissed; non-info → persist
    survived_non_info = [a for a in survived_pending if not _is_info(a)]
    survived_info_show = [a for a in survived_pending if _is_info(a) and _should_show_info(a, auto_patterns)]
    survived_info_auto = [a for a in survived_pending if _is_info(a) and not _should_show_info(a, auto_patterns)]

    # Split new_actions: info → show-once (not persisted); non-info → persist
    new_non_info = [a for a in new_actions if not _is_info(a)]
    new_info_show = [a for a in new_actions if _is_info(a) and _should_show_info(a, auto_patterns)]
    new_info_auto = [a for a in new_actions if _is_info(a) and not _should_show_info(a, auto_patterns)]

    state["pending_actions"] = survived_non_info + new_non_info
    state["skipped_threads"] = skipped
    state["processed_threads"] = processed
    state["last_run_at"] = run_started_at
    save_state(state)

    # ---------------------------------------------------------------
    # 8. Build Discord output — include show-once info actions for
    #    this run's display, even though they won't persist to state.
    # ---------------------------------------------------------------
    discord_survived = survived_non_info + survived_info_show
    discord_new = new_non_info + new_info_show
    info_auto_compact = survived_info_auto + new_info_auto  # compact one-liner in Auto section

    output_text = build_discord_output(
        tier1_auto=run_index["tier1_auto"],
        new_actions=discord_new,
        survived_pending=discord_survived,
        unsnoozed=unsnoozed_this_run,
        run_started_at=run_started_at,
        thread_objs=thread_objs,
        info_auto_compact=info_auto_compact,
    )
    DISCORD_OUTPUT_PATH.write_text(output_text, encoding="utf-8")

    summary = {
        "pending_kept": len(survived_non_info),
        "new_actions": len(new_non_info),
        "info_show_once": len(survived_info_show) + len(new_info_show),
        "info_auto_compact": len(info_auto_compact),
        "unsnoozed": len(unsnoozed_this_run),
        "tier1_auto": len(run_index["tier1_auto"]),
        "newly_skipped": len(newly_skipped_ids),
        "auto_sender_suggestions_new": suggestions_added,
        "discord_output": str(DISCORD_OUTPUT_PATH),
    }
    log("apply: " + ", ".join(f"{k}={v}" for k, v in summary.items()))
    print(json.dumps(summary, ensure_ascii=False))
    return 0


def cmd_send(args: list[str]) -> int:
    if not DISCORD_OUTPUT_PATH.exists():
        print("discord_output.txt missing — run apply first", file=sys.stderr)
        return 2
    sent = send_discord_file(DISCORD_OUTPUT_PATH)
    if sent < 0:
        return 1
    print(json.dumps({"chunks_sent": sent}))
    return 0


def cmd_run(args: list[str]) -> int:
    rc = cmd_apply(args)

def cmd_run(args: list[str]) -> int:
    rc = cmd_apply(args)
    if rc != 0:
        return rc
    return cmd_send(args)


def cmd_diff(args: list[str]) -> int:
    if not LAST_OUTPUT_PATH.exists():
        print("no previous output")
        return 0
    if not DISCORD_OUTPUT_PATH.exists():
        print("no current output (run apply first)")
        return 2
    a = LAST_OUTPUT_PATH.read_text(encoding="utf-8").splitlines()
    b = DISCORD_OUTPUT_PATH.read_text(encoding="utf-8").splitlines()
    diff = list(difflib.unified_diff(a, b, fromfile="last_output", tofile="discord_output", lineterm=""))
    if not diff:
        print("DIFF: 0 lines")
        return 0
    for line in diff:
        print(line)
    return 0


COMMANDS = {
    "apply": cmd_apply,
    "send": cmd_send,
    "run": cmd_run,
    "diff": cmd_diff,
}


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print(f"usage: mail_finale.py {{{'|'.join(COMMANDS)}}}", file=sys.stderr)
        return 2
    return COMMANDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    sys.exit(main())
