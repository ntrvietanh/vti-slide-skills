---
name: hourly-mail-summary
description: Tóm tắt email — chạy 7h, 9h, 11h, 13h, 15h, 17h hàng ngày trong tuần. Python lo crawl/check thread + build Discord; Claude lo reasoning (triage/done/un-snooze) trên markdown context files.
---

## Phân vai trò

**Python** (deterministic, không reasoning):
- `mail_prelude.py` — scan inbox, diff vs state, dump markdown context files cho Claude
- `mail_finale.py` — đọc decisions Claude ghi, update state, build Discord, gửi curl
- `mail_lib.py` — shared utilities

**Claude** (reasoning trên context có sẵn):
- Đọc markdown context files do prelude dump ra
- Reason → ghi quyết định vào `mail_context/decisions.json`

## Files quan trọng

| Path | Mục đích |
|---|---|
| `state.json` | Persistent state |
| `inbox.json` | Claude dump kết quả pagination inbox |
| `threads_to_fetch.json` | Prelude xác định thread nào cần get_thread |
| `thread_cache/<id>.json` | Claude dump raw thread (1 file/thread) |
| `mail_context/threads_to_triage.md` | Context cho triage decisions |
| `mail_context/pending_done_checks.md` | Context cho done check |
| `mail_context/unsnooze_checks.md` | Context cho un-snooze check |
| `mail_context/_run_index.json` | Meta cho finale (deterministic decisions từ prelude) |
| `mail_context/decisions.json` | **Claude ghi quyết định vào đây** |
| `discord_output.txt` | Finale ghi nội dung gửi Discord |

## Pipeline 6 bước

### Bước 1 — Paginate Gmail inbox

```
gmail.search_threads(query="in:inbox newer_than:30d -in:draft", pageSize=50)
```

Lặp với `pageToken` đến hết (max 20 page = 1000 thread).

Gom kết quả thành array `[{threadId, latestMessageId}, ...]` và ghi vào `inbox.json`:
```bash
python -c "import json; json.dump([...], open('inbox.json','w'), ensure_ascii=False)"
```

### Bước 2 — Diff vs state

```bash
python mail_prelude.py scan inbox.json
```

Output `threads_to_fetch.json` — list thread cần `get_thread`.

### Bước 3 — Fetch threads

Với mỗi `thread_id` trong `threads_to_fetch.json`:

```
gmail.get_thread(threadId=<id>)
```

Lưu raw response vào `thread_cache/<id>.json`.

### Bước 4 — Prepare markdown context

```bash
python mail_prelude.py prepare
```

Sinh:
- `mail_context/threads_to_triage.md` (nếu có thread cần triage)
- `mail_context/pending_done_checks.md` (nếu có pending action cần check done)
- `mail_context/unsnooze_checks.md` (nếu có thread skip có message mới)
- `mail_context/_run_index.json` (cho finale)
- `mail_context/decisions.json` (template rỗng để fill)

Nếu cả 3 file `.md` đều không tồn tại → không có gì cần reason, nhảy thẳng Bước 6.

### Bước 5 — Claude reason

**Cho mỗi file `.md` tồn tại trong `mail_context/`:**

1. Read full file
2. Reason theo guidance trong preamble của file
3. Append quyết định vào array tương ứng trong `mail_context/decisions.json`

**3 array trong `decisions.json`:**

```json
{
  "triage_decisions": [
    {
      "thread_id": "abc",
      "actions": [
        {
          "action_type": "reply | push_member | external_action | info",
          "priority": "red | yellow | green",
          "expected_sender_hint": "michael | <email> | non-vti | null",
          "action_desc": "...",
          "content_summary": "...",
          "trigger_message_id": "..."
        }
      ]
    }
  ],
  "done_decisions": [
    {
      "action_id": "xyz",
      "done": true,
      "done_by_message_id": "msg_id or null",
      "updated_content_summary": "(nếu done=false)",
      "reasoning": "..."
    }
  ],
  "unsnooze_decisions": [
    {
      "thread_id": "abc",
      "should_unsnooze": false,
      "trigger_message_id": null,
      "trigger_summary": null,
      "reasoning": "..."
    }
  ]
}
```

**Lưu ý quan trọng khi reason:**

- **Hard rules ở triage preamble override mọi suy luận.** Áp dụng trước.
- **Đọc message[-1] (tin cuối)** để xác định ai đang chờ ai. KHÔNG dùng message[0].
- **Nếu Michael là sender của tin cuối → Michael đã reply.** Không tạo action `reply` cho Michael nữa. Có thể tạo `push_member` external nếu Michael vừa gửi và chờ khách.
- **Done check**: đọc nội dung, KHÔNG nhìn ai gửi. Ack "sẽ gửi" ≠ done.
- **Un-snooze**: chỉ bật lại theo dõi nếu có yêu cầu/cam kết/thông tin mới. Reply lịch sự không đủ.
- **Thread có NHIỀU action song song được** (vd vừa chờ member gửi BQ, vừa chờ khách trả câu khác).
- **Không tạo action trùng** với "Existing actions" đã list trong preamble.

### Bước 6 — Apply + Send

```bash
python mail_finale.py run
```

(Hoặc tách: `python mail_finale.py apply` rồi `python mail_finale.py send`.)

Finale sẽ:
- Validate `decisions.json` schema → dừng nếu sai
- Apply deterministic decisions từ `_run_index.json` (skip changes, no_new_msg, tier1_auto)
- Apply Claude's decisions
- Update state, save
- Build `discord_output.txt`
- POST curl lên webhook

### Khi không có gì mới

Nếu prelude không sinh ra file markdown nào VÀ không có pending action mới VÀ không có un-snooze → finale vẫn chạy được, sẽ gửi `_Không có gì mới._` lên Discord.

## Tóm tắt command sequence

```bash
# Bước 1: Claude pagination Gmail → inbox.json (dùng MCP)
# Bước 2:
python mail_prelude.py scan inbox.json

# Bước 3: Claude get_thread từng id → thread_cache/<id>.json (dùng MCP)
# Bước 4:
python mail_prelude.py prepare

# Bước 5: Claude đọc mail_context/*.md → ghi decisions.json
# Bước 6:
python mail_finale.py run
```

## Setup ban đầu (1 lần)

1. Tạo label Gmail tên `Claude/Skip` (Michael apply lên thread để skip).
2. `python mail_prelude.py init`

## Debug

- Pipeline lỗi giữa chừng? `python mail_finale.py diff` để so output mới vs lần trước.
- Cache cần reset? `python mail_prelude.py clear`.
- Discord webhook lỗi? Check `run.log`. **KHÔNG gửi test message** lên Discord khi debug.

## Tuyệt đối tránh

- ❌ Gửi message test ("test", "ok", dấu chấm…) lên Discord
- ❌ Tự build prompt rồi gọi LLM API riêng (đã có markdown context, Claude reason inline)
- ❌ Bỏ qua hard rules ở triage preamble (Michael identity, HR/system filter)
- ❌ Reason mà không đọc full file `.md` (sẽ miss context)
