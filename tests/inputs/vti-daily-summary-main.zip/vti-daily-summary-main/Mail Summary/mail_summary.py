#!/usr/bin/env python3
"""mail_summary.py — deterministic engine for hourly-mail-summary scheduled task.

Goal: same inputs → same outputs across every run. Everything that can be
coded (state I/O, migration, sorting, grouping, Discord formatting/send,
Tier-1 auto-sender classification) lives here. Only genuine judgment
(un-snooze, done-check, full-thread triage) requires LLM, and those use
FROZEN prompt templates in PROMPTS plus a fingerprint cache so identical
inputs reuse the same answer.

Pipeline (orchestrated by SKILL.md):
    1. Claude paginates inbox     → writes inbox.json
    2. python mail_summary.py classify_inbox inbox.json
                                  → outputs threads_to_fetch.json
    3. Claude calls get_thread for each → saves to thread_cache/<id>.json
    4. python mail_summary.py prepare
                                  → writes manifest.json with Tier-1 auto-handled
                                    and a list of LLM judgments needed
    5. Claude answers each judgment → judgments.json
    6. python mail_summary.py apply judgments.json
                                  → merges into state, writes discord_output.txt
    7. python mail_summary.py send
                                  → POSTs to Discord webhook via curl
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PROJECT_DIR = Path(__file__).resolve().parent
STATE_PATH = PROJECT_DIR / "state.json"
THREAD_CACHE_DIR = PROJECT_DIR / "thread_cache"
INBOX_PATH = PROJECT_DIR / "inbox.json"
MANIFEST_PATH = PROJECT_DIR / "manifest.json"
JUDGMENTS_PATH = PROJECT_DIR / "judgments.json"
JUDGMENT_CACHE_PATH = PROJECT_DIR / "judgment_cache.json"
DISCORD_OUTPUT_PATH = PROJECT_DIR / "discord_output.txt"
RUN_LOG_PATH = PROJECT_DIR / "run.log"
LAST_OUTPUT_PATH = PROJECT_DIR / "last_output.txt"

DISCORD_WEBHOOK = (
    "https://discord.com/api/webhooks/1503692385824149544/"
    "m4HNatodLO5vekEJOXXdhg_h5SBHruc-ThRHN__LAtXbYQZ_caq02cR582UkQKZ0MlXW"
)

VTI_DOMAIN = "@vti.com.vn"
MICHAEL_EMAILS = {"anh.nguyentruongviet@vti.com.vn", "michael.nguyen@vti.com.vn"}
SKIP_LABEL = "Claude/Skip"
GMAIL_LINK = "https://mail.google.com/mail/mu/mp/751/#cv/Inbox/{thread_id}"
LOCAL_TZ = timezone(timedelta(hours=7))

PROCESSED_LIMIT = 500
PENDING_LIMIT = 50
DISCORD_CHUNK_BYTES = 1900

PROMPT_VERSION = "v1.1"  # bumped 2026-05-15: hard rules cho Michael identity + filter HR/vbs/vms

# ---------------------------------------------------------------------------
# FROZEN PROMPT TEMPLATES (bump PROMPT_VERSION when changing any of these)
# ---------------------------------------------------------------------------

PROMPTS: dict[str, str] = {
    "unsnooze_check": (
        "Thread này đã được Michael đánh dấu skip — không muốn theo dõi nữa.\n"
        "\n"
        "Tóm tắt thread trước khi skip:\n"
        "{prior_summary}\n"
        "\n"
        "Message mới sau khi skip (theo thứ tự thời gian):\n"
        "{new_messages_block}\n"
        "\n"
        "Có message nào ĐỦ QUAN TRỌNG để bật lại theo dõi không?\n"
        "- Quan trọng: yêu cầu mới, cam kết mới, thông tin mới, điều khoản, deadline, "
        "thay đổi scope.\n"
        "- KHÔNG quan trọng: 'cảm ơn', 'ok', 'đã nhận', reply lịch sự, tiếp nối chuyện cũ.\n"
        "\n"
        "Trả lời CHỈ một JSON object, không markdown, không text thừa:\n"
        '{{"should_unsnooze": <bool>, '
        '"trigger_message_id": "<id>", '
        '"trigger_summary": "<một câu>", '
        '"reasoning": "<một câu>"}}'
    ),
    "done_check": (
        "Action đang chờ: {action_desc}\n"
        "Loại: {action_type}\n"
        "\n"
        "Trigger từ message:\n"
        "  Sender: {trigger_sender}\n"
        "  Nội dung: {trigger_body}\n"
        "\n"
        "Message mới trong thread (theo thứ tự thời gian):\n"
        "{new_messages_block}\n"
        "\n"
        "Action trên đã THỰC SỰ HOÀN THÀNH chưa?\n"
        "- Hoàn thành = nội dung được giao đã được thực hiện. Vd 'gửi báo giá' = "
        "báo giá đã GỬI (file/nội dung), KHÔNG phải chỉ ack 'sẽ gửi'.\n"
        "- Auto-reply 'out of office' KHÔNG tính.\n"
        "- Reply lịch sự 'đã nhận, sẽ xem' KHÔNG tính nếu action yêu cầu output cụ thể.\n"
        "\n"
        "Trả lời CHỈ một JSON object, không markdown, không text thừa:\n"
        '{{"done": <bool>, '
        '"done_by_message_id": "<id hoặc null>", '
        '"updated_content_summary": "<tóm tắt mới phản ánh diễn biến, dùng nếu done=false>", '
        '"reasoning": "<một câu>"}}'
    ),
    "triage_full": (
        "Bạn đang giúp Michael (VTI APAC) phân loại 1 thread email.\n"
        "Email của Michael: {michael_emails}\n"
        "Domain nội bộ VTI: {vti_domain}\n"
        "\n"
        "============================================================\n"
        "RULE CỨNG — ÁP DỤNG TRƯỚC KHI READ THREAD (override mọi suy luận):\n"
        "============================================================\n"
        "\n"
        "[RULE 1] MICHAEL KHÔNG BAO GIỜ LÀ push_member TARGET\n"
        "Michael CHÍNH LÀ user — KHÔNG phải member để push. Mọi tình huống mà người\n"
        "khác đang chờ Michael trả lời / xử lý / quyết định → BẮT BUỘC `reply`,\n"
        "TUYỆT ĐỐI KHÔNG `push_member` với hint = email của Michael.\n"
        "Cụ thể: nếu `expected_sender_hint` định gán bằng anh.nguyentruongviet@vti.com.vn\n"
        "hoặc michael.nguyen@vti.com.vn, hoặc nội dung gọi 'Việt Anh ơi', '@Michael',\n"
        "'@Anh', '@Việt Anh', '@VietAnh', 'nhờ Việt Anh', 'nhờ Michael' — chuyển thành\n"
        "action_type = `reply`, expected_sender_hint = `michael`.\n"
        "Why: Michael là chính chủ tài khoản; push_member nghĩa là nhắc người khác làm việc.\n"
        "Không thể nhắc chính Michael bằng push_member — đó là việc Michael phải tự làm.\n"
        "\n"
        "[RULE 2] MAIL HỆ THỐNG / HR NỘI BỘ → LUÔN `info`, KHÔNG action\n"
        "Sender hoặc thread thuộc một trong các nhóm sau → BẮT BUỘC action_type = `info`,\n"
        "KHÔNG bao giờ `reply` hay `push_member`:\n"
        "  · vbs@vti…, vms@vti…, hoặc bất kỳ alias system VTI nào (vbs.*, vms.*, @vbs.*,\n"
        "    @vms.*) — đây là broadcast hệ thống, không có người thực nào chờ phản hồi.\n"
        "  · hr@vti.*, vti.hr@*, vti-hr@*, hr.vti@*, @hr.vti.* — mailbox HR nội bộ.\n"
        "    Bao gồm: lương, chấm công, chính sách phúc lợi, training, sinh nhật, party,\n"
        "    nội quy, khảo sát, KPI form, employee handbook, leave request reminder, v.v.\n"
        "  · NGOẠI LỆ HR: ngay cả khi là 'BAN HÀNH QUY ĐỊNH', 'QUYẾT ĐỊNH CẤP CÔNG TY',\n"
        "    'CÔNG VĂN', 'CHỈ THỊ', 'THÔNG BÁO TỪ BAN LÃNH ĐẠO' — vẫn là `info`. Có thể\n"
        "    nâng priority lên `red` nếu quy định/quyết định ảnh hưởng trực tiếp Michael\n"
        "    (deadline tuân thủ, ký nhận, ...), nhưng KHÔNG đổi action_type.\n"
        "Why: HR/system mail là broadcast, không có loop chờ-phản hồi thực sự. Đẩy lên\n"
        "thành reply/push_member sẽ làm nhiễu Discord summary mỗi giờ.\n"
        "\n"
        "============================================================\n"
        "Thread '{subject}' — đọc theo thứ tự thời gian:\n"
        "============================================================\n"
        "{messages_block}\n"
        "\n"
        "Action đã có trên thread này (KHÔNG tạo trùng):\n"
        "{existing_actions_block}\n"
        "\n"
        "============================================================\n"
        "QUY TRÌNH PHÂN LOẠI (đi tuần tự, không skip):\n"
        "============================================================\n"
        "\n"
        "BƯỚC A — Kiểm tra RULE CỨNG ở trên. Nếu match → output theo rule, dừng.\n"
        "\n"
        "BƯỚC B — Xác định trạng thái hiện tại (dùng MESSAGE CUỐI của thread):\n"
        "  · Sender của message cuối là ai (Michael / VTI member khác / external)?\n"
        "  · TO / CC của message cuối có Michael không?\n"
        "  · Nội dung message cuối là gì (câu hỏi, cam kết, ack, attachment, FYI)?\n"
        "  Lưu ý: Action phải dựa trên `messages[-1]` (tin cuối), KHÔNG phải `messages[0]`.\n"
        "  Nếu Michael là sender của tin cuối → Michael đã reply → KHÔNG tạo action `reply`\n"
        "  cho Michael nữa, có thể tạo `push_member` external (chờ khách phản hồi) nếu\n"
        "  Michael vừa gửi outbound chờ trả lời.\n"
        "\n"
        "BƯỚC C — Đọc full thread, liệt kê TẤT CẢ cặp 'chờ–phản hồi' đang treo:\n"
        "  Với mỗi cặp, xác định action_type:\n"
        "    1. Khách/đối tác chờ Michael trả lời                 → `reply`\n"
        "       expected_sender_hint = `michael`\n"
        "    2. Khách/đối tác chờ VTI member CỤ THỂ (Cuong/Kevin/Khoi/Quyen/...)\n"
        "       → `push_member`, expected_sender_hint = `email member đó`\n"
        "    3. VTI đã gửi outbound (BQ/NDA/proposal/attachment), khách CHƯA reply\n"
        "       → `push_member`, expected_sender_hint = `non-vti`\n"
        "    4. VTI member nội bộ chờ assignment được làm\n"
        "       → `push_member`, expected_sender_hint = `email người được giao`\n"
        "    5. Không ai chờ ai, chỉ FYI / broadcast                → `info`\n"
        "    6. Auto/no-reply, cần click portal / approve link    → `external_action`\n"
        "\n"
        "BƯỚC D — Áp dụng RULE 1 lần cuối:\n"
        "  Nếu BƯỚC C cho ra `push_member` với hint là một trong các email của Michael\n"
        "  ({michael_emails}) → đổi thành `reply`, hint = `michael`.\n"
        "\n"
        "============================================================\n"
        "LƯU Ý QUAN TRỌNG (không có thì sai):\n"
        "============================================================\n"
        "- Michael ở CC KHÔNG mặc định = `info`. Phải đọc loop trao đổi giữa các bên.\n"
        "- Message ack 'sẽ gửi / will send / I'll / we'll' tạo CAM KẾT — đẻ thêm action\n"
        "  chờ thực hiện cam kết đó (push_member với hint = email người cam kết).\n"
        "- 1 thread có thể có NHIỀU action song song (vừa chờ member gửi BQ, vừa chờ\n"
        "  khách trả lời câu hỏi khác).\n"
        "- Auto-reply 'out of office' KHÔNG tính là phản hồi.\n"
        "- Reply lịch sự 'đã nhận, sẽ xem' KHÔNG hoàn thành action yêu cầu output cụ thể.\n"
        "- BỎ QUA action đã có trong 'Action đã có' (cùng action_type + nội dung tương tự).\n"
        "- VTI member tên gọi thân mật trong nội bộ: Cuong = cuong.nguyenduc2,\n"
        "  Kevin = kevin.nguyen, Khoi = khoi, Quyen = quyen.nguyenthido, Dung = dung.nguyenthi,\n"
        "  Tung = tung.nguyenba, Khanh = khanh.tranduy, Tu = tu.phan (đều @vti.com.vn).\n"
        "  Việt Anh / Michael = chính Michael (xem RULE 1).\n"
        "\n"
        "Priority: `red`=khẩn (deadline trong 24h, khách gấp, blocker), `yellow`=trong\n"
        "ngày/tuần, `green`=không gấp / FYI.\n"
        "\n"
        "Trả lời CHỈ một JSON object, không markdown, không text thừa:\n"
        '{{"actions": ['
        '{{"action_type": "reply|push_member|external_action|info", '
        '"priority": "red|yellow|green", '
        '"expected_sender_hint": "<email|michael|non-vti|null>", '
        '"action_desc": "<một câu mô tả action cụ thể>", '
        '"content_summary": "<2-3 câu tóm tắt nội dung thread>", '
        '"trigger_message_id": "<id của message làm phát sinh action>"}}'
        "]}}\n"
        "Nếu thread không có action nào → trả `{{\"actions\": []}}`."
    ),
}

# ---------------------------------------------------------------------------
# Tier-1 auto-sender classifier
# ---------------------------------------------------------------------------

AUTO_SENDER_PATTERNS = [
    r"^no[-_.]?reply@",
    r"^do[-_.]?not[-_.]?reply@",
    r"^notifications?@",
    r"^mailer[-_]daemon@",
    r"^alert(s)?@",
    r"^postmaster@",
    r"^bounce@",
    r"^digest@",
    r"@github\.com$",
    r"@(.*\.)?notifications?\.github\.com$",
    r"@atlassian\.(net|com)$",
    r"@.*\.atlassian\.net$",
    r"@confluence\..*$",
    r"@slack\.com$",
    r"@accounts\.google\.com$",
    r"@apps\.google\.com$",
    r"@docs\.google\.com$",
    r"@meet\.google\.com$",
    r"@calendar-notification\.google\.com$",
    r"@google\.com$",
    r"@microsoft\.com$",
    r"@.*\.microsoftonline\.com$",
    r"@notion\.so$",
    r"@figma\.com$",
    r"@linear\.app$",
    r"@asana\.com$",
    r"@zoom\.us$",
    r"@dropbox\.com$",
    r"@stripe\.com$",
    r"@paypal\.com$",
    r"@medium\.com$",
    r"@linkedin\.com$",
    # VTI internal system aliases — không bao giờ là action item của Michael.
    # vbs/vms là alias system của VTI gửi notification nội bộ.
    # vti.hr / hr@vti là mailbox HR — gửi thông báo nhân sự / chính sách / quy định.
    r"^vbs@",
    r"^vms@",
    r"^vbs\.",
    r"^vms\.",
    r"@vbs\.",
    r"@vms\.",
    r"^hr@vti\.",
    r"^vti\.hr@",
    r"^vti-hr@",
    r"^hr\.vti@",
    r"@hr\.vti\.",
    r"@vti\.hr$",
]
AUTO_SENDER_RE = re.compile("|".join(AUTO_SENDER_PATTERNS), re.IGNORECASE)


def is_auto_sender(email: str) -> bool:
    return bool(email and AUTO_SENDER_RE.search(email.strip()))


# ---------------------------------------------------------------------------
# State migration & I/O
# ---------------------------------------------------------------------------


def _empty_state() -> dict:
    return {
        "processed_threads": {},
        "pending_actions": [],
        "skipped_threads": {},
        "last_run_at": None,
    }


def migrate_state(state: dict) -> dict:
    s = dict(state)
    if "processed_ids" in s and "processed_threads" not in s:
        s["processed_threads"] = {tid: None for tid in s.pop("processed_ids")}
    s.setdefault("processed_threads", {})
    s.setdefault("skipped_threads", {})
    migrated_pending = []
    for action in s.get("pending_actions", []) or []:
        a = dict(action)
        if "pushed_member_email" in a:
            a.setdefault("expected_sender_hint", a.pop("pushed_member_email"))
        if "expected_sender" in a:
            a.setdefault("expected_sender_hint", a.pop("expected_sender"))
        if "latest_message_id" in a:
            a.setdefault("trigger_message_id", a.pop("latest_message_id"))
        a.pop("last_processed_message", None)
        a.setdefault("action_id", _short_id())
        a.setdefault("reminder_count", 0)
        a.setdefault("flagged_at", _now_iso())
        a.setdefault("unsnooze_reason", None)
        a.setdefault("content_summary", "")
        a.setdefault("subject", "")
        a.setdefault("sender", "")
        a.setdefault("action_type", "reply")
        a.setdefault("action_desc", "")
        a.setdefault("expected_sender_hint", None)
        a.setdefault("priority", "yellow")
        migrated_pending.append(a)
    s["pending_actions"] = migrated_pending
    s.setdefault("last_run_at", None)
    return s


def load_state() -> dict:
    if not STATE_PATH.exists():
        return _empty_state()
    with STATE_PATH.open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return migrate_state(raw)


def save_state(state: dict) -> None:
    processed = state.get("processed_threads", {})
    if len(processed) > PROCESSED_LIMIT:
        items = sorted(processed.items(), key=lambda kv: (kv[1] or kv[0]), reverse=True)[:PROCESSED_LIMIT]
        state["processed_threads"] = dict(items)
    pending = state.get("pending_actions", [])
    if len(pending) > PENDING_LIMIT:
        pending = sorted(pending, key=lambda a: a.get("flagged_at", ""), reverse=True)[:PENDING_LIMIT]
        state["pending_actions"] = pending
    tmp = STATE_PATH.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2, sort_keys=True)
    tmp.replace(STATE_PATH)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now() -> datetime:
    return datetime.now(LOCAL_TZ)


def _now_iso() -> str:
    return _now().strftime("%Y-%m-%dT%H:%M:%S")


def _short_id() -> str:
    return uuid.uuid4().hex[:12]


def _log(msg: str) -> None:
    line = f"[{_now_iso()}] {msg}"
    print(line, file=sys.stderr)
    try:
        with RUN_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def _fingerprint(prompt: str, *extra: str) -> str:
    h = hashlib.sha256()
    h.update(PROMPT_VERSION.encode("utf-8"))
    h.update(b"\x1f")
    h.update(prompt.encode("utf-8"))
    for x in extra:
        h.update(b"\x1f")
        h.update(x.encode("utf-8"))
    return h.hexdigest()[:16]


def _load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _dump_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
    tmp.replace(path)


# ---------------------------------------------------------------------------
# Thread parsing
# ---------------------------------------------------------------------------


def parse_address(raw: str | None) -> tuple[str, str]:
    if not raw:
        return "", ""
    raw = raw.strip()
    m = re.match(r"^(.*?)<([^>]+)>\s*$", raw)
    if m:
        name = m.group(1).strip().strip('"').strip("'").strip()
        email = m.group(2).strip().lower()
        return name, email
    return "", raw.lower()


def parse_thread(thread_data: dict) -> dict:
    tid = thread_data.get("id") or thread_data.get("threadId") or ""
    messages_raw = thread_data.get("messages") or []
    parsed_msgs = []
    has_unread = False
    has_skip = False
    subject = ""
    for msg in messages_raw:
        mid = msg.get("id") or ""
        from_raw = msg.get("from") or msg.get("From") or msg.get("sender") or ""
        from_name, from_email = parse_address(from_raw)
        to_field = msg.get("to") or msg.get("To") or msg.get("toRecipients") or []
        if isinstance(to_field, str):
            to_field = [to_field]
        to_emails = [parse_address(t)[1] for t in to_field if t]
        cc_field = msg.get("cc") or msg.get("Cc") or msg.get("ccRecipients") or []
        if isinstance(cc_field, str):
            cc_field = [cc_field]
        cc_emails = [parse_address(c)[1] for c in cc_field if c]
        ts = msg.get("internalDate") or msg.get("date") or msg.get("ts") or ""
        body = msg.get("body") or msg.get("text") or msg.get("plainBody") or ""
        snippet = msg.get("snippet") or ""
        if not subject:
            subject = msg.get("subject") or ""
        labels = msg.get("labelIds") or msg.get("labels") or []
        if any(str(lb).upper() == "UNREAD" for lb in labels):
            has_unread = True
        if any(str(lb) == SKIP_LABEL or str(lb).lower().endswith("/skip") for lb in labels):
            has_skip = True
        parsed_msgs.append(
            {
                "id": mid,
                "ts": str(ts),
                "from_name": from_name,
                "from_email": from_email,
                "to_emails": to_emails,
                "cc_emails": cc_emails,
                "body": body,
                "snippet": snippet,
            }
        )
    thread_labels = thread_data.get("labelIds") or thread_data.get("labels") or []
    if any(str(lb) == SKIP_LABEL or str(lb).lower().endswith("/skip") for lb in thread_labels):
        has_skip = True
    if not subject:
        subject = thread_data.get("subject") or ""
    return {
        "id": tid,
        "subject": subject,
        "messages": parsed_msgs,
        "latest_message_id": parsed_msgs[-1]["id"] if parsed_msgs else "",
        "has_unread": has_unread,
        "has_skip_label": has_skip,
    }


def _load_thread_objs() -> dict[str, dict]:
    objs: dict[str, dict] = {}
    if not THREAD_CACHE_DIR.exists():
        return objs
    for f in sorted(THREAD_CACHE_DIR.glob("*.json")):
        try:
            with f.open("r", encoding="utf-8") as fp:
                raw = json.load(fp)
            t = parse_thread(raw)
            if t["id"]:
                objs[t["id"]] = t
        except Exception as e:
            _log(f"skip thread cache {f}: {e}")
    return objs


# ---------------------------------------------------------------------------
# classify_inbox
# ---------------------------------------------------------------------------


def cmd_classify_inbox(args: list[str]) -> int:
    if not args:
        print("usage: classify_inbox <inbox.json>", file=sys.stderr)
        return 2
    inbox_path = Path(args[0])
    with inbox_path.open("r", encoding="utf-8") as f:
        inbox = json.load(f)
    state = load_state()
    processed = state.get("processed_threads", {})
    pending_thread_ids = {a["thread_id"] for a in state.get("pending_actions", [])}
    skipped_thread_ids = set(state.get("skipped_threads", {}).keys())
    to_fetch: list[str] = []
    seen: set[str] = set()
    for item in inbox:
        tid = item.get("threadId") or item.get("id")
        latest = item.get("latestMessageId") or item.get("historyId") or ""
        if not tid:
            continue
        seen.add(tid)
        if tid in skipped_thread_ids or tid not in processed or processed[tid] != latest:
            to_fetch.append(tid)
    for tid in pending_thread_ids | skipped_thread_ids:
        if tid not in seen and tid not in to_fetch:
            to_fetch.append(tid)
    deduped: list[str] = []
    seen2: set[str] = set()
    for tid in to_fetch:
        if tid not in seen2:
            seen2.add(tid)
            deduped.append(tid)
    out_path = PROJECT_DIR / "threads_to_fetch.json"
    _dump_json(out_path, {"thread_ids": deduped, "total_inbox": len(inbox)})
    _log(f"classify_inbox: {len(inbox)} in inbox, {len(deduped)} need fetch")
    print(json.dumps({"thread_ids": deduped, "total_inbox": len(inbox)}, ensure_ascii=False))
    return 0


# ---------------------------------------------------------------------------
# prepare
# ---------------------------------------------------------------------------


def _msg_index(messages: list[dict], msg_id: str) -> int:
    for i, m in enumerate(messages):
        if m["id"] == msg_id:
            return i
    return -1


def _format_messages(messages: list[dict], limit_chars: int = 2000) -> str:
    lines = []
    for m in messages:
        body = (m["body"] or m["snippet"] or "").strip()
        if len(body) > limit_chars:
            body = body[:limit_chars] + " […truncated…]"
        sender_disp = m["from_name"] or m["from_email"]
        lines.append(
            f"--- msg {m['id']} | from: {sender_disp} <{m['from_email']}> | ts: {m['ts']} ---\n"
            f"{body}"
        )
    return "\n\n".join(lines)


def _is_internal(thread: dict) -> bool:
    for m in thread["messages"]:
        for addr in [m["from_email"], *m["to_emails"], *m["cc_emails"]]:
            if addr and not addr.endswith(VTI_DOMAIN):
                return False
    return True


def _company_name_from_thread(thread: dict | None) -> str:
    if thread:
        for m in thread["messages"]:
            for addr in [m["from_email"], *m["to_emails"], *m["cc_emails"]]:
                if addr and not addr.endswith(VTI_DOMAIN):
                    return addr.split("@", 1)[-1].upper()
    return "KHÁC"


def _summarize_prior(messages: list[dict], up_to_index: int) -> str:
    parts = []
    for m in messages[: up_to_index + 1]:
        sender = m["from_name"] or m["from_email"]
        snippet = (m["body"] or m["snippet"] or "").strip().replace("\n", " ")
        if len(snippet) > 200:
            snippet = snippet[:200] + "…"
        parts.append(f"  · {sender}: {snippet}")
    return "\n".join(parts) if parts else "(không có message trước skip)"


def _format_existing_actions(pending: list[dict], thread_id: str) -> str:
    actions = [a for a in pending if a["thread_id"] == thread_id]
    if not actions:
        return "(chưa có)"
    return "\n".join(
        f"  · [{a['action_type']}] {a['action_desc']} (hint: {a.get('expected_sender_hint')})"
        for a in actions
    )


def cmd_prepare(args: list[str]) -> int:
    state = load_state()
    cache = _load_json(JUDGMENT_CACHE_PATH, {"answers": {}})
    cached_answers = cache.get("answers", {})

    run_started_at = _now_iso()
    pending = state["pending_actions"]
    skipped = state["skipped_threads"]
    processed = state["processed_threads"]

    thread_objs = _load_thread_objs()

    # Skip-label handling
    skip_changes: dict[str, Any] = {
        "remove_from_skipped": [],
        "newly_skipped": [],
        "stay_skipped": [],
    }
    unsnooze_judgments: list[dict] = []

    threads_to_inspect_for_skip = (
        set(skipped.keys())
        | {a["thread_id"] for a in pending}
        | set(thread_objs.keys())
    )

    for tid in sorted(threads_to_inspect_for_skip):
        t = thread_objs.get(tid)
        if not t:
            _log(f"skip-label check: thread {tid} not in cache, skipping (will retry)")
            continue
        has_label = t["has_skip_label"]
        was_skipped = tid in skipped
        if has_label and not was_skipped:
            skip_changes["newly_skipped"].append(
                {
                    "thread_id": tid,
                    "skipped_at": run_started_at,
                    "skipped_at_message_id": t["latest_message_id"],
                    "subject": t["subject"],
                }
            )
        elif has_label and was_skipped:
            anchor = skipped[tid].get("skipped_at_message_id")
            idx = _msg_index(t["messages"], anchor) if anchor else -1
            new_msgs = t["messages"][idx + 1 :] if idx >= 0 else []
            if not new_msgs:
                skip_changes["stay_skipped"].append({"thread_id": tid})
            else:
                prior_summary = _summarize_prior(t["messages"], idx)
                new_block = _format_messages(new_msgs)
                prompt = PROMPTS["unsnooze_check"].format(
                    prior_summary=prior_summary,
                    new_messages_block=new_block,
                )
                fp = _fingerprint(prompt, tid, new_msgs[-1]["id"])
                jid = f"unsnooze::{tid}::{new_msgs[-1]['id']}"
                unsnooze_judgments.append(
                    {
                        "judgment_id": jid,
                        "fingerprint": fp,
                        "type": "unsnooze_check",
                        "thread_id": tid,
                        "subject": t["subject"],
                        "new_messages_latest_id": new_msgs[-1]["id"],
                        "prompt": prompt,
                        "cached": fp in cached_answers,
                    }
                )
        elif (not has_label) and was_skipped:
            skip_changes["remove_from_skipped"].append({"thread_id": tid})

    # Done-check
    newly_skipped_ids = {x["thread_id"] for x in skip_changes["newly_skipped"]}
    removed_skip_ids = {x["thread_id"] for x in skip_changes["remove_from_skipped"]}
    done_judgments: list[dict] = []
    no_new_msg_decisions: list[dict] = []

    for action in pending:
        tid = action["thread_id"]
        if tid in newly_skipped_ids:
            continue
        if tid in skipped and tid not in removed_skip_ids:
            continue
        t = thread_objs.get(tid)
        if not t:
            no_new_msg_decisions.append(
                {"action_id": action["action_id"], "decision": "keep_no_new_msgs"}
            )
            continue
        trigger_idx = _msg_index(t["messages"], action.get("trigger_message_id", ""))
        new_msgs = t["messages"][trigger_idx + 1 :] if trigger_idx >= 0 else []
        if not new_msgs:
            if action["action_type"] in ("info", "external_action") and not t["has_unread"]:
                no_new_msg_decisions.append(
                    {"action_id": action["action_id"], "decision": "done_unread_cleared"}
                )
            else:
                no_new_msg_decisions.append(
                    {"action_id": action["action_id"], "decision": "keep_no_new_msgs"}
                )
            continue
        trigger_msg = t["messages"][trigger_idx] if trigger_idx >= 0 else None
        if trigger_msg:
            trigger_sender = f"{trigger_msg['from_name']} <{trigger_msg['from_email']}>"
            trigger_body = (trigger_msg["body"] or trigger_msg["snippet"] or "")[:1500]
        else:
            trigger_sender = "(không rõ)"
            trigger_body = "(không rõ)"
        prompt = PROMPTS["done_check"].format(
            action_desc=action.get("action_desc", ""),
            action_type=action.get("action_type", ""),
            trigger_sender=trigger_sender,
            trigger_body=trigger_body,
            new_messages_block=_format_messages(new_msgs),
        )
        fp = _fingerprint(prompt, action["action_id"], new_msgs[-1]["id"])
        jid = f"done::{action['action_id']}::{new_msgs[-1]['id']}"
        done_judgments.append(
            {
                "judgment_id": jid,
                "fingerprint": fp,
                "type": "done_check",
                "action_id": action["action_id"],
                "thread_id": tid,
                "subject": t["subject"],
                "new_messages_latest_id": new_msgs[-1]["id"],
                "prompt": prompt,
                "cached": fp in cached_answers,
            }
        )

    # Triage
    threads_with_new_messages: set[str] = set()
    for j in done_judgments:
        threads_with_new_messages.add(j["thread_id"])
    for j in unsnooze_judgments:
        threads_with_new_messages.add(j["thread_id"])

    triage_judgments: list[dict] = []
    tier1_auto: list[dict] = []

    for tid, t in thread_objs.items():
        if tid in newly_skipped_ids:
            continue
        if tid in skipped and tid not in removed_skip_ids:
            continue
        is_new = tid not in processed or processed[tid] != t["latest_message_id"]
        if not (is_new or tid in threads_with_new_messages):
            continue
        if not t["messages"]:
            continue
        first_msg = t["messages"][0]
        if len(t["messages"]) == 1 and is_auto_sender(first_msg["from_email"]):
            tier1_auto.append(
                {
                    "thread_id": tid,
                    "subject": t["subject"],
                    "sender_name": first_msg["from_name"] or first_msg["from_email"],
                    "sender_email": first_msg["from_email"],
                    "ts": first_msg["ts"],
                    "snippet": (first_msg["snippet"] or first_msg["body"][:200]).strip(),
                    "latest_message_id": t["latest_message_id"],
                }
            )
            continue
        existing_block = _format_existing_actions(pending, tid)
        messages_block = _format_messages(t["messages"])
        prompt = PROMPTS["triage_full"].format(
            michael_emails=" / ".join(sorted(MICHAEL_EMAILS)),
            vti_domain=VTI_DOMAIN,
            subject=t["subject"],
            messages_block=messages_block,
            existing_actions_block=existing_block,
        )
        fp = _fingerprint(prompt, tid, t["latest_message_id"])
        jid = f"triage::{tid}::{t['latest_message_id']}"
        triage_judgments.append(
            {
                "judgment_id": jid,
                "fingerprint": fp,
                "type": "triage_full",
                "thread_id": tid,
                "subject": t["subject"],
                "latest_message_id": t["latest_message_id"],
                "prompt": prompt,
                "cached": fp in cached_answers,
            }
        )

    manifest = {
        "prompt_version": PROMPT_VERSION,
        "run_started_at": run_started_at,
        "skip_changes": skip_changes,
        "no_new_msg_decisions": no_new_msg_decisions,
        "tier1_auto": tier1_auto,
        "judgments_needed": unsnooze_judgments + done_judgments + triage_judgments,
        "stats": {
            "threads_in_cache": len(thread_objs),
            "newly_skipped": len(skip_changes["newly_skipped"]),
            "unsnoozed_to_check": len(unsnooze_judgments),
            "done_checks": len(done_judgments),
            "triage_full": len(triage_judgments),
            "tier1_auto": len(tier1_auto),
            "no_new_msg_actions": len(no_new_msg_decisions),
        },
    }
    _dump_json(MANIFEST_PATH, manifest)
    _log("prepare: " + ", ".join(f"{k}={v}" for k, v in manifest["stats"].items()))
    print(json.dumps({"stats": manifest["stats"], "manifest_path": str(MANIFEST_PATH)}, ensure_ascii=False))
    return 0


# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------


def _similar(a: str, b: str) -> bool:
    na = re.sub(r"\W+", " ", a.lower()).strip()
    nb = re.sub(r"\W+", " ", b.lower()).strip()
    if not na or not nb:
        return False
    if na == nb:
        return True
    short, long_ = sorted([na, nb], key=len)
    return short in long_ and len(short) >= 8


def cmd_apply(args: list[str]) -> int:
    path = Path(args[0]) if args else JUDGMENTS_PATH
    judgments_doc = _load_json(path, {"answers": {}})
    answers: dict[str, dict] = judgments_doc.get("answers", {})

    manifest = _load_json(MANIFEST_PATH, None)
    if not manifest:
        print("manifest.json missing — run prepare first", file=sys.stderr)
        return 2

    state = load_state()
    cache = _load_json(JUDGMENT_CACHE_PATH, {"answers": {}})
    cached_answers = cache.get("answers", {})

    run_started_at = manifest["run_started_at"]
    pending = state["pending_actions"]
    skipped = state["skipped_threads"]
    processed = state["processed_threads"]

    def get_answer(item: dict) -> dict | None:
        if item["judgment_id"] in answers:
            return answers[item["judgment_id"]]
        if item["fingerprint"] in cached_answers:
            return cached_answers[item["fingerprint"]]
        return None

    thread_objs = _load_thread_objs()

    # 1. Skip changes
    newly_skipped_ids = {x["thread_id"] for x in manifest["skip_changes"]["newly_skipped"]}
    for x in manifest["skip_changes"]["newly_skipped"]:
        skipped[x["thread_id"]] = {
            "skipped_at": x["skipped_at"],
            "skipped_at_message_id": x["skipped_at_message_id"],
        }
    for x in manifest["skip_changes"]["remove_from_skipped"]:
        skipped.pop(x["thread_id"], None)
    pending = [a for a in pending if a["thread_id"] not in newly_skipped_ids]

    # 2. Un-snooze
    unsnoozed_this_run: dict[str, dict] = {}
    for item in manifest["judgments_needed"]:
        if item["type"] != "unsnooze_check":
            continue
        ans = get_answer(item)
        if not ans:
            tid = item["thread_id"]
            if tid in skipped:
                skipped[tid]["skipped_at_message_id"] = item["new_messages_latest_id"]
            continue
        if ans.get("should_unsnooze"):
            skipped.pop(item["thread_id"], None)
            unsnoozed_this_run[item["thread_id"]] = {
                "trigger_summary": ans.get("trigger_summary", ""),
                "reasoning": ans.get("reasoning", ""),
            }
        else:
            tid = item["thread_id"]
            if tid in skipped:
                skipped[tid]["skipped_at_message_id"] = item["new_messages_latest_id"]

    # 3. Done-check
    done_action_ids: set[str] = set()
    updated_summaries: dict[str, str] = {}
    for d in manifest["no_new_msg_decisions"]:
        if d["decision"] == "done_unread_cleared":
            done_action_ids.add(d["action_id"])
    for item in manifest["judgments_needed"]:
        if item["type"] != "done_check":
            continue
        ans = get_answer(item)
        if not ans:
            continue
        if ans.get("done"):
            done_action_ids.add(item["action_id"])
        else:
            new_sum = ans.get("updated_content_summary")
            if new_sum:
                updated_summaries[item["action_id"]] = new_sum

    survived_pending: list[dict] = []
    for a in pending:
        if a["action_id"] in done_action_ids:
            continue
        a = dict(a)
        a["reminder_count"] = a.get("reminder_count", 0) + 1
        if a["action_id"] in updated_summaries:
            a["content_summary"] = updated_summaries[a["action_id"]]
        survived_pending.append(a)

    # 4. Triage answers
    new_actions: list[dict] = []
    for item in manifest["judgments_needed"]:
        if item["type"] != "triage_full":
            continue
        ans = get_answer(item)
        if not ans:
            continue
        tid = item["thread_id"]
        t = thread_objs.get(tid)
        if not t:
            continue
        for raw_action in ans.get("actions", []) or []:
            atype = raw_action.get("action_type")
            if atype not in {"reply", "push_member", "external_action", "info"}:
                continue
            similar = any(
                pa["thread_id"] == tid
                and pa["action_type"] == atype
                and _similar(pa.get("action_desc", ""), raw_action.get("action_desc", ""))
                for pa in survived_pending
            )
            if similar:
                continue
            trigger_id = raw_action.get("trigger_message_id") or t["latest_message_id"]
            sender_msg = None
            for m in t["messages"]:
                if m["id"] == trigger_id:
                    sender_msg = m
                    break
            if not sender_msg:
                sender_msg = t["messages"][-1]
            sender_email = sender_msg["from_email"]
            sender_name = sender_msg["from_name"]
            if sender_name and sender_name != sender_email:
                sender_disp = f"{sender_name} · {sender_email}"
            else:
                sender_disp = sender_email
            unsnooze_info = unsnoozed_this_run.get(tid)
            new_actions.append(
                {
                    "action_id": _short_id(),
                    "thread_id": tid,
                    "subject": t["subject"],
                    "sender": sender_disp,
                    "sender_email": sender_email,
                    "sender_name": sender_name,
                    "ts": sender_msg["ts"],
                    "action_type": atype,
                    "priority": raw_action.get("priority", "yellow"),
                    "expected_sender_hint": raw_action.get("expected_sender_hint"),
                    "action_desc": raw_action.get("action_desc", ""),
                    "content_summary": raw_action.get("content_summary", ""),
                    "trigger_message_id": trigger_id,
                    "flagged_at": run_started_at,
                    "reminder_count": 0,
                    "unsnooze_reason": (
                        f"{unsnooze_info['trigger_summary']} · {unsnooze_info['reasoning']}"
                        if unsnooze_info else None
                    ),
                }
            )

    # 5. processed_threads
    for tid, t in thread_objs.items():
        if t["latest_message_id"]:
            processed[tid] = t["latest_message_id"]

    # 6. Cache judgments
    for item in manifest["judgments_needed"]:
        ans = answers.get(item["judgment_id"])
        if ans is not None:
            cached_answers[item["fingerprint"]] = ans
    cache["answers"] = cached_answers
    cache["prompt_version"] = PROMPT_VERSION
    _dump_json(JUDGMENT_CACHE_PATH, cache)

    # 7. Save state
    state["pending_actions"] = survived_pending + new_actions
    state["skipped_threads"] = skipped
    state["processed_threads"] = processed
    state["last_run_at"] = run_started_at
    save_state(state)

    # 8. Discord output
    output_text = build_discord_output(
        state=state,
        tier1_auto=manifest["tier1_auto"],
        new_actions=new_actions,
        survived_pending=survived_pending,
        unsnoozed=unsnoozed_this_run,
        run_started_at=run_started_at,
        thread_objs=thread_objs,
    )
    DISCORD_OUTPUT_PATH.write_text(output_text, encoding="utf-8")
    _log(
        f"apply: pending kept={len(survived_pending)}, new={len(new_actions)}, "
        f"unsnoozed={len(unsnoozed_this_run)}, tier1={len(manifest['tier1_auto'])}"
    )
    print(
        json.dumps(
            {
                "pending_kept": len(survived_pending),
                "new_actions": len(new_actions),
                "unsnoozed": len(unsnoozed_this_run),
                "tier1_auto": len(manifest["tier1_auto"]),
                "discord_output": str(DISCORD_OUTPUT_PATH),
            },
            ensure_ascii=False,
        )
    )
    return 0


# ---------------------------------------------------------------------------
# Discord formatting
# ---------------------------------------------------------------------------

PRIORITY_RANK = {"red": 0, "yellow": 1, "green": 2}
PRIORITY_EMOJI = {"red": "🔴", "yellow": "🟡", "green": "🟢"}


def _fmt_ts(ts_str: str) -> str:
    if not ts_str:
        return ""
    try:
        n = int(ts_str)
        dt = datetime.fromtimestamp(n / 1000, tz=LOCAL_TZ)
        return dt.strftime("%H:%M")
    except (ValueError, TypeError):
        pass
    try:
        dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).astimezone(LOCAL_TZ)
        return dt.strftime("%H:%M")
    except ValueError:
        return ts_str[:5] if len(ts_str) >= 5 else ts_str


def _fmt_date_short(iso_ts: str) -> str:
    try:
        if "T" in iso_ts:
            dt = datetime.fromisoformat(iso_ts)
        else:
            dt = datetime.fromisoformat(iso_ts)
        return dt.strftime("%d/%m %H:%M")
    except (ValueError, AttributeError):
        return iso_ts


def _action_is_customer(action: dict, thread: dict | None) -> bool:
    se = (action.get("sender_email") or "").lower()
    if se and not se.endswith(VTI_DOMAIN):
        return True
    if thread:
        return not _is_internal(thread)
    hint = (action.get("expected_sender_hint") or "").lower()
    return hint == "non-vti"


def _company_name_from_action(action: dict, thread: dict | None) -> str:
    name = _company_name_from_thread(thread)
    if name != "KHÁC":
        return name
    se = (action.get("sender_email") or "").lower()
    if se and "@" in se:
        return se.split("@", 1)[-1].upper()
    return "KHÁC"


def _parse_ts_for_sort(ts: str) -> int:
    try:
        return int(ts)
    except (ValueError, TypeError):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            return int(dt.timestamp() * 1000)
        except (ValueError, AttributeError):
            return 0


def _sort_actions(actions: list[dict]) -> list[dict]:
    return sorted(
        actions,
        key=lambda a: (
            PRIORITY_RANK.get(a.get("priority", "yellow"), 1),
            -a.get("reminder_count", 0),
            -_parse_ts_for_sort(a.get("ts", "")),
            a.get("action_id", ""),
        ),
    )


def _action_label(action: dict) -> str:
    atype = action.get("action_type", "")
    hint = action.get("expected_sender_hint") or ""
    if atype == "push_member" and hint and hint != "non-vti":
        return f"push_member → {hint}"
    if atype == "push_member" and hint == "non-vti":
        return "push_member → non-vti (chờ khách phản hồi)"
    return atype


def _format_action_line(action: dict, run_started_at: str) -> str:
    pe = PRIORITY_EMOJI.get(action.get("priority", "yellow"), "🟡")
    link = GMAIL_LINK.format(thread_id=action["thread_id"])
    subject = action.get("subject", "(no subject)")
    ts = _fmt_ts(action.get("ts", ""))
    sender = action.get("sender", "")
    reminder_count = action.get("reminder_count", 0)
    is_pending_reminder = reminder_count > 0 and action.get("flagged_at") != run_started_at
    suffix = ""
    if is_pending_reminder:
        suffix = f"  *(nhắc lần {reminder_count} — flagged {_fmt_date_short(action.get('flagged_at', ''))})*"
    elif action.get("unsnooze_reason"):
        suffix = "  *(un-snooze)*"
    head = f"{pe} [{subject}]({link}){suffix}\n{sender} · {ts}"
    summary = action.get("content_summary", "").strip()
    action_label = _action_label(action)
    desc = action.get("action_desc", "")
    body_lines = [
        f"**Nội dung:** {summary}" if summary else "**Nội dung:** (chưa có tóm tắt)",
        f"**Action [{action_label}]:** {desc}",
    ]
    if action.get("unsnooze_reason"):
        body_lines.insert(0, f"**Lý do un-snooze:** {action['unsnooze_reason']}")
    return head + "\n" + "\n".join(body_lines)


def build_discord_output(
    state: dict,
    tier1_auto: list[dict],
    new_actions: list[dict],
    survived_pending: list[dict],
    unsnoozed: dict,
    run_started_at: str,
    thread_objs: dict[str, dict] | None = None,
) -> str:
    all_actions = survived_pending + new_actions
    if thread_objs is None:
        thread_objs = _load_thread_objs()

    customer_actions: list[dict] = []
    internal_actions: list[dict] = []
    for a in all_actions:
        t = thread_objs.get(a["thread_id"])
        if _action_is_customer(a, t):
            customer_actions.append(a)
        else:
            internal_actions.append(a)

    customer_count = len(customer_actions)
    internal_count = len(internal_actions)
    auto_count = len(tier1_auto)
    unsnooze_count = len(unsnoozed)

    try:
        dt = datetime.fromisoformat(run_started_at)
    except (ValueError, TypeError):
        dt = _now()

    header_line2 = f"Khách hàng: {customer_count}  |  Nội bộ: {internal_count}  |  Auto: {auto_count}"
    if unsnooze_count > 0:
        header_line2 += f"  |  Un-snooze: {unsnooze_count}"

    lines: list[str] = []
    lines.append(f"# MAIL SUMMARY — {dt.strftime('%H:%M %d/%m/%Y')}")
    lines.append(header_line2)
    lines.append("")

    if unsnoozed:
        lines.append("## 🔄 UN-SNOOZE — THREAD ĐÃ SKIP NAY CÓ DIỄN BIẾN MỚI")
        lines.append("")
        lines.append(
            "> ⚠️ Các thread dưới đây trước đó đã được apply label `Claude/Skip`. "
            "Hệ thống phát hiện message mới ĐỦ QUAN TRỌNG nên bật lại theo dõi.\n"
            "> Nếu vẫn không muốn theo dõi, apply lại label `Claude/Skip` lên thread."
        )
        lines.append("")
        for a in _sort_actions([a for a in new_actions if a.get("unsnooze_reason")]):
            lines.append(_format_action_line(a, run_started_at))
            lines.append("")

    if customer_actions:
        lines.append("## 🏢 KHÁCH HÀNG")
        lines.append("")
        by_company: dict[str, list[dict]] = {}
        for a in customer_actions:
            key = _company_name_from_action(a, thread_objs.get(a["thread_id"]))
            by_company.setdefault(key, []).append(a)
        sorted_companies = sorted(
            by_company.items(),
            key=lambda kv: (
                min(PRIORITY_RANK.get(a.get("priority", "yellow"), 1) for a in kv[1]),
                kv[0],
            ),
        )
        for company, actions in sorted_companies:
            lines.append(f"**{company}**")
            for a in _sort_actions(actions):
                lines.append(_format_action_line(a, run_started_at))
                lines.append("")
        lines.append("")

    if internal_actions:
        lines.append("## 👥 NỘI BỘ")
        lines.append("")
        for a in _sort_actions(internal_actions):
            lines.append(_format_action_line(a, run_started_at))
            lines.append("")

    if tier1_auto:
        lines.append("## 🤖 HỆ THỐNG / AUTO")
        for t in sorted(tier1_auto, key=lambda x: -_parse_ts_for_sort(x.get("ts", ""))):
            sender = t["sender_name"] or t["sender_email"]
            ts = _fmt_ts(t["ts"])
            snip = (t.get("snippet") or "")[:120].replace("\n", " ")
            lines.append(f"{sender} — {snip} · {ts}")
        lines.append("")

    if not (all_actions or tier1_auto or unsnoozed):
        lines.append("_Không có gì mới._")

    return "\n".join(lines).rstrip() + "\n"


# ---------------------------------------------------------------------------
# send
# ---------------------------------------------------------------------------


def cmd_send(args: list[str]) -> int:
    if not DISCORD_OUTPUT_PATH.exists():
        print("discord_output.txt missing — run apply first", file=sys.stderr)
        return 2
    text = DISCORD_OUTPUT_PATH.read_text(encoding="utf-8")
    chunks = _split_for_discord(text)
    for chunk in chunks:
        status = _send_chunk(chunk)
        if status not in (200, 204):
            _log(f"discord POST failed status={status} chunk_len={len(chunk)}")
            print(f"discord POST failed status={status}", file=sys.stderr)
            return 1
    shutil.copy(DISCORD_OUTPUT_PATH, LAST_OUTPUT_PATH)
    _log(f"sent {len(chunks)} chunks")
    print(json.dumps({"chunks_sent": len(chunks)}))
    return 0


def _split_for_discord(text: str) -> list[str]:
    lines = text.split("\n")
    chunks: list[str] = []
    cur = ""
    for line in lines:
        if len(cur) + len(line) + 1 > DISCORD_CHUNK_BYTES:
            if cur.strip():
                chunks.append(cur)
            cur = ""
        cur += line + "\n"
    if cur.strip():
        chunks.append(cur)
    return chunks


def _send_chunk(content: str) -> int:
    payload = json.dumps({"content": content})
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
        f.write(payload)
        tmp_path = f.name
    try:
        result = subprocess.run(
            [
                "curl", "-s", "-o", os.devnull, "-w", "%{http_code}",
                "-X", "POST", DISCORD_WEBHOOK,
                "-H", "Content-Type: application/json",
                "--data-binary", f"@{tmp_path}",
            ],
            capture_output=True, text=True, timeout=30,
        )
        try:
            return int(result.stdout.strip() or "0")
        except ValueError:
            return -1
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# misc
# ---------------------------------------------------------------------------


def cmd_init(args: list[str]) -> int:
    THREAD_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    state = load_state()
    save_state(state)
    print(
        json.dumps(
            {
                "state_path": str(STATE_PATH),
                "pending_count": len(state["pending_actions"]),
                "processed_count": len(state["processed_threads"]),
                "skipped_count": len(state["skipped_threads"]),
                "last_run_at": state.get("last_run_at"),
                "prompt_version": PROMPT_VERSION,
            },
            ensure_ascii=False,
        )
    )
    return 0


def cmd_clear_cache(args: list[str]) -> int:
    if THREAD_CACHE_DIR.exists():
        for f in THREAD_CACHE_DIR.glob("*.json"):
            f.unlink()
    for p in [MANIFEST_PATH, JUDGMENTS_PATH, DISCORD_OUTPUT_PATH]:
        if p.exists():
            p.unlink()
    print("cleared thread_cache + manifest + judgments + discord_output")
    return 0


def cmd_diff_last(args: list[str]) -> int:
    if not LAST_OUTPUT_PATH.exists():
        print("no previous output")
        return 0
    if not DISCORD_OUTPUT_PATH.exists():
        print("no current output (run apply first)")
        return 2
    a = LAST_OUTPUT_PATH.read_text(encoding="utf-8").splitlines()
    b = DISCORD_OUTPUT_PATH.read_text(encoding="utf-8").splitlines()
    import difflib
    diff = list(difflib.unified_diff(a, b, fromfile="last_output", tofile="discord_output", lineterm=""))
    if not diff:
        print("DIFF: 0 lines")
        return 0
    for line in diff:
        print(line)
    return 0


def cmd_help(args: list[str]) -> int:
    print(__doc__)
    return 0


# ---------------------------------------------------------------------------
# entrypoint
# ---------------------------------------------------------------------------

COMMANDS = {
    "init": cmd_init,
    "classify_inbox": cmd_classify_inbox,
    "prepare": cmd_prepare,
    "apply": cmd_apply,
    "send": cmd_send,
    "clear_cache": cmd_clear_cache,
    "diff_last": cmd_diff_last,
    "help": cmd_help,
    "--help": cmd_help,
    "-h": cmd_help,
}


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print(
            "usage: mail_summary.py {init|classify_inbox|prepare|apply|send|clear_cache|diff_last|help}",
            file=sys.stderr,
        )
        return 2
    cmd = sys.argv[1]
    return COMMANDS[cmd](sys.argv[2:])


if __name__ == "__main__":
    sys.exit(main())

