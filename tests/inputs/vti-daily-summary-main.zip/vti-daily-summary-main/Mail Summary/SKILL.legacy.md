BACKUP CỦA SKILL.md GỐC — backed up: 2026-05-15
============================================================
Để rollback: copy toàn bộ nội dung GIỮA hai dòng `===BEGIN===` và `===END===`,
gọi:
  update_scheduled_task(taskId="hourly-mail-summary", prompt=<nội dung copy>)
============================================================

===BEGIN===
---
name: hourly-mail-summary
description: Tóm tắt email — chạy lúc 7h, 9h, 11h, 13h, 15h, 17h mỗi ngày trong tuần
---

---
name: hourly-mail-summary
description: Tóm tắt email — chạy lúc 7h, 9h, 11h, 13h, 15h, 17h mỗi ngày trong tuần
---

## Nhiệm vụ: Mail Summary

**Discord Webhook:** `https://discord.com/api/webhooks/1503692385824149544/m4HNatodLO5vekEJOXXdhg_h5SBHruc-ThRHN__LAtXbYQZ_caq02cR582UkQKZ0MlXW`
**State file:** `C:\Users\Administrator\Documents\Claude\Projects\Mail Summary\state.json`
**Gmail link format:** `https://mail.google.com/mail/mu/mp/751/#cv/Inbox/<threadId>`
**Email của Michael:** `anh.nguyentruongviet@vti.com.vn` và `michael.nguyen@vti.com.vn`
**Domain nội bộ VTI:** `@vti.com.vn`
**Skip label:** `Claude/Skip` (Michael apply lên thread khi muốn dừng nhắc)

---

## Setup yêu cầu (1 lần)

Trong Gmail, tạo label tên `Claude/Skip`. Apply lên thread để dừng nhắc. Gỡ label để theo dõi lại.

---

## Tư duy cốt lõi

Với mỗi email mới, chỉ cần trả lời 2 câu hỏi:

1. **Email này về cái gì?** → đọc nội dung
2. **Có ai cần làm gì không?** → đọc thread cũ nếu chưa rõ context

Track action sinh ra. Mỗi lần có message mới, dùng LLM đọc **nội dung** để check action đã thực sự xong chưa — **không** dựa vào "ai gửi message". Một message từ đúng người vẫn có thể không hoàn thành action (ví dụ: chỉ ack "sẽ gửi tuần sau", chưa gửi thật).

Hết. Không thêm metadata phụ, không force re-triage định kỳ, không rule cứng — để LLM đọc context và quyết định.

---

## State schema

```json
{
  "processed_threads": {
    "threadId1": "latestMsgId1"
  },
  "pending_actions": [
    {
      "action_id": "uuid-hoặc-hash-ngắn",
      "thread_id": "abc123",
      "subject": "Tiêu đề email",
      "sender": "Tên · email",
      "action_type": "reply | push_member | external_action | info",
      "expected_sender_hint": "michael | <email cụ thể> | non-vti | null",
      "action_desc": "Mô tả action cụ thể",
      "content_summary": "Tóm tắt nội dung đầy đủ",
      "trigger_message_id": "msgIdGốc",
      "flagged_at": "2026-05-12T09:30:00",
      "reminder_count": 0,
      "unsnooze_reason": null
    }
  ],
  "skipped_threads": {
    "threadId1": {
      "skipped_at": "2026-05-12T14:00:00",
      "skipped_at_message_id": "msgIdLúcLabelĐượcĐặt"
    }
  },
  "last_run_at": "2026-05-12T14:00:00"
}
```

**`expected_sender_hint`** — chỉ là metadata mô tả "đang chờ ai" cho người đọc Discord summary. **Không** dùng làm done condition. Done check luôn là semantic.

**Migration**:
- `processed_ids` (array) → `processed_threads = {id: null for id in processed_ids}`.
- Pending cũ có `pushed_member_email` → `expected_sender_hint`.
- Pending cũ có `expected_sender` → đổi tên thành `expected_sender_hint`.
- Pending cũ có `latest_message_id` → `trigger_message_id`.
- Pending cũ có `last_processed_message` → xoá (không dùng nữa).
- Thiếu `skipped_threads` → khởi tạo `{}`.

---

## Bước 1 — Đọc state

Đọc file. Không tồn tại → tạo state rỗng. Chạy migration nếu phát hiện schema cũ.

Khởi tạo `unsnoozed_this_run = []` để track thread vừa un-snooze.

---

## Bước 2 — Xử lý skip label

Với mỗi `threadId` trong **`skipped_threads ∪ tất cả thread_id của pending_actions`**:

1. Gọi `get_thread(threadId)`, cache thread data.
2. Kiểm tra label `Claude/Skip`.

**Thread CÓ label `Claude/Skip`:**

- Chưa có trong `skipped_threads` (vừa được apply):
  - Xoá tất cả pending action của thread khỏi `pending_actions`.
  - Thêm `skipped_threads[threadId] = {skipped_at: now, skipped_at_message_id: <message cuối hiện tại>}`.
  - Bỏ qua thread ở các bước sau.

- Đã có trong `skipped_threads`:
  - `new_messages` = các message > `skipped_at_message_id`.
  - Không có `new_messages` → giữ nguyên, bỏ qua.
  - Có `new_messages` → **semantic un-snooze check**:

    > **Prompt LLM:**
    > ```
    > Thread này đã được Michael đánh dấu skip — không muốn theo dõi nữa.
    > Tóm tắt thread trước khi skip: <tóm tắt đến message skipped_at_message_id>
    >
    > Message mới sau khi skip:
    > <liệt kê new_messages — sender, timestamp, nội dung>
    >
    > Có message nào ĐỦ QUAN TRỌNG để bật lại theo dõi không?
    > Quan trọng = yêu cầu/cam kết/thông tin mới chưa từng xuất hiện trước skip, KHÔNG phải tiếp nối chuyện cũ.
    > Không quan trọng: "cảm ơn", "ok", "đã nhận", reply lịch sự.
    > Đủ quan trọng: điều khoản mới, yêu cầu mới, deadline mới, thay đổi scope.
    >
    > JSON: {"should_unsnooze": bool, "trigger_message_id": "...", "trigger_summary": "...", "reasoning": "..."}
    > ```

    - `should_unsnooze = true` → xoá khỏi `skipped_threads`, đẩy thread vào `threads_with_new_messages`, ghi `unsnoozed_this_run`.
    - `should_unsnooze = false` → cập nhật `skipped_at_message_id` = message mới nhất, bỏ qua.

**Thread KHÔNG có label `Claude/Skip`:**

- Có trong `skipped_threads` → user đã gỡ label → xoá entry, xử lý bình thường.
- Không có trong `skipped_threads` → xử lý bình thường.

---

## Bước 3 — Check done cho pending actions (semantic)

Với mỗi pending action **của thread KHÔNG bị skip**:

1. Lấy thread data (đã cache từ Bước 2 nếu thread có pending).
2. Lấy `new_messages` = message > `trigger_message_id`.

**Không có `new_messages`:**
- Action có `action_type = info` hoặc `external_action` → check label UNREAD của thread.
  - Hết UNREAD → done, xoá khỏi pending.
  - Còn UNREAD → tăng `reminder_count`, giữ pending.
- Action khác (`reply` / `push_member`) → tăng `reminder_count`, giữ pending.

**Có `new_messages`:**

Chạy **semantic done check** — đọc NỘI DUNG, không nhìn ai gửi:

> **Prompt LLM:**
> ```
> Action đang chờ: <action.action_desc>
> Loại: <action.action_type>
> Trigger từ message:
>   Sender: <sender của trigger>
>   Nội dung: <nội dung message tại trigger_message_id>
>
> Message mới trong thread (theo thứ tự thời gian):
> <liệt kê new_messages — sender, timestamp, nội dung đầy đủ>
>
> Câu hỏi: Action trên đã THỰC SỰ HOÀN THÀNH chưa?
>
> Lưu ý:
> - Hoàn thành = nội dung được giao đã được thực hiện. Ví dụ: "gửi báo giá" = báo giá đã được gửi (file đính kèm/nội dung báo giá), KHÔNG phải chỉ ack "sẽ gửi".
> - Auto-reply "out of office" KHÔNG tính là phản hồi.
> - Reply lịch sự "đã nhận, sẽ xem" KHÔNG tính là hoàn thành nếu action yêu cầu output cụ thể.
>
> JSON: {"done": bool, "done_by_message_id": "...", "reasoning": "..."}
> ```

- `done = true` → bỏ khỏi pending.
- `done = false` → tăng `reminder_count`, giữ pending. Cập nhật `content_summary` để phản ánh diễn biến mới (giúp Discord summary cập nhật).

**Sau khi xử lý action của thread:** đẩy `threadId` vào `threads_with_new_messages` để Bước 5 triage lại — bắt action MỚI có thể phát sinh từ message mới (vì 1 message có thể vừa hoàn thành action cũ vừa đẻ action mới).

---

## Bước 4 — Quét Gmail 30 ngày (pagination đầy đủ)

```
all_threads = []
page_token = None
max_pages = 20  # safety cap: 1000 thread

while True:
    result = search_threads(query="in:inbox newer_than:30d -in:draft",
                            pageSize=50, pageToken=page_token)
    all_threads.extend(result.threads)
    page_token = result.nextPageToken
    if not page_token or len(all_threads) >= max_pages * 50:
        break

if len(all_threads) >= max_pages * 50:
    log_warning("Đạt cap 1000 thread")
```

Lọc thread cần triage:

- Thread trong `skipped_threads` → bỏ qua hoàn toàn (Bước 2 đã quyết).
- Thread không trong `processed_threads` → thêm vào `new_threads`.
- Thread trong `processed_threads`:
  - Message mới nhất khác `processed_threads[threadId]` (hoặc value null từ migration) → `new_threads`.
  - Bằng nhau → skip.

`to_triage` = `new_threads` ∪ `threads_with_new_messages` (từ Bước 2 & 3). Loại trùng.

Nếu `to_triage` rỗng và `pending_actions` rỗng và `unsnoozed_this_run` rỗng → gửi "Không có gì mới." → kết thúc.

---

## Bước 5 — Triage (3-tier)

Với mỗi thread trong `to_triage`, output 0/1/nhiều pending action mới.

### Tier 1 — Auto/system, không gọi get_thread

Áp dụng khi TẤT CẢ:
- Sender là auto/system: `no-reply@`, `noreply@`, `notifications@`, `mailer-daemon@`, `alert@`, `donotreply@`, GitHub, Jira, Confluence, HRIS, Google, Microsoft, Slack…
- Subject rõ là thông báo tự động
- Thread chỉ 1 message

→ Classify `external_action` hoặc `info`, `expected_sender_hint = null`. **Không** thêm vào pending. Chỉ cập nhật `processed_threads`.

### Tier 2 — Phân tích snippet

Signal rõ → classify luôn:
- `"[Tên] ơi"`, `"nhờ [Tên]"`, `"@[Tên]"` + chỉ thị rõ cho Michael → `push_member`
- `"sẽ gửi"`, `"will send"`, `"I'll"`, `"we'll"` + cam kết rõ → `push_member`
- Câu hỏi trực tiếp cho Michael, single message từ khách → `reply`
- FYI rõ ràng, không có action → `info`

Escalate Tier 3 khi:
- Snippet bị cắt (`"…"`)
- Sender là `@vti.com.vn`
- Thread có nhiều messages
- Michael ở CC (không phải TO)
- Subject liên quan project/contract/proposal/NDA/sign-off/estimation/QnA
- Không chắc chắn
- Thread đến từ `threads_with_new_messages` (đã có pending hoặc vừa un-snooze)

### Tier 3 — Đọc full thread, identify TẤT CẢ action đang treo

Tái sử dụng thread data cache.

**Quy trình (LLM đọc full thread, trả lời 2 câu hỏi gốc):**

> Đọc toàn bộ thread theo thứ tự thời gian. Trả lời:
>
> 1. **Trong thread này, hiện tại có ai đang chờ ai phản hồi không?** Liệt kê tất cả.
> 2. **Mỗi cặp chờ-phản hồi đó là loại action nào?**
>    - Khách/đối tác chờ Michael trả lời → `reply`
>    - Khách/đối tác chờ VTI member cụ thể (Hùng/Quyen/Kevin...) → `push_member` internal, `expected_sender_hint = email member đó`
>    - VTI member đã gửi outbound, đang chờ khách phản hồi → `push_member` external, `expected_sender_hint = non-vti`
>    - VTI member nội bộ chờ assignment được thực hiện → `push_member` internal
>    - Không ai đang chờ ai, chỉ FYI → `info`
>    - Auto/no-reply, action ngoài hệ thống → `external_action`
>
> **Lưu ý quan trọng:**
> - Michael ở CC KHÔNG có nghĩa là `info`. Phải check loop trao đổi giữa các bên trong thread.
> - Một message ack "sẽ gửi/check" tạo ra cam kết → có thể đẻ thêm action chờ thực hiện cam kết.
> - Một thread có thể có NHIỀU action cùng lúc (ví dụ vừa chờ member gửi báo giá, vừa chờ khách trả lời câu hỏi khác).

**Lọc trùng:** với mỗi action định tạo, check `pending_actions` của thread này. Đã có action tương đương (cùng `action_type` + nội dung tương tự) → bỏ qua.

**Nếu thread trong `unsnoozed_this_run`:** mỗi action mới sinh ra → set `unsnooze_reason = "<trigger_summary> · <reasoning từ Bước 2>"`.

### Priority

🔴 khẩn / 🟡 trong ngày/tuần / 🟢 không gấp

### Mỗi action mới cần có:
- `action_id` (uuid hoặc hash ngắn)
- `trigger_message_id` = message làm phát sinh action
- `flagged_at` = now
- `reminder_count` = 0
- `unsnooze_reason` = null (hoặc string nếu từ un-snooze)
- `content_summary` đầy đủ để hiển thị trên Discord

---

## Bước 6 — Cập nhật state

- `processed_threads`: cập nhật `threadId → message_id_mới_nhất` cho mọi thread đã xử lý. Giới hạn 500.
- `pending_actions` = pending còn lại sau Bước 3 + new_pending từ Bước 5. Giới hạn 50.
- `skipped_threads`: đã cập nhật trong Bước 2.
- `last_run_at`: timestamp hiện tại.

---

## Bước 7 — Gửi Discord bằng curl

**LUÔN dùng curl. KHÔNG dùng Python urllib (bị 403 trong sandbox).**

**TUYỆT ĐỐI KHÔNG gửi bất kỳ message test nào lên Discord** — kể cả dấu chấm, "test", "ok", hay bất kỳ payload nào khác trước khi gửi nội dung thật. KHÔNG có bước kiểm tra kết nối trước. Gửi nội dung thật luôn. Nếu curl trả về lỗi (non-2xx) thì log lỗi và dừng lại.

**Hàm gửi:**

```python
import json, subprocess, tempfile, os

WEBHOOK = "https://discord.com/api/webhooks/1503692385824149544/m4HNatodLO5vekEJOXXdhg_h5SBHruc-ThRHN__LAtXbYQZ_caq02cR582UkQKZ0MlXW"

def send_discord(content):
    payload = json.dumps({"content": content})
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        f.write(payload)
        tmp = f.name
    subprocess.run([
        "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
        "-X", "POST", WEBHOOK,
        "-H", "Content-Type: application/json",
        "--data-binary", f"@{tmp}"
    ], check=True)
    os.unlink(tmp)

def send_long(text):
    MAX = 1900
    lines = text.split("\n")
    chunk = ""
    for line in lines:
        if len(chunk) + len(line) + 1 > MAX:
            send_discord(chunk)
            chunk = ""
        chunk += line + "\n"
    if chunk.strip():
        send_discord(chunk)
```

**Thứ tự nội dung:**

**[1] Header**
```
# MAIL SUMMARY — HH:MM DD/MM/YYYY
Khách hàng: X  |  Nội bộ: X  |  Auto: X  |  Un-snooze: X
```
(Giờ = UTC+7. Hiển thị `Un-snooze: X` chỉ khi X > 0. Counter của Khách hàng/Nội bộ tính TỔNG cả mail mới và pending đang nhắc lại — vì cùng là task cần follow.)

**[2] UN-SNOOZE — Thread đã skip nay có diễn biến mới** (đặt NGAY SAU header nếu có):

```
## 🔄 UN-SNOOZE — THREAD ĐÃ SKIP NAY CÓ DIỄN BIẾN MỚI

> ⚠️ Các thread dưới đây trước đó đã được apply label `Claude/Skip`. Hệ thống phát hiện message mới ĐỦ QUAN TRỌNG nên bật lại theo dõi.
> Nếu vẫn không muốn theo dõi, apply lại label `Claude/Skip` lên thread.

**TÊN CÔNG TY**
🔴 [Tiêu đề](link)  *(đã skip từ DD/MM HH:MM)*
Tên · email · HH:MM
**Lý do un-snooze:** <reasoning từ LLM>
**Nội dung message mới:** <trigger_summary>
**Action [push_member / reply / ...]:** <action mới sinh ra>
```

**[3] Khách hàng** (mọi action liên quan khách/đối tác — mail mới + pending — group theo công ty):
```
## 🏢 KHÁCH HÀNG

**TÊN CÔNG TY**
🔴 [Tiêu đề](link)  *(nhắc lần X — flagged DD/MM HH:MM)*  ← chỉ hiển thị nếu là pending
Tên · email · HH:MM
**Nội dung:** <tóm tắt>
**Action [push_member → Tên (email) / reply / external_action / push_customer → TenVTI (email) push TenKhach (email) / info]:** <cụ thể>

🟡 [Tiêu đề khác](link)
Tên · email · HH:MM
**Nội dung:** <tóm tắt>
**Action [...]:** <cụ thể>
```

**[4] Nội bộ** (action nội bộ VTI — mail mới + pending):
```
## 👥 NỘI BỘ

🔴 [Tiêu đề](link)  *(nhắc lần X — flagged DD/MM HH:MM)*  ← chỉ hiển thị nếu là pending
Tên · email · HH:MM
**Nội dung:** <tóm tắt>
**Action [push_member → Tên (email) / reply / external_action / info]:** <cụ thể>
```

**[5] Hệ thống / Auto** (1 dòng mỗi mail):
```
## 🤖 HỆ THỐNG / AUTO
Tên hệ thống — Mô tả · HH:MM
```

---

### Quy tắc sắp xếp trong mỗi section

**Trong cùng section, sắp xếp theo:**
1. Priority trước: 🔴 → 🟡 → 🟢
2. Cùng priority: pending có `reminder_count` cao nhất trước (action lâu nhất chưa xử lý lên đầu)
3. Cùng reminder_count: mail mới hơn lên trên

**Format `*(nhắc lần X — flagged DD/MM HH:MM)*` chỉ hiện khi `reminder_count > 0`** (pending từ run trước). Mail mới triage ở run hiện tại thì không hiện.

**Phân loại Khách hàng vs Nội bộ:**
- Xác định từ sender hoặc toRecipients của thread.
- Thread có bất kỳ địa chỉ non-VTI nào → Khách hàng (group theo công ty của khách).
- Thread chỉ có `@vti.com.vn` → Nội bộ.

**Trong section Khách hàng — sắp xếp công ty:**
- Công ty có action 🔴 (cao nhất) lên đầu.
- Trong cùng công ty, action sắp theo quy tắc 1-2-3 ở trên.

`Nội dung` MANDATORY — nếu `content_summary` thiếu, gọi `get_thread` lấy lại.
===END===
