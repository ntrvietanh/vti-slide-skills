# Hướng dẫn update rule cho Mail Summary Task

> Tạo bởi scheduled task run — 13/05/2026 08:20 GMT+7
> **Lý do:** Bổ sung rule "VTI gửi khách, chưa có phản hồi → push_member"

## Vấn đề phát hiện

Thread NDA Terrabitnet (`19e16990f37c5130`) không bị flagged vì:
- Kevin (VTI) là người gửi email cuối → hệ thống nghĩ "VTI đã reply rồi, không cần action"
- Không có rule kiểm tra: VTI đã commit gửi tài liệu nhưng khách chưa reply

## Cách cập nhật

**Mở chat mới với Claude (ngoài scheduled task)**, rồi paste nội dung sau:

---

> Cập nhật scheduled task `hourly-mail-summary`, thêm rule mới vào Bước 6 phần `action_type`, SAU đoạn `info`:
>
> ```
> [RULE QUAN TRONG] VTI gui khach, chua co phan hoi — luon la push_member:
> Neu thread thoa man TAT CA:
> 1. Message cuoi trong thread gui TU @vti.com.vn den dia chi NGOAI VTI (khach hang)
> 2. Noi dung: VTI da gui attachment/BQ/NDA/proposal/invoice HOAC commit "will send / please find attached / se gui lai"
> 3. Khach hang CHUA co reply sau message cuoi cua VTI
> 4. Khong phai no-reply/auto
>
> → action_type: push_member
> → pushed_member_email: email nguoi VTI gui cuoi
> → action_desc: "Push [ten] theo doi [cong ty] — da gui [gi] vao [ngay], chua co phan hoi"
> → Priority: 🟡 (< 2 ngay), 🔴 (>= 2 ngay)
> ```

---

## Trạng thái hiện tại

NDA Terrabitnet đã được thêm vào `pending_actions` thủ công và sẽ được nhắc lại trong lần chạy tiếp theo.
