# Un-snooze check — <<RUN_STARTED_AT>>

Each thread below was previously marked `Claude/Skip` by Michael. New messages have arrived since the skip point. Decide whether the new content is **important enough to resume tracking**.

## Rules

- **Important** (un-snooze): new requests, new commitments, new deadlines, new terms, scope changes, escalations.
- **NOT important** (stay skipped): "cảm ơn", "ok", "đã nhận", polite replies, continuation of the same conversation that was already skipped.

---

## Skipped threads with new messages

<<THREADS>>

---

## How to write your decisions

Append all un-snooze decisions to the `unsnooze_decisions` array in `mail_context/decisions.json`:

```json
{
  "unsnooze_decisions": [
    {
      "thread_id": "<thread_id>",
      "should_unsnooze": true | false,
      "trigger_message_id": "<msg_id or null>",
      "trigger_summary": "<one sentence summarizing the new content>",
      "reasoning": "<one sentence why>"
    }
  ]
}
```

Threads to check: **<<COUNT>>**
