# Pending action — done-check queue — <<RUN_STARTED_AT>>

For each pending action below, decide if the action has **ACTUALLY been completed** by the new messages that arrived in its thread.

## Rules

- **Done = the work was actually performed.** Example: "send quote" = the quote was actually sent (attachment / quote body in the message), NOT just an ack like "I'll send it next week".
- **Auto-reply "out of office" does NOT count** as a reply or completion.
- **Polite ack "đã nhận, sẽ xem", "noted, will check"** does NOT complete an action that requires concrete output.
- Read the ACTUAL content, not just who sent it. A message from the expected sender can still fail to complete the action (e.g. they replied but didn't deliver).
- If `done = false`, provide an `updated_content_summary` reflecting the latest state of the thread — this will replace the old summary in the Discord digest.

---

## Pending actions with new messages

<<THREADS>>

---

## How to write your decisions

Append all done-check decisions to the `done_decisions` array in `mail_context/decisions.json`:

```json
{
  "done_decisions": [
    {
      "action_id": "<action_id>",
      "done": true,
      "done_by_message_id": "<msg_id or null>",
      "updated_content_summary": "<new summary if done=false; else empty string>",
      "reasoning": "<one sentence why>"
    }
  ]
}
```

Actions to check: **<<COUNT>>**
