# Cowork Projects

Tập hợp các project được tạo và sử dụng qua Cowork mode (Claude).

## Projects

| Project | Mô tả |
|---|---|
| **Google Chat Crawl** | Tool crawl và tổng hợp dữ liệu từ Google Chat |
| **Mail Summary** | Tool tóm tắt email tự động |
| **Meeting Preparation** | Hỗ trợ chuẩn bị tài liệu họp |
| **Week Summary** | Tổng hợp công việc theo tuần |

## Lưu ý bảo mật

Các file sau đã được đưa vào `.gitignore` và **KHÔNG bao giờ** được commit:

- `credentials.json` — Google OAuth client credentials
- `token.json` — OAuth access/refresh tokens
- `.pkce_verifier` — PKCE OAuth verifier
- `.env*` — biến môi trường

Nếu cần dùng lại trên máy khác, các file credentials phải được tạo mới hoặc copy thủ công (không qua git).

## Cấu trúc

```
Projects/
├── Google Chat Crawl/
├── Mail Summary/
├── Meeting Preparation/
└── Week Summary/
```
